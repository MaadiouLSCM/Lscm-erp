// App.tsx - React Native Mobile App
import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { QueryClientProvider, QueryClient } from '@tanstack/react-query';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuthStore } from './store/authStore';
import 'react-native-gesture-handler';

// Screens
import LoginScreen from './screens/auth/LoginScreen';
import DashboardScreen from './screens/dashboard/DashboardScreen';
import OrdersListScreen from './screens/orders/OrdersListScreen';
import OrderDetailScreen from './screens/orders/OrderDetailScreen';
import TrackingScreen from './screens/tracking/TrackingScreen';
import InvoicesScreen from './screens/invoices/InvoicesScreen';
import DSRScreen from './screens/reports/DSRScreen';
import ProfileScreen from './screens/profile/ProfileScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const queryClient = new QueryClient();

function DashboardStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: '#2563eb' },
        headerTintColor: '#fff',
        headerTitleStyle: { fontWeight: 'bold' },
      }}
    >
      <Stack.Screen 
        name="Dashboard" 
        component={DashboardScreen}
        options={{ title: 'Dashboard' }}
      />
    </Stack.Navigator>
  );
}

function OrdersStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: '#2563eb' },
        headerTintColor: '#fff',
        headerTitleStyle: { fontWeight: 'bold' },
      }}
    >
      <Stack.Screen 
        name="OrdersList" 
        component={OrdersListScreen}
        options={{ title: 'Orders' }}
      />
      <Stack.Screen 
        name="OrderDetail" 
        component={OrderDetailScreen}
        options={{ title: 'Order Details' }}
      />
    </Stack.Navigator>
  );
}

function TrackingStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: '#2563eb' },
        headerTintColor: '#fff',
        headerTitleStyle: { fontWeight: 'bold' },
      }}
    >
      <Stack.Screen 
        name="Tracking" 
        component={TrackingScreen}
        options={{ title: 'Real-Time Tracking' }}
      />
    </Stack.Navigator>
  );
}

function InvoicesStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: '#2563eb' },
        headerTintColor: '#fff',
        headerTitleStyle: { fontWeight: 'bold' },
      }}
    >
      <Stack.Screen 
        name="Invoices" 
        component={InvoicesScreen}
        options={{ title: 'Invoices' }}
      />
    </Stack.Navigator>
  );
}

function ReportsStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: '#2563eb' },
        headerTintColor: '#fff',
        headerTitleStyle: { fontWeight: 'bold' },
      }}
    >
      <Stack.Screen 
        name="DSR" 
        component={DSRScreen}
        options={{ title: 'Daily Reports' }}
      />
    </Stack.Navigator>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: '#2563eb',
        tabBarInactiveTintColor: '#9ca3af',
        tabBarStyle: { backgroundColor: '#f3f4f6', borderTopColor: '#e5e7eb' },
      }}
    >
      <Tab.Screen
        name="DashboardTab"
        component={DashboardStack}
        options={{
          title: 'Dashboard',
          tabBarIcon: ({ color }) => <Icon name="home" color={color} size={24} />,
        }}
      />
      <Tab.Screen
        name="OrdersTab"
        component={OrdersStack}
        options={{
          title: 'Orders',
          tabBarIcon: ({ color }) => <Icon name="box" color={color} size={24} />,
        }}
      />
      <Tab.Screen
        name="TrackingTab"
        component={TrackingStack}
        options={{
          title: 'Tracking',
          tabBarIcon: ({ color }) => <Icon name="map" color={color} size={24} />,
        }}
      />
      <Tab.Screen
        name="InvoicesTab"
        component={InvoicesStack}
        options={{
          title: 'Invoices',
          tabBarIcon: ({ color }) => <Icon name="receipt" color={color} size={24} />,
        }}
      />
      <Tab.Screen
        name="ReportsTab"
        component={ReportsStack}
        options={{
          title: 'Reports',
          tabBarIcon: ({ color }) => <Icon name="bar-chart" color={color} size={24} />,
        }}
      />
      <Tab.Screen
        name="ProfileTab"
        component={ProfileScreen}
        options={{
          title: 'Profile',
          tabBarIcon: ({ color }) => <Icon name="user" color={color} size={24} />,
        }}
      />
    </Tab.Navigator>
  );
}

function AuthStack() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
        animationEnabled: false,
      }}
    >
      <Stack.Screen name="Login" component={LoginScreen} />
    </Stack.Navigator>
  );
}

function RootNavigator() {
  const { user, isLoading, initAuth } = useAuthStore();

  useEffect(() => {
    initAuth();
  }, [initAuth]);

  if (isLoading) {
    return null; // Show splash screen
  }

  return (
    <NavigationContainer>
      {user ? <MainTabs /> : <AuthStack />}
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <RootNavigator />
    </QueryClientProvider>
  );
}

// screens/dashboard/DashboardScreen.tsx
import React from 'react';
import { View, ScrollView, StyleSheet, Text, RefreshControl } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { getDashboardStats } from '@/services/api';
import DashboardCard from '@/components/DashboardCard';
import OrdersChart from '@/components/OrdersChart';

export default function DashboardScreen() {
  const { data: stats, isLoading, refetch } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: getDashboardStats,
    refetchInterval: 60000,
  });

  const [refreshing, setRefreshing] = React.useState(false);

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    refetch().then(() => setRefreshing(false));
  }, [refetch]);

  return (
    <ScrollView
      style={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
    >
      <View style={styles.header}>
        <Text style={styles.title}>Dashboard</Text>
        <Text style={styles.subtitle}>Welcome back to LSCM ERP</Text>
      </View>

      <View style={styles.cardsContainer}>
        <DashboardCard
          title="Active Orders"
          value={stats?.activeOrders || 0}
          icon="📦"
          trend={stats?.ordersTrend}
        />
        <DashboardCard
          title="In Transit"
          value={stats?.inTransit || 0}
          icon="✈️"
          trend={stats?.transitTrend}
        />
        <DashboardCard
          title="On-Time Rate"
          value={`${stats?.onTimeRate || 0}%`}
          icon="✅"
        />
        <DashboardCard
          title="Monthly Revenue"
          value={`$${(stats?.monthlyRevenue || 0).toLocaleString()}`}
          icon="💰"
        />
      </View>

      {stats && <OrdersChart data={stats.ordersByStatus} />}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1f2937',
  },
  subtitle: {
    fontSize: 14,
    color: '#6b7280',
    marginTop: 4,
  },
  cardsContainer: {
    paddingHorizontal: 16,
    gap: 12,
  },
});

// screens/orders/OrdersListScreen.tsx
import React, { useState } from 'react';
import { View, StyleSheet, FlatList, TouchableOpacity, Text } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { listOrders } from '@/services/api';
import OrderCard from '@/components/OrderCard';
import SearchBar from '@/components/SearchBar';

export default function OrdersListScreen({ navigation }: any) {
  const [filters, setFilters] = useState({
    status: '',
    page: 0,
    limit: 20,
  });

  const { data: ordersData, isLoading } = useQuery({
    queryKey: ['orders', filters],
    queryFn: () => listOrders(filters),
  });

  const handleOrderPress = (orderId: string) => {
    navigation.navigate('OrderDetail', { id: orderId });
  };

  return (
    <View style={styles.container}>
      <SearchBar
        placeholder="Search orders..."
        onSearch={(text) => setFilters({ ...filters, search: text })}
      />

      {isLoading ? (
        <Text style={styles.loadingText}>Loading orders...</Text>
      ) : (
        <FlatList
          data={ordersData?.data || []}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => handleOrderPress(item.id)}>
              <OrderCard order={item} />
            </TouchableOpacity>
          )}
          contentContainerStyle={styles.listContent}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  listContent: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 12,
  },
  loadingText: {
    textAlign: 'center',
    marginTop: 20,
    fontSize: 16,
    color: '#6b7280',
  },
});

// screens/orders/OrderDetailScreen.tsx
import React from 'react';
import { View, ScrollView, StyleSheet, Text, ActivityIndicator } from 'react-native';
import { useQuery } from '@tanstack/react-query';
import { getOrder, getOrderTimeline, calculateKPIs } from '@/services/api';
import OrderInfoCard from '@/components/OrderInfoCard';
import TimelineView from '@/components/TimelineView';
import KPICards from '@/components/KPICards';

export default function OrderDetailScreen({ route }: any) {
  const { id } = route.params;

  const { data: order, isLoading: orderLoading } = useQuery({
    queryKey: ['order', id],
    queryFn: () => getOrder(id),
  });

  const { data: timeline } = useQuery({
    queryKey: ['timeline', id],
    queryFn: () => getOrderTimeline(id),
  });

  const { data: kpis } = useQuery({
    queryKey: ['kpis', id],
    queryFn: () => calculateKPIs(id),
  });

  if (orderLoading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#2563eb" />
      </View>
    );
  }

  if (!order) {
    return (
      <View style={styles.centerContainer}>
        <Text style={styles.errorText}>Order not found</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <OrderInfoCard order={order} />
      <KPICards kpis={kpis} />
      <TimelineView timeline={timeline} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    fontSize: 16,
    color: '#ef4444',
  },
});

// screens/tracking/TrackingScreen.tsx
import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import { useQuery } from '@tanstack/react-query';
import { fetchTracking } from '@/services/api';
import TrackingSearch from '@/components/TrackingSearch';
import TrackingInfo from '@/components/TrackingInfo';

export default function TrackingScreen() {
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  const { data: tracking } = useQuery({
    queryKey: ['tracking', selectedOrderId],
    queryFn: () => selectedOrderId ? fetchTracking(selectedOrderId) : null,
    enabled: !!selectedOrderId,
  });

  return (
    <View style={styles.container}>
      <TrackingSearch onSelectOrder={setSelectedOrderId} />

      {tracking && (
        <>
          <MapView
            style={styles.map}
            initialRegion={{
              latitude: tracking.segments[0]?.lat || 0,
              longitude: tracking.segments[0]?.lng || 0,
              latitudeDelta: 20,
              longitudeDelta: 20,
            }}
          >
            {tracking.segments.map((segment: any, idx: number) => (
              <Marker
                key={idx}
                coordinate={{ latitude: segment.lat, longitude: segment.lng }}
                title={segment.location}
              />
            ))}
            {tracking.segments.length > 1 && (
              <Polyline
                coordinates={tracking.segments.map((s: any) => ({
                  latitude: s.lat,
                  longitude: s.lng,
                }))}
                strokeColor="#2563eb"
                strokeWidth={2}
              />
            )}
          </MapView>

          <TrackingInfo tracking={tracking} />
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
});

// store/authStore.ts
import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { authAPI } from '@/services/api';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
}

interface AuthStore {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  initAuth: () => Promise<void>;
}

export const useAuthStore = create<AuthStore>((set) => ({
  user: null,
  token: null,
  isLoading: true,

  login: async (email: string, password: string) => {
    try {
      const { accessToken, user } = await authAPI.login(email, password);
      await AsyncStorage.setItem('token', accessToken);
      set({ user, token: accessToken });
    } catch (error) {
      throw error;
    }
  },

  logout: async () => {
    await AsyncStorage.removeItem('token');
    set({ user: null, token: null });
  },

  initAuth: async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      if (token) {
        set({ token });
        const user = await authAPI.getCurrentUser();
        set({ user, isLoading: false });
      } else {
        set({ isLoading: false });
      }
    } catch {
      await AsyncStorage.removeItem('token');
      set({ isLoading: false });
    }
  },
}));

// services/api.ts
import axios from 'axios';
import { useAuthStore } from '@/store/authStore';

const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api/v1';

const apiClient = axios.create({ baseURL: BASE_URL });

apiClient.interceptors.request.use((config) => {
  const { token } = useAuthStore.getState();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const authAPI = {
  login: async (email: string, password: string) => {
    const { data } = await apiClient.post('/auth/login', { email, password });
    return data;
  },
  getCurrentUser: async () => {
    const { data } = await apiClient.get('/auth/me');
    return data;
  },
};

export const getDashboardStats = async () => {
  const { data } = await apiClient.get('/dashboard/stats');
  return data;
};

export const listOrders = async (filters?: any) => {
  const { data } = await apiClient.get('/orders', { params: filters });
  return data;
};

export const getOrder = async (id: string) => {
  const { data } = await apiClient.get(`/orders/${id}`);
  return data;
};

export const getOrderTimeline = async (id: string) => {
  const { data } = await apiClient.get(`/orders/${id}/timeline`);
  return data;
};

export const calculateKPIs = async (id: string) => {
  const { data } = await apiClient.get(`/orders/${id}/kpis`);
  return data;
};

export const fetchTracking = async (orderId: string) => {
  const { data } = await apiClient.get(`/tracking/${orderId}`);
  return data;
};

export const listInvoices = async () => {
  const { data } = await apiClient.get('/invoices');
  return data;
};
