# REQUEST FOR COLLECTION (RFC)
## Template Officiel LSCM v5.0

---

## 📋 RFC - DEMANDE DE COLLECTE

**Reference:** RFC-TEPNG-250215-001  
**Date:** 15 Feb 2025  
**Version:** 1.0  
**Client:** SNEPCO (Shell Nigeria Exploration & Production)

---

## 1. JOB IDENTIFICATION

| Field | Value | Source |
|-------|-------|--------|
| **Order Reference** | TEPNG-250215-001 | ERP (Auto-generated) |
| **PO Number** | 4560168494 | Client (Manual) |
| **Incoterm** | FCA (Free Carrier) | Client (Manual) |
| **Transport Mode** | SEA | Client (Manual) |
| **Job Type** | Export | ERP (Derived from scope) |

---

## 2. SUPPLIER / OEM DETAILS (PICKUP LOCATION)

```
┌─────────────────────────────────────────┐
│ SUPPLIER INFORMATION                    │
├─────────────────────────────────────────┤
│                                         │
│ Company Name: ZEZ LIMITED               │
│ Address: Unit 15, Belle Borne Zone      │
│          Cargo 7, BT 3457               │
│          93290 Tremblay-en-France       │
│          FRANCE                         │
│                                         │
│ Contact Person: [Name - from RFC form] │
│ Phone: [Number]                        │
│ Email: [Email]                         │
│                                         │
│ Business Hours: [Specify]              │
│ Special Access Requirements: None       │
│                                         │
│ LSCM Account Manager: John Coordinator │
│ Phone: +221 77 123 4567                │
│                                         │
└─────────────────────────────────────────┘
```

**Notes:**
- Confirm supplier has material ready ✓
- Supplier to affix Shipping Marks BEFORE pickup (preferred)
- If not able → LSCM will affix upon receipt

---

## 3. PACKING & ITEMS LIST

### 3.1 Packing Information

| Item | Details |
|------|---------|
| **Casing Type** | Box |
| **Number of Packages** | 3 |
| **Total Gross Weight** | 32 kg |
| **Total Volume** | 0.0172 m³ |
| **Dimensions (L×W×H)** | [From PL] |
| **Palletized** | No |
| **Special Packaging** | None |

### 3.2 Items List

```
┌─────────────────────────────────────────────────────────────┐
│ ITEM DETAILS                                                │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ ITEM 1:                                                     │
│ ├─ Material: Diffuseur gaz Mega4 - 10u                     │
│ ├─ PO Item #: 10752691                                     │
│ ├─ Quantity: 1                                             │
│ ├─ Unit: Box                                               │
│ ├─ Weight: 10 kg                                           │
│ ├─ HS Code: 84030000                                       │
│ ├─ Unit Price: $50,000                                     │
│ └─ Total Value: $50,000                                    │
│                                                             │
│ ITEM 2:                                                     │
│ ├─ Material: Tube contact O 1.2 Mega 4 - 20u              │
│ ├─ PO Item #: 20752694                                     │
│ ├─ Quantity: 1                                             │
│ ├─ Unit: Box                                               │
│ ├─ Weight: 12 kg                                           │
│ ├─ HS Code: 84030000                                       │
│ ├─ Unit Price: $50,000                                     │
│ └─ Total Value: $50,000                                    │
│                                                             │
│ ITEM 3:                                                     │
│ ├─ Material: Buse D 16 Mega 4-Sachet 10u                  │
│ ├─ PO Item #: 30752699                                     │
│ ├─ Quantity: 1                                             │
│ ├─ Unit: Box                                               │
│ ├─ Weight: 10 kg                                           │
│ ├─ HS Code: 84030000                                       │
│ ├─ Unit Price: $50,000                                     │
│ └─ Total Value: $50,000                                    │
│                                                             │
│ ═══════════════════════════════════════════════════════    │
│ TOTAL ITEMS: 3 | TOTAL WEIGHT: 32 kg | TOTAL VALUE: $150K │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 4. PICKUP DETAILS

### 4.1 Pickup Schedule

| Element | Details |
|---------|---------|
| **Preferred Pickup Date** | 17 Feb 2025 |
| **Preferred Pickup Time** | 10:00 - 12:00 UTC |
| **Latest Pickup Date** | 18 Feb 2025 |
| **Pickup Address** | ZEZ LIMITED (as above) |
| **Contact for Pickup** | [Supplier contact] |

### 4.2 Pickup Method

```
☑ Ground Transportation
└─ Via: Local pickup agent (to be confirmed)

☐ Courier (FedEx/UPS/DHL)
☐ Supplier arranges (LCL/FCL consolidation)
```

### 4.3 Proof of Collection Requirements

```
┌────────────────────────────────────────┐
│ MANDATORY AT PICKUP                    │
├────────────────────────────────────────┤
│                                        │
│ ☑ Shipping Marks affixed or ready     │
│   (See SM template below)              │
│                                        │
│ ☑ POC Photos (minimum 2 per package)  │
│   ├─ External condition (all angles)   │
│   ├─ Shipping mark visible             │
│   ├─ Package contents visible (if open)│
│   └─ Timestamped & geotagged          │
│                                        │
│ ☑ Signed Proof of Collection (POC)    │
│   ├─ Supplier signature OR             │
│   ├─ Pickup agent signature (if agent) │
│   └─ Date & time                      │
│                                        │
│ ☑ Waybill/Receipt from supplier       │
│                                        │
│ ☑ Weight & dimensions verification    │
│                                        │
└────────────────────────────────────────┘
```

---

## 5. DOCUMENTATION AT PICKUP

```
┌────────────────────────────────────────────────┐
│ DOCUMENTS TO COLLECT FROM SUPPLIER             │
├────────────────────────────────────────────────┤
│                                                │
│ CRITICAL (Must have BEFORE pickup):            │
│ ☑ Commercial Invoice (CI)                      │
│   - Issued by: ZEZ LIMITED                     │
│   - Includes: Items, quantities, prices, dates │
│   - Status: ✓ Provided                         │
│                                                │
│ ☑ Packing List (PL)                            │
│   - Itemized list with weights & dimensions   │
│   - Status: ✓ Provided                         │
│                                                │
│ ☑ Certificate of Value & Origin (CCVO)        │
│   - Proof of origin: FRANCE                    │
│   - Value confirmation: $150,000               │
│   - Status: ✓ Provided                         │
│                                                │
│ SUPPORTING (As needed):                        │
│ ☐ MSDS (Material Safety Data Sheets)           │
│   ├─ Required: [DG declaration if applicable]  │
│   ├─ If YES: Obtain BEFORE pickup              │
│   └─ If NO: Not applicable                     │
│                                                │
│ ☐ Certificates (Health, Quality, etc)         │
│   ├─ SONCAP: [If regulated goods]              │
│   ├─ ISO: [If certified]                       │
│   └─ Other: [As applicable]                    │
│                                                │
│ ☐ Purchase Order (PO)                          │
│   - Reference: 4560168494                      │
│   - Status: ✓ Provided by client               │
│                                                │
│ ☐ Pro-Forma Invoice (PFI)                      │
│   - LSCM's quote for services                  │
│   - Status: ✓ Approved by client               │
│                                                │
└────────────────────────────────────────────────┘
```

---

## 6. STORAGE & HANDLING

### 6.1 Special Requirements

```
☐ Special Storage Conditions: NONE
  └─ Standard warehouse storage

☐ Fragile/Breakable Goods: NO
  └─ Standard handling

☐ Dangerous Goods: NO
  └─ Standard transportation

☐ Temperature Control: NO
  └─ Ambient temperature acceptable

☐ Inspection Required: NO
  └─ Visual inspection only
```

### 6.2 Handling Instructions

```
PICKUP INSTRUCTIONS:

1. VERIFY MATERIALS
   ☐ Count all packages (must be 3)
   ☐ Check for visible damage
   ☐ Verify weight (should be ~32 kg total)
   ☐ Cross-check items with PL

2. AFFIX SHIPPING MARKS (if not done by supplier)
   ☐ Apply SM labels to all 3 packages
   ☐ Ensure "From" and "To" clearly visible
   ☐ Check barcodes are not damaged
   ☐ Photograph after affixing

3. PHOTOGRAPH PACKAGES
   ☐ 2 photos minimum per package
   ☐ Show external condition (all sides)
   ☐ Show shipping mark clearly
   ☐ Include timestamp in photo metadata
   ☐ Geo-tag location

4. COMPLETE POC FORM
   ☐ Signature from supplier or agent
   ☐ Date and time of pickup
   ☐ Signature from LSCM coordinator
   ☐ Attach all photos

5. COLLECT DOCUMENTS
   ☐ Obtain original CI from supplier
   ☐ Obtain original PL from supplier
   ☐ Obtain CCVO if available
   ☐ Obtain any certificates (SONCAP, etc)
```

---

## 7. INCOTERMS & RESPONSIBILITIES

### 7.1 FCA - Free Carrier

```
INCOTERM: FCA (Free Carrier)

Responsibilities:
├─ SUPPLIER (until pickup):
│  ├─ Prepare goods for shipment
│  ├─ Arrange packaging & SM
│  ├─ Provide documents (CI, PL, CCVO)
│  ├─ Make goods available at pickup location
│  ├─ Cover cost until pickup
│  └─ Handle until LSCM takes possession
│
└─ LSCM (from pickup onwards):
   ├─ Arrange transportation
   ├─ Handle export customs
   ├─ Arrange ocean freight
   ├─ Handle import customs (if scope = X+M)
   ├─ Arrange final delivery
   └─ Cover all costs from pickup to delivery
```

---

## 8. APPROVAL & SIGN-OFF

### 8.1 Request Approval

```
PREPARED BY:
Name: [ERP System / Coordinator]
Date: 15 Feb 2025
Signature: [Digital]

REVIEWED BY:
Name: [Operations Manager]
Date: [Date]
Status: ☑ APPROVED

SUPPLIER ACKNOWLEDGMENT:
Company: ZEZ LIMITED
Contact: [Name]
Received: [Date]
Confirmed Ready: ☑ YES
Signature: [Digital]
```

### 8.2 Conditions d'Acceptation

```
This RFC is VALID until: 18 Feb 2025

If supplier cannot meet pickup deadline:
1. Notify LSCM IMMEDIATELY
2. Propose alternative date
3. Management will assess feasibility
4. If not feasible → Job cancelled

CRITICAL: No pickup after 18 Feb without
prior written approval from LSCM management.
```

---

## 9. ATTACHED DOCUMENTS

```
Supporting Documentation:
├─ ✓ Commercial Invoice (CI_SNEPCO_250215.pdf)
├─ ✓ Packing List (PL_ZEZ_250215.pdf)
├─ ✓ CCVO (CCVO_France_250215.pdf)
├─ ✓ Purchase Order (PO_4560168494.pdf)
├─ ✓ PFI Approved (PFI_SNEPCO_250215_APPROVED.pdf)
├─ ✓ Job Execution Plan (JEP_TEPNG_250215_001.pdf)
└─ ✓ Shipping Marks (SM_TEPNG_250215_001.pdf)
```

---

## 10. SPECIAL NOTES

```
IMPORTANT REMINDERS:

1. Shipping Marks MUST show:
   ✓ From: ZEZ LIMITED, Unit 15, 93290 Tremblay-en-France
   ✓ To: SNEPCO, Nigeria (final destination)
   ✓ Reference: TEPNG-250215-001
   ✓ PO Number: 4560168494
   ✓ QR Code (auto-generated by ERP)

2. Pickup Timing:
   ✓ Early window: 17 Feb (preferred)
   ✓ Last date: 18 Feb 2025
   ✓ After 18 Feb → Requires special approval

3. Documentation Completeness:
   ✓ All documents MUST be with courier for:
     - Commercial Invoice
     - Packing List
     - CCVO
     - Any certificates

4. POC / Photos:
   ✓ POC cannot be issued without minimum 2 photos
     per package showing external condition
   ✓ Photos must be timestamped & geotagged
   ✓ If photos missing → Pickup agent must redo

5. Any Issues During Pickup:
   ✓ Contact immediately: [LSCM emergency number]
   ✓ Do not leave location without resolution
   ✓ Await instructions from coordinator
```

---

## DOCUMENT FOOTER

```
LSCM LOGISTICS AND SUPPLY CHAIN MANAGEMENT
19 Benghazi Street, Wuse Zone 4, Abuja, Nigeria
Phone: +234 (0) 703 944 7777
Email: operations@lscmltd.com
Website: www.lscmltd.com

RFC Version: 5.0
Date Generated: 15 Feb 2025
Reference: RFC-TEPNG-250215-001
Status: ACTIVE - Ready for execution

⚠️ This is an official LSCM document.
Unauthorized reproduction or modification is prohibited.
```

---

## ERP INTEGRATION NOTES

```
AUTO-POPULATED FIELDS (from Order):
├─ Order Reference (TEPNG-250215-001)
├─ Client (SNEPCO)
├─ PO Number (4560168494)
├─ Supplier (ZEZ LIMITED)
├─ Items list (from Order Items)
├─ Weights (from Order)
├─ Incoterm (FCA)
├─ Transport Mode (SEA)
└─ Job Type (Export)

MANUAL FIELDS (from Coordinator):
├─ Pickup date preference
├─ Pickup time window
├─ Special handling instructions
├─ Contact person at supplier
├─ Any special notes/requirements

SYSTEM ACTIONS:
├─ Generate RFC PDF
├─ Send to supplier via email
├─ Create task: "Confirm pickup readiness" (48h before)
├─ Create task: "Collect documents"
├─ Create task: "Verify POC photos"
└─ Auto-transition to next phase on completion
```

---

**RFC Template COMPLETE** ✅

**Next: JEP & SM templates coming...**
