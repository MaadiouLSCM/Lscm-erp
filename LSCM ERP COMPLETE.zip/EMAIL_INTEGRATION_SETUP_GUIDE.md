# 📧 EMAIL INTEGRATION - COMPLETE SETUP GUIDE
## LSCM ERP Email System with Gmail, Outlook, SendGrid

═══════════════════════════════════════════════════════════════════════════════
## WHAT'S NOW INTEGRATED
═══════════════════════════════════════════════════════════════════════════════

### ✅ Task Manager + Email
```
Task assigned → Email sent to assignee
Task reminder → 24h before due date
Task completed → Notification to stakeholders
Task escalation → If overdue
```

### ✅ Orders + Email
```
Order created → Confirmation email
Order status change → Real-time notification
Order delivered → Proof of delivery email
Order cancelled → Notification + reason
```

### ✅ Invoices + Email
```
Invoice generated → Sent to buyer
Invoice sent → Payment reminder
Payment overdue → Auto-reminder every 7 days
Payment received → Confirmation + receipt
```

### ✅ Daily Status Reports (DSR)
```
Auto-generated every day at 17:00 UTC
Sent to all coordinators
Includes: orders created, delivered, revenue, KPIs
Directly from email
```

### ✅ Loading Plans + Email
```
Plan generated → Notification with scores
Plan optimization ready → Suggestion email
Ready to load → Notification to warehouse
```

### ✅ Green Light 3-Party Gate + Email
```
Awaiting CLIENT approval → Email to client
Awaiting CUSTOMS_BROKER approval → Email to broker
Awaiting CARRIER approval → Email to carrier
All approved → Confirmation to all parties
```

### ✅ Gmail Integration
```
Create tasks from Gmail (TASK: Task Name / DESC: ... / DUE: ... / PRIORITY: ...)
Sync inbox with ERP
Auto-create orders from supplier emails
Reply-tracking for status updates
```

### ✅ Outlook Integration
```
Calendar sync (tasks ↔ calendar)
Send emails from Outlook
Access files from OneDrive
Teams integration for notifications
```

═══════════════════════════════════════════════════════════════════════════════
## SETUP OPTIONS (Choose ONE)
═══════════════════════════════════════════════════════════════════════════════

### OPTION 1: SendGrid (Recommended - Easiest)
Best for: Production, High volume

```bash
# 1. Create SendGrid account
# Go to: https://sendgrid.com
# Sign up (free account gets 100 emails/day)

# 2. Create API Key
# Settings → API Keys → Create API Key
# Name: LSCM-ERP
# Permissions: Full Access
# Copy the key

# 3. Add to .env
export SENDGRID_API_KEY="SG.xxxxxxxxxxxxx"
export EMAIL_FROM="noreply@lscmltd.com"
export EMAIL_PROVIDER="SENDGRID"
```

**Cost:** $20/month (10,000 emails)

---

### OPTION 2: Gmail (Best Integration)
Best for: Gmail users, Calendar sync, conversation threading

```bash
# 1. Create Google Cloud Project
# Go to: https://console.cloud.google.com
# Create New Project → LSCM ERP

# 2. Enable Gmail API
# APIs & Services → Enable APIs
# Search "Gmail API" → Enable

# 3. Create OAuth 2.0 Credentials
# Credentials → Create Credentials → OAuth 2.0 Client ID
# Application type: Web application
# Authorized redirect URIs: http://localhost:3000/auth/gmail/callback
# Download JSON file

# 4. Add to .env
export GMAIL_CLIENT_ID="xxxxx.apps.googleusercontent.com"
export GMAIL_CLIENT_SECRET="GOCSPX-xxxxx"
export GMAIL_REDIRECT_URL="http://localhost:3000/auth/gmail/callback"
export EMAIL_PROVIDER="GMAIL"

# 5. In app, add Gmail login button
# User clicks "Connect Gmail"
# Authorizes app to send/read emails
```

**Cost:** Free (Google Cloud gives $300 credit)

---

### OPTION 3: Outlook (Enterprise Integration)
Best for: Microsoft shops, Calendar + Teams

```bash
# 1. Create Azure App
# Go to: https://portal.azure.com
# Create → App Registration → LSCM ERP

# 2. Add Credentials
# Certificates & secrets → New client secret
# Copy the secret value

# 3. Configure Permissions
# API permissions → Add permission
# Microsoft Graph:
#   - Mail.Send
#   - Mail.Read
#   - Calendars.ReadWrite

# 4. Add to .env
export OUTLOOK_CLIENT_ID="xxxxx"
export OUTLOOK_CLIENT_SECRET="xxxxx"
export OUTLOOK_TENANT_ID="xxxxx"
export EMAIL_PROVIDER="OUTLOOK"
```

**Cost:** Free (or $6/user if using Microsoft 365)

---

### OPTION 4: SMTP (Self-Hosted)
Best for: Complete control, Custom domains

```bash
# Use any SMTP provider:
# - AWS SES
# - MailGun
# - Postmark
# - Your own mail server

export SMTP_HOST="smtp.gmail.com"
export SMTP_PORT="587"
export SMTP_USER="your-email@gmail.com"
export SMTP_PASSWORD="your-app-password"
export SMTP_SECURE="true"
export EMAIL_PROVIDER="SMTP"
```

**Cost:** $0-50/month (depends on provider)

═══════════════════════════════════════════════════════════════════════════════
## COMPLETE .ENV CONFIGURATION
═══════════════════════════════════════════════════════════════════════════════

```bash
# ============================================================
# EMAIL CONFIGURATION
# ============================================================

# Provider choice: SENDGRID | GMAIL | OUTLOOK | SMTP
EMAIL_PROVIDER=SENDGRID

# From email address
EMAIL_FROM=noreply@lscmltd.com
EMAIL_FROM_NAME=LSCM ERP

# Frontend/Dashboard URL (for email links)
FRONTEND_URL=http://localhost:3001
DASHBOARD_URL=http://localhost:3001/dashboard

# ============================================================
# SENDGRID (if using SendGrid)
# ============================================================

SENDGRID_API_KEY=SG.xxxxxxxxxxxxx
SENDGRID_FROM_EMAIL=noreply@lscmltd.com

# ============================================================
# GMAIL (if using Gmail)
# ============================================================

GMAIL_CLIENT_ID=xxxxx.apps.googleusercontent.com
GMAIL_CLIENT_SECRET=GOCSPX-xxxxx
GMAIL_REDIRECT_URL=http://localhost:3000/auth/gmail/callback

# ============================================================
# OUTLOOK (if using Outlook/Azure)
# ============================================================

OUTLOOK_CLIENT_ID=xxxxx
OUTLOOK_CLIENT_SECRET=xxxxx
OUTLOOK_TENANT_ID=common

# ============================================================
# SMTP (if using SMTP)
# ============================================================

SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=true
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password

# ============================================================
# EMAIL NOTIFICATION PREFERENCES
# ============================================================

# Send emails for order events?
EMAIL_ON_ORDER_CREATED=true
EMAIL_ON_ORDER_STATUS_CHANGE=true
EMAIL_ON_ORDER_DELIVERED=true

# Send emails for task events?
EMAIL_ON_TASK_ASSIGNED=true
EMAIL_ON_TASK_REMINDER=true
EMAIL_ON_TASK_OVERDUE=true

# Send emails for invoice events?
EMAIL_ON_INVOICE_GENERATED=true
EMAIL_ON_INVOICE_SENT=true
EMAIL_ON_PAYMENT_OVERDUE=true

# Auto-send DSR (Daily Status Report)?
SEND_DSR_ENABLED=true
SEND_DSR_TIME=17:00  # UTC
SEND_DSR_TO_USERS=COORDINATOR,MANAGER,ADMIN

# Auto-send payment reminders?
SEND_PAYMENT_REMINDERS=true
PAYMENT_REMINDER_DAYS=7  # Send reminder 7 days after due date

# ============================================================
# GMAIL INTEGRATION OPTIONS
# ============================================================

GMAIL_SYNC_INBOX=true
GMAIL_SYNC_INTERVAL=30  # Minutes
GMAIL_AUTO_CREATE_TASKS=true
GMAIL_AUTO_CREATE_ORDERS=true

# ============================================================
# OUTLOOK INTEGRATION OPTIONS
# ============================================================

OUTLOOK_SYNC_CALENDAR=true
OUTLOOK_SYNC_CONTACTS=true
OUTLOOK_SEND_AS_USER=true

# ============================================================
# EMAIL TEMPLATES
# ============================================================

# Use custom email templates?
CUSTOM_EMAIL_TEMPLATES_ENABLED=false
CUSTOM_EMAIL_TEMPLATES_PATH=/app/email-templates

# Include company logo in emails?
EMAIL_INCLUDE_LOGO=true
EMAIL_LOGO_URL=https://lscmltd.com/logo.png

# Email styling
EMAIL_BRAND_COLOR=#1A5F99
EMAIL_ACCENT_COLOR=#FF6B35
```

═══════════════════════════════════════════════════════════════════════════════
## IMPLEMENTATION STEPS
═══════════════════════════════════════════════════════════════════════════════

### Step 1: Install dependencies

```bash
npm install nodemailer @sendgrid/mail googleapis @microsoft/microsoft-graph-client
npm install --save-dev @types/nodemailer
```

### Step 2: Copy email service to your project

```bash
cp email_integration_complete.ts src/email/email.service.ts
```

### Step 3: Update your app.module.ts

```typescript
import { EmailModule } from './email/email.module';
import { ScheduleModule } from '@nestjs/schedule';

@Module({
  imports: [
    ScheduleModule.forRoot(),  // For scheduled tasks
    EmailModule,                // Email integration
    // ... other modules
  ],
})
export class AppModule {}
```

### Step 4: Create database migration

```bash
# Add to prisma/schema.prisma:

model EmailNotification {
  id        String   @id @default(cuid())
  recipientEmail String
  recipientName  String?
  subject   String
  template  String
  data      Json
  provider  String   // SENDGRID, GMAIL, OUTLOOK, SMTP
  status    String   // PENDING, SENT, FAILED
  sentAt    DateTime?
  failureReason String?
  createdAt DateTime @default(now())
}

model EmailTemplate {
  id        String   @id @default(cuid())
  name      String   @unique
  subject   String
  htmlTemplate String @db.Text
  textTemplate String @db.Text
  variables String[] // ["userName", "taskName"]
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

# Run migration
npx prisma migrate dev --name add-email-support
```

### Step 5: Seed email templates

```bash
# Create: prisma/seed-emails.ts

import { PrismaClient } from '@prisma/client';
import { EMAIL_TEMPLATES } from '../src/email/email.service';

const prisma = new PrismaClient();

async function main() {
  for (const [key, template] of Object.entries(EMAIL_TEMPLATES)) {
    await prisma.emailTemplate.create({
      data: {
        name: template.name,
        subject: template.subject,
        htmlTemplate: template.html,
        textTemplate: template.text,
      },
    });
  }
  console.log('✅ Email templates seeded');
}

main()
  .catch((e) => console.error(e))
  .finally(() => prisma.$disconnect());

# Run:
npx ts-node prisma/seed-emails.ts
```

### Step 6: Update your controllers

```typescript
import { EmailService } from './email/email.service';
import { OrderEmailService } from './email/email.service';

@Injectable()
export class OrderService {
  constructor(
    private emailService: EmailService,
    private orderEmailService: OrderEmailService,
    private prisma: PrismaService,
  ) {}

  async createOrder(data: CreateOrderDto): Promise<Order> {
    const order = await this.prisma.shipmentOrder.create({ data });

    // Send notification email
    await this.orderEmailService.notifyOrderCreated(order.id);

    return order;
  }
}
```

═══════════════════════════════════════════════════════════════════════════════
## EMAIL TEMPLATES - EXAMPLES
═══════════════════════════════════════════════════════════════════════════════

### Custom Template Example: Order Status

```html
<!-- emails/order-status.html -->

<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; color: #333; }
    .header { background: #1A5F99; color: white; padding: 20px; }
    .content { padding: 20px; }
    .status-box { 
      background: #f0f0f0; 
      border-left: 4px solid #FF6B35; 
      padding: 15px; 
      margin: 10px 0;
    }
    .button { 
      display: inline-block; 
      background: #1A5F99; 
      color: white; 
      padding: 10px 20px; 
      text-decoration: none; 
      border-radius: 5px; 
    }
  </style>
</head>
<body>
  <div class="header">
    <h2>Order Status Update</h2>
  </div>
  <div class="content">
    <p>Hi {{buyerName}},</p>
    
    <p>Your order <strong>{{orderReference}}</strong> status has changed to <strong>{{status}}</strong>.</p>
    
    <div class="status-box">
      <p><strong>Order Details:</strong></p>
      <ul>
        <li>Reference: {{orderReference}}</li>
        <li>Supplier: {{supplierName}}</li>
        <li>Commodity: {{commodityDescription}}</li>
        <li>Quantity: {{quantity}} units</li>
        <li>Current Status: {{status}}</li>
        <li>Last Update: {{lastUpdate}}</li>
      </ul>
    </div>
    
    {{#if estimatedDelivery}}
    <p>Estimated delivery: <strong>{{estimatedDelivery}}</strong></p>
    {{/if}}
    
    <p>
      <a href="{{dashboardUrl}}" class="button">View Order in Dashboard</a>
    </p>
    
    <p>If you have any questions, reply to this email.</p>
    
    <p>Best regards,<br/>
    LSCM ERP System</p>
  </div>
</body>
</html>
```

### Create custom templates programmatically

```typescript
// In your setup/seed script:

await emailService.createTemplate(
  'order-status',
  'Order {{orderReference}} Status: {{status}}',
  fs.readFileSync('emails/order-status.html', 'utf-8'),
  'Order {{orderReference}} is now {{status}}'
);
```

═══════════════════════════════════════════════════════════════════════════════
## API ENDPOINTS (NEW)
═══════════════════════════════════════════════════════════════════════════════

### Send manual email

```bash
POST /api/v1/email/send

{
  "to": "buyer@example.com",
  "subject": "Test Email",
  "template": "order-created",
  "data": {
    "buyerName": "John Doe",
    "orderReference": "ORD-2025-001",
    "supplierName": "SNIM"
  },
  "provider": "SENDGRID"
}

Response:
{
  "id": "email-123",
  "status": "SENT",
  "sentAt": "2025-03-06T10:30:00Z"
}
```

### Get email history

```bash
GET /api/v1/email/history

Response:
{
  "total": 1250,
  "sent": 1200,
  "failed": 50,
  "recent": [
    {
      "id": "email-123",
      "to": "buyer@example.com",
      "subject": "Order Created",
      "status": "SENT",
      "sentAt": "2025-03-06T10:30:00Z"
    }
  ]
}
```

### Sync Gmail inbox

```bash
POST /api/v1/email/gmail/sync

Response:
{
  "tasksCreated": 5,
  "ordersCreated": 2,
  "messagesProcessed": 15,
  "lastSync": "2025-03-06T10:35:00Z"
}
```

### Test email configuration

```bash
POST /api/v1/email/test

{
  "email": "test@example.com",
  "provider": "SENDGRID"
}

Response:
{
  "success": true,
  "message": "Test email sent successfully",
  "messageId": "xyz123"
}
```

═══════════════════════════════════════════════════════════════════════════════
## SCHEDULED TASKS (AUTOMATIC)
═══════════════════════════════════════════════════════════════════════════════

```
⏰ DAILY @ 08:00 UTC  → Send task reminders (due in 24h)
⏰ DAILY @ 17:00 UTC  → Send Daily Status Reports (DSR)
⏰ EVERY MONDAY @ 09:00 → Send payment reminders
⏰ EVERY 30 MINUTES   → Sync Gmail inbox (create tasks/orders)
⏰ EVERY HOUR         → Retry failed email sends
⏰ ON ORDER STATUS    → Send order notification (instantly)
⏰ ON INVOICE CREATE  → Send invoice email (instantly)
⏰ ON TASK ASSIGN     → Send assignment notification (instantly)
```

═══════════════════════════════════════════════════════════════════════════════
## TROUBLESHOOTING
═══════════════════════════════════════════════════════════════════════════════

### Email not sending?

```bash
# Check logs
docker-compose logs backend | grep "email"

# Check SendGrid credentials
curl https://api.sendgrid.com/v3/mail/validate \
  -H "Authorization: Bearer $SENDGRID_API_KEY"

# Check Gmail credentials
# Go to: https://myaccount.google.com/security/password
# Generate App Password if using Gmail
```

### Emails going to spam?

```
Fix:
1. Add SPF record to your domain
   v=spf1 sendgrid.net ~all

2. Add DKIM to SendGrid
   Settings → Sender Authentication → Authenticate

3. Add DMARC record
   v=DMARC1; p=none; rua=mailto:admin@yourdomain.com
```

### Task reminders not sending?

```bash
# Verify scheduling is running
docker-compose logs backend | grep "Task reminders"

# Check database for scheduled tasks
psql -U lscm_user -d lscm_erp -c "SELECT * FROM tasks WHERE dueDate > NOW() LIMIT 10;"

# Manually trigger
curl -X POST http://localhost:3000/api/v1/email/tasks/send-reminders \
  -H "Authorization: Bearer $TOKEN"
```

═══════════════════════════════════════════════════════════════════════════════
## COST COMPARISON (Annual)
═══════════════════════════════════════════════════════════════════════════════

```
SendGrid:    $240/year (10,000 emails/month)
Gmail:       $0/year (with Google Cloud free tier)
Outlook:     $72/year (Microsoft 365, optional)
SMTP (SES):  $0.10 per 1,000 emails ($10-50/year)
Self-hosted: $100-500/year (server costs)
```

**Best choice:** Gmail (free) or SendGrid ($20/month)

═══════════════════════════════════════════════════════════════════════════════
## NEXT STEPS
═══════════════════════════════════════════════════════════════════════════════

1. ✅ Choose email provider (SendGrid recommended)
2. ✅ Get API key / credentials
3. ✅ Add to .env file
4. ✅ Copy email service code
5. ✅ Run database migration
6. ✅ Seed email templates
7. ✅ Test with /api/v1/email/test
8. ✅ Enable notification preferences
9. ✅ Monitor email sending
10. ✅ Setup SPF/DKIM/DMARC for production

**All emails are now integrated into your ERP!** 📧✅
