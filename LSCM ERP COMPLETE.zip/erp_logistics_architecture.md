# Architecture ERP Logistique 3PL - LSCM
## Système intégré de gestion des commandes, expéditions et responsabilités

---

## 1. VUE D'ENSEMBLE FONCTIONNELLE

### Contexte Métier
- **Type**: 3PL (Third-Party Logistics) pour projets pétroliers/gaziers
- **Modèles de transport**: Aérien, Maritime, Routier
- **Acteurs**: Clients LSCM, partenaires logistiques, douane, transporteurs
- **Documents critiques**: BL (Bill of Lading), MAWB (Master Air Waybill), CMR (Lettre de Voiture), Kit Exports
- **Conformité**: Réglementations douanières, locales et internationales

### Modules Principaux
1. **Commande & Planification**
2. **Gestion des Expéditions Multi-modales**
3. **Transfert de Responsabilité** (chaîne logistique)
4. **Task Manager** (coordination 3PL)
5. **Gestion de Stock**
6. **Tracking Real-time**
7. **Génération de Documents** (BL, MAWB, CMR, Kit Export, brouillons douaniers)
8. **Facturation & Reporting**
9. **Système d'Autorisations** (validation clients/partenaires)

---

## 2. ARCHITECTURE TECHNIQUE RECOMMANDÉE

### Stack Frontend
```
- Framework: React.js ou Vue 3
- State Management: Redux/Zustand
- UI Library: Tailwind CSS + shadcn/ui
- Maps/Tracking: Mapbox ou Google Maps API
- Real-time: WebSocket (Socket.io)
- Export: jsPDF, ExcelJS pour documents
```

### Stack Backend
```
- Framework: Node.js (Express/NestJS) ou Python (FastAPI/Django)
- Base de données: PostgreSQL (relationnel) + Redis (cache + real-time)
- ORM: Prisma (Node) ou SQLAlchemy (Python)
- Message Queue: RabbitMQ ou Bull (pour jobs asynchrones)
- PDF Generation: puppeteer ou reportlab
- Authentication: JWT + OAuth2
```

### Infrastructure
```
- Containerization: Docker + Docker Compose
- Orchestration: Kubernetes (optionnel, pour production)
- Cloud: AWS/GCP/Azure
- CDN: CloudFront/Cloudflare
- Monitoring: ELK Stack / Datadog
```

### Recommandation LSCM
**Node.js + React + PostgreSQL** (scalabilité, temps réel, écosystème logistique riche)

---

## 3. MODÈLE DE DONNÉES - SCHÉMA CORE

```
┌─────────────────────────────────────────────────────────────┐
│                    ENTITÉS PRINCIPALES                       │
└─────────────────────────────────────────────────────────────┘

USERS & ROLES
├── users (id, email, nom, entreprise_id, role_id, status)
├── roles (ADMIN, CLIENT, PARTNER_LOGISTICS, DOUANE, CUSTOMER_SERVICE)
└── permissions (par role)

CLIENTS & PARTNERS
├── clients (id, raison_sociale, contact, adresse, KYC_docs)
├── logistics_partners (id, nom, capabilities[AÉRIEN|MARITIME|ROUTIER])
└── customs_brokers (id, nom, spécialisation, certifications)

COMMANDES
├── orders (id, reference, client_id, date, statut, montant_total)
├── order_items (id, order_id, description, qty, poids, volume, incoterms)
├── order_documents (id, order_id, type[DRAFT|APPROVED], contenu)
└── order_authorizations (id, order_id, actor_id, type, status, timestamp)

EXPÉDITIONS
├── shipments (id, order_id, shipment_mode[AIR|SEA|LAND], statut)
├── shipment_legs (id, shipment_id, origin, destination, carrier, etape_num)
├── shipment_responsability_transfers (id, shipment_id, from_actor, to_actor, timestamp, signature)
└── shipment_documents (id, shipment_id, type[BL|MAWB|CMR|MANIFEST], contenu_json)

STOCK
├── warehouses (id, localisation, capacité)
├── inventory (id, warehouse_id, sku, qty, reserved, location_bin)
├── inventory_movements (id, from_warehouse, to_warehouse, shipment_id, timestamp)
└── inventory_holds (id, shipment_id, reason[CUSTOMS|PAYMENT|INSPECTION], depuis, jusquà)

TRACKING
├── gps_events (id, shipment_id, latitude, longitude, timestamp, statut)
├── shipment_status_history (id, shipment_id, ancien_status, nouveau_status, timestamp)
└── notifications (id, shipment_id, user_id, type, contenu, lu)

DOCUMENTS DE TRANSPORT
├── bill_of_lading (id, shipment_id, numero_bl, details_json)
├── master_awb (id, shipment_id, mawb_number, details_json)
├── cmr_letters (id, shipment_id, numero_cmr, details_json)
├── export_kits (id, shipment_id, contenu_checklist, statut)
└── customs_drafts (id, shipment_id, broker_id, version, contenu_json, approuvé)

TASKS & WORKFLOW
├── tasks (id, shipment_id, assigné_à, type[PICKUP|CLEARANCE|DELIVERY|INSPECTION], statut)
├── task_dependencies (id, task_id, depends_on_task_id)
├── task_comments (id, task_id, author_id, contenu, timestamp)
└── task_attachments (id, task_id, file_path, type_document)

FACTURATION
├── invoices (id, shipment_id, montant, statut[DRAFT|SENT|PAID], date_emission)
├── invoice_items (id, invoice_id, description, qty, prix_unitaire)
├── payments (id, invoice_id, montant, mode_paiement, date, reference)
└── commission_tracking (id, partner_id, shipment_id, pourcentage, montant)

REPORTING
├── shipment_analytics (id, period, mode, count, revenue, avg_transit_time)
├── customer_metrics (id, client_id, period, shipments_count, spent_total)
└── audit_logs (id, user_id, action, table, ancien_value, nouveau_value, timestamp)
```

---

## 4. FLUX DE PROCESSUS CLÉS

### A) FLUX COMMANDE → EXPÉDITION → LIVRAISON

```
1. CLIENT CRÉE COMMANDE
   ├─ Précise: origine, destination, produit, poids, incoterms
   ├─ Choisit: mode de transport préféré
   └─ Upload: documents requis (facture commerciale, certifications)

2. LSCM ANALYSE & PLANIFIE
   ├─ Demande au CLIENT: approbation expédition (DRAFT pour autorisation)
   ├─ Propose: itinéraire + coût estimation
   └─ CLIENT APPROUVE

3. TRANSFERT DE RESPONSABILITÉ #1: Client → LSCM
   ├─ Signature électronique
   ├─ Timestamp + metadata
   └─ Update: shipment_responsability_transfers

4. LSCM COORDONNE LOGISTIQUE (Task Manager)
   ├─ TASK 1: Pickup au dépôt client
   ├─ TASK 2: Consolidation warehouse
   ├─ TASK 3: Customs clearance (approbation customs broker)
   └─ TASK 4: Transport vers destination

5. TRANSFERT DE RESPONSABILITÉ #2: LSCM → Partner Logistique
   ├─ Handover officiel
   ├─ Partner accepte sur système
   └─ Documents: BL/MAWB/CMR générés

6. TRANSPORT & TRACKING REAL-TIME
   ├─ GPS updates toutes les heures
   ├─ Status updates: IN_PICKUP → IN_TRANSIT → CUSTOMS_CLEARANCE → IN_DELIVERY
   ├─ Notifications clients via email/SMS
   └─ Task auto-updates

7. TRANSFERT DE RESPONSABILITÉ #3: Partner → Douane (en destination)
   ├─ Documents customs finalisés
   ├─ Inspection si nécessaire
   └─ Release document

8. TRANSFERT DE RESPONSABILITÉ #4: Douane → Destinataire
   ├─ Livraison finale confirmée
   ├─ POD (Proof of Delivery)
   └─ Invoice générée automatiquement

9. FACTURATION
   ├─ Invoice = coûts transport + services LSCM
   ├─ Commissions calculées pour partners
   └─ Payment tracking
```

### B) FLUX GESTION DOCUMENTS DOUANIERS

```
SCÉNARIO: Expédition maritime avec dédouanement en destination

1. CLIENT FOURNIT INFOS
   ├─ Valeur commerciale
   ├─ HS codes
   ├─ Certificats/licenses si requis
   └─ Documents commerciaux

2. LSCM GÉNÈRE DRAFT CUSTOMS
   ├─ Formulaire pré-rempli
   ├─ Détails shipment auto-importés
   ├─ Statut: DRAFT (nécessite approbation)
   └─ Visible à: CLIENT + CUSTOMS_BROKER

3. CLIENT APPROUVE DRAFT (Widget signature)
   ├─ Revoit tous les détails
   ├─ Signe électroniquement
   ├─ Timestamp enregistré
   └─ Statut: CLIENT_APPROVED

4. CUSTOMS BROKER REVOIT & COMPLÈTE
   ├─ Ajoute infos réglementaires locales
   ├─ Modifie si nécessaire
   ├─ Ajoute documents additionnels
   └─ Signe & soumet: BROKER_APPROVED

5. BL/MAWB/CMR GÉNÉRÉS AUTOMATIQUEMENT
   ├─ À partir des données validées
   ├─ Format standard international
   ├─ Numéros de référence auto-générés
   └─ PDF downloadable + archivé en base

6. EXPORT KIT GÉNÉRÉ
   ├─ Checklist complète pour douane
   ├─ Tous les documents requis listés
   ├─ Status par document (✓ présent ou ✗ manquant)
   └─ Prêt pour cleared
```

### C) FLUX TASK MANAGER (Coordination 3PL)

```
SHIIP #001: Marchandises client A → Port destination

┌──────────────────────────────────────────────────────────┐
│ TASK BOARD - Vue Kanban                                  │
├──────────────────────────────────────────────────────────┤
│ TODO        │ IN PROGRESS  │ BLOCKED     │ COMPLETED     │
├─────────────┼──────────────┼─────────────┼───────────────┤
│ • Pickup    │ • Customs    │ • Customs   │ ✓ Booking     │
│ • Clearance │   Clearance  │   docs     │ ✓ Pickup      │
│ • Booking   │              │   missing   │               │
└─────────────┴──────────────┴─────────────┴───────────────┘

TASK: Customs Clearance
├─ Assigné à: broker_partner_xyz
├─ Deadline: 2024-03-10
├─ Dépendances: [Booking COMPLETED, Documents READY]
├─ Infos:
│  ├─ Valeur totale: $50,000 USD
│  ├─ HS Codes: [8708.30, 8708.40]
│  ├─ Documents: [Invoice, Packing List, Certificate of Origin]
│  └─ Statut douanier: PENDING_INSPECTION
├─ Comments thread:
│  └─ [Broker]: "Docs received, processing..."
├─ Attachments:
│  └─ customs_draft_v2.pdf [CLIENT APPROVED] [BROKER APPROVED]
└─ Actions:
   ├─ Mark Complete (generates notification)
   ├─ Escalate if delayed
   └─ Auto-trigger next task: "Generate BL"
```

---

## 5. MODULES DÉTAILLÉS

### 5.1 GESTION COMMANDES

**Fonctionnalités:**
- Création multi-modale (choix transport AIR/SEA/LAND)
- Calcul automatique des coûts et delais
- Incoterms gestion (EXW, FOB, CIF, DDP, etc.)
- Documents pré-requis par mode & destination
- Validation poids/volume/dimensions
- Draft pour approbation client

**Workflows:**
- CLIENT crée → LSCM valide → CLIENT approuve → ACTIVE

---

### 5.2 GESTION EXPÉDITIONS MULTI-MODALES

**Modes supportés:**

```
AIR FREIGHT
├─ Carriers: DHL, Fedex, Lufthansa Cargo
├─ Document: MAWB (Master Air Waybill)
├─ Délai: 3-7 jours
├─ Coût: ~5-8 USD/kg
└─ Limite: 1500 kg économique

SEA FREIGHT
├─ Types: Full Container Load (FCL) / Less than Container Load (LCL)
├─ Vessels: Maersk, MSC, CMA CGM
├─ Document: BL (Bill of Lading)
├─ Délai: 15-45 jours selon route
├─ Coût: ~0.50-2 USD/kg (FCL/LCL)
└─ Limit: illimité

LAND/ROAD
├─ Modes: Camion, Wagon
├─ Document: CMR (Lettre de Voiture)
├─ Délai: 1-10 jours selon distance
├─ Coût: ~0.5-1.5 USD/km
└─ Zones: Europe/Proche-Orient
```

**Fonctionnalités:**
- Multi-leg support (ex: AIR-SEA-ROAD)
- Consolidation automatique de plusieurs commandes
- Pricing rules par partner/destination
- Equipment type auto-selection
- Capacity planning vs inventory

---

### 5.3 TRANSFERT DE RESPONSABILITÉ

**Concept clé:** À chaque étape, la responsabilité passe d'un acteur à l'autre avec signature électronique

```
Acteurs:
├─ CLIENT (propriétaire des marchandises)
├─ LSCM (responsable dépôt & coordination)
├─ LOGISTICS_PARTNER (responsable transport)
├─ CUSTOMS_AUTHORITY (responsable dédouanement)
└─ FINAL_RECIPIENT (destinataire final)

Chaque transfert enregistre:
├─ De: actor_id
├─ Vers: actor_id
├─ Timestamp (serveur)
├─ Signature électronique (JWT ou E-signature)
├─ Status du shipment à ce moment
├─ Location/warehouse
├─ Condition marchandises (POD, inspections)
└─ Documents signés
```

**Audit trail complet:** Impossible de nier responsabilité, traçabilité légale

---

### 5.4 TASK MANAGER (3PL COORDINATION)

**Interface Kanban:**
```
Colonnes: TODO | IN_PROGRESS | BLOCKED | COMPLETED | ESCALATED

Pour chaque task:
├─ Type: PICKUP, CONSOLIDATION, CUSTOMS, TRANSPORT, DELIVERY, INSPECTION
├─ Assigné à: personne spécifique
├─ Deadline avec alerte 48h avant
├─ Dépendances: task_id (ex: Customs dépend de Booking)
├─ Priorité: LOW, MEDIUM, HIGH, CRITICAL
├─ Pièces jointes & comments thread
├─ Historique modifications
└─ Actions: Complete, Reassign, Escalate, Delay
```

**Auto-workflows:**
```
Shipment créée
├─ Crée TASK: Booking ✓
├─ Crée TASK: Pickup (dépend: Booking)
├─ Crée TASK: Customs Clearance (dépend: Documents Ready)
├─ Crée TASK: Transport (dépend: Customs)
├─ Crée TASK: Delivery (dépend: Transport Complete)
└─ Crée TASK: Invoice (dépend: Delivery POD)

When TASK Complete:
├─ Check dépendances
├─ Auto-trigger next task(s)
├─ Update shipment status
└─ Send notifications
```

**Collaborations:**
- Comments: à chaque task
- @mentions pour alerter collègues
- File attachments (docs, photos, inspections)
- Activity timeline par shipment

---

### 5.5 GESTION STOCK

**Entrepôt logistique LSCM:**

```
Warehouse Layout:
├─ Zone de réception (RECEIVING)
├─ Zone de contrôle (QC)
├─ Zone de stockage (STORAGE)
│  └─ Racks organisés par bin/location
├─ Zone de consolidation (CONSOLIDATION)
└─ Zone d'expédition (SHIPPING)

Inventory tracking:
├─ SKU unique par client/article
├─ Localisation bin (ex: RACK-A3-LEVEL2)
├─ Quantité:
│  ├─ Available (dispo pour expédition)
│  ├─ Reserved (réservée pour shipment en cours)
│  ├─ On Hold (blocage customs/payment)
│  └─ Damaged (non utilisable)
├─ Movemenets (audit trail):
│  └─ Receiving → QC → Storage → Consolidation → Shipping
└─ Expiration tracking (si produits périssables)
```

**Fonctionnalités:**
- Barcode/QR scan à chaque mouvement
- Real-time visibility
- Auto-hold si customs block
- Stock vs reserved reports
- Slow-moving items alerts
- Rotation FIFO/LIFO tracking

---

### 5.6 TRACKING REAL-TIME

**GPS/Location updates:**

```
Shipment Tracking Map View:
├─ Route: Origin → Transit points → Destination
├─ Current position (live GPS)
├─ Estimated vs Actual Arrival
├─ Status indicator (IN_TRANSIT, CUSTOMS_CLEARANCE, DELIVERY)
├─ Historical path (où le shipment est passé)
└─ Geofence alerts (arrivée zone importante)

Data sources:
├─ Carrier API integration (DHL, Maersk, etc.)
├─ IoT sensors (temperature, humidity si produits sensibles)
├─ Manual updates (driver confirmation)
├─ Mobile app: driver input + photos
└─ Customs: document status updates
```

**Notifications:**
```
Client Dashboard:
├─ Shipment picked up ✓
├─ In customs clearance [PROCESSING]
├─ Delivery scheduled for 2024-03-15
├─ Delivery in progress [GPS update: 500m away]
└─ Delivered at 14:32 [POD: signature captured]

Email/SMS alerts:
├─ Threshold-based (ex: delayed > 24h)
├─ Milestone-based (ex: cleared customs)
├─ Anomaly-based (ex: wrong location)
└─ Document-based (ex: BL ready for download)
```

---

### 5.7 DOCUMENTS DE TRANSPORT

**Types de documents & workflow:**

```
1. BILL OF LADING (BL) - SEA FREIGHT
   ├─ Numbering: AUTO-GENERATED (ex: LSCM-2024-BL-001234)
   ├─ Data sources:
   │  ├─ Shipment: route, poids, volume
   │  ├─ Client: nom, adresse, contact
   │  ├─ Items: description, qty, HS codes
   │  ├─ Incoterms: prix, responsabilités
   │  └─ Vessel: nom, voyage, port loading/discharge
   ├─ Signatures:
   │  ├─ Client (shipper) - approbation
   │  ├─ LSCM (freight forwarder)
   │  └─ Carrier (signature d'acceptation)
   ├─ Format: PDF (standard international)
   └─ Archive: PDF + JSON pour modif futures

2. MASTER AIR WAYBILL (MAWB) - AIR FREIGHT
   ├─ Numbering: AUTO-GENERATED (ex: LSCM-2024-MAWB-005678)
   ├─ Data sources: (similaire BL)
   ├─ Particulariés:
   │  ├─ Pieces/Weight/Dimensions
   │  ├─ Class: N (Non-restricted), Q (Restricted)
   │  └─ Chargeable weight (réel vs volumétrique)
   ├─ Signatures: Shipper + Agent carrier
   └─ Format: IATA standard format

3. LETTRE DE VOITURE (CMR) - ROAD TRANSPORT
   ├─ Numbering: AUTO-GENERATED (ex: LSCM-2024-CMR-009012)
   ├─ Data sources: (similaire)
   ├─ Particulariés:
   │  ├─ Driver info (nom, licence)
   │  ├─ Vehicle (immatriculation, type)
   │  └─ Route: originé-destination-distance
   ├─ Signatures: 3 originaux (shipper, carrier, receiver)
   └─ Format: A4 imprimable

4. EXPORT KIT
   ├─ Checklist dynamique par destination:
   │  ├─ Required: BL/MAWB/CMR ✓
   │  ├─ Required: Commercial Invoice ✓
   │  ├─ Required: Packing List ✓
   │  ├─ Conditional: Certificate of Origin (si préférence tarifaire)
   │  ├─ Conditional: Health Certificate (si produits alimentaires)
   │  ├─ Conditional: Phytosanitary (si agricole)
   │  ├─ Optional: Insurance certificate
   │  └─ Optional: Inspection report
   ├─ Status tracking:
   │  ├─ ✓ Present & scanned
   │  ├─ ⏳ Pending receipt
   │  ├─ ✗ Missing (risk!)
   │  └─ ⚠️ Expired (si certificats)
   └─ Generation date & approval flow

5. CUSTOMS DECLARATION DRAFT
   ├─ Version control:
   │  ├─ v1 DRAFT (auto-generated by LSCM)
   │  ├─ v2 DRAFT (after client comments)
   │  ├─ v3 DRAFT (after customs broker modifications)
   │  └─ FINAL (approved by both)
   ├─ Approval workflow:
   │  ├─ CLIENT: reviews & signs (widget signature)
   │  └─ CUSTOMS_BROKER: finalizes & submits
   ├─ Data structure (JSON):
   │  ├─ shipper_info, consignee_info
   │  ├─ items[hs_code, description, qty, value]
   │  ├─ incoterms, shipping_terms
   │  ├─ certifications[], licenses[]
   │  └─ special_handling[]
   └─ Audit trail (who changed what & when)
```

**Generation Engine:**

```
Template-based PDF generation:

1. Pull data from database:
   - Shipment, Client, Items, Partner, Vessel

2. Render to HTML:
   - Header: company logo, document type
   - Body: structured data with borders/boxes
   - Footer: signatures areas, document number, date
   - Multi-language support (EN, FR, ES, AR)

3. Convert to PDF:
   - Using puppeteer (headless browser) or reportlab
   - Preserve formatting, fonts, colors
   - Embed images (logos, barcodes, QR codes)
   - Add metadata (author, creation date, encryption si requis)

4. Sign digitally (optional):
   - Electronic signature stamp (image + timestamp)
   - JWT token embedded in PDF

5. Store:
   - Original PDF in file storage
   - JSON metadata in database
   - Version history

6. Deliver:
   - Email to recipients
   - Dashboard download link
   - Archive/compliance storage
   - EDI export si required par partners
```

---

### 5.8 FACTURATION

**Invoice generation:**

```
INVOICE #INV-2024-001234
═════════════════════════════════════════

FROM: LSCM Ltd
TO: Client Name

SHIPMENT DETAILS:
├─ Reference: SHIP-2024-005678
├─ Origin: Shanghai, China
├─ Destination: Lagos, Nigeria
├─ Mode: SEA_FREIGHT (1x40' Container)
├─ Date: 2024-03-01

CHARGES:
├─ Ocean freight:           $2,500.00
├─ Port handling (origin):  $  300.00
├─ Port handling (dest):    $  400.00
├─ Customs clearance:       $  200.00
├─ Documentation:           $  100.00
├─ Insurance (3%):          $  90.00
├─ Transport to warehouse:  $  150.00
└─ ────────────────────────────────
   TOTAL:                   $3,740.00

PAYMENT TERMS: Net 30
DUE DATE: 2024-04-30
INVOICE DATE: 2024-03-15
```

**Features:**
- Auto-generated from shipment data
- Configurable pricing rules per partner
- Commission tracking (% ou amount)
- Multi-currency support (USD, EUR, GBP, CNY, NGN, etc.)
- Recurring invoices (monthly contracts)
- Late payment alerts
- Payment reconciliation
- Tax calculation (VAT, GST per country)

---

### 5.9 REPORTING & ANALYTICS

**Dashboards:**

```
EXECUTIVE DASHBOARD (Real-time KPIs)
├─ Active Shipments: 127
├─ Pending Customs: 12
├─ On-time Delivery: 94.3%
├─ Revenue This Month: $125,400
├─ Average Transit Time: 18.5 days

BY MODE:
├─ Air: 23 shipments | $89,200 revenue
├─ Sea: 76 shipments | $28,900 revenue
├─ Road: 28 shipments | $7,300 revenue

BY CUSTOMER:
├─ Total / Halliburton / Hyundai / Sterling / Cameron / Acergy
│  ├─ Count, revenue, avg transit, % on-time

FINANCIAL:
├─ YTD Revenue: $1.2M
├─ Outstanding Invoices: $89,000
├─ Collection Rate: 97.2%
├─ Avg Days Sales Outstanding: 25 days

OPERATIONAL:
├─ Warehouse Utilization: 73%
├─ Task Completion Rate: 98.1%
├─ Average Task Time: 2.3 days
├─ Escalations: 3 (critical)
```

**Custom Reports:**

```
1. SHIPMENT PERFORMANCE
   - Filter: date range, mode, customer, destination region
   - Metrics: count, weight, volume, revenue, transit time
   - Export: PDF, Excel, CSV

2. CUSTOMER STATEMENTS
   - Period: monthly/quarterly
   - Summarize: shipments, charges, payments, balance due
   - Auto-send on schedule

3. REGULATORY COMPLIANCE
   - All shipments with proper documentation
   - Failed customs clearances (root cause analysis)
   - Delays > 24h (impact analysis)
   - Audit trail exports

4. PARTNER PERFORMANCE
   - By logistics partner: reliability, speed, cost, quality
   - Ranking & SLA compliance
   - Commission reconciliation

5. CUSTOMS ANALYTICS
   - Clearance times by port/destination
   - Documentation completeness
   - Rejection rate & reasons
   - Risk assessment trends
```

---

## 6. SYSTÈME DE SÉCURITÉ & AUTORISATIONS

### 6.1 Authentification & Authorization

```
LOGIN:
├─ Email + Password (minimum)
├─ Multi-Factor Authentication (2FA via SMS/Email)
├─ SSO support (SAML2, OAuth2 avec clients)
└─ Session timeout (30 min inactivité)

RBAC (Role-Based Access Control):
├─ CLIENT_USER
│  ├─ Can: create orders, view own shipments, approve drafts
│  └─ Cannot: create invoices, assign tasks
├─ LSCM_ADMIN
│  ├─ Can: everything
│  └─ Audit: full access control
├─ LSCM_COORDINATOR
│  ├─ Can: manage tasks, create shipments, update status
│  ├─ Cannot: modify pricing, delete orders
│  └─ Audit: restricted
├─ PARTNER_LOGISTICS
│  ├─ Can: view assigned shipments, update status, upload POD
│  └─ Cannot: create orders, see competitor shipments
├─ CUSTOMS_BROKER
│  ├─ Can: access customs drafts, submit clearances
│  └─ Cannot: modify charges, change shipment routing
└─ CUSTOMER_SERVICE
   ├─ Can: view all shipments, respond to inquiries
   └─ Cannot: modify orders (read-only)
```

### 6.2 Document Approval Workflow

```
CUSTOM DRAFT APPROVAL:

STATE 1: DRAFT (Système génère)
├─ Auteur: LSCM_COORDINATOR
├─ Statut: LOCKED (readonly pour CLIENT)
└─ Notification: CLIENT → "Review & approve draft"

STATE 2: CLIENT_REVIEW (CLIENT lit)
├─ Permissions: Can comment, request changes
├─ Signature: widget signature (e-signature)
│  └─ Validates: identity, timestamp, consent
├─ Options:
│  ├─ APPROVE → passe à STATE 3
│  ├─ REJECT → back to STATE 1 (LSCM modifie)
│  └─ REQUEST_CHANGES → comments thread
└─ Auto-expire: 14 jours sans action

STATE 3: BROKER_REVIEW (CUSTOMS_BROKER finalise)
├─ Permissions: Can modify fields, add documents
├─ Modifications tracked (change log)
├─ Signature: broker e-signature
├─ Options:
│  ├─ APPROVE_AND_SUBMIT → FINAL
│  ├─ REQUEST_CLIENT_CHANGES → back to CLIENT
│  └─ REJECT (rare) → back to STATE 1
└─ Auto-escalate: 7 jours sans action

STATE 4: FINAL
├─ Immutable (no changes)
├─ Timestamp: final approval time
├─ Signatures: concatenated (JWT tokens)
├─ Hash: document integrity (SHA-256)
└─ Status: READY_FOR_SUBMISSION
```

### 6.3 Electronic Signature

```
Implementation:
├─ JWT-based signature (simple approach)
│  ├─ Payload: {user_id, document_id, timestamp, purpose}
│  ├─ Signed with: user's private key (stored securely)
│  └─ Verifiable: public key signature validation
│
├─ OR Advanced e-signature (compliance forte)
│  ├─ Integration: Docusign / Signfx / Adobe Sign
│  ├─ Standards: UETA/eIDAS compliant
│  ├─ Audit trail: intrinsic
│  └─ Legal weight: maximal (surtout pour customs)
└─ Widget UI:
   ├─ "I confirm & authorize this document"
   ├─ Capture: email, full name, timestamp
   ├─ Validation: email verification (link)
   └─ Result: signature embedded in PDF + DB
```

---

## 7. INTÉGRATIONS EXTERNES

### 7.1 Carrier APIs

```
DHL ECOMMERCE API:
├─ Create shipment
├─ Get label (PDF)
├─ Track shipment (status updates)
└─ Webhook: updates push vers notre système

MAERSK LINE API:
├─ Booking (FCL/LCL)
├─ B/L generation
├─ Track container (GPS)
└─ Document exchange (EDI)

FEDEX API:
├─ Rate shipping
├─ Create MAWB
├─ Track package
└─ Returns management
```

### 7.2 Customs/Regulatory APIs

```
PEPPOL Network:
├─ Electronic invoicing (cross-border)
├─ Compliance: GDPR, VAT, local tax laws
└─ Format: UBL standard

Customs Authority APIs (per country):
├─ Nigeria: NICIS (Nigeria Integrated Customs Info System)
├─ Egypt: EMCS (Egyptian Customs)
├─ UAE: TATWEER (Tariffs & Trade)
└─ Payload: customs declarations, pre-clearance
```

### 7.3 Payment Gateway

```
Integration:
├─ Stripe/Paypal: online invoice payment
├─ Bank transfer tracking: automatic reconciliation
├─ Multi-currency support
└─ Subscription billing (monthly contracts)
```

### 7.4 Email & SMS

```
SendGrid / AWS SES:
├─ Transactional emails: notifications
├─ Bulk emails: customer statements
├─ Templates: personalization
└─ Tracking: delivery rate, bounces

Twilio:
├─ SMS alerts (critical updates)
├─ Delivery confirmations
└─ Driver notifications
```

---

## 8. DONNÉES & CONFORMITÉ

### 8.1 Data Protection

```
GDPR Compliance:
├─ Personal data: client users, contacts
├─ Privacy policy: clear usage terms
├─ Consent: explicit opt-in for marketing
├─ Right to access: export user data (JSON)
├─ Right to deletion: anonymize & delete on request
├─ Data residency: EU servers si EU clients
└─ Encryption: AES-256 at rest, TLS in transit

Audit Logs (Immutable):
├─ User: who performed action
├─ Timestamp: when (server time, UTC)
├─ Action: create, read, update, delete, approve
├─ Table: which entity modified
├─ Old/New values: before & after (diffs)
├─ IP address: for security investigation
└─ Retention: 7 years (legal requirement)
```

### 8.2 Data Backup & Disaster Recovery

```
Backup Strategy:
├─ Daily full backup (PostgreSQL dump)
├─ Hourly incremental backup
├─ Geographic redundancy: 3 regions minimum
├─ RPO (Recovery Point Objective): < 1 hour
└─ RTO (Recovery Time Objective): < 4 hours

Testing:
├─ Monthly restore tests
├─ Documentation: runbooks
└─ DR drill: annual full recovery test
```

---

## 9. ROADMAP IMPLÉMENTATION (PHASES)

### PHASE 1: MVP (3-4 mois)
**Objectif:** Proof of Concept fonctionnel

```
✓ Backend: Node.js + PostgreSQL setup
✓ Auth: JWT login, basic RBAC
✓ Orders: create order, simple shipment
✓ Documents: BL auto-generate (template basic)
✓ Tracking: mock GPS tracking
✓ Dashboard: shipment list with status
✓ Task Manager: Kanban simple
✓ Invoicing: auto-generate basic invoice
└─ Deployment: Docker setup, cloud (AWS/GCP)
```

### PHASE 2: Core Features (4-5 mois)
**Objectif:** Production-ready pour clients pilotes

```
✓ Multi-modal support: AIR/SEA/ROAD workflows
✓ Transferts de responsabilité: full audit trail
✓ Documents avancés: MAWB, CMR, Export Kit
✓ Customs drafts: approval workflow avec e-signature
✓ Real-time tracking: intégration carrier APIs
✓ Task Manager: auto-workflows, dépendances
✓ Stock management: warehouse + inventory
✓ Reporting: basic dashboards + custom reports
✓ Payment: invoice + basic payment tracking
└─ User training & documentation
```

### PHASE 3: Optimisations (3-4 mois)
**Objectif:** Scalabilité et performance

```
✓ Advanced analytics: ML pour predictions (ETAs)
✓ Mobile app: iOS/Android pour drivers
✓ Notifications: real-time push + SMS/Email
✓ Integrations: Customs APIs, EDI standard
✓ Performance: DB optimization, caching (Redis)
✓ Security: advanced 2FA, encryption
✓ Compliance: audit logs, regulatory reporting
└─ Load testing & optimization
```

### PHASE 4: Enterprise (Ongoing)
**Objectif:** Feature richness

```
✓ Multi-tenant: white-label pour resellers
✓ AI-powered: demand forecasting, route optimization
✓ Supply chain visibility: supplier integration
✓ Finance: advanced invoicing, tax compliance
✓ IoT sensors: temp/humidity tracking si needed
└─ Community feedback & continuous improvement
```

---

## 10. ESTIMATIONS TECHNIQUES

### 10.1 Effort de développement

| Module | Tâches | Semaines | Effort |
|--------|--------|----------|--------|
| Architecture & DB | Design, schema, migrations | 2 | 80h |
| Auth & Security | JWT, RBAC, encryption | 1.5 | 60h |
| Orders Management | CRUD + validation | 1.5 | 60h |
| Shipments | Multi-modal routing | 3 | 120h |
| Task Manager | Kanban + workflows | 2 | 80h |
| Documents | PDF generation + approvals | 2.5 | 100h |
| Tracking | GPS + status updates | 2 | 80h |
| Stock Management | Warehouse + movements | 2 | 80h |
| Invoicing | Generation + payment | 1.5 | 60h |
| Reporting | Dashboards + exports | 2 | 80h |
| Integrations | Carriers, customs, payment | 3 | 120h |
| Testing & QA | Unit, integration, E2E | 3 | 120h |
| DevOps & Deploy | Docker, CI/CD, monitoring | 2 | 80h |
| **TOTAL** | | **28 semaines** | **1120h** |

**Par rôle:**
- Backend: 600h (Node.js + DB)
- Frontend: 350h (React)
- DevOps: 80h (Docker/AWS)
- QA: 90h

**Timeline:**
- Small team (3 devs): ~9-10 mois
- Medium team (5 devs): ~6-7 mois
- Large team (8 devs): ~4-5 mois

### 10.2 Coûts estimés (ordre de magnitude)

```
Développement:
├─ In-house team (3 devs, 9 mois): $180,000 - $270,000
├─ Outsourced (5 devs, 7 mois): $140,000 - $210,000
└─ Hybrid (2 core + 3 contractors): $150,000 - $200,000

Infrastructure (annuel):
├─ Cloud compute: $24,000 - $36,000
├─ Database (PostgreSQL managed): $6,000 - $12,000
├─ Storage (files, backups): $3,000 - $6,000
├─ CDN & monitoring: $2,000 - $4,000
└─ Total: ~$35,000 - $60,000/an

Third-party SaaS:
├─ E-signature (Docusign): $5,000 - $15,000/an
├─ Payment gateway (Stripe): % per transaction (2.9% + 0.30)
├─ SMS (Twilio): $100 - $500/an
├─ Email (SendGrid): $100 - $400/an
└─ Total: ~$5,200 - $16,000/an

Support & Maintenance:
├─ 1 DevOps: $60,000/an
├─ 2 support engineers: $120,000/an
└─ Total: ~$180,000/an

**TOTAL ANNUEL (Year 1): $220K - $330K**
**TOTAL ANNUEL (Year 2+): $150K - $200K** (sans développement)
```

---

## 11. TECHNOLOGIES SPÉCIFIQUES RECOMMANDÉES

### Frontend Stack
```javascript
// Package.json essentials
{
  "dependencies": {
    "react": "^18.2.0",
    "react-router-dom": "^6.8.0",
    "zustand": "^4.3.2",           // State management
    "react-query": "^3.39.2",       // Server state
    "tailwindcss": "^3.2.4",        // Styling
    "@headlessui/react": "^1.7.0",  // UI components
    "@mapbox/mapbox-gl": "^2.15.0", // Maps
    "socket.io-client": "^4.5.4",   // Real-time
    "axios": "^1.3.0",              // HTTP client
    "date-fns": "^2.29.2",          // Date utils
    "recharts": "^2.5.0",           // Charts
    "jspdf": "^2.5.1",              // PDF export
    "xlsx": "^0.18.5"               // Excel export
  }
}
```

### Backend Stack
```javascript
// Node.js + Express + PostgreSQL
{
  "dependencies": {
    "express": "^4.18.2",
    "prisma": "^4.9.0",             // ORM
    "@prisma/client": "^4.9.0",
    "pg": "^8.8.0",                 // PostgreSQL driver
    "redis": "^4.6.5",              // Caching
    "jsonwebtoken": "^9.0.0",       // Auth
    "bcryptjs": "^2.4.3",           // Password hashing
    "joi": "^17.8.0",               // Validation
    "nodemailer": "^6.9.1",         // Email
    "bull": "^4.10.4",              // Job queue
    "puppeteer": "^19.8.0",         // PDF generation
    "socket.io": "^4.5.4",          // Real-time
    "morgan": "^1.10.0",            // Logging
    "helmet": "^7.0.0",             // Security headers
    "cors": "^2.8.5"                // CORS
  }
}
```

### Databases
```
PostgreSQL:
├─ Primary OLTP (Online Transaction Processing)
├─ Relational: customers, shipments, invoices
├─ Constraints: foreign keys, indexes, sequences
└─ Extensions: PostGIS si tracking géographique

Redis:
├─ Cache: session tokens, shipping rates
├─ Real-time: subscriptions socket.io
├─ Job queue: task processing (Bull)
└─ Rate limiting: API throttling

TimescaleDB (optional):
├─ Time-series: GPS events, status updates
├─ Compression: efficient storage pour historical data
└─ Query: fast aggregations par time window
```

---

## 12. SECURITY CHECKLIST

```
[ ] SSL/TLS encryption (HTTPS everywhere)
[ ] JWT tokens with expiration (short-lived)
[ ] Refresh tokens (separate, long-lived)
[ ] Password hashing (bcrypt, argon2)
[ ] Rate limiting (API endpoints)
[ ] CORS properly configured
[ ] SQL injection prevention (parameterized queries)
[ ] XSS protection (input validation, output encoding)
[ ] CSRF tokens (if forms)
[ ] HTTPS headers (Helmet.js)
[ ] Secrets management (environment variables, vaults)
[ ] 2FA/MFA support
[ ] API key rotation policy
[ ] Audit logs (immutable)
[ ] GDPR compliance (data privacy)
[ ] PCI compliance (if processing cards)
[ ] Penetration testing (annual)
[ ] Security scanning (SAST/DAST in CI/CD)
```

---

## 13. DOCUMENTATION REQUISE

```
Pour l'équipe development:
├─ API Documentation (OpenAPI/Swagger)
├─ Database Schema Diagram (ER diagram)
├─ Architecture Diagrams (C4 model)
├─ Setup Guide (local development)
├─ Deployment Guide (production)
└─ Troubleshooting Runbooks

Pour les utilisateurs:
├─ User Manual (par rôle)
├─ Video Tutorials (key workflows)
├─ FAQ
├─ Terms of Service
└─ Privacy Policy

Pour les partners:
├─ Partner Integration Guide
├─ API Documentation (if exposing endpoints)
└─ SLA & Support Terms
```

---

## 14. SUCCESS METRICS (KPIs)

```
System Performance:
├─ Uptime: > 99.9%
├─ API response time: < 200ms (p95)
├─ Page load time: < 2s
└─ Database query time: < 100ms (p95)

Business Metrics:
├─ User adoption: > 80% active monthly
├─ Task completion rate: > 95%
├─ On-time delivery: > 95%
├─ Customer satisfaction: > 4.5/5 rating
├─ Customs clearance success: > 99%
├─ Invoice accuracy: > 99.5%
└─ Support ticket resolution: < 24h

Operational Metrics:
├─ Shipment processing time: < 2 hours
├─ Stock accuracy: > 99%
├─ Document generation time: < 5 minutes
└─ Report generation time: < 30 seconds
```

---

## CONCLUSION

Ce système est un **ERP logistique complet et intégré** qui automatise les processus critiques de LSCM:

✅ **Commandes** - full lifecycle from creation to invoice
✅ **Expéditions multi-modales** - AIR/SEA/ROAD support
✅ **Transferts de responsabilité** - audit trail légal
✅ **Task management** - coordination 3PL transparent
✅ **Documents** - BL/MAWB/CMR auto-generation avec approvals
✅ **Tracking** - real-time visibility
✅ **Stock** - warehouse management intégré
✅ **Facturation** - automated invoice generation
✅ **Reporting** - business intelligence
✅ **Conformité** - regulatory compliance + audit logs

**Prochaines étapes:**
1. Valider cette architecture avec stakeholders
2. Affiner requirements par module
3. Setup development environment
4. Commencer Phase 1 (MVP)
5. Recruter/organiser team

**Questions pour affiner?** Happy to deep-dive dans any module spécifique!
