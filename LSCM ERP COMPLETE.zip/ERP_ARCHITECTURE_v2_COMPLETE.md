# 🏗️ LSCM ERP - COMPLETE ARCHITECTURE DOCUMENT

**Version:** 2.0 Production  
**Built From:** CLEAR System Complete Analysis  
**Date:** March 2025  
**Status:** Ready for Phase 1 Development

---

# TABLE OF CONTENTS

1. Executive Summary
2. Business Context & Scope
3. Core Data Model (Entities & Relationships)
4. Module Architecture (10 Modules)
5. Key Workflows (End-to-End)
6. Integration Layer (CLEAR, SAP BW, Carriers, Banks)
7. Technology Stack
8. KPIs & SLAs
9. Implementation Roadmap (5 Phases)
10. Risk Register

---

# 1. EXECUTIVE SUMMARY

## What This ERP Does

LSCM ERP is a **comprehensive logistics management system** that orchestrates the complete lifecycle of freight forwarding operations from order creation through final payment recovery.

### Built From Reality
- **CLEAR System** (existing 3PL platform)
- **SAP BW** (PO data, vendors, materials)
- **Real workflows** (RFC, JEP, DSR, JCR)
- **Real clients** (SNIM, EGI, LADOL Free Zone)
- **Real routes** (NKC→IST→JNB, Sea freight, Consolidation)

### Core Capabilities
```
✅ Order-to-Delivery lifecycle management
✅ Multi-leg shipping (air, sea, land, consolidation)
✅ Document auto-generation (7 document types)
✅ Customs & regulatory compliance
✅ Real-time tracking (segment-by-segment)
✅ Financial management (invoicing, VAT, payment recovery)
✅ KPI dashboard (on-time rate, lead time, profitability)
✅ SAP BW integration (vendor, PO, material data)
✅ Bank integration (Access Bank payment verification)
✅ CLEAR API connectivity (existing platform)
```

---

# 2. BUSINESS CONTEXT & SCOPE

## Client Base & Cargo Types

### Primary Clients
| Client | Volume | Route | Cargo Type |
|--------|--------|-------|-----------|
| **SNIM** (Mauritania mining) | 50+ orders/month | NKC→JNB | Iron ore, equipment |
| **EGI** (Nigerian oil) | 30+ orders/month | Multiple | Oilfield services |
| **LADOL** (Free Zone) | 40+ orders/month | International | Consolidation hub |
| **Takamul-Atomai** | 10+ orders/month | Mauritania→EU | Mining equipment |

### Typical Shipments
```
Scenario A: SNIM Air Freight
├─ Origin: Nouakchott (NKC)
├─ Via: Istanbul (IST) consolidation
├─ Destination: Johannesburg (JNB)
├─ Cargo: 25 cbm, 8 tons
├─ Incoterm: FOB
├─ Lead time: 7-10 days
└─ Revenue: $3,500-5,000

Scenario B: EGI Sea Freight
├─ Origin: Port Harcourt (Nigeria)
├─ Route: Global South Africa (GSA)
├─ Destination: Pretoria warehouse
├─ Cargo: 200 cbm, 50 tons
├─ Incoterm: CIF
├─ Lead time: 14-21 days
└─ Revenue: $8,000-12,000

Scenario C: LADOL Consolidation
├─ Origins: 20+ suppliers (Nigeria, Ghana, etc)
├─ Hub: LADOL Free Zone
├─ Destination: Various (Europe, USA, Asia)
├─ Cargo: 500+ cbm, 100+ tons
├─ Incoterm: DDP
├─ Lead time: 30-45 days
└─ Revenue: $25,000-40,000
```

## Regulatory Context

```
CLEAR System Compliance
├─ SAP BW data integrity (purchase orders, vendors)
├─ Nigerian customs procedures (import/export)
├─ Free Zone regulations (LADOL)
├─ Bank reporting (Access Bank)
├─ VAT compliance (7.5% on services)
└─ Client confidentiality (data security)

Routes & Regions
├─ West Africa (Nigeria, Ghana, Mauritania)
├─ East Africa (Kenya, Tanzania, South Africa)
├─ International (Europe, Americas, Asia)
├─ Incoterms: EXW, FCA, FOB, CFR, CIF, DDP
└─ Transport modes: AIR, SEA, LAND, MULTIMODAL
```

---

# 3. CORE DATA MODEL

## 3.1 Entity Definitions

### **Entity 1: Order (ShipmentOrder)**

```typescript
interface ShipmentOrder {
  // === Identifiers ===
  orderId: string;                    // SNIM-26020001
  orderReference: string;             // From CLEAR
  poNumber: string;                   // 4560184557 (from SAP BW)
  rfcReference?: string;              // RFC-SNIM-250301
  
  // === Parties ===
  supplierId: string;                 // Vendor ID from SAP BW
  supplierName: string;               // ZEZ LIMITED, EGI Services
  supplierCountry: string;            // Mauritania, Nigeria
  
  buyerId: string;                    // Buyer ID from SAP BW
  buyerName: string;                  // SNIM, EGI, LADOL
  buyerCountry: string;               // Destination country
  
  consigneeId?: string;               // Final destination entity
  consigneeName?: string;
  
  // === Cargo Details ===
  commodityCode: string;              // HS Code (e.g., 2601)
  description: string;                // Material description
  itemNumber: string;                 // SAP item number
  quantity: number;
  unitOfMeasure: string;              // PCS, KG, CBM, TON
  
  weight: {
    gross: number;                    // kg
    net: number;                      // kg
  };
  
  dimensions: {
    length: number;                   // cm
    width: number;                    // cm
    height: number;                   // cm
    cbm: number;                      // Cubic meters (auto-calculated)
  };
  
  // === Logistics ===
  origin: {
    location: string;                 // NKC, PRH, LOS
    airport?: string;
    port?: string;
    warehouse?: string;
  };
  
  destination: {
    location: string;                 // JNB, IST, GVA
    airport?: string;
    port?: string;
    warehouse?: string;
  };
  
  incoterm: 'EXW' | 'FCA' | 'FOB' | 'CFR' | 'CIF' | 'DDP';
  transportMode: 'AIR' | 'SEA' | 'LAND' | 'MULTIMODAL';
  
  segments: TransportSegment[];        // Multi-leg journey
  
  // === Financial ===
  chargeWeight: number;               // For billing (kg or CBM)
  currencyCode: 'USD' | 'NGN' | 'EUR';
  
  costs: {
    serviceCharges: number;           // Base freight
    handlingFees: number;
    customsFees?: number;
    insurance?: number;
    vat: number;                      // 7.5% of services
    total: number;
  };
  
  // === Timeline ===
  createdAt: Date;
  pickupDate?: Date;
  estimatedDeparture?: Date;
  estimatedArrival?: Date;
  actualDeparture?: Date;
  actualArrival?: Date;
  deliveryDate?: Date;
  
  // === Status & Tracking ===
  status: OrderStatus;                // DRAFT, CONFIRMED, IN_TRANSIT, DELIVERED, INVOICED, CLOSED
  phase: OrderPhase;                  // Which major phase
  
  // === Documents ===
  documents: Document[];              // CI, PL, BL, AWB, RFC, JEP, etc
  
  // === Metadata ===
  createdBy: string;                  // Coordinator name
  updatedAt: Date;
  updatedBy: string;
  notes?: string;
  tags?: string[];                    // URGENT, VIP, LADOL_FZ, etc
}
```

### **Entity 2: Document**

```typescript
interface Document {
  // === Identifiers ===
  docId: string;
  orderId: string;                    // Parent order
  
  // === Classification ===
  type: DocumentType;                 // CI, PL, BL, AWB, RFC, JEP, JCR, etc
  documentNumber: string;             // INV-2025-00142
  version: 'DRAFT' | 'FINAL' | 'ORIGINAL';
  
  // === Generation ===
  isAutoGenerated: boolean;           // true if from CLEAR
  generatedAt: Date;
  generatedBy: string;                // System or user
  
  // === Content & Storage ===
  fileUrl: string;                    // S3 or cloud storage
  fileName: string;
  fileSize: number;                   // bytes
  fileHash: string;                   // MD5 checksum
  
  // === Approval Workflow ===
  status: DocumentStatus;             // DRAFT, PENDING_REVIEW, APPROVED, SIGNED, ARCHIVED
  requiredApprovals?: {
    client?: boolean;
    broker?: boolean;
    management?: boolean;
  };
  
  approvedAt?: Date;
  approvedBy?: string;
  signedAt?: Date;
  signedBy?: string;
  
  // === Customs-Specific ===
  customsReference?: string;          // Customs office reference
  mrnNumber?: string;                 // Movement Reference Number
  declarationStatus?: string;
  
  // === Metadata ===
  createdAt: Date;
  updatedAt: Date;
  isObsolete?: boolean;
  replacedBy?: string;                // If superseded
}

type DocumentType = 
  | 'CI'           // Commercial Invoice
  | 'PL'           // Packing List
  | 'BL'           // Bill of Lading (sea)
  | 'AWB'          // Air Waybill (air)
  | 'RFC'          // Request for Collection
  | 'JEP'          // Job Execution Plan
  | 'DSR'          // Daily Status Report
  | 'WSR'          // Weekly Status Report
  | 'JCR'          // Job Completion Report
  | 'SM'           // Shipping Marks
  | 'INVOICE'      // LSCM Invoice
  | 'CUSTOMS_DECL' // Customs Declaration
  | 'POA'          // Power of Attorney
  | 'FORM_M'       // Import License
  | 'PAAR'         // Pre-Arrival Assessment
  | 'CCVO'         // Certificate of Value & Origin
  | 'SR'           // Survey Report
  | 'POD';         // Proof of Delivery

type DocumentStatus = 'DRAFT' | 'PENDING_REVIEW' | 'APPROVED' | 'SIGNED' | 'ARCHIVED' | 'REJECTED';
type OrderStatus = 'DRAFT' | 'CONFIRMED' | 'RFC_SENT' | 'PFI_PENDING' | 'PICKUP_SCHEDULED' | 'IN_TRANSIT' | 'CUSTOMS_HOLD' | 'DELIVERED' | 'INVOICED' | 'PAID' | 'CLOSED' | 'CANCELLED';
type OrderPhase = 'PREPARATION' | 'DOCUMENTATION' | 'PICKUP' | 'EXPORT_CUSTOMS' | 'TRANSIT' | 'IMPORT_CUSTOMS' | 'DELIVERY' | 'BILLING' | 'CLOSURE';
```

### **Entity 3: TransportSegment**

```typescript
interface TransportSegment {
  segmentId: string;                  // SEG-1, SEG-2, etc
  orderId: string;
  legNumber: number;                  // 1, 2, 3...
  
  // === Route ===
  origin: {
    code: string;                     // NKC, IST, JNB
    name: string;                     // Nouakchott, Istanbul, Johannesburg
    type: 'AIRPORT' | 'SEAPORT' | 'WAREHOUSE';
  };
  
  destination: {
    code: string;
    name: string;
    type: 'AIRPORT' | 'SEAPORT' | 'WAREHOUSE';
  };
  
  // === Transport Details ===
  mode: 'AIR' | 'SEA' | 'LAND' | 'BARGE';
  carrier: {
    carrierId: string;
    name: string;                     // Turkish Airlines, MSC, etc
    reference: string;                // Flight number, vessel name
  };
  
  vehicle?: {
    registration: string;             // Aircraft reg, vessel IMO
    capacity: number;
    type: string;
  };
  
  // === Milestones ===
  estimatedDeparture: Date;           // ETD
  estimatedArrival: Date;             // ETA
  actualDeparture?: Date;
  actualArrival?: Date;
  
  // === Tracking ===
  status: SegmentStatus;              // IN_TRANSIT, ARRIVED, DELAYED, CANCELLED
  currentLocation?: string;
  lastUpdate?: Date;
  trackingReference?: string;
  
  // === Incidents ===
  incidents?: {
    type: string;                     // DELAY, HOLD, DAMAGE, WEATHER
    description: string;
    reportedAt: Date;
    resolvedAt?: Date;
    delayHours?: number;
  }[];
  
  // === Capacity ===
  allocatedWeight: number;            // kg
  allocatedCBM: number;
  utilizationRate?: number;           // %
}

type SegmentStatus = 'SCHEDULED' | 'IN_TRANSIT' | 'ARRIVED' | 'DELAYED' | 'CUSTOMS_CLEARED' | 'DELIVERED' | 'CANCELLED';
```

### **Entity 4: DailyStatusReport (DSR)**

```typescript
interface DailyStatusReport {
  dsrId: string;
  orderId: string;
  reportDate: Date;
  reportTime: string;                 // HH:MM
  
  // === Current State ===
  currentPhase: OrderPhase;
  currentStatus: OrderStatus;
  currentLocation?: string;
  currentSegment?: string;
  
  // === Progress ===
  eta: Date;
  etaLocation: string;
  lastAction: string;
  lastActionTime: Date;
  
  // === KPIs ===
  daysInPickup?: number;              // Days since order created
  daysSinceDeparture?: number;
  onTimeStatus: 'ON_TIME' | 'AT_RISK' | 'DELAYED';
  
  // === Issues ===
  incidents: {
    type: string;
    description: string;
    delayHours?: number;
    status: 'OPEN' | 'RESOLVED';
  }[];
  
  // === Next Steps ===
  nextMilestone: string;
  upcomingActions: string[];
  
  // === Client Communication ===
  sentToClient: boolean;
  sentAt?: Date;
  clientAcknowledged?: boolean;
  
  createdAt: Date;
  createdBy: string;
}
```

### **Entity 5: Invoice & Payment**

```typescript
interface Invoice {
  invoiceId: string;
  orderId: string;
  invoiceNumber: string;              // INV-2025-00142
  
  // === Line Items ===
  lineItems: {
    description: string;              // Freight charges, Handling, etc
    quantity: number;
    unitPrice: number;
    amount: number;
  }[];
  
  subtotal: number;
  vat: number;                        // 7.5% of services
  total: number;
  currencyCode: string;
  
  // === Payment ===
  status: 'DRAFT' | 'SENT' | 'PENDING' | 'PARTIAL' | 'PAID' | 'OVERDUE';
  dueDate: Date;
  paymentTerms: string;               // Net 30, etc
  
  paidAmount?: number;
  paidDate?: Date;
  paymentReference?: string;
  
  // === Bank Details ===
  bankName: string;                   // Access Bank
  accountName: string;
  accountNumber: string;
  bankCode: string;
  
  // === Metadata ===
  issuedAt: Date;
  issuedBy: string;
  sentAt?: Date;
  remindersSent?: number;
  overdueNotification?: Date;
}
```

---

## 3.2 Relationships Diagram

```
ShipmentOrder (1) ──→ (M) Document
     │
     ├──→ (M) TransportSegment
     │
     ├──→ (1) DailyStatusReport
     │
     ├──→ (M) Invoice
     │
     └──→ (1) Party (Supplier)
           │
           └──→ SAP BW (Vendor Master)

Document (1) ──→ (M) ApprovalLog

TransportSegment (1) ──→ (1) Carrier
                         │
                         └──→ External Tracking API

Invoice (1) ──→ (1) BankAccount
                  │
                  └──→ Payment Gateway (Access Bank)
```

---

# 4. MODULE ARCHITECTURE (10 Modules)

## Module 1: Order Management

**Purpose:** Create, track, and manage shipment orders end-to-end

```typescript
// OrderService.ts
class OrderService {
  
  // 1.1 Create Order
  async createOrder(input: CreateOrderInput): Promise<ShipmentOrder> {
    // From RFC or CLEAR import
    // Auto-populate from SAP BW (PO details)
    // Generate unique order ID
    // Set initial status: DRAFT
    // Create timeline milestones
    return order;
  }
  
  // 1.2 Update Order Status
  async updateOrderStatus(orderId: string, newStatus: OrderStatus): Promise<void> {
    // Validate status transition rules
    // Log status change with timestamp
    // Trigger notifications to relevant parties
    // Update DSR if in transit
  }
  
  // 1.3 Get Order Timeline
  async getOrderTimeline(orderId: string): Promise<TimelineEvent[]> {
    // Return all milestones (scheduled + actual)
    // Compare to KPI targets
    // Flag if delays detected
  }
  
  // 1.4 Calculate Order KPIs
  async calculateKPIs(orderId: string): Promise<OrderKPIs> {
    return {
      daysInPickup: daysDifference(createdAt, pickupDate),
      daysToGreenLight: daysDifference(pickupDate, greenLightDate),
      daysInTransit: daysDifference(departure, arrival),
      totalLeadTime: daysDifference(createdAt, deliveryDate),
      onTimeDelivery: actualArrival <= estimatedArrival,
      costVariance: (actualCost - estimatedCost) / estimatedCost,
    };
  }
}

interface CreateOrderInput {
  poNumber: string;                   // From SAP BW
  supplierId: string;
  buyerId: string;
  commodityCode: string;
  quantity: number;
  incoterm: string;
  transportMode: string;
  origin: string;
  destination: string;
}

interface OrderKPIs {
  daysInPickup: number;
  daysToGreenLight: number;
  daysInTransit: number;
  totalLeadTime: number;
  onTimeDelivery: boolean;
  costVariance: number;
}
```

**KPI Thresholds (from Weekly Status Report):**
```
✓ Pickup: ≤ 5 days from order
✓ Green Light: ≤ 14 days from pickup
✓ Sea Delivery: ≤ 70 days total
✓ Air Delivery: ≤ 20 days total
✓ Lead Time Variance: < 5%
✓ Cost Variance: < 10%
```

---

## Module 2: Document Management & Auto-Generation

**Purpose:** Auto-generate, version, and manage all shipping documents

```typescript
// DocumentService.ts
class DocumentService {
  
  // 2.1 Auto-Generate Documents
  async autoGenerateDocuments(orderId: string): Promise<Document[]> {
    const order = await getOrder(orderId);
    const documents: Document[] = [];
    
    // Always generate
    documents.push(await generateRFC(order));
    documents.push(await generateJEP(order));
    documents.push(await generateShippingMarks(order));
    
    // Conditional based on transport mode
    if (order.transportMode === 'AIR') {
      documents.push(await generateAWB(order));
    } else if (order.transportMode === 'SEA') {
      documents.push(await generateBL(order));
    }
    
    // Conditional based on destination
    if (requiresCustoms(order)) {
      documents.push(await generateCustomsDeclaration(order));
    }
    
    return documents;
  }
  
  // 2.2 Generate RFC (Request for Collection)
  async generateRFC(order: ShipmentOrder): Promise<Document> {
    return {
      type: 'RFC',
      isAutoGenerated: true,
      content: {
        supplierName: order.supplierName,
        pickupAddress: order.origin,
        commodities: order.description,
        quantity: order.quantity,
        weight: order.weight.gross,
        incoterm: order.incoterm,
        estimatedPickupDate: addDays(now(), 2),
        specialInstructions: extractSEI4CCompliance(order),
      },
      template: 'RFC_v5.0',
    };
  }
  
  // 2.3 Generate JEP (Job Execution Plan)
  async generateJEP(order: ShipmentOrder): Promise<Document> {
    const segments = order.segments;
    
    return {
      type: 'JEP',
      isAutoGenerated: true,
      content: {
        orderId: order.orderId,
        shipmentReference: order.orderReference,
        supplier: order.supplierName,
        consignee: order.buyerName,
        
        timeline: {
          milestones: segments.map((seg, i) => ({
            leg: i + 1,
            from: seg.origin.code,
            to: seg.destination.code,
            etd: seg.estimatedDeparture,
            eta: seg.estimatedArrival,
            mode: seg.mode,
            carrier: seg.carrier.name,
          })),
          totalLeadDays: calculateLeadTime(segments),
        },
        
        responsibilities: {
          lscm: ['Pickup', 'Export customs', 'Freight booking', 'Import clearance'],
          client: ['PFI approval', 'Duty payment', 'Final delivery'],
          supplier: ['Material prep', 'Shipping marks'],
        },
        
        documents: [
          'Commercial Invoice',
          'Packing List',
          'Bill of Lading / Air Waybill',
          'Customs declarations',
          'Power of Attorney',
          'Survey Report',
        ],
      },
      template: 'JEP_v5.0',
    };
  }
  
  // 2.4 Generate Shipping Marks
  async generateShippingMarks(order: ShipmentOrder): Promise<Document> {
    const marks = [];
    
    for (let i = 1; i <= order.quantity; i++) {
      marks.push({
        packageNumber: i,
        reference: order.orderReference,
        from: order.supplierName,
        to: order.buyerName,
        weight: calculateWeight(order, i),
        dimensions: calculateDimensions(order, i),
        qrCode: generateQRCode(order.orderId, i),
      });
    }
    
    return {
      type: 'SM',
      isAutoGenerated: true,
      content: { marks },
      template: 'SM_v5.0',
    };
  }
  
  // 2.5 Update Document Approval Status
  async approveDocument(docId: string, approver: string): Promise<void> {
    const doc = await getDocument(docId);
    doc.status = 'APPROVED';
    doc.approvedBy = approver;
    doc.approvedAt = new Date();
    
    // Check if all required approvals are now complete
    const allApproved = await checkAllApprovalsComplete(doc.orderId);
    if (allApproved) {
      await updateOrderPhase(doc.orderId, 'PICKUP');
      await notifyCoordinator(doc.orderId);
    }
  }
  
  // 2.6 Archive Old Versions
  async archiveOldVersions(orderId: string, docType: DocumentType): Promise<void> {
    const docs = await getDocumentsByType(orderId, docType);
    const latest = docs.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())[0];
    
    docs.forEach(doc => {
      if (doc.docId !== latest.docId) {
        doc.status = 'ARCHIVED';
      }
    });
  }
}
```

**Document Generation Rules:**
```
RFC (Always)
├─ Trigger: Order confirmed
├─ Auto-populate: Supplier, commodity, weight, incoterm
├─ Template: RFC_v5.0
└─ Send to: Supplier + Coordinator

JEP (Always)
├─ Trigger: All segments confirmed
├─ Auto-populate: Milestones, timeline, responsibilities
├─ Template: JEP_v5.0
└─ Send to: Client + All stakeholders

Shipping Marks (Always)
├─ Trigger: Order confirmed
├─ Auto-generate: QR codes, labels (per package)
├─ Template: SM_v5.0
└─ Send to: Supplier (for affixing)

Bill of Lading / AWB (Conditional)
├─ Trigger: Carrier confirmed + loaded
├─ If transportMode = SEA → BL
├─ If transportMode = AIR → AWB
├─ Template: BL_v5.0 / AWB_v5.0
└─ Send to: Carrier + Consignee

Customs Declarations (Conditional)
├─ Trigger: Pre-departure
├─ Based on destination country & commodity
├─ Template: CUSTOMS_v5.0
└─ Send to: Customs broker

Survey Report (On Loading)
├─ Trigger: At loading / stuffing
├─ Content: Photos, condition assessment
├─ Template: SR_v5.0
└─ Attach: Loading photos (min 2 per package)
```

---

## Module 3: Pickup & Collection

**Purpose:** Manage pickup execution and proof of collection

```typescript
class PickupService {
  
  // 3.1 Schedule Pickup
  async schedulePickup(orderId: string, pickup: PickupRequest): Promise<PickupSchedule> {
    return {
      pickupId: generateId(),
      orderId,
      scheduledDate: pickup.date,
      scheduledTime: pickup.timeWindow,
      supplier: pickup.supplierLocation,
      agent: pickup.agentAssigned,
      estimatedDuration: calculateDuration(pickup.weight),
      contactPerson: pickup.contact,
    };
  }
  
  // 3.2 Record Proof of Collection (POC)
  async recordPOC(orderId: string, pocData: POCInput): Promise<ProofOfCollection> {
    const poc: ProofOfCollection = {
      pocId: generateId(),
      orderId,
      pickedUpAt: pocData.timestamp,
      pickedUpBy: pocData.agent,
      location: pocData.location,
      
      // Physical inspection
      packageCount: pocData.packageCount,
      actualWeight: pocData.weight,
      actualDimensions: pocData.dimensions,
      condition: pocData.externalCondition,
      
      // Verification
      shippingMarksVerified: pocData.smVerified,
      documentsCollected: pocData.docsCollected,
      
      // Photos (MANDATORY: min 2 per package)
      photos: pocData.photos,  // Array of {url, caption, timestamp}
      photosVerified: pocData.photos.length >= 2 * pocData.packageCount,
      
      // Signatures
      supplierSignature: pocData.supplierSig,
      agentSignature: pocData.agentSig,
      signatureDate: pocData.sigDate,
      
      status: 'VERIFIED',
    };
    
    // Update order status
    await updateOrder(orderId, { status: 'PICKED_UP', pickupDate: pocData.timestamp });
    
    return poc;
  }
  
  // 3.3 Hub Reception & Quality Check
  async receiveAtHub(orderId: string, hubData: HubReceiptInput): Promise<HubReceipt> {
    return {
      receiptId: generateId(),
      orderId,
      receivedAt: hubData.timestamp,
      receivedBy: hubData.hub_manager,
      
      // Quality inspection
      packageCountVerified: hubData.packageCount === expectedCount,
      weightVerified: hubData.weight <= expectedWeight * 1.05,
      conditionOK: hubData.condition !== 'DAMAGED',
      smIntact: hubData.shippingMarksOK,
      
      // Storage assignment
      storageLocation: hubData.location,
      consolidationQueue?: hubData.consolidationRefId,
      
      // Photos
      receptionPhotos: hubData.photos,
      
      status: 'RECEIVED',
    };
  }
}

interface PickupRequest {
  date: Date;
  timeWindow: string;        // HH:MM - HH:MM
  supplierLocation: string;
  agentAssigned: string;
  contact: ContactInfo;
}

interface ProofOfCollection {
  pocId: string;
  orderId: string;
  pickedUpAt: Date;
  pickedUpBy: string;
  location: string;
  
  packageCount: number;
  actualWeight: number;
  actualDimensions: Dimensions;
  condition: 'GOOD' | 'DAMAGED' | 'DIRTY';
  
  shippingMarksVerified: boolean;
  documentsCollected: string[];  // Doc types collected
  
  photos: { url: string; caption: string; timestamp: Date }[];
  photosVerified: boolean;  // BLOCKING: Must have >= 2 per package
  
  supplierSignature: string;
  agentSignature: string;
  signatureDate: Date;
  
  status: 'VERIFIED' | 'REJECTED' | 'HOLD';
}
```

**SEI 4C Compliance (from RFC):**
```
✓ Box dimensions: 13 × 34 × 39 cm standard
✓ Package numbering: Sequential 1 of N, 2 of N, etc
✓ Weight recording: Gross + net
✓ Shipping marks: From, To, Reference, QR code
✓ Documentation: 2 minimum photos per package
✓ Condition assessment: Exterior, damages, content
✓ Signatures: Supplier + Agent + Date
✓ Timeline: Photos timestamped + geotagged (if mobile)
```

---

## Module 4: Export Customs & Green Light Approval

**Purpose:** Manage export customs clearance and get multi-party approval

```typescript
class ExportCustomsService {
  
  // 4.1 Submit Export Declaration
  async submitExportDeclaration(orderId: string): Promise<ExportDeclaration> {
    const order = await getOrder(orderId);
    
    const declaration = {
      declId: generateId(),
      orderId,
      
      // Shipper info
      shipper: order.supplierName,
      shippingAddress: order.origin.warehouse,
      
      // Goods info
      hsCode: order.commodityCode,
      description: order.description,
      quantity: order.quantity,
      weight: order.weight.gross,
      value: order.costs.total,
      valueCurrency: order.currencyCode,
      
      // Destination
      destination: order.destination.code,
      consignee: order.buyerName,
      
      // Documents
      attachedDocs: [
        { type: 'CI', reference: getCIDocument(orderId) },
        { type: 'PL', reference: getPLDocument(orderId) },
        { type: 'BL_DRAFT', reference: getBLDocument(orderId) },
      ],
      
      status: 'SUBMITTED',
      submittedAt: new Date(),
      submittedBy: 'SYSTEM',
    };
    
    // Notify customs broker
    await notifyBroker(orderId, 'Export declaration submitted');
    
    return declaration;
  }
  
  // 4.2 Get Greenlight (3-Way Approval)
  async requestGreenLight(orderId: string): Promise<GreenlightRequest> {
    const order = await getOrder(orderId);
    
    const glRequest = {
      glId: generateId(),
      orderId,
      requestedAt: new Date(),
      
      // Kit documentaire
      documentsIncluded: [
        'RFC',
        'JEP',
        'CI',
        'PL',
        'SM',
        'Export Declaration',
      ],
      
      // 3-party approval
      requiredApprovals: {
        client: {
          role: 'BUYER',
          status: 'PENDING',
          deadline: addHours(now(), 24),
        },
        customsBroker: {
          role: 'CUSTOMS_AGENT',
          status: 'PENDING',
          deadline: addHours(now(), 24),
        },
        carrier: {
          role: 'TRANSPORTER',
          status: 'PENDING',
          deadline: addHours(now(), 24),
        },
      },
      
      status: 'PENDING',  // Only changes to APPROVED if all 3 approve
    };
    
    // Send GL package to all 3 parties
    await sendGLToClient(orderId, glRequest);
    await sendGLToCustomsBroker(orderId, glRequest);
    await sendGLToCarrier(orderId, glRequest);
    
    // Set deadline reminders
    scheduleReminder(orderId, addHours(now(), 20), 'GL approval deadline in 4 hours');
    
    return glRequest;
  }
  
  // 4.3 Record Approval
  async recordApproval(glId: string, approver: string, approved: boolean): Promise<void> {
    const gl = await getGreenlight(glId);
    
    if (!approved) {
      gl.status = 'REJECTED';
      await notifyCoordinator(gl.orderId, `GL rejected by ${approver}`);
      return;
    }
    
    // Record approval
    gl.requiredApprovals[approver].status = 'APPROVED';
    gl.requiredApprovals[approver].approvedAt = new Date();
    
    // Check if all 3 approved
    const allApproved = Object.values(gl.requiredApprovals).every(
      (approval) => approval.status === 'APPROVED'
    );
    
    if (allApproved) {
      gl.status = 'APPROVED';
      
      // NOW can proceed: Send pre-alert, schedule loading, etc
      await updateOrderPhase(gl.orderId, 'BOOKING');
      await sendPreAlert(gl.orderId);
      await scheduleLoading(gl.orderId);
      
      await notifyCoordinator(gl.orderId, 'GREENLIGHT APPROVED - Proceed to loading');
    }
  }
}

interface GreenlightRequest {
  glId: string;
  orderId: string;
  requestedAt: Date;
  documentsIncluded: string[];
  
  requiredApprovals: {
    client: ApprovalDetail;
    customsBroker: ApprovalDetail;
    carrier: ApprovalDetail;
  };
  
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
}

interface ApprovalDetail {
  role: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  deadline: Date;
  approvedAt?: Date;
  reason?: string;
}
```

**Greenlight Blocking Rules:**
```
🔴 CRITICAL GATE: Order BLOCKED in EXPORT_CUSTOMS phase

Requirements:
├─ ✓ RFC verified (supplier ready)
├─ ✓ JEP finalized
├─ ✓ All documents (CI, PL, SM) generated
├─ ✓ Export declaration submitted
└─ ✓ All 3 parties approved

If ANY approval missing → ORDER STUCK
If ANY approval rejected → Order cancelled, renegotiate

Timeline:
├─ GL sent: T+0h
├─ Client approval: Deadline T+24h
├─ Customs broker approval: Deadline T+24h
├─ Carrier approval: Deadline T+24h
├─ If not all approved by T+24h: Auto-escalate to management
```

---

## Module 5: Booking & Transportation

**Purpose:** Book carrier, schedule loading, manage shipment

```typescript
class TransportationService {
  
  // 5.1 Book Carrier
  async bookCarrier(orderId: string, booking: CarrierBooking): Promise<BookingConfirmation> {
    const order = await getOrder(orderId);
    
    const confirmation = {
      bookingId: generateId(),
      orderId,
      carrier: booking.carrierName,
      reference: booking.carrierReference,  // Flight #, Vessel name, etc
      
      // Routing
      departure: {
        airport: booking.depAirport,
        date: booking.etd,
        time: booking.etdTime,
      },
      arrival: {
        airport: booking.arrAirport,
        date: booking.eta,
      },
      
      // Capacity
      allocatedWeight: booking.weight,
      allocatedCBM: booking.cbm,
      rate: booking.rate,          // Per kg or per CBM
      totalFreight: booking.totalFreight,
      
      status: 'CONFIRMED',
      bookedAt: new Date(),
    };
    
    await updateOrder(orderId, {
      status: 'BOOKING_CONFIRMED',
      segments: [
        {
          carrier: booking.carrierName,
          reference: booking.carrierReference,
          estimatedDeparture: booking.etd,
          estimatedArrival: booking.eta,
        },
      ],
    });
    
    return confirmation;
  }
  
  // 5.2 Schedule Loading / Stuffing
  async scheduleLoading(orderId: string): Promise<LoadingSchedule> {
    const order = await getOrder(orderId);
    
    // For consolidation orders, may go to LADOL hub first
    const loadingLocation = order.tags?.includes('LADOL_FZ')
      ? 'LADOL_FREE_ZONE'
      : order.origin.warehouse;
    
    return {
      loadingId: generateId(),
      orderId,
      loadingLocation,
      scheduledDate: order.segments[0].estimatedDeparture,
      scheduledTime: subtractHours(order.segments[0].estimatedDeparture, 12),
      
      // Prepare survey report
      surveyRequired: true,
      photosRequired: true,
      minPhotosPerPackage: 2,
      
      status: 'SCHEDULED',
    };
  }
  
  // 5.3 Record Loading & Generate Survey Report
  async recordLoading(orderId: string, loadingData: LoadingInput): Promise<SurveyReport> {
    const survey = {
      surveyId: generateId(),
      orderId,
      surveyDate: loadingData.timestamp,
      surveyBy: loadingData.surveyor,
      
      // Physical inspection at loading
      packaging: {
        condition: loadingData.condition,         // GOOD, FAIR, DAMAGED
        marksVisible: loadingData.marksOK,
        sealsIntact: loadingData.sealsOK,
      },
      
      // Per-package assessment
      packages: loadingData.packages.map((pkg) => ({
        number: pkg.number,
        externalCondition: pkg.condition,
        damageNotes: pkg.damage,
        weight: pkg.weight,
        marksVerified: pkg.marksVerified,
      })),
      
      // Photos (MANDATORY: min 2 per package)
      photos: loadingData.photos,
      photoCount: loadingData.photos.length,
      photosCompliant: loadingData.photos.length >= 2 * loadingData.packages.length,
      
      // Container/vehicle sealing
      containerNumber?: loadingData.containerNumber,
      seals: loadingData.seals,  // [{sealNumber, type, affixedAt}]
      
      // Certification
      surveyorSignature: loadingData.signature,
      stampDate: loadingData.stampDate,
      
      status: 'VERIFIED',
    };
    
    await updateOrder(orderId, {
      status: 'LOADED',
      phase: 'TRANSIT',
    });
    
    // Generate and attach to JCR
    await attachDocumentToOrder(orderId, 'SR', survey);
    
    return survey;
  }
  
  // 5.4 Track Shipment (Real-time)
  async trackSegment(segmentId: string): Promise<SegmentTracking> {
    const segment = await getSegment(segmentId);
    
    // Call carrier API for tracking
    const carrierUpdate = await getCarrierTracking(
      segment.carrier.name,
      segment.carrier.reference
    );
    
    return {
      segmentId,
      currentLocation: carrierUpdate.location,
      lastUpdate: carrierUpdate.timestamp,
      status: carrierUpdate.status,
      eta: carrierUpdate.eta,
      
      // Update segment
      actualDeparture: carrierUpdate.departureActual,
      actualArrival: carrierUpdate.arrivalActual,
      
      // Check for delays
      onTime: carrierUpdate.eta <= segment.estimatedArrival,
      delayHours: calculateDelay(carrierUpdate.eta, segment.estimatedArrival),
    };
  }
}

interface CarrierBooking {
  carrierName: string;
  carrierReference: string;       // Flight #, vessel name
  depAirport: string;
  arrAirport: string;
  etd: Date;
  etdTime: string;
  eta: Date;
  weight: number;
  cbm: number;
  rate: number;
  totalFreight: number;
}

interface SurveyReport {
  surveyId: string;
  orderId: string;
  surveyDate: Date;
  surveyBy: string;
  
  packaging: {
    condition: 'GOOD' | 'FAIR' | 'DAMAGED';
    marksVisible: boolean;
    sealsIntact: boolean;
  };
  
  packages: {
    number: number;
    externalCondition: string;
    damageNotes?: string;
    weight: number;
    marksVerified: boolean;
  }[];
  
  photos: { url: string; caption: string; timestamp: Date }[];
  photoCount: number;
  photosCompliant: boolean;  // BLOCKING: must be >= 2 per package
  
  containerNumber?: string;
  seals: { sealNumber: string; type: string; affixedAt: Date }[];
  
  surveyorSignature: string;
  stampDate: Date;
  
  status: 'VERIFIED' | 'REJECTED' | 'HOLD';
}
```

---

## Module 6: Import Customs & Delivery

**Purpose:** Handle destination customs, import clearance, final delivery

```typescript
class ImportCustomsService {
  
  // 6.1 Submit Import Declaration
  async submitImportDeclaration(orderId: string): Promise<ImportDeclaration> {
    const order = await getOrder(orderId);
    const survey = await getSurveyReport(orderId);
    
    const declaration = {
      declId: generateId(),
      orderId,
      
      // Importer info
      importer: order.buyerName,
      importingCountry: order.destination.code,
      
      // Shipment details (from survey)
      hsCode: order.commodityCode,
      description: order.description,
      quantity: order.quantity,
      weight: survey.packages.reduce((sum, pkg) => sum + pkg.weight, 0),
      value: order.costs.total,
      
      // Origin
      originCountry: getCountry(order.origin.code),
      shipper: order.supplierName,
      
      // Documents attached
      attachedDocs: [
        { type: 'CI', reference: getCIDocument(orderId) },
        { type: 'PL', reference: getPLDocument(orderId) },
        { type: 'BL', reference: getBLDocument(orderId) },
        { type: 'PAAR', reference: getPAARDocument(orderId) },
      ],
      
      status: 'SUBMITTED',
      submittedAt: new Date(),
    };
    
    // Notify customs broker at destination
    await notifyImportBroker(orderId, declaration);
    
    return declaration;
  }
  
  // 6.2 Monitor Customs Clearance Status
  async monitorClearanceStatus(orderId: string): Promise<ClearanceStatus> {
    const declaration = await getImportDeclaration(orderId);
    
    // Poll customs office API
    const officialStatus = await getCustumOfficeStatus(declaration.declId);
    
    return {
      orderId,
      status: officialStatus.status,  // PENDING, UNDER_REVIEW, CLEARED, HOLD
      lastUpdate: officialStatus.timestamp,
      
      // If hold
      holdReason?: officialStatus.holdReason,
      inspectionRequired?: officialStatus.inspectionRequired,
      documentsRequested?: officialStatus.missingDocs,
      
      // If cleared
      releaseOrderNumber?: officialStatus.releaseOrder,
      clearedAt?: officialStatus.clearedAt,
    };
  }
  
  // 6.3 Schedule Final Delivery
  async scheduleDelivery(orderId: string, delivery: DeliveryRequest): Promise<DeliverySchedule> {
    // Can only schedule if customs cleared
    const clearanceStatus = await monitorClearanceStatus(orderId);
    if (clearanceStatus.status !== 'CLEARED') {
      throw new Error('Cannot schedule delivery - customs not cleared');
    }
    
    return {
      deliveryId: generateId(),
      orderId,
      consignee: delivery.consigneeLocation,
      scheduledDate: delivery.deliveryDate,
      estimatedTimeWindow: delivery.timeWindow,
      
      deliveryAgent: delivery.agent,
      contact: delivery.contactPerson,
      
      status: 'SCHEDULED',
    };
  }
  
  // 6.4 Record Final Delivery & POD
  async recordDelivery(orderId: string, deliveryData: DeliveryInput): Promise<ProofOfDelivery> {
    const pod = {
      podId: generateId(),
      orderId,
      deliveredAt: deliveryData.timestamp,
      deliveredBy: deliveryData.agent,
      deliveredTo: deliveryData.recipientName,
      
      // Condition
      conditionOnDelivery: deliveryData.condition,  // GOOD, DAMAGED, PARTIAL
      damageLogs: deliveryData.damage,
      
      // Photos (at delivery)
      photos: deliveryData.photos,
      
      // Signature
      recipientSignature: deliveryData.signature,
      signatureDate: deliveryData.signDate,
      
      // Update order
      status: 'DELIVERED',
    };
    
    await updateOrder(orderId, {
      status: 'DELIVERED',
      deliveryDate: deliveryData.timestamp,
      phase: 'BILLING',
    });
    
    // NOW can generate Invoice & JCR
    await generateInvoice(orderId);
    await generateJCR(orderId);
    
    return pod;
  }
}

interface ImportDeclaration {
  declId: string;
  orderId: string;
  importer: string;
  importingCountry: string;
  
  hsCode: string;
  description: string;
  quantity: number;
  weight: number;
  value: number;
  
  originCountry: string;
  shipper: string;
  
  attachedDocs: { type: string; reference: string }[];
  
  status: 'SUBMITTED' | 'UNDER_REVIEW' | 'CLEARED' | 'HOLD' | 'REJECTED';
  submittedAt: Date;
}

interface ProofOfDelivery {
  podId: string;
  orderId: string;
  deliveredAt: Date;
  deliveredBy: string;
  deliveredTo: string;
  
  conditionOnDelivery: 'GOOD' | 'DAMAGED' | 'PARTIAL';
  damageLogs: string[];
  
  photos: { url: string; timestamp: Date }[];
  
  recipientSignature: string;
  signatureDate: Date;
  
  status: 'VERIFIED' | 'DISPUTED' | 'CLOSED';
}
```

---

## Module 7: Daily & Weekly Status Reporting

**Purpose:** Auto-generate DSR/WSR and share with clients in real-time

```typescript
class StatusReportingService {
  
  // 7.1 Generate Daily Status Report (DSR)
  async generateDSR(orderId: string): Promise<DailyStatusReport> {
    const order = await getOrder(orderId);
    
    // Get latest tracking from all segments
    const segmentUpdates = await Promise.all(
      order.segments.map((seg) => trackSegment(seg.segmentId))
    );
    
    // Calculate KPIs
    const kpis = await calculateOrderKPIs(orderId);
    
    const dsr = {
      dsrId: generateId(),
      orderId,
      reportDate: new Date(),
      reportTime: '17:00',
      
      // Current status
      currentPhase: order.phase,
      currentStatus: order.status,
      currentLocation: segmentUpdates[0]?.currentLocation || order.origin.code,
      
      // Progress
      eta: segmentUpdates[segmentUpdates.length - 1]?.eta,
      etaLocation: order.destination.code,
      
      // KPI Assessment
      daysInPickup: kpis.daysInPickup,
      daysSinceDeparture: kpis.daysSinceDeparture,
      onTimeStatus: kpis.onTimeStatus,
      
      // Timeline
      milestones: {
        scheduledVsActual: [
          { phase: 'PICKUP', scheduled: order.pickupDate, actual: order.actualPickupDate },
          { phase: 'DEPARTURE', scheduled: order.segments[0].estimatedDeparture, actual: order.segments[0].actualDeparture },
          { phase: 'ARRIVAL', scheduled: order.segments[order.segments.length - 1].estimatedArrival, actual: order.segments[order.segments.length - 1].actualArrival },
        ],
      },
      
      // Incidents
      incidents: segmentUpdates.flatMap((seg) => seg.incidents || []),
      
      // Next actions
      nextMilestone: getNextMilestone(order),
      upcomingActions: generateUpcomingActions(order),
      
      status: 'GENERATED',
    };
    
    return dsr;
  }
  
  // 7.2 Send DSR to Client (Auto-scheduled for 17:00 daily)
  async sendDSRToClient(orderId: string): Promise<void> {
    const order = await getOrder(orderId);
    const dsr = await generateDSR(orderId);
    
    // Format for email
    const emailHTML = formatDSREmail(dsr);
    
    // Send to client
    await emailService.send({
      to: order.clientEmail,
      cc: order.coordinatorEmail,
      subject: `Daily Status Update - ${order.orderReference}`,
      html: emailHTML,
    });
    
    dsr.sentToClient = true;
    dsr.sentAt = new Date();
    await saveDSR(dsr);
  }
  
  // 7.3 Generate Weekly Status Report (WSR)
  async generateWSR(startDate: Date, endDate: Date): Promise<WeeklyStatusReport> {
    const orders = await getOrdersUpdatedBetween(startDate, endDate);
    
    // Aggregate stats
    const stats = {
      totalOrders: orders.length,
      ordersDelivered: orders.filter((o) => o.status === 'DELIVERED').length,
      ordersInTransit: orders.filter((o) => o.status === 'IN_TRANSIT').length,
      ordersDelayed: orders.filter((o) => isDelayed(o)).length,
      
      avgLeadTime: calculateAverage(orders.map((o) => o.totalLeadTime)),
      onTimePercentage: (
        orders.filter((o) => o.actualArrival <= o.estimatedArrival).length / orders.length
      ) * 100,
      
      // Revenue
      totalRevenue: orders.reduce((sum, o) => sum + o.costs.total, 0),
      avgRevenuePerOrder: orders.reduce((sum, o) => sum + o.costs.total, 0) / orders.length,
      
      // Incidents
      totalIncidents: orders.flatMap((o) => o.incidents).length,
      incidentTypes: groupIncidentsByType(orders),
    };
    
    return {
      wsrId: generateId(),
      weekStart: startDate,
      weekEnd: endDate,
      generatedAt: new Date(),
      
      summary: stats,
      detailedOrders: orders.map((o) => ({
        reference: o.orderReference,
        status: o.status,
        leadTime: o.totalLeadTime,
        onTime: o.actualArrival <= o.estimatedArrival,
        incidents: o.incidents,
      })),
    };
  }
  
  // 7.4 Schedule Automatic DSR Generation (Cron job)
  async scheduleAutoDSR(): Promise<void> {
    // Every day at 17:00 UTC
    cron.schedule('0 17 * * *', async () => {
      const activeOrders = await getActiveOrders();  // IN_TRANSIT, CUSTOMS_HOLD, etc
      
      for (const order of activeOrders) {
        try {
          await sendDSRToClient(order.orderId);
        } catch (error) {
          console.error(`Failed to send DSR for ${order.orderId}:`, error);
        }
      }
    });
  }
}

interface DailyStatusReport {
  dsrId: string;
  orderId: string;
  reportDate: Date;
  reportTime: string;
  
  currentPhase: OrderPhase;
  currentStatus: OrderStatus;
  currentLocation?: string;
  
  eta: Date;
  etaLocation: string;
  
  daysInPickup: number;
  daysSinceDeparture: number;
  onTimeStatus: 'ON_TIME' | 'AT_RISK' | 'DELAYED';
  
  milestones: {
    phase: string;
    scheduled: Date;
    actual?: Date;
  }[];
  
  incidents: Incident[];
  
  nextMilestone: string;
  upcomingActions: string[];
  
  sentToClient: boolean;
  sentAt?: Date;
}

interface WeeklyStatusReport {
  wsrId: string;
  weekStart: Date;
  weekEnd: Date;
  generatedAt: Date;
  
  summary: {
    totalOrders: number;
    ordersDelivered: number;
    ordersInTransit: number;
    ordersDelayed: number;
    avgLeadTime: number;
    onTimePercentage: number;
    totalRevenue: number;
    avgRevenuePerOrder: number;
    totalIncidents: number;
    incidentTypes: { [type: string]: number };
  };
  
  detailedOrders: {
    reference: string;
    status: OrderStatus;
    leadTime: number;
    onTime: boolean;
    incidents: Incident[];
  }[];
}
```

**DSR Templates (from Weekly Status Report file):**
```
Daily Status Report (DSR) Fields:
├─ Order reference: SNIM-26020001
├─ Current status: IN_TRANSIT
├─ Current location: Istanbul (IST)
├─ ETA: 2025-03-10
├─ Days in pickup: 3
├─ Days since departure: 4
├─ On-time status: ON_TIME
├─ Last action: Arrived IST consolidation hub
├─ Next milestone: Depart IST for JNB
├─ Incidents: None
└─ Upcoming actions: 1. Transfer to JNB flight, 2. Monitor weather

Frequency: Daily (auto-generated at 17:00 UTC)
Recipients: Client, Coordinator, Management
Format: Email HTML + PDF attachment
```

---

## Module 8: Financial Management & Invoicing

**Purpose:** Generate invoices, track payments, manage VAT

```typescript
class FinancialService {
  
  // 8.1 Generate Invoice (Post-Delivery)
  async generateInvoice(orderId: string): Promise<Invoice> {
    const order = await getOrder(orderId);
    const pod = await getProofOfDelivery(orderId);
    
    // Can only invoice after delivery
    if (order.status !== 'DELIVERED') {
      throw new Error('Order must be delivered before invoicing');
    }
    
    // Get cost breakdown from PFI
    const costs = order.costs;
    
    const invoice = {
      invoiceId: generateId(),
      orderId,
      invoiceNumber: `INV-${getCurrentYear()}-${generateSequence()}`,  // INV-2025-00142
      
      invoiceDate: new Date(),
      
      // Party details
      invoicedTo: order.clientName,
      invoicedToAddress: order.clientAddress,
      invoiceFrom: 'LSCM Ltd',
      invoiceFromAddress: 'LSCM Headquarters',
      
      // Line items
      lineItems: [
        {
          description: 'Freight charges',
          quantity: 1,
          unitPrice: costs.serviceCharges,
          amount: costs.serviceCharges,
        },
        {
          description: 'Handling & documentation',
          quantity: 1,
          unitPrice: costs.handlingFees,
          amount: costs.handlingFees,
        },
        {
          description: 'Customs & regulatory',
          quantity: 1,
          unitPrice: costs.customsFees || 0,
          amount: costs.customsFees || 0,
        },
        {
          description: 'Insurance',
          quantity: 1,
          unitPrice: costs.insurance || 0,
          amount: costs.insurance || 0,
        },
      ],
      
      subtotal: costs.serviceCharges + costs.handlingFees + (costs.customsFees || 0) + (costs.insurance || 0),
      vat: costs.vat,  // 7.5%
      total: costs.total,
      currencyCode: order.currencyCode,
      
      // Payment terms
      dueDate: addDays(new Date(), 30),  // Net 30
      paymentTerms: 'Net 30 days',
      
      // Bank details (from Access Bank)
      bankDetails: {
        bankName: 'Access Bank',
        accountName: 'LSCM Ltd',
        accountNumber: '1234567890',  // From config
        bankCode: '044',
        swiftCode: 'ABNGNGLA',
      },
      
      // Status
      status: 'ISSUED',
      issuedAt: new Date(),
      issuedBy: 'SYSTEM',
      
      // Tracking
      sentAt: null,
      sentTo: null,
      paidAmount: 0,
      paidDate: null,
      paymentReference: null,
    };
    
    // Generate PDF
    const pdfUrl = await generateInvoicePDF(invoice);
    invoice.fileUrl = pdfUrl;
    
    // Save invoice
    await saveInvoice(invoice);
    
    // Notify client
    await notifyClientOfInvoice(orderId, invoice);
    
    return invoice;
  }
  
  // 8.2 Send Invoice to Client
  async sendInvoiceToClient(invoiceId: string): Promise<void> {
    const invoice = await getInvoice(invoiceId);
    const order = await getOrder(invoice.orderId);
    
    const emailHTML = formatInvoiceEmail(invoice);
    
    await emailService.send({
      to: order.clientEmail,
      subject: `Invoice ${invoice.invoiceNumber} - ${order.orderReference}`,
      html: emailHTML,
      attachments: [
        {
          filename: `${invoice.invoiceNumber}.pdf`,
          path: invoice.fileUrl,
        },
      ],
    });
    
    invoice.sentAt = new Date();
    invoice.sentTo = order.clientEmail;
    await saveInvoice(invoice);
  }
  
  // 8.3 Record Payment (Access Bank Integration)
  async recordPayment(invoiceId: string, payment: PaymentInput): Promise<void> {
    const invoice = await getInvoice(invoiceId);
    const order = await getOrder(invoice.orderId);
    
    // Verify payment with bank
    const bankVerification = await verifyPaymentWithAccessBank({
      amount: payment.amount,
      reference: payment.reference,
      accountNumber: invoice.bankDetails.accountNumber,
    });
    
    if (!bankVerification.verified) {
      throw new Error(`Payment verification failed: ${bankVerification.reason}`);
    }
    
    // Record payment
    invoice.paidAmount = (invoice.paidAmount || 0) + payment.amount;
    invoice.paidDate = new Date();
    invoice.paymentReference = payment.reference;
    
    if (invoice.paidAmount >= invoice.total) {
      invoice.status = 'PAID';
      
      // Update order status
      await updateOrder(order.orderId, {
        status: 'PAID',
        phase: 'CLOSURE',
      });
      
      // Trigger JCR finalization
      await finalizeJCR(order.orderId);
    } else {
      invoice.status = 'PARTIAL';
    }
    
    await saveInvoice(invoice);
    
    // Notify management
    await notifyFinanceTeam(`Payment received: ${invoice.invoiceNumber}`);
  }
  
  // 8.4 Payment Follow-up & Reminders
  async schedulePaymentReminders(invoiceId: string): Promise<void> {
    const invoice = await getInvoice(invoiceId);
    
    // Reminder 1: 5 days before due
    scheduleTask(addDays(invoice.dueDate, -5), async () => {
      await sendPaymentReminder(invoice, 1);
    });
    
    // Reminder 2: 2 days before due
    scheduleTask(addDays(invoice.dueDate, -2), async () => {
      await sendPaymentReminder(invoice, 2);
    });
    
    // Escalation: On due date
    scheduleTask(invoice.dueDate, async () => {
      invoice.status = 'OVERDUE';
      await sendOverdueNotice(invoice);
      await notifyManagement(`Invoice ${invoice.invoiceNumber} is overdue`);
    });
  }
}

interface Invoice {
  invoiceId: string;
  orderId: string;
  invoiceNumber: string;  // INV-2025-00142
  
  invoiceDate: Date;
  dueDate: Date;
  paymentTerms: string;
  
  invoicedTo: string;
  invoicedToAddress: string;
  invoiceFrom: string;
  invoiceFromAddress: string;
  
  lineItems: {
    description: string;
    quantity: number;
    unitPrice: number;
    amount: number;
  }[];
  
  subtotal: number;
  vat: number;
  total: number;
  currencyCode: string;
  
  bankDetails: {
    bankName: string;
    accountName: string;
    accountNumber: string;
    bankCode: string;
    swiftCode: string;
  };
  
  fileUrl: string;
  status: 'DRAFT' | 'ISSUED' | 'SENT' | 'PARTIAL' | 'PAID' | 'OVERDUE';
  issuedAt: Date;
  issuedBy: string;
  
  sentAt?: Date;
  sentTo?: string;
  
  paidAmount: number;
  paidDate?: Date;
  paymentReference?: string;
}

interface PaymentInput {
  amount: number;
  reference: string;                  // Bank transaction reference
  bankName: string;
  paymentDate: Date;
  notes?: string;
}
```

**Invoice Template (from PFI MTO-EGI106):**
```
Invoice Structure:
├─ Header: LSCM Ltd, Address, Tax ID
├─ Bill To: Client name, address, reference
├─ Line items:
│  ├─ Freight charges (base rate)
│  ├─ Handling & documentation
│  ├─ Customs & regulatory fees
│  └─ Insurance (if applicable)
├─ VAT calculation: 7.5% of subtotal
├─ Bank details: Access Bank account
├─ Payment terms: Net 30 days
└─ Attachments: POD, SR, JCR documents
```

---

## Module 9: Job Completion Report (JCR)

**Purpose:** Final consolidation of all shipment documents and closure

```typescript
class JobCompletionService {
  
  // 9.1 Generate JCR (Post-Delivery)
  async generateJCR(orderId: string): Promise<JobCompletionReport> {
    const order = await getOrder(orderId);
    
    // Collect all documents
    const documents = await getOrderDocuments(orderId);
    const pod = await getProofOfDelivery(orderId);
    const invoice = await getInvoice(orderId);
    const survey = await getSurveyReport(orderId);
    const dsr = await getLatestDSR(orderId);
    
    const jcr = {
      jcrId: generateId(),
      orderId,
      jcrNumber: `JCR-${getCurrentYear()}-${generateSequence()}`,
      jcrDate: new Date(),
      
      // Summary
      orderReference: order.orderReference,
      shipper: order.supplierName,
      consignee: order.buyerName,
      
      shipmentDetails: {
        origin: order.origin.code,
        destination: order.destination.code,
        transportMode: order.transportMode,
        totalLeadDays: calculateLeadTime(order.segments),
        actualDeparture: order.actualDeparture,
        actualArrival: order.actualArrival,
      },
      
      // Consolidated documents (MANDATORY: all must be present)
      attachedDocuments: [
        { type: 'RFC', reference: documents.find((d) => d.type === 'RFC')?.docId },
        { type: 'JEP', reference: documents.find((d) => d.type === 'JEP')?.docId },
        { type: 'CI', reference: documents.find((d) => d.type === 'CI')?.docId },
        { type: 'PL', reference: documents.find((d) => d.type === 'PL')?.docId },
        { type: 'BL', reference: documents.find((d) => d.type === 'BL')?.docId },
        { type: 'SR', reference: survey?.surveyId },
        { type: 'POD', reference: pod?.podId },
        { type: 'CUSTOMS_EXPORT', reference: documents.find((d) => d.type === 'CUSTOMS_DECL')?.docId },
        { type: 'CUSTOMS_IMPORT', reference: documents.find((d) => d.type === 'IMPORT_DECL')?.docId },
        { type: 'INVOICE', reference: invoice?.invoiceId },
      ],
      
      // KPI Summary
      kpis: {
        daysInPickup: dsr?.daysInPickup,
        daysInTransit: dsr?.daysSinceDeparture,
        totalLeadTime: order.segments.reduce((sum, seg) => sum + calculateSegmentDays(seg), 0),
        onTime: order.actualArrival <= order.estimatedArrival,
        costVariance: (order.actualCost - order.estimatedCost) / order.estimatedCost,
      },
      
      // Financial summary
      financial: {
        chargeWeight: order.weight.gross,
        rateApplied: calculateRate(order),
        serviceCharges: order.costs.serviceCharges,
        vat: order.costs.vat,
        total: order.costs.total,
        invoiced: invoice?.invoiceNumber,
        paid: invoice?.status === 'PAID',
        paymentReference: invoice?.paymentReference,
      },
      
      // Incidents (if any)
      incidents: dsr?.incidents || [],
      
      // Status
      status: 'FINALIZED',
      finalizedAt: new Date(),
      finalizedBy: 'SYSTEM',
    };
    
    // Generate PDF
    const pdfUrl = await generateJCRPDF(jcr);
    jcr.fileUrl = pdfUrl;
    
    // Save JCR
    await saveJCR(jcr);
    
    // Update order to CLOSED
    await updateOrder(orderId, {
      status: 'CLOSED',
      jcrId: jcr.jcrId,
    });
    
    // Send JCR to client
    await sendJCRToClient(orderId, jcr);
    
    return jcr;
  }
  
  // 9.2 Send JCR to Client
  async sendJCRToClient(orderId: string, jcr: JobCompletionReport): Promise<void> {
    const order = await getOrder(orderId);
    
    const emailHTML = formatJCREmail(jcr);
    
    await emailService.send({
      to: order.clientEmail,
      cc: order.coordinatorEmail,
      subject: `Job Completion Report - ${order.orderReference}`,
      html: emailHTML,
      attachments: [
        {
          filename: `${jcr.jcrNumber}.pdf`,
          path: jcr.fileUrl,
        },
      ],
    });
  }
  
  // 9.3 Close Order
  async closeOrder(orderId: string): Promise<void> {
    const order = await getOrder(orderId);
    
    // Validate all requirements
    if (order.status !== 'PAID') {
      throw new Error('Order must be fully paid before closure');
    }
    
    if (!order.jcrId) {
      throw new Error('JCR must be finalized before closure');
    }
    
    // Update order
    await updateOrder(orderId, {
      status: 'CLOSED',
      closedAt: new Date(),
      phase: 'CLOSURE',
    });
    
    // Archive all documents
    const docs = await getOrderDocuments(orderId);
    docs.forEach((doc) => {
      doc.status = 'ARCHIVED';
    });
    
    // Send closure notification
    await notifyClientOfClosure(orderId);
    await notifyManagementOfClosure(orderId);
  }
}

interface JobCompletionReport {
  jcrId: string;
  orderId: string;
  jcrNumber: string;
  jcrDate: Date;
  
  orderReference: string;
  shipper: string;
  consignee: string;
  
  shipmentDetails: {
    origin: string;
    destination: string;
    transportMode: string;
    totalLeadDays: number;
    actualDeparture: Date;
    actualArrival: Date;
  };
  
  attachedDocuments: {
    type: string;
    reference: string;
  }[];
  
  kpis: {
    daysInPickup: number;
    daysInTransit: number;
    totalLeadTime: number;
    onTime: boolean;
    costVariance: number;
  };
  
  financial: {
    chargeWeight: number;
    rateApplied: number;
    serviceCharges: number;
    vat: number;
    total: number;
    invoiced: string;
    paid: boolean;
    paymentReference: string;
  };
  
  incidents: Incident[];
  
  fileUrl: string;
  status: 'DRAFT' | 'FINALIZED' | 'SENT' | 'ARCHIVED';
  finalizedAt: Date;
  finalizedBy: string;
}

interface Incident {
  type: string;
  description: string;
  reportedAt: Date;
  resolvedAt?: Date;
  delayHours?: number;
}
```

---

## Module 10: Integration Layer (CLEAR, SAP BW, Carriers, Banks)

**Purpose:** Connect external systems for data sync and automation

```typescript
// IntegrationService.ts
class IntegrationService {
  
  // 10.1 CLEAR API Integration
  async importOrderFromCLEAR(clearJobId: string): Promise<ShipmentOrder> {
    // Call CLEAR API
    const clearData = await clearAPIClient.getJob(clearJobId);
    
    // Map CLEAR fields to our Order model
    const order = {
      orderId: generateId(),
      orderReference: clearData.reference,
      poNumber: clearData.poNumber,
      supplierId: clearData.supplier.id,
      supplierName: clearData.supplier.name,
      buyerId: clearData.buyer.id,
      buyerName: clearData.buyer.name,
      
      commodityCode: clearData.hs_code,
      description: clearData.commodity,
      weight: {
        gross: clearData.gross_weight,
        net: clearData.net_weight,
      },
      
      origin: {
        location: clearData.origin_code,
        airport: clearData.origin_airport,
        warehouse: clearData.origin_warehouse,
      },
      
      destination: {
        location: clearData.destination_code,
        airport: clearData.destination_airport,
      },
      
      incoterm: clearData.incoterm,
      transportMode: clearData.transport_mode,
      
      // Will be populated by other services
      status: 'DRAFT',
      documents: [],
      segments: [],
    };
    
    await saveOrder(order);
    return order;
  }
  
  // 10.2 SAP BW Integration (PO Data)
  async syncPOFromSAPBW(poNumber: string): Promise<PurchaseOrderData> {
    // Call SAP BW API
    const sapData = await sapBWClient.getPurchaseOrder(poNumber);
    
    // Extract key fields
    const poData: PurchaseOrderData = {
      poNumber: sapData.PO_NUMBER,
      vendorCode: sapData.VENDOR_CODE,
      vendorName: sapData.VENDOR_NAME,
      buyerId: sapData.BUYER_ID,
      buyerName: sapData.BUYER_NAME,
      
      materials: sapData.ITEMS.map((item) => ({
        materialNumber: item.MATERIAL_NUMBER,
        description: item.DESCRIPTION,
        hsCode: item.HS_CODE,
        quantity: item.QUANTITY,
        unitPrice: item.UNIT_PRICE,
        totalValue: item.TOTAL_VALUE,
      })),
      
      grValue: sapData.GR_VALUE,        // Goods receipt value
      invoiceValue: sapData.IV_VALUE,   // Invoice value
      
      deliveryDateScheduled: sapData.DELIVERY_DATE,
      incoterm: sapData.INCOTERM,
    };
    
    return poData;
  }
  
  // 10.3 Carrier Tracking Integration
  async fetchCarrierTracking(carrierId: string, reference: string): Promise<TrackingUpdate> {
    let trackingData;
    
    if (carrierId === 'TURKISH_AIRLINES') {
      trackingData = await turkishAirlinesAPI.getFlightStatus(reference);
    } else if (carrierId === 'MSC') {
      trackingData = await mscAPI.getShipmentStatus(reference);
    } else if (carrierId === 'FEDEX') {
      trackingData = await fedexAPI.getPackageTracking(reference);
    } else {
      throw new Error(`Unsupported carrier: ${carrierId}`);
    }
    
    return {
      reference,
      status: trackingData.status,
      location: trackingData.currentLocation,
      timestamp: trackingData.lastUpdate,
      eta: trackingData.estimatedArrival,
      departureActual: trackingData.departureActual,
      arrivalActual: trackingData.arrivalActual,
      incidents: trackingData.incidents || [],
    };
  }
  
  // 10.4 Bank Integration (Access Bank)
  async verifyPaymentWithAccessBank(payment: PaymentVerification): Promise<PaymentVerificationResult> {
    const result = await accessBankAPI.verifyDeposit({
      accountNumber: payment.accountNumber,
      amount: payment.amount,
      reference: payment.reference,
      dateRange: { from: subDays(new Date(), 5), to: new Date() },
    });
    
    return {
      verified: result.found,
      amount: result.amount,
      depositDate: result.date,
      transactionId: result.txn_id,
      reason: result.reason,
    };
  }
  
  // 10.5 Data Sync (Bidirectional)
  async syncOrderToCLEAR(orderId: string): Promise<void> {
    const order = await getOrder(orderId);
    
    // Update CLEAR job with our latest status
    await clearAPIClient.updateJob(order.orderReference, {
      status: order.status,
      phase: order.phase,
      estimatedArrival: order.segments[order.segments.length - 1]?.estimatedArrival,
      actualArrival: order.segments[order.segments.length - 1]?.actualArrival,
      documents: order.documents.map((doc) => ({
        type: doc.type,
        reference: doc.documentNumber,
        status: doc.status,
      })),
    });
  }
}

interface PurchaseOrderData {
  poNumber: string;
  vendorCode: string;
  vendorName: string;
  buyerId: string;
  buyerName: string;
  
  materials: {
    materialNumber: string;
    description: string;
    hsCode: string;
    quantity: number;
    unitPrice: number;
    totalValue: number;
  }[];
  
  grValue: number;
  invoiceValue: number;
  
  deliveryDateScheduled: Date;
  incoterm: string;
}

interface TrackingUpdate {
  reference: string;
  status: string;
  location: string;
  timestamp: Date;
  eta: Date;
  departureActual?: Date;
  arrivalActual?: Date;
  incidents: Incident[];
}

interface PaymentVerification {
  accountNumber: string;
  amount: number;
  reference: string;
}

interface PaymentVerificationResult {
  verified: boolean;
  amount: number;
  depositDate: Date;
  transactionId: string;
  reason: string;
}
```

---

# 5. KEY WORKFLOWS (END-TO-END)

## Workflow A: Air Freight Order (SNIM)

```
SNIM Air Freight: NKC → IST → JNB (7-10 days)

[T+0] Order Received
├─ Import SNIM PO from SAP BW
├─ Create Order (DRAFT)
└─ Auto-generate RFC, JEP, SM

[T+1] Pickup Scheduled
├─ Send RFC to supplier
├─ Coordinator contacts supplier
└─ Pickup agent confirmed

[T+2] Pickup Executed
├─ POC recorded with photos (min 2 per package)
├─ Material transported to LSCM hub
├─ Hub reception & QC
└─ Update order status: PICKED_UP

[T+3] Export Preparation
├─ Export declaration submitted
├─ Request Green Light approval (3-party)
│  ├─ CLIENT approves PFI + JEP
│  ├─ CUSTOMS BROKER validates docs
│  └─ CARRIER confirms space
└─ Pre-alert sent to JNB receiver

[T+4] Loading
├─ Loading scheduled at departure hub
├─ Survey Report generated + photos (min 2 per package)
├─ Airway Bill (AWB) issued by carrier
└─ Shipment ready for departure

[T+5-6] Transit
├─ Departure: NKC → IST consolidation
├─ Daily tracking updates (DSR at 17:00)
├─ At IST: Transfer to JNB flight
└─ ETA updates sent to client

[T+7] Arrival at Destination
├─ Shipment arrives JNB
├─ Import customs clearance initiated
├─ PAAR/customs broker engagement
└─ Physical inspection (if required)

[T+8] Import Clearance
├─ Customs clears shipment
├─ Release order issued
└─ Ready for final delivery

[T+9] Final Delivery
├─ Delivery scheduled with consignee
├─ POD signed (waybill becomes proof of delivery)
├─ Order status: DELIVERED
└─ Invoice generated

[T+10] Financial Closure
├─ Invoice sent to SNIM
├─ JCR (Job Completion Report) generated
├─ Payment reminder (Day 25, Day 28, Day 30+)
├─ Payment received via Access Bank
└─ Order status: CLOSED, all documents archived
```

## Workflow B: Sea Freight Consolidation (LADOL Free Zone)

```
LADOL Sea Consolidation: 20+ suppliers → Free Zone → Global

[T+0-2] Order Aggregation
├─ Receive 20+ individual RFCs from various suppliers
├─ Central pickup coordination from LADOL hub
├─ Each supplier's cargo marked with SM
└─ All materials converge at LADOL warehouse

[T+3-10] Hub Consolidation
├─ Quality inspection of all consolidated cargo
├─ Consolidation planning (CBM optimization)
├─ Final weight & dimension verification
├─ Customs preparation for export
└─ Container stuffing + sealing

[T+11] Export Declaration
├─ Consolidated export declaration filed
├─ Includes all 20+ supplier invoices
├─ Green Light approval from all parties
└─ Pre-alert to multiple global consignees

[T+12] Loading & Departure
├─ Container loaded on vessel
├─ Survey report + photos (min 2 per consolidated package)
├─ Bill of Lading issued (multi-consignee)
└─ Vessel departure

[T+13-35] Sea Transit (22 days)
├─ Weekly Status Reports (WSR) sent to clients
├─ ETA updates as vessel progresses
├─ Track through Suez Canal, Indian Ocean, etc
└─ Arrival at multiple global ports (staggered)

[T+36-40] Import & Destuffing
├─ Container arrives first destination
├─ Import customs clearance
├─ Container destuffed
├─ Individual shipments separated
└─ Each cargo gets its own POD

[T+41-60] Final Delivery (Multi-consignee)
├─ Each shipment delivered to respective consignee
├─ Individual PODs collected
└─ Final invoices consolidated

[T+61] Closure
├─ Master JCR generated (covers all 20+ sub-orders)
├─ Master invoice to LADOL (consolidation fee + individual charges)
├─ Payment tracking for all parties
└─ Archive consolidated documentation
```

---

# 6. INTEGRATION LAYER ARCHITECTURE

```
┌─────────────────────────────────────────────────────────────────┐
│                         ERP CORE                                 │
├─────────────────────────────────────────────────────────────────┤
│  Order | Document | Pickup | Customs | Transport | Invoice | JCR│
└─────────────────────────────────────────────────────────────────┘
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
   ┌────▼────┐        ┌───▼────┐       ┌────▼─────┐
   │ CLEAR   │        │ SAP BW │       │ Carriers │
   │ API     │        │ API    │       │ API      │
   └────┬────┘        └───┬────┘       └────┬─────┘
        │                  │                │
   ┌────▼──────────────────▼─────────────────▼──────┐
   │         Integration Service Layer              │
   ├──────────────────────────────────────────────┤
   │  Import/Export | SAP Sync | Tracking | Bank  │
   └──────────────────────────────────────────────┘
        │
        └──────────────────────────┐
                                   │
                          ┌────────▼────────┐
                          │  Access Bank API│
                          └────────────────┘
```

**API Endpoints Required:**

```typescript
// CLEAR Integration
POST   /api/integrations/clear/import-job     // Import job from CLEAR
PUT    /api/integrations/clear/sync-order     // Sync order status back to CLEAR
GET    /api/integrations/clear/job/:id        // Get CLEAR job details

// SAP BW Integration
GET    /api/integrations/sap-bw/purchase-order/:po  // Get PO data
GET    /api/integrations/sap-bw/vendor/:code       // Get vendor master
GET    /api/integrations/sap-bw/material/:code     // Get material master

// Carrier Tracking
GET    /api/integrations/carriers/tracking/:carrier/:ref  // Get real-time tracking
POST   /api/integrations/carriers/webhook              // Carrier webhook (status update)

// Bank Payment Verification
POST   /api/integrations/bank/verify-payment    // Verify deposit with Access Bank
GET    /api/integrations/bank/account-details   // Get bank account info for invoices
```

---

# 7. TECHNOLOGY STACK

## Backend Architecture

```
┌─────────────────────────────────────────┐
│   API Layer (Node.js + Express/NestJS)  │
├─────────────────────────────────────────┤
│   Services (TypeScript OOP)             │
│   - OrderService                        │
│   - DocumentService                     │
│   - CustomsService                      │
│   - FinancialService                    │
│   - IntegrationService                  │
├─────────────────────────────────────────┤
│   Data Layer (TypeORM/Prisma)           │
├─────────────────────────────────────────┤
│   PostgreSQL Database                   │
│   - Orders, Documents, Invoices,        │
│   - DSR, JCR, Segments, etc             │
└─────────────────────────────────────────┘
```

## Frontend Architecture

```
┌─────────────────────────────────────────┐
│    React.js + TypeScript                │
├─────────────────────────────────────────┤
│   Pages                                 │
│   - Dashboard (KPI overview)            │
│   - Orders (list + detail view)         │
│   - Documents (upload + generate)       │
│   - Tracking (real-time map)            │
│   - Invoices (send + track payment)     │
│   - DSR Archive (daily reports)         │
├─────────────────────────────────────────┤
│   UI Components (Tailwind CSS)          │
│   - Form builders                       │
│   - Data tables                         │
│   - Timeline views                      │
│   - Status indicators                   │
│   - Document viewers (PDF)              │
├─────────────────────────────────────────┤
│   State Management (Redux/Zustand)      │
│   - Order state                         │
│   - Document cache                      │
│   - Authentication                      │
└─────────────────────────────────────────┘
```

## Deployment Architecture

```
┌──────────────────────────────────┐
│     Docker Containers            │
├──────────────────────────────────┤
│ ┌────────┐  ┌───────┐  ┌──────┐ │
│ │Backend │  │ DB    │  │Redis │ │
│ │ (Node) │  │(Postgres)│Cache │ │
│ └────────┘  └───────┘  └──────┘ │
└──────────────────────────────────┘
          │
    ┌─────▼─────┐
    │ Docker    │
    │ Compose   │
    └───────────┘
          │
    ┌─────▼──────────────┐
    │ Kubernetes / AWS   │
    │ ECS / DigitalOcean │
    └────────────────────┘
```

## Tech Stack Selection

```
✅ Backend: Node.js 20 + TypeScript + Express/NestJS
✅ Frontend: React 18 + TypeScript + Tailwind CSS
✅ Database: PostgreSQL 15 + Redis cache
✅ ORM: Prisma or TypeORM
✅ Testing: Jest + Supertest
✅ Documentation: OpenAPI/Swagger
✅ DevOps: Docker + GitHub Actions + GitLab CI
✅ Monitoring: Prometheus + Grafana + Sentry
✅ Email: SendGrid or AWS SES
✅ File Storage: AWS S3 or MinIO (self-hosted)
✅ PDF Generation: puppeteer or pdfkit
```

---

# 8. KPIs & SLAs

## Critical KPIs (from Weekly Status Report)

```
PICKUP KPI
├─ Target: ≤ 5 days from order creation to pickup
├─ Current Performance: 4.2 days (SNIM), 5.1 days (EGI)
├─ Alert: > 6 days → Escalate to management
└─ Impact: Delay in downstream customs & freight booking

GREEN LIGHT KPI
├─ Target: ≤ 14 days from pickup to GL approval
├─ Metric: Days in EXPORT_CUSTOMS phase
├─ Alert: > 16 days → Review bottleneck (customs? client approval?)
└─ Impact: Blocks loading & departure

SEA DELIVERY KPI
├─ Target: ≤ 70 days total (pickup to delivery)
├─ Breakdown:
│  ├─ Pickup: 5 days
│  ├─ Export customs: 7 days
│  ├─ Booking: 3 days
│  ├─ Loading: 2 days
│  ├─ Sea transit: 35 days
│  ├─ Import customs: 7 days
│  ├─ Final delivery: 2 days
│  └─ Buffer: 12 days
└─ Current: 68 days avg (On track)

AIR DELIVERY KPI
├─ Target: ≤ 20 days total
├─ Current: 19 days avg (Good)
└─ Most reliable service for SNIM

ON-TIME DELIVERY RATE
├─ Target: ≥ 98%
├─ Current: 96.5% (SNIM), 94.2% (EGI), 97.1% (Overall)
├─ Alert: < 95% → Root cause analysis
└─ Top delay causes: Customs hold, weather, carrier delay

COST VARIANCE
├─ Target: ± 5% variance from quoted costs
├─ Current: +3.2% (within tolerance)
├─ Tracking: Fuel surcharge, customs fees, warehousing
└─ Alert: > ±10% → Price review with partners

PAYMENT RECOVERY RATE
├─ Target: 100% payment within 30 days
├─ Current: 92% (5% overdue, 3% outstanding)
├─ Days to payment: 28 days avg
├─ Alert: Invoice overdue by 5 days → Send reminder
└─ Overdue > 30 days → Escalate to management

CONSOLIDATION UTILIZATION (LADOL)
├─ Target: ≥ 85% container/vehicle utilization
├─ Current: 88% (sea), 76% (air) 
├─ Impact: Cost per unit shipped
└─ Improvement: Better forecasting, flex scheduling
```

## Service Level Agreement (SLA) Tiers

```
TIER 1: EXPRESS (Air Freight, SNIM)
├─ Pickup: 2 days (guaranteed)
├─ Green Light: 5 days (fast-track approval)
├─ Transit: 7-10 days
├─ Total: 14-17 days
├─ Pricing: Premium (+25%)
└─ SLA: 99% on-time, compensation if missed

TIER 2: STANDARD (Sea Freight)
├─ Pickup: 5 days
├─ Green Light: 14 days
├─ Transit: 35 days (sea) + customs
├─ Total: 50-70 days
├─ Pricing: Base rate
└─ SLA: 95% on-time, written explanation if delayed > 5 days

TIER 3: ECONOMY (Consolidation, LADOL)
├─ Pickup: 5 days (aggregated from 20+ suppliers)
├─ Green Light: 7 days (bundled approval)
├─ Transit: 45 days (sea consolidation)
├─ Total: 57-70 days
├─ Pricing: Discounted (-20%)
└─ SLA: 90% on-time, best-effort basis (shared capacity)
```

## Dashboard Monitoring

```
Real-Time KPI Dashboard (for management):
├─ Active Orders:
│  ├─ Count by status (DRAFT, IN_TRANSIT, DELIVERED, etc)
│  ├─ Count by phase (PICKUP, CUSTOMS, DELIVERY, etc)
│  └─ Count by delay status (ON_TIME, AT_RISK, DELAYED)
│
├─ Timeline Metrics:
│  ├─ Avg days in PICKUP phase (target ≤ 5)
│  ├─ Avg days in CUSTOMS phase (target ≤ 14)
│  ├─ Avg total lead time (target ≤ 70 for sea)
│  └─ On-time delivery % (target ≥ 95%)
│
├─ Financial Metrics:
│  ├─ Revenue (YTD, MTD, weekly)
│  ├─ Invoiced vs Paid ratio
│  ├─ Average invoice value
│  ├─ Cost variance (actual vs estimated)
│  └─ Overdue invoices (aging)
│
├─ Operational Metrics:
│  ├─ Cargo volume (weight, CBM)
│  ├─ Consolidation utilization (%)
│  ├─ Incident count (delays, holds, damage)
│  └─ Customer satisfaction score
│
└─ Alerts:
   ├─ Order delayed > target → RED
   ├─ Invoice overdue > 30 days → RED
   ├─ Customs hold > 5 days → YELLOW
   ├─ No payment activity > 45 days → RED
   └─ High cost variance > 10% → YELLOW
```

---

# 9. IMPLEMENTATION ROADMAP (5 Phases)

## Phase 0: Foundation (Week 1-4) - COMPLETED

```
✅ Core Data Model (Order, Document, Segment)
✅ Order Management Module
✅ Document auto-generation (RFC, JEP, SM)
✅ Status tracking
✅ Database schema (PostgreSQL)
✅ API skeleton
```

## Phase 1A: Core Logistics (Week 5-12) - NEXT

```
□ Pickup & Collection module
├─ POC (Proof of Collection) recording
├─ Photo management (min 2 per package validation)
├─ Hub reception & QC
└─ Weight/dimension verification

□ Export Customs & Green Light
├─ Export declaration submission
├─ 3-party approval workflow (CLIENT + BROKER + CARRIER)
├─ Blocking logic (order stuck until all 3 approve)
└─ Pre-alert generation

□ Transportation module
├─ Carrier booking
├─ Loading/stuffing schedule
├─ Survey Report + loading photos
├─ Real-time tracking integration
└─ Segment status updates

□ DSR Automation
├─ Daily report generation (auto at 17:00)
├─ Email delivery to clients
├─ Client acknowledgment tracking
└─ Archive old DSR

Deliverables:
- Functional code (TypeScript)
- Database migrations
- API endpoints (30+)
- User documentation
- Test coverage (60%+)
```

## Phase 1B: Financial (Week 13-18)

```
□ Invoice Management
├─ Auto-invoice post-delivery
├─ Line items from PFI (freight, handling, customs, insurance)
├─ VAT calculation (7.5%)
├─ PDF generation
└─ Email delivery

□ Payment Tracking
├─ Bank integration (Access Bank)
├─ Payment verification
├─ Receipt recording
├─ Payment reminders (auto-scheduled)
└─ Overdue escalation

□ Job Completion Report (JCR)
├─ Auto-generate post-delivery
├─ Consolidate all documents (15+)
├─ PDF generation
├─ Archive & closure
└─ Client delivery

Deliverables:
- Invoice module with PDF
- Bank integration
- JCR consolidation
- Email templates
- Payment verification
```

## Phase 1C: Integration (Week 19-24)

```
□ CLEAR API Integration
├─ Import orders from CLEAR
├─ Auto-populate from CLEAR data
├─ Sync status back to CLEAR
└─ Document repository connection

□ SAP BW Integration
├─ Fetch PO data (vendor, material, value)
├─ Auto-populate order from PO
├─ Vendor master sync
└─ Material master sync

□ Carrier Tracking
├─ Turkish Airlines API
├─ MSC (shipping) API
├─ FedEx API
├─ Real-time status updates
└─ Webhook receivers

□ Bank Integration
├─ Access Bank payment verification
├─ Deposit confirmation
├─ Payment reconciliation
└─ Account balance check

Deliverables:
- CLEAR connector
- SAP BW connector
- Carrier tracking service
- Bank API integration
- Webhook handlers
```

## Phase 2A: Advanced Features (Week 25-30)

```
□ Multi-Leg Consolidation
├─ LADOL hub support
├─ Consolidation planning
├─ CBM optimization
├─ Multi-consignee routing
└─ Destuffing workflow

□ Advanced Customs
├─ Multiple customs declarations
├─ Country-specific requirements
├─ PAAR / Form M handling
├─ Duty calculation & payment
└─ Hold management

□ Analytics Dashboard
├─ KPI dashboard (real-time)
├─ Historical reports
├─ Performance by client/route
├─ Cost analysis
└─ Revenue projections

Deliverables:
- Consolidation module
- Advanced customs module
- Dashboard UI
- Analytics engine
```

## Phase 2B: Optimization (Week 31-36)

```
□ Performance Optimization
├─ Database indexing
├─ Query optimization
├─ Caching strategy (Redis)
├─ API rate limiting
└─ Load testing

□ Monitoring & Alerting
├─ Prometheus metrics
├─ Grafana dashboards
├─ Sentry error tracking
├─ Slack notifications
└─ Health checks

□ Documentation & Training
├─ API documentation (Swagger)
├─ User guides
├─ Admin guides
├─ Video tutorials
└─ Team training

Deliverables:
- Optimized codebase
- Monitoring setup
- Complete documentation
- Training materials
```

---

# 10. RISK REGISTER

## Critical Risks

| Risk | Probability | Impact | Mitigation | Owner |
|------|-------------|--------|-----------|-------|
| **CLEAR API Instability** | MEDIUM | HIGH | Cache CLEAR data locally, fallback to manual entry | Integration Lead |
| **SAP BW Data Quality** | MEDIUM | MEDIUM | Validation rules, duplicate detection, manual review | SAP Lead |
| **Customs Hold (Unexpected)** | MEDIUM | MEDIUM | Communication plan, escalation process, customer notification | Customs Broker |
| **Payment Default** | LOW | HIGH | Payment terms clarity, follow-up system, escalation | Finance |
| **Data Loss** | LOW | CRITICAL | Daily backups, replication, disaster recovery plan | DBA |
| **Security Breach** | LOW | CRITICAL | Encryption, access controls, audit logs, penetration testing | Security |

## Operational Risks

```
PICKUP DELAYS
├─ Cause: Supplier not ready, documentation incomplete
├─ Impact: Cascade delays in customs, freight booking
├─ Mitigation: 48h pre-pickup confirmation, doc checklist
└─ Owner: Coordinator

CUSTOMS HOLDS
├─ Cause: Missing docs, commodity classification issue
├─ Impact: 3-5 day delay
├─ Mitigation: Pre-submission review, customs broker liaison
└─ Owner: Customs Broker

GREEN LIGHT FAILURE (3-party not approved)
├─ Cause: Client doesn't approve PFI, slow response
├─ Impact: Order stuck, freight booking jeopardized
├─ Mitigation: 24h deadline, reminder emails, escalation
└─ Owner: Coordinator

CARRIER CAPACITY
├─ Cause: Flight/vessel full, overbooking
├─ Impact: Delay in departure
├─ Mitigation: Early booking (T+5), flexible scheduling
└─ Owner: Freight Coordinator

PAYMENT OVERDUE
├─ Cause: Client cash flow issue, disputes
├─ Impact: Receivables aging, cash flow pressure
├─ Mitigation: Clear payment terms, early reminders, escalation
└─ Owner: Finance
```

---

# CONCLUSION

This ERP architecture provides a **complete, production-ready system** for managing LSCM's freight forwarding operations from order creation through final payment recovery.

## Key Achievements

✅ **Based on Reality** - Built directly from CLEAR system, SAP BW integration, and real workflows  
✅ **End-to-End Coverage** - Pickup → Customs → Transit → Delivery → Invoice → JCR → Closure  
✅ **Automation-First** - Documents auto-generated, DSR automated, payment reminders automated  
✅ **Multi-Stakeholder** - Manages client, supplier, carrier, broker, customs, bank interactions  
✅ **Real-Time Tracking** - Segment-level tracking with carrier API integration  
✅ **Financial Complete** - Invoicing, VAT calculation, payment verification, overdue management  
✅ **KPI-Driven** - Dashboard monitoring, alert thresholds, performance reporting  
✅ **Scalable** - Supports single orders, consolidation (LADOL), high-volume operations  

## Next Steps

1. **Week 1-4 (Phase 0):** Deploy foundation - Order, Document, Status modules
2. **Week 5-12 (Phase 1A):** Deploy Pickup, Customs, Transport, DSR
3. **Week 13-18 (Phase 1B):** Deploy Invoice, Payment, JCR
4. **Week 19-24 (Phase 1C):** Deploy integrations (CLEAR, SAP BW, Carriers, Bank)
5. **Week 25-30 (Phase 2A):** Deploy advanced features (consolidation, analytics)
6. **Week 31-36 (Phase 2B):** Optimize, monitor, document, train

**Ready to build.** All modules defined. All workflows documented. All integrations mapped.

---

**Document prepared by:** Claude AI  
**For:** LSCM Logistics & Supply Chain Management  
**Based on:** CLEAR System Analysis + Takamul-Atomai Documentation + Real workflows  
**Status:** ✅ Ready for Phase 1A Development
