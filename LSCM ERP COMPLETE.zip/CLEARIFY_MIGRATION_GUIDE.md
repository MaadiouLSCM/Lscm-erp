# 🔗 GUIDE D'INTÉGRATION: CLEARIFY → ERP LSCM

## Objectif
Migrer 6,820 commandes de CLEARIFY Excel vers l'ERP LSCM PostgreSQL sans perte de données.

---

## 1. MAPPING DES DONNÉES

### CLEARIFY Fields → ERP Schema

#### Order Information
```
CLEARIFY              → ERP Table     → Field
───────────────────────────────────────────────────
Date of request       → Order         → createdAt
LSCM ref              → Order         → reference
PO#                   → OrderItem     → (custom field needed)
Item #                → OrderItem     → description
Nb of packages        → OrderItem     → quantity
Total weight          → Order         → totalWeight
Vendor                → Vendor        → (new table!)
Country of collect    → Order         → originCountry
MOT (Mode)            → Shipment      → mode (AIR/SEA/LAND)
PROJECT               → Order         → clientId (DW, JV, ONESUBSEA)
```

#### Document Statuses
```
CLEARIFY PHASE        → ERP Concept
─────────────────────────────────────
SETTING (Starter Kit) → Order creation
  ├─ PO               → OrderDocument (PURCHASE_ORDER)
  ├─ Vendor Invoice   → OrderDocument (VENDOR_INVOICE)
  ├─ OEM Invoice      → OrderDocument (OEM_INVOICE)
  ├─ PL               → OrderDocument (PACKING_LIST)
  ├─ RFC              → OrderDocument (REQUEST_FOR_CLEARANCE)
  └─ MSDS             → OrderDocument (HEALTH_CERTIFICATE)

QUOTING               → Order → status = QUOTING
  ├─ RFQ             → Task (type: QUOTE_REQUEST)
  ├─ Quote           → Document (QUOTE)
  └─ Approved        → Order.approvalStatus = APPROVED

COLLECTING            → Order → status = COLLECTING
  ├─ Shipping Marks  → Task (type: SHIPPING_MARKS)
  ├─ Pickup Date     → Task.startedAt
  ├─ POC             → Document (PROOF_OF_COLLECTION)
  ├─ Signed POC      → Document with signature
  ├─ CONSO/DIRECT    → Shipment.consolidationType
  └─ Alert p/u       → Task.priority = HIGH

SHIPPING              → Order → status = IN_TRANSIT
  ├─ HUB             → Shipment.logisticsPartner
  ├─ Form M          → ShipmentDocument (FORM_M)
  ├─ BL/MAWB         → ShipmentDocument (BL or MAWB)
  ├─ Ref CONSO       → Shipment.reference
  └─ Kit Clear       → Task (type: EXPORT_KIT)

REPORTING             → Order → status = DELIVERY_SCHEDULED
  ├─ Pré-alerte      → Task (type: PRE_ALERT)
  ├─ ATD             → Shipment.departureDate
  ├─ ATA             → Shipment.expectedDelivery
  └─ Agent Invoice   → Shipment.agent

BILLING               → Invoice
  ├─ Agent Invoice   → Invoice (from agent)
  ├─ Amount          → Invoice.total
  ├─ Currency        → Invoice.currency
  ├─ Invoice date    → Invoice.issuedAt
  ├─ Due date        → Invoice.dueAt
  ├─ Status          → Invoice.status
  └─ Payment date    → Payment.paidAt
```

#### Special Fields
```
CLEARIFY              → ERP        → Type
──────────────────────────────────────────
✔ / OK / Alert date  → Status      → Computed
Comments             → Task.comment → Text
PIX (Images)         → Document    → File upload
Threaded comments    → Comments    → Thread
Alert (calculated)   → Task.priority → HIGH/MEDIUM
Error reports        → AuditLog    → Incident
```

---

## 2. DATABASE SCHEMA ADDITIONS

### New Tables Needed

#### Vendor Table
```sql
CREATE TABLE Vendor (
  id STRING PRIMARY KEY,
  name STRING,
  country STRING,
  type STRING, -- Supplier, Carrier, Broker
  contactEmail STRING,
  contactPhone STRING,
  createdAt DATETIME
);
```

#### Project Table
```sql
CREATE TABLE Project (
  id STRING PRIMARY KEY,
  name STRING, -- DW, JV, ONESUBSEA
  clientId STRING REFERENCES Company(id),
  startDate DATE,
  endDate DATE,
  isActive BOOLEAN
);
```

#### Consolidation Type
```sql
ENUM ConsolidationType {
  DIRECT,
  CONSO,
  PARTIAL
}
```

#### Document Categories
```sql
ENUM DocumentCategory {
  PURCHASE_ORDER,
  VENDOR_INVOICE,
  OEM_INVOICE,
  PACKING_LIST,
  FORM_M,
  QUOTE,
  CERTIFICATE_OF_ORIGIN,
  HEALTH_CERTIFICATE,
  PHYTOSANITARY,
  ...
}
```

---

## 3. DATA MIGRATION PROCESS

### Step 1: Export from CLEARIFY

```python
# Export to CSV (no formulas)
# File: clearify_export.csv
# Columns: All 70 from DW, JV, ONESUBSEA sheets
# Format: UTF-8, CSV

import openpyxl
import csv

wb = openpyxl.load_workbook('CLEARIFY_4.xlsx')

for sheet_name in ['DW', 'JV', 'ONESUBSEA']:
    ws = wb[sheet_name]
    
    with open(f'clearify_{sheet_name}.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        
        # Headers (row 3)
        headers = []
        for col in range(1, ws.max_column + 1):
            headers.append(ws.cell(3, col).value)
        writer.writerow(headers)
        
        # Data (rows 4+)
        for row in range(4, ws.max_row + 1):
            row_data = []
            for col in range(1, ws.max_column + 1):
                cell = ws.cell(row, col)
                # Skip formulas, use values only
                value = cell.value
                if isinstance(value, str) and value.startswith('='):
                    value = None  # Skip formula
                row_data.append(value)
            writer.writerow(row_data)

print("Export complete: 3 CSV files created")
```

### Step 2: Transform Data

```python
# Transform CLEARIFY format → ERP format
# File: transform_clearify.py

import pandas as pd
from datetime import datetime
import uuid

# Read CLEARIFY data
df_dw = pd.read_csv('clearify_DW.csv')
df_jv = pd.read_csv('clearify_JV.csv')
df_onesubsea = pd.read_csv('clearify_ONESUBSEA.csv')

# Add project column
df_dw['project'] = 'DW'
df_jv['project'] = 'JV'
df_onesubsea['project'] = 'ONESUBSEA'

# Combine all
df_all = pd.concat([df_dw, df_jv, df_onesubsea], ignore_index=True)

# Create ERP Order records
orders = []

for idx, row in df_all.iterrows():
    order = {
        'id': str(uuid.uuid4()),
        'reference': row['LSCM ref'],
        'clientId': get_client_id(row['project']),  # Map DW→Total, etc
        'createdById': 'admin_user_id',
        'originCountry': get_origin_country(row),
        'destinationCountry': 'Nigeria',  # Or extract from data
        'totalWeight': float(row[' Total weight']) if pd.notna(row[' Total weight']) else 0,
        'totalVolume': 0,  # Not in CLEARIFY - use 0
        'totalValue': 0,  # Not in CLEARIFY - to be filled
        'incoterms': '',  # Not in CLEARIFY
        'preferredMode': normalize_mode(row['MOT']),  # AIR, SEA, LAND
        'description': row['Vendor'],
        'status': map_status(row),  # Infer from columns
        'createdAt': row['Date of request']
    }
    orders.append(order)

# Create ERP OrderItem records
items = []

for idx, row in df_all.iterrows():
    order_id = orders[idx]['id']
    item = {
        'id': str(uuid.uuid4()),
        'orderId': order_id,
        'description': f"Item {row['Item #']}",
        'hsCode': '',  # Not in CLEARIFY
        'quantity': float(row['Nb of packages']) if pd.notna(row['Nb of packages']) else 1,
        'unitPrice': 0,  # Not in CLEARIFY
        'weight': float(row[' Total weight']) if pd.notna(row[' Total weight']) else 0,
        'volume': 0,  # Not in CLEARIFY
    }
    items.append(item)

# Create ShipmentDocument records (for each document status)
documents = []

for idx, row in df_all.iterrows():
    order_id = orders[idx]['id']
    
    # Map each CLEARIFY column to a document
    doc_mapping = {
        'PO': ('PO', 'PURCHASE_ORDER'),
        'OEM Invoice': ('OEMIV', 'OEM_INVOICE'),
        'PL': ('PL', 'PACKING_LIST'),
        'RFC': ('RFC', 'REQUEST_FOR_CLEARANCE'),
        'MSDS': ('MSDS', 'HEALTH_CERTIFICATE'),
        'Form M': ('FM', 'FORM_M'),
        'BL/MAWB': ('BL', 'BILL_OF_LADING'),
    }
    
    for col_name, (doc_type, doc_enum) in doc_mapping.items():
        if col_name in row and pd.notna(row[col_name]):
            doc = {
                'id': str(uuid.uuid4()),
                'orderId': order_id,
                'type': doc_enum,
                'status': 'RECEIVED' if row[col_name] in ['✔', 'OK'] else 'PENDING',
                'receivedAt': row[col_name] if isinstance(row[col_name], datetime) else None
            }
            documents.append(doc)

# Export to JSON for PostgreSQL import
import json

export = {
    'orders': orders,
    'items': items,
    'documents': documents,
    'total_records': len(orders)
}

with open('clearify_transformed.json', 'w') as f:
    json.dump(export, f, indent=2, default=str)

print(f"✅ Transformed {len(orders)} orders successfully")
```

### Step 3: Load into PostgreSQL

```typescript
// src/scripts/import-clearify.ts

import { prisma } from '../index';
import * as fs from 'fs';

interface TransformedData {
  orders: any[];
  items: any[];
  documents: any[];
}

async function importClearifyData() {
  console.log('🚀 Starting CLEARIFY import...');

  // Load transformed data
  const data: TransformedData = JSON.parse(
    fs.readFileSync('clearify_transformed.json', 'utf-8')
  );

  try {
    // Import orders
    console.log(`📦 Importing ${data.orders.length} orders...`);
    for (const order of data.orders) {
      await prisma.order.create({
        data: {
          reference: order.reference,
          clientId: order.clientId,
          createdById: order.createdById,
          originCountry: order.originCountry,
          destinationCountry: order.destinationCountry,
          totalWeight: order.totalWeight,
          totalVolume: order.totalVolume,
          totalValue: order.totalValue,
          incoterms: order.incoterms,
          preferredMode: order.preferredMode,
          description: order.description,
          status: order.status,
          createdAt: new Date(order.createdAt),
        },
      });
    }
    console.log('✅ Orders imported');

    // Import items
    console.log(`📋 Importing ${data.items.length} items...`);
    for (const item of data.items) {
      await prisma.orderItem.create({
        data: {
          orderId: item.orderId,
          description: item.description,
          hsCode: item.hsCode || null,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          weight: item.weight,
          volume: item.volume,
        },
      });
    }
    console.log('✅ Items imported');

    // Import documents
    console.log(`📄 Importing ${data.documents.length} documents...`);
    for (const doc of data.documents) {
      await prisma.orderDocument.create({
        data: {
          orderId: doc.orderId,
          type: doc.type,
          fileName: `${doc.type}_legacy.pdf`,
          filePath: `/legacy/clearify/${doc.orderId}/${doc.type}.pdf`,
          content: JSON.stringify({
            legacy: true,
            importedFrom: 'CLEARIFY',
            originalDate: doc.receivedAt,
          }),
          uploadedAt: new Date(doc.receivedAt || Date.now()),
        },
      });
    }
    console.log('✅ Documents imported');

    // Create audit log
    await prisma.auditLog.create({
      data: {
        userId: 'system',
        action: 'CLEARIFY_IMPORT',
        table: 'Order',
        recordId: 'BATCH',
        oldValue: null,
        newValue: JSON.stringify({
          imported: data.orders.length,
          timestamp: new Date(),
        }),
      },
    });

    console.log(`
╔════════════════════════════════════╗
║  CLEARIFY IMPORT SUCCESSFUL! ✅    ║
├════════════════════════════════════┤
║ Orders:   ${data.orders.length.toString().padEnd(25)} ║
║ Items:    ${data.items.length.toString().padEnd(25)} ║
║ Documents: ${data.documents.length.toString().padEnd(23)} ║
╚════════════════════════════════════╝
    `);
  } catch (error) {
    console.error('❌ Import failed:', error);
    process.exit(1);
  }
}

importClearifyData().then(() => {
  console.log('Done!');
  process.exit(0);
});
```

### Run Import
```bash
# Compile and run
npm run build
npx ts-node src/scripts/import-clearify.ts
```

---

## 4. VERIFICATION & CLEANUP

```typescript
// Verify import
const imported = await prisma.order.count();
console.log(`✅ Imported ${imported} orders`);

// Update statistics
const by_status = await prisma.order.groupBy({
  by: ['status'],
  _count: true,
});
console.log('Orders by status:', by_status);

// Update missing fields (post-import)
// This would require manual data enrichment:
// - totalValue (need invoice data)
// - incoterms
// - destinationCountry (hardcoded as Nigeria but should vary)
// - accountable information

// Archive CLEARIFY
// - Keep copy as backup
// - Mark as legacy in UI
```

---

## 5. USER MIGRATION

### Create Client Companies from CLEARIFY Data

```typescript
// Extract unique clients from CLEARIFY
const clients = {
  'DW': 'Total Senegal',
  'JV': 'Partner Company',
  'ONESUBSEA': 'OneSubSea Corporation'
};

for (const [project, name] of Object.entries(clients)) {
  await prisma.company.create({
    data: {
      name,
      email: `contact@${name.toLowerCase().replace(/\s/g, '')}.com`,
      country: 'Senegal',
      companyType: 'CLIENT',
      isActive: true,
    },
  });
}
```

### Create Vendor Database

```typescript
// Extract unique vendors from CLEARIFY
const vendors = ['ZEZ LIMITED', 'JOCAM', 'HYDRAULIC GLOBAL', ...];

for (const vendor of vendors) {
  await prisma.vendor.create({
    data: {
      name: vendor,
      country: guessCountry(vendor),
      type: 'SUPPLIER',
    },
  });
}
```

---

## 6. VALIDATION CHECKLIST

```
☐ All 6,820 orders imported
☐ Order counts match by project:
  ☐ DW: 4,030 ✓
  ☐ JV: 797 ✓
  ☐ ONESUBSEA: 993 ✓
☐ All items preserved
☐ Document references intact
☐ Dates parsed correctly
☐ Statuses mapped accurately
☐ No data loss
☐ All users can access their data
☐ Search functionality works
☐ Reports generate correctly
☐ Audit log created
```

---

## 7. ROLLBACK PLAN

If issues occur:

```bash
# Keep CLEARIFY backup
cp CLEARIFY_4.xlsx CLEARIFY_4_BACKUP.xlsx

# Database backup before import
pg_dump erp_lscm_dev > backup_pre_import.sql

# If needed, restore
psql erp_lscm_dev < backup_pre_import.sql
```

---

## 8. TIMELINE

```
Day 1: Export CLEARIFY → CSV
Day 2: Transform → JSON (verify data)
Day 3: Load into PostgreSQL
Day 4: Verify & validate
Day 5: User testing
Day 6-7: Parallel run (both systems)
Day 8: Go-live with ERP
```

---

## ✅ RESULT

After migration:
- ✅ 6,820 orders in ERP
- ✅ Full searchability
- ✅ Better visibility
- ✅ Audit trail
- ✅ Modern dashboard
- ✅ Mobile access
- ✅ Real-time updates
- ✅ Automated workflows
