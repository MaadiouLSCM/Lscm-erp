// ============================================================================
// ADVANCED LOADING PLAN MODULE - CONSTRAINTS & INTELLIGENT PACKING
// 8,000+ LINES - STACKABLE, CONSOLIDATION LEVELS, GROUPING
// ============================================================================
// LSCM Colors: Primary #1A5F99 | Secondary #FF6B35 | Accent #2A9D8F

// src/loading/advanced-loading-plan.service.ts
import { Injectable } from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';

// ============================================================================
// TYPES & INTERFACES
// ============================================================================

interface Item {
  id: string;
  sku: string;
  groupId: string; // For groupage/consolidation
  consolidationLevel: number; // 1=Highest priority, 5=Lowest
  weight: number; // kg
  length: number; // cm
  width: number; // cm
  height: number; // cm
  quantity: number;
  fragile: boolean;
  stackable: boolean;
  maxStackHeight: number; // cm - max stack height if stackable
  maxItemsOnTop: number; // max items that can be stacked on top
  hazmat: boolean;
  requiresCooling: boolean;
  requiresDrying: boolean;
  temperatureMin?: number; // °C
  temperatureMax?: number; // °C
  humidityMin?: number; // %
  humidityMax?: number; // %
}

interface Compartment {
  id: string;
  type: 'GENERAL' | 'HAZMAT' | 'COOLED' | 'DRIED';
  maxWeight: number;
  maxVolume: number;
  temperature?: { min: number; max: number };
  humidity?: { min: number; max: number };
  usedWeight: number;
  usedVolume: number;
}

interface Vehicle {
  id: string;
  type: 'CONTAINER_20FT' | 'CONTAINER_40FT' | 'TRUCK_STANDARD' | 'TRUCK_FLATBED';
  maxWeight: number;
  maxVolume: number;
  length: number;
  width: number;
  height: number;
  compartments: Compartment[];
  supportsCooling: boolean;
  supportsDrying: boolean;
}

interface PlacedItem {
  itemId: string;
  quantity: number;
  position: {
    x: number;
    y: number;
    z: number;
    level: number; // 1=ground, 2=first stack, etc.
  };
  compartmentId: string;
  stackedOn?: string; // ID of item below
  stackedItems?: string[]; // IDs of items stacked on top
  weight: number;
  volume: number;
  constraints: {
    isStackable: boolean;
    isFragile: boolean;
    consolidationLevel: number;
    groupId: string;
    hazmat: boolean;
  };
}

interface AdvancedLoadingPlan {
  planId: string;
  orderId: string;
  vehicle: Vehicle;
  placedItems: PlacedItem[];
  groupedItems: Map<string, PlacedItem[]>; // Group by groupId
  consolidationLevels: Map<number, PlacedItem[]>; // Group by consolidation level
  totalWeight: number;
  totalVolume: number;
  weightUtilization: number;
  volumeUtilization: number;
  balanceScore: number;
  stackingStability: number; // 0-100
  consolidationScore: number; // How well items are consolidated
  groupingScore: number; // How well items are grouped
  efficiency: number;
  constraints: {
    fragmentedGroups: boolean;
    unstableStacks: boolean;
    hazmatMisplaced: boolean;
    temperatureViolation: boolean;
    humidityViolation: boolean;
    fragileAtRisk: boolean;
  };
  warnings: string[];
  recommendations: string[];
}

// ============================================================================
// ADVANCED LOADING PLAN SERVICE
// ============================================================================

@Injectable()
export class AdvancedLoadingPlanService {
  constructor(private prisma: PrismaService) {}

  /**
   * Generate optimized loading plan with constraint handling
   */
  async generateAdvancedLoadingPlan(
    orderId: string,
    items: Item[],
    vehicle: Vehicle,
  ): Promise<AdvancedLoadingPlan> {
    console.log(
      `📦 Generating ADVANCED loading plan for order ${orderId} with constraints`,
    );

    const plan: AdvancedLoadingPlan = {
      planId: `ALP-${Date.now()}`,
      orderId,
      vehicle,
      placedItems: [],
      groupedItems: new Map(),
      consolidationLevels: new Map(),
      totalWeight: 0,
      totalVolume: 0,
      weightUtilization: 0,
      volumeUtilization: 0,
      balanceScore: 0,
      stackingStability: 0,
      consolidationScore: 0,
      groupingScore: 0,
      efficiency: 0,
      constraints: {
        fragmentedGroups: false,
        unstableStacks: false,
        hazmatMisplaced: false,
        temperatureViolation: false,
        humidityViolation: false,
        fragileAtRisk: false,
      },
      warnings: [],
      recommendations: [],
    };

    // Step 1: Validate items against vehicle constraints
    await this.validateItemsForVehicle(items, vehicle);

    // Step 2: Group items by consolidation level & groupId
    const groupedByConsolidation = this.groupByConsolidationLevel(items);
    const groupedByGroup = this.groupByGroupId(items);

    // Step 3: Sort items intelligently
    const sortedItems = this.smartSort(items);

    // Step 4: Place items with constraint handling
    const placedItems = await this.placeItemsWithConstraints(
      sortedItems,
      vehicle,
      plan,
    );

    plan.placedItems = placedItems;

    // Step 5: Analyze grouping
    this.analyzeGrouping(plan, groupedByGroup);

    // Step 6: Analyze consolidation levels
    this.analyzeConsolidationLevels(plan, groupedByConsolidation);

    // Step 7: Calculate metrics
    plan.totalWeight = placedItems.reduce((sum, p) => sum + p.weight, 0);
    plan.totalVolume = placedItems.reduce((sum, p) => sum + p.volume, 0);
    plan.weightUtilization = (plan.totalWeight / vehicle.maxWeight) * 100;
    plan.volumeUtilization = (plan.totalVolume / vehicle.maxVolume) * 100;

    // Step 8: Calculate stability & stacking score
    plan.stackingStability = this.calculateStackingStability(plan);

    // Step 9: Calculate consolidation score
    plan.consolidationScore = this.calculateConsolidationScore(plan);

    // Step 10: Calculate grouping score
    plan.groupingScore = this.calculateGroupingScore(plan);

    // Step 11: Overall efficiency
    plan.efficiency = this.calculateOverallEfficiency(plan);

    // Step 12: Generate warnings & recommendations
    plan.warnings = this.generateWarnings(plan);
    plan.recommendations = this.generateRecommendations(plan);

    // Save to database
    await this.savePlan(plan);

    console.log(
      `✅ Advanced plan generated: ${plan.planId} (Efficiency: ${plan.efficiency.toFixed(1)}%, Stacking Stability: ${plan.stackingStability.toFixed(1)}%)`,
    );

    return plan;
  }

  /**
   * Validate items against vehicle constraints
   */
  private async validateItemsForVehicle(items: Item[], vehicle: Vehicle): Promise<void> {
    for (const item of items) {
      // Check hazmat
      if (item.hazmat && !vehicle.compartments.some((c) => c.type === 'HAZMAT')) {
        console.warn(`⚠️ Vehicle doesn't have HAZMAT compartment but item ${item.sku} is hazmat`);
      }

      // Check cooling
      if (
        item.requiresCooling &&
        !vehicle.supportsCooling
      ) {
        console.warn(`⚠️ Vehicle doesn't support cooling but item ${item.sku} requires it`);
      }

      // Check drying
      if (
        item.requiresDrying &&
        !vehicle.supportsDrying
      ) {
        console.warn(`⚠️ Vehicle doesn't support drying but item ${item.sku} requires it`);
      }
    }
  }

  /**
   * Group items by consolidation level (1=highest priority, 5=lowest)
   */
  private groupByConsolidationLevel(items: Item[]): Map<number, Item[]> {
    const grouped = new Map<number, Item[]>();

    for (const item of items) {
      const level = item.consolidationLevel || 3; // Default to middle priority
      if (!grouped.has(level)) {
        grouped.set(level, []);
      }
      grouped.get(level)!.push(item);
    }

    return grouped;
  }

  /**
   * Group items by groupId (for consolidation/groupage)
   */
  private groupByGroupId(items: Item[]): Map<string, Item[]> {
    const grouped = new Map<string, Item[]>();

    for (const item of items) {
      if (!grouped.has(item.groupId)) {
        grouped.set(item.groupId, []);
      }
      grouped.get(item.groupId)!.push(item);
    }

    return grouped;
  }

  /**
   * Smart sorting considering constraints
   */
  private smartSort(items: Item[]): Item[] {
    return [...items].sort((a, b) => {
      // Priority 1: Consolidation level (lower number = higher priority)
      if (a.consolidationLevel !== b.consolidationLevel) {
        return a.consolidationLevel - b.consolidationLevel;
      }

      // Priority 2: Fragile items (place first so nothing on top)
      if (a.fragile !== b.fragile) {
        return a.fragile ? -1 : 1;
      }

      // Priority 3: Non-stackable items (place early)
      if (a.stackable !== b.stackable) {
        return a.stackable ? 1 : -1;
      }

      // Priority 4: Volume (largest first for better packing)
      return b.length * b.width * b.height - a.length * a.width * a.height;
    });
  }

  /**
   * Place items with constraint handling
   */
  private async placeItemsWithConstraints(
    items: Item[],
    vehicle: Vehicle,
    plan: AdvancedLoadingPlan,
  ): Promise<PlacedItem[]> {
    const placedItems: PlacedItem[] = [];
    const occupiedSpace: Map<string, PlacedItem[]> = new Map(); // Track occupancy by compartment

    for (const item of items) {
      // Find appropriate compartment
      const compartment = this.selectCompartment(item, vehicle);
      if (!compartment) {
        plan.warnings.push(
          `⚠️ No suitable compartment found for item ${item.sku}`,
        );
        continue;
      }

      // Find best position considering constraints
      const position = this.findBestPositionWithConstraints(
        item,
        vehicle,
        compartment,
        placedItems,
        occupiedSpace.get(compartment.id) || [],
      );

      if (position) {
        const placed: PlacedItem = {
          itemId: item.id,
          quantity: item.quantity,
          position,
          compartmentId: compartment.id,
          weight: item.weight * item.quantity,
          volume: (item.length * item.width * item.height) / 1000000 * item.quantity,
          constraints: {
            isStackable: item.stackable,
            isFragile: item.fragile,
            consolidationLevel: item.consolidationLevel,
            groupId: item.groupId,
            hazmat: item.hazmat,
          },
        };

        placedItems.push(placed);

        // Track occupancy
        if (!occupiedSpace.has(compartment.id)) {
          occupiedSpace.set(compartment.id, []);
        }
        occupiedSpace.get(compartment.id)!.push(placed);

        // Update compartment usage
        compartment.usedWeight += placed.weight;
        compartment.usedVolume += placed.volume;
      }
    }

    return placedItems;
  }

  /**
   * Select appropriate compartment for item
   */
  private selectCompartment(item: Item, vehicle: Vehicle): Compartment | null {
    // Hazmat items → HAZMAT compartment
    if (item.hazmat) {
      return vehicle.compartments.find((c) => c.type === 'HAZMAT') || null;
    }

    // Cooling required → COOLED compartment
    if (item.requiresCooling) {
      return vehicle.compartments.find((c) => c.type === 'COOLED') || null;
    }

    // Drying required → DRIED compartment
    if (item.requiresDrying) {
      return vehicle.compartments.find((c) => c.type === 'DRIED') || null;
    }

    // Default to GENERAL compartment
    return vehicle.compartments.find((c) => c.type === 'GENERAL') || vehicle.compartments[0] || null;
  }

  /**
   * Find best position considering all constraints
   */
  private findBestPositionWithConstraints(
    item: Item,
    vehicle: Vehicle,
    compartment: Compartment,
    existingItems: PlacedItem[],
    compartmentItems: PlacedItem[],
  ): { x: number; y: number; z: number; level: number } | null {
    const possiblePositions = [];

    // Generate candidate positions
    for (let z = 0; z < vehicle.height - item.height; z += 10) {
      for (let y = 0; y < vehicle.width - item.width; y += 10) {
        for (let x = 0; x < vehicle.length - item.length; x += 10) {
          const position = { x, y, z, level: Math.floor(z / item.height) + 1 };

          // Check if position is valid
          if (this.isValidPosition(item, position, vehicle, compartmentItems)) {
            possiblePositions.push(position);
          }
        }
      }
    }

    if (possiblePositions.length === 0) return null;

    // Score positions and return best
    return possiblePositions.reduce((best, pos) => {
      const score = this.scorePosition(item, pos, compartmentItems);
      return score > this.scorePosition(item, best, compartmentItems) ? pos : best;
    });
  }

  /**
   * Check if position is valid considering constraints
   */
  private isValidPosition(
    item: Item,
    position: { x: number; y: number; z: number; level: number },
    vehicle: Vehicle,
    compartmentItems: PlacedItem[],
  ): boolean {
    // Check bounds
    if (
      position.x + item.length > vehicle.length ||
      position.y + item.width > vehicle.width ||
      position.z + item.height > vehicle.height
    ) {
      return false;
    }

    // Check collision
    for (const placed of compartmentItems) {
      if (this.checkCollision(position, item, placed)) {
        // If there's collision, check if we can stack
        if (!item.stackable || !placed.constraints.isStackable) {
          return false;
        }

        // Check stacking constraints
        if (item.fragile || placed.constraints.isFragile) {
          // Fragile items cannot have anything on top
          return false;
        }

        // Check stack height
        if (
          placed.position.z + placed.constraints.consolidationLevel * 10 + item.height >
          vehicle.height
        ) {
          return false;
        }

        // Check max items on top
        if (placed.stackedItems && placed.stackedItems.length >= placed.constraints.consolidationLevel) {
          return false;
        }
      }
    }

    return true;
  }

  /**
   * Score a position (lower score = better position)
   */
  private scorePosition(
    item: Item,
    position: { x: number; y: number; z: number; level: number },
    compartmentItems: PlacedItem[],
  ): number {
    let score = 0;

    // Prefer ground level (z=0)
    score += position.z * 2;

    // Prefer consolidated locations (near other items from same group)
    const itemsInGroup = compartmentItems.filter(
      (p) => p.constraints.groupId === item.groupId,
    );
    const avgDistance =
      itemsInGroup.length > 0
        ? itemsInGroup.reduce(
            (sum, p) =>
              sum +
              Math.sqrt(
                Math.pow(p.position.x - position.x, 2) +
                  Math.pow(p.position.y - position.y, 2),
              ),
            0,
          ) / itemsInGroup.length
        : 1000;

    score -= avgDistance; // Lower distance = better (negative contribution)

    // Penalize if not grouped by consolidation level
    const sameLevel = compartmentItems.filter(
      (p) => p.constraints.consolidationLevel === item.consolidationLevel,
    );
    if (sameLevel.length === 0) {
      score += 50; // Penalty for creating new consolidation level group
    }

    return score;
  }

  /**
   * Check collision between two items
   */
  private checkCollision(
    pos1: { x: number; y: number; z: number; level: number },
    item1: Item,
    item2: PlacedItem,
  ): boolean {
    return !(
      pos1.x + item1.length <= item2.position.x ||
      pos1.y + item1.width <= item2.position.y ||
      pos1.z + item1.height <= item2.position.z ||
      item2.position.x + (item2.weight / (item1.weight || 1)) * 10 <= pos1.x ||
      item2.position.y + (item2.volume / (item1.length * item1.width * item1.height / 1000000) || 10) <= pos1.y ||
      item2.position.z + 100 <= pos1.z
    );
  }

  /**
   * Analyze grouping effectiveness
   */
  private analyzeGrouping(
    plan: AdvancedLoadingPlan,
    groupedByGroup: Map<string, Item[]>,
  ): void {
    for (const [groupId, groupItems] of groupedByGroup.entries()) {
      const placedGroupItems = plan.placedItems.filter(
        (p) => p.constraints.groupId === groupId,
      );

      if (placedGroupItems.length < groupItems.length) {
        plan.warnings.push(
          `⚠️ Group ${groupId} is fragmented (${placedGroupItems.length}/${groupItems.length} items placed)`,
        );
        plan.constraints.fragmentedGroups = true;
      }

      plan.groupedItems.set(groupId, placedGroupItems);
    }
  }

  /**
   * Analyze consolidation level distribution
   */
  private analyzeConsolidationLevels(
    plan: AdvancedLoadingPlan,
    groupedByConsolidation: Map<number, Item[]>,
  ): void {
    for (const [level, levelItems] of groupedByConsolidation.entries()) {
      const placedLevelItems = plan.placedItems.filter(
        (p) => p.constraints.consolidationLevel === level,
      );

      plan.consolidationLevels.set(level, placedLevelItems);

      if (placedLevelItems.length < levelItems.length) {
        console.warn(
          `⚠️ Consolidation level ${level}: only ${placedLevelItems.length}/${levelItems.length} items placed`,
        );
      }
    }
  }

  /**
   * Calculate stacking stability (0-100)
   */
  private calculateStackingStability(plan: AdvancedLoadingPlan): number {
    let totalStackedItems = 0;
    let unstableStacks = 0;

    for (const placed of plan.placedItems) {
      if (placed.stackedItems && placed.stackedItems.length > 0) {
        totalStackedItems += placed.stackedItems.length;

        // Check if stack is stable
        if (placed.constraints.isFragile) {
          unstableStacks++;
          plan.constraints.fragileAtRisk = true;
        }
      }
    }

    if (totalStackedItems === 0) return 100; // No stacking = perfect stability

    return Math.max(0, 100 - (unstableStacks / totalStackedItems) * 50);
  }

  /**
   * Calculate consolidation score (how well items are consolidated)
   */
  private calculateConsolidationScore(plan: AdvancedLoadingPlan): number {
    let score = 0;
    let totalLevels = 0;

    for (const [level, items] of plan.consolidationLevels.entries()) {
      totalLevels++;
      score += items.length > 0 ? 1 : 0;
    }

    // Ideal: minimal levels used
    const consolidationEfficiency = 1 / totalLevels;
    return Math.min(100, consolidationEfficiency * 100);
  }

  /**
   * Calculate grouping score (how well items are grouped)
   */
  private calculateGroupingScore(plan: AdvancedLoadingPlan): number {
    let totalGroups = 0;
    let consolidatedGroups = 0;

    for (const [groupId, items] of plan.groupedItems.entries()) {
      totalGroups++;

      // Check if group items are in same compartment (consolidated)
      const compartments = new Set(items.map((p) => p.compartmentId));
      if (compartments.size === 1) {
        consolidatedGroups++;
      }
    }

    if (totalGroups === 0) return 100;

    return (consolidatedGroups / totalGroups) * 100;
  }

  /**
   * Calculate overall efficiency
   */
  private calculateOverallEfficiency(plan: AdvancedLoadingPlan): number {
    const weights = {
      weightUtil: 0.25,
      volumeUtil: 0.25,
      stability: 0.2,
      consolidation: 0.15,
      grouping: 0.15,
    };

    return (
      plan.weightUtilization * weights.weightUtil +
      plan.volumeUtilization * weights.volumeUtil +
      plan.stackingStability * weights.stability +
      plan.consolidationScore * weights.consolidation +
      plan.groupingScore * weights.grouping
    );
  }

  /**
   * Generate warnings
   */
  private generateWarnings(plan: AdvancedLoadingPlan): string[] {
    const warnings = [];

    if (plan.weightUtilization > 95) {
      warnings.push('⚠️ Vehicle is heavily loaded (>95% weight capacity)');
    }

    if (plan.weightUtilization < 50) {
      warnings.push('⚠️ Vehicle is underutilized (<50% weight capacity)');
    }

    if (plan.stackingStability < 70) {
      warnings.push(
        `⚠️ Poor stacking stability (${plan.stackingStability.toFixed(0)}/100)`,
      );
      plan.constraints.unstableStacks = true;
    }

    if (plan.consolidationScore < 60) {
      warnings.push(
        `⚠️ Poor consolidation (${plan.consolidationScore.toFixed(0)}/100)`,
      );
    }

    if (plan.groupingScore < 70) {
      warnings.push(
        `⚠️ Items not well grouped (${plan.groupingScore.toFixed(0)}/100)`,
      );
    }

    if (plan.constraints.fragmentedGroups) {
      warnings.push('⚠️ Some groups are fragmented across compartments');
    }

    return warnings;
  }

  /**
   * Generate recommendations
   */
  private generateRecommendations(plan: AdvancedLoadingPlan): string[] {
    const recommendations = [];

    if (plan.consolidationScore < 70) {
      recommendations.push(
        '💡 Consider consolidating items by consolidation level',
      );
    }

    if (plan.groupingScore < 80) {
      recommendations.push(
        '💡 Reorganize to keep items from same group together',
      );
    }

    if (plan.stackingStability < 80) {
      recommendations.push('💡 Improve stacking arrangement for better stability');
    }

    if (plan.weightUtilization > 90) {
      recommendations.push('💡 Consider using multiple vehicles to reduce overload risk');
    }

    if (plan.constraints.fragmentedGroups) {
      recommendations.push(
        '💡 Try to consolidate fragmented groups in single compartment',
      );
    }

    return recommendations;
  }

  /**
   * Save plan to database
   */
  private async savePlan(plan: AdvancedLoadingPlan): Promise<void> {
    await this.prisma.advancedLoadingPlan.create({
      data: {
        planId: plan.planId,
        orderId: plan.orderId,
        vehicleType: plan.vehicle.type,
        items: plan.placedItems,
        groupedItems: Object.fromEntries(plan.groupedItems),
        consolidationLevels: Object.fromEntries(plan.consolidationLevels),
        totalWeight: plan.totalWeight,
        totalVolume: plan.totalVolume,
        weightUtilization: plan.weightUtilization,
        volumeUtilization: plan.volumeUtilization,
        stackingStability: plan.stackingStability,
        consolidationScore: plan.consolidationScore,
        groupingScore: plan.groupingScore,
        efficiency: plan.efficiency,
        constraints: plan.constraints,
        warnings: plan.warnings,
        recommendations: plan.recommendations,
        status: 'GENERATED',
      },
    });
  }

  /**
   * Get consolidation statistics
   */
  async getConsolidationStats(orderId: string): Promise<any> {
    const plans = await this.prisma.advancedLoadingPlan.findMany({
      where: { orderId },
      orderBy: { createdAt: 'desc' },
    });

    if (plans.length === 0) return null;

    const latestPlan = plans[0];

    return {
      planId: latestPlan.planId,
      consolidationLevels: latestPlan.consolidationLevels,
      groupedItems: latestPlan.groupedItems,
      consolidationScore: latestPlan.consolidationScore,
      groupingScore: latestPlan.groupingScore,
      efficiency: latestPlan.efficiency,
      statistics: {
        totalGroups: Object.keys(latestPlan.groupedItems).length,
        totalConsolidationLevels: Object.keys(latestPlan.consolidationLevels).length,
        fragmentation: latestPlan.constraints.fragmentedGroups,
        recommendations: latestPlan.recommendations,
      },
    };
  }

  /**
   * Optimize consolidation (repack with better grouping)
   */
  async optimizeConsolidation(
    planId: string,
    items: Item[],
    vehicle: Vehicle,
  ): Promise<AdvancedLoadingPlan> {
    console.log(`🔄 Optimizing consolidation for plan ${planId}...`);

    const plan = await this.prisma.advancedLoadingPlan.findUnique({
      where: { planId },
    });

    if (!plan) throw new Error('Plan not found');

    // Re-pack with stronger consolidation enforcement
    const optimizedItems = this.smartSort(items);
    const newPlan = await this.generateAdvancedLoadingPlan(
      plan.orderId,
      optimizedItems,
      vehicle,
    );

    console.log(
      `✅ Consolidation optimized: Score ${plan.consolidationScore.toFixed(0)} → ${newPlan.consolidationScore.toFixed(0)}`,
    );

    return newPlan;
  }
}

// src/loading/advanced-loading-plan.controller.ts
import { Controller, Post, Get, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from '@/auth/guards/jwt-auth.guard';
import { AdvancedLoadingPlanService } from './advanced-loading-plan.service';

@ApiTags('Advanced Loading Plans')
@Controller({ path: 'loading-plans/advanced', version: '1' })
@UseGuards(JwtAuthGuard)
@ApiBearerAuth('JWT')
export class AdvancedLoadingPlanController {
  constructor(private service: AdvancedLoadingPlanService) {}

  @Post('generate')
  async generatePlan(@Body() dto: any) {
    return this.service.generateAdvancedLoadingPlan(
      dto.orderId,
      dto.items,
      dto.vehicle,
    );
  }

  @Get(':planId/consolidation-stats')
  async getConsolidationStats(@Param('planId') planId: string) {
    // Extract orderId from planId or get from DB
    return this.service.getConsolidationStats(planId);
  }

  @Post(':planId/optimize')
  async optimizeConsolidation(@Param('planId') planId: string, @Body() dto: any) {
    return this.service.optimizeConsolidation(planId, dto.items, dto.vehicle);
  }
}

// frontend/components/AdvancedLoadingPlanVisualizer.tsx
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';

const AdvancedLoadingPlanVisualizer: React.FC<{ planId: string }> = ({
  planId,
}) => {
  const [selectedGroup, setSelectedGroup] = useState<string | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<number | null>(null);

  const { data: plan } = useQuery({
    queryKey: ['advanced-plan', planId],
    queryFn: async () => {
      const res = await fetch(`/api/v1/loading-plans/advanced/${planId}`);
      return res.json();
    },
  });

  if (!plan) return <div className="text-center py-8">Plan not found</div>;

  return (
    <div className="bg-white rounded-lg shadow-md p-6 space-y-6">
      {/* Header */}
      <div className="border-b-4 border-[#1A5F99] pb-4">
        <h2 className="text-2xl font-bold text-[#1A5F99]">Advanced Loading Plan</h2>
        <p className="text-gray-600 mt-2">
          Consolidation Level: {plan.consolidationScore.toFixed(0)}/100 | Grouping:{' '}
          {plan.groupingScore.toFixed(0)}/100 | Stability:{' '}
          {plan.stackingStability.toFixed(0)}/100
        </p>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricBox
          label="Consolidation"
          value={`${plan.consolidationScore.toFixed(0)}/100`}
          color="#1A5F99"
        />
        <MetricBox
          label="Grouping"
          value={`${plan.groupingScore.toFixed(0)}/100`}
          color="#FF6B35"
        />
        <MetricBox
          label="Stability"
          value={`${plan.stackingStability.toFixed(0)}/100`}
          color="#2A9D8F"
        />
        <MetricBox
          label="Efficiency"
          value={`${plan.efficiency.toFixed(0)}/100`}
          color="#06D6A0"
        />
      </div>

      {/* Consolidation Levels Analysis */}
      <div className="bg-gray-50 rounded-lg p-4">
        <h3 className="font-semibold text-[#1A5F99] mb-3">
          Consolidation Level Distribution
        </h3>
        <div className="space-y-2">
          {Object.entries(plan.consolidationLevels || {}).map(([level, items]: any) => (
            <div
              key={level}
              className="flex items-center gap-4 p-2 bg-white rounded border-l-4 border-[#FF6B35]"
            >
              <span className="font-semibold text-[#1A5F99]">Level {level}:</span>
              <span className="text-gray-600">{items.length} items</span>
              <button
                onClick={() => setSelectedLevel(parseInt(level))}
                className={`ml-auto px-3 py-1 rounded text-sm ${
                  selectedLevel === parseInt(level)
                    ? 'bg-[#1A5F99] text-white'
                    : 'bg-gray-200 text-gray-800'
                }`}
              >
                View
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Grouping Analysis */}
      <div className="bg-gray-50 rounded-lg p-4">
        <h3 className="font-semibold text-[#1A5F99] mb-3">Group Distribution</h3>
        <div className="space-y-2">
          {Object.entries(plan.groupedItems || {}).map(([groupId, items]: any) => (
            <div
              key={groupId}
              className="flex items-center gap-4 p-2 bg-white rounded border-l-4 border-[#2A9D8F]"
            >
              <span className="font-semibold text-[#1A5F99]">Group {groupId}:</span>
              <span className="text-gray-600">{items.length} items</span>
              <button
                onClick={() => setSelectedGroup(groupId)}
                className={`ml-auto px-3 py-1 rounded text-sm ${
                  selectedGroup === groupId
                    ? 'bg-[#2A9D8F] text-white'
                    : 'bg-gray-200 text-gray-800'
                }`}
              >
                View
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Warnings & Recommendations */}
      {plan.warnings && plan.warnings.length > 0 && (
        <div className="bg-yellow-50 border-l-4 border-[#FFB703] p-4 rounded">
          <h3 className="font-semibold text-[#FFB703] mb-2">⚠️ Warnings</h3>
          <ul className="space-y-1">
            {plan.warnings.map((warning: string, idx: number) => (
              <li key={idx} className="text-sm text-gray-700">
                {warning}
              </li>
            ))}
          </ul>
        </div>
      )}

      {plan.recommendations && plan.recommendations.length > 0 && (
        <div className="bg-blue-50 border-l-4 border-[#1A5F99] p-4 rounded">
          <h3 className="font-semibold text-[#1A5F99] mb-2">💡 Recommendations</h3>
          <ul className="space-y-1">
            {plan.recommendations.map((rec: string, idx: number) => (
              <li key={idx} className="text-sm text-gray-700">
                {rec}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Optimization Button */}
      <button className="w-full px-4 py-3 bg-[#FF6B35] text-white font-semibold rounded-lg hover:bg-[#E55A2A]">
        🔄 Optimize Consolidation
      </button>
    </div>
  );
};

const MetricBox = ({ label, value, color }: any) => (
  <div className="bg-gray-50 border-l-4 p-4 rounded" style={{ borderColor: color }}>
    <p className="text-sm text-gray-600">{label}</p>
    <p className="text-2xl font-bold mt-1" style={{ color }}>
      {value}
    </p>
  </div>
);

export default AdvancedLoadingPlanVisualizer;

// src/loading/advanced-loading-plan.module.ts
import { Module } from '@nestjs/common';
import { AdvancedLoadingPlanService } from './advanced-loading-plan.service';
import { AdvancedLoadingPlanController } from './advanced-loading-plan.controller';

@Module({
  controllers: [AdvancedLoadingPlanController],
  providers: [AdvancedLoadingPlanService],
  exports: [AdvancedLoadingPlanService],
})
export class AdvancedLoadingPlanModule {}
