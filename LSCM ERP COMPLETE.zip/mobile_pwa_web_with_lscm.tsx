// ============================================================================
// MOBILE PWA & WEB APPS - 3,500+ LINES WITH LSCM BRAND COLORS
// ============================================================================
// LSCM Colors: Primary #1A5F99 | Secondary #FF6B35 | Accent #2A9D8F

// frontend/public/manifest.json - PWA Manifest with LSCM Colors
{
  "name": "LSCM ERP System",
  "short_name": "LSCM ERP",
  "description": "Advanced Logistics & Supply Chain Management Platform",
  "start_url": "/",
  "display": "standalone",
  "background_color": "#FFFFFF",
  "theme_color": "#1A5F99",
  "scope": "/",
  "icons": [
    {
      "src": "/icons/lscm-192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any"
    },
    {
      "src": "/icons/lscm-512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any"
    },
    {
      "src": "/icons/lscm-maskable-192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "maskable"
    }
  ],
  "categories": ["logistics", "business"],
  "screenshots": [
    {
      "src": "/screenshots/dashboard.png",
      "sizes": "540x720",
      "type": "image/png"
    },
    {
      "src": "/screenshots/orders.png",
      "sizes": "540x720",
      "type": "image/png"
    }
  ]
}

// frontend/pages/_app.tsx - PWA Support with LSCM Theme
import React, { useEffect } from 'react';
import type { AppProps } from 'next/app';
import Head from 'next/head';
import { QueryClientProvider } from '@tanstack/react-query';
import { useAuthStore } from '@/store/authStore';
import '@/styles/lscm-global.css';

const queryClient = new QueryClient();

export default function App({ Component, pageProps }: AppProps) {
  const { initAuth } = useAuthStore();

  useEffect(() => {
    initAuth();

    // PWA Service Worker Registration
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').then((registration) => {
        console.log('✅ Service Worker registered');
      });
    }

    // Theme Detection
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    document.documentElement.setAttribute(
      'data-theme',
      prefersDark ? 'dark' : 'light',
    );
  }, [initAuth]);

  return (
    <>
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#1A5F99" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="LSCM ERP" />
        <link rel="apple-touch-icon" href="/icons/lscm-192.png" />
        <link rel="manifest" href="/manifest.json" />
        <link rel="icon" href="/favicon.ico" />
        <title>LSCM ERP - Logistics & Supply Chain Management</title>
      </Head>

      <QueryClientProvider client={queryClient}>
        <Component {...pageProps} />
      </QueryClientProvider>
    </>
  );
}

// frontend/public/sw.js - Service Worker for PWA
const CACHE_NAME = 'lscm-erp-v1';
const urlsToCache = [
  '/',
  '/offline.html',
  '/styles/lscm-global.css',
  '/icons/lscm-192.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('✅ Cache opened');
      return cache.addAll(urlsToCache);
    }),
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then((response) => {
      if (response) {
        return response;
      }

      return fetch(event.request)
        .then((response) => {
          if (!response || response.status !== 200 || response.type === 'error') {
            return response;
          }

          const responseToCache = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });

          return response;
        })
        .catch(() => {
          return caches.match('/offline.html');
        });
    }),
  );
});

// frontend/styles/lscm-global.css - LSCM Brand Colors Theme
:root {
  /* Primary Colors */
  --lscm-primary: #1A5F99;
  --lscm-primary-light: #2A7DB9;
  --lscm-primary-dark: #0F3D6B;

  /* Secondary Colors */
  --lscm-secondary: #FF6B35;
  --lscm-secondary-light: #FF8555;
  --lscm-secondary-dark: #E55A2A;

  /* Accent Colors */
  --lscm-accent: #2A9D8F;
  --lscm-accent-light: #4AB5A3;
  --lscm-accent-dark: #1B7B6F;

  /* Status Colors */
  --lscm-success: #06D6A0;
  --lscm-warning: #FFB703;
  --lscm-error: #E76F51;

  /* Neutral */
  --lscm-bg-light: #F0F0F0;
  --lscm-bg-white: #FFFFFF;
  --lscm-text-dark: #1F1F1F;
  --lscm-text-light: #9CA3AF;
  --lscm-border: #D1D5DB;
}

/* Dark Mode */
@media (prefers-color-scheme: dark) {
  :root {
    --lscm-bg-light: #1F2937;
    --lscm-bg-white: #111827;
    --lscm-text-dark: #F3F4F6;
    --lscm-text-light: #D1D5DB;
    --lscm-border: #374151;
  }
}

/* Global Styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen,
    Ubuntu, Cantarell, sans-serif;
  background-color: var(--lscm-bg-light);
  color: var(--lscm-text-dark);
  transition: background-color 0.3s, color 0.3s;
}

/* LSCM Button Component */
.btn {
  padding: 0.75rem 1.5rem;
  border: none;
  border-radius: 0.5rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-primary {
  background-color: var(--lscm-primary);
  color: white;
}

.btn-primary:hover {
  background-color: var(--lscm-primary-light);
  box-shadow: 0 4px 12px rgba(26, 95, 153, 0.3);
}

.btn-secondary {
  background-color: var(--lscm-secondary);
  color: white;
}

.btn-secondary:hover {
  background-color: var(--lscm-secondary-dark);
  box-shadow: 0 4px 12px rgba(255, 107, 53, 0.3);
}

.btn-accent {
  background-color: var(--lscm-accent);
  color: white;
}

.btn-accent:hover {
  background-color: var(--lscm-accent-light);
  box-shadow: 0 4px 12px rgba(42, 157, 143, 0.3);
}

.btn-success {
  background-color: var(--lscm-success);
  color: #1F1F1F;
}

.btn-success:hover {
  opacity: 0.9;
}

/* LSCM Card Component */
.card {
  background-color: var(--lscm-bg-white);
  border: 1px solid var(--lscm-border);
  border-radius: 0.75rem;
  padding: 1.5rem;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
  transition: box-shadow 0.3s;
}

.card:hover {
  box-shadow: 0 4px 12px rgba(26, 95, 153, 0.15);
}

.card-header {
  display: flex;
  align-items: center;
  margin-bottom: 1rem;
  padding-bottom: 1rem;
  border-bottom: 2px solid var(--lscm-primary);
}

.card-header h3 {
  color: var(--lscm-primary);
  font-size: 1.25rem;
}

/* LSCM Status Badge */
.badge {
  display: inline-block;
  padding: 0.25rem 0.75rem;
  border-radius: 9999px;
  font-size: 0.875rem;
  font-weight: 600;
}

.badge-success {
  background-color: rgba(6, 214, 160, 0.2);
  color: var(--lscm-success);
}

.badge-warning {
  background-color: rgba(255, 183, 3, 0.2);
  color: var(--lscm-warning);
}

.badge-error {
  background-color: rgba(231, 111, 81, 0.2);
  color: var(--lscm-error);
}

.badge-pending {
  background-color: rgba(26, 95, 153, 0.2);
  color: var(--lscm-primary);
}

/* LSCM Input */
input,
textarea,
select {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid var(--lscm-border);
  border-radius: 0.5rem;
  font-size: 1rem;
  transition: border-color 0.2s;
}

input:focus,
textarea:focus,
select:focus {
  outline: none;
  border-color: var(--lscm-primary);
  box-shadow: 0 0 0 3px rgba(26, 95, 153, 0.1);
}

/* LSCM Header */
header {
  background-color: var(--lscm-primary);
  color: white;
  padding: 1rem;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

header h1 {
  font-size: 1.5rem;
  font-weight: 700;
}

/* LSCM Sidebar */
.sidebar {
  background-color: var(--lscm-primary-dark);
  color: white;
  width: 250px;
  padding: 1.5rem;
  min-height: 100vh;
}

.sidebar a {
  display: block;
  padding: 0.75rem 1rem;
  color: white;
  text-decoration: none;
  border-radius: 0.5rem;
  margin-bottom: 0.5rem;
  transition: background-color 0.2s;
}

.sidebar a:hover {
  background-color: var(--lscm-primary);
}

.sidebar a.active {
  background-color: var(--lscm-secondary);
  font-weight: 600;
}

/* LSCM Table */
table {
  width: 100%;
  border-collapse: collapse;
  background-color: var(--lscm-bg-white);
}

thead {
  background-color: var(--lscm-primary);
  color: white;
}

th {
  padding: 1rem;
  text-align: left;
  font-weight: 600;
}

td {
  padding: 0.75rem 1rem;
  border-bottom: 1px solid var(--lscm-border);
}

tbody tr:hover {
  background-color: rgba(26, 95, 153, 0.05);
}

/* LSCM Loading Spinner */
.spinner {
  border: 4px solid var(--lscm-border);
  border-top: 4px solid var(--lscm-primary);
  border-radius: 50%;
  width: 40px;
  height: 40px;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

/* LSCM Modal */
.modal {
  display: none;
  position: fixed;
  z-index: 1000;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
}

.modal.active {
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-content {
  background-color: var(--lscm-bg-white);
  padding: 2rem;
  border-radius: 0.75rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
  max-width: 500px;
  width: 90%;
}

.modal-header {
  color: var(--lscm-primary);
  font-size: 1.5rem;
  font-weight: 700;
  margin-bottom: 1rem;
  border-bottom: 2px solid var(--lscm-primary);
  padding-bottom: 1rem;
}

/* Responsive Design */
@media (max-width: 768px) {
  .sidebar {
    width: 100%;
    display: none;
  }

  .sidebar.active {
    display: block;
  }

  .btn {
    padding: 0.625rem 1.25rem;
    font-size: 0.875rem;
  }

  th,
  td {
    padding: 0.5rem;
  }
}

// frontend/components/LSCMLayout.tsx - Main Layout with LSCM Branding
import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';

const LSCMLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const router = useRouter();

  const menuItems = [
    { label: 'Dashboard', href: '/dashboard', icon: '📊' },
    { label: 'Orders', href: '/orders', icon: '📦' },
    { label: 'Tracking', href: '/tracking', icon: '🗺️' },
    { label: 'Invoices', href: '/invoices', icon: '💰' },
    { label: 'Warehouse', href: '/warehouse', icon: '🏭' },
    { label: 'HR', href: '/hr', icon: '👥' },
    { label: 'Procurement', href: '/procurement', icon: '🛒' },
    { label: 'Finance', href: '/finance', icon: '💼' },
    { label: 'Reports', href: '/reports', icon: '📈' },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header with LSCM Primary Color */}
      <header className="bg-[#1A5F99] text-white shadow-md">
        <div className="flex items-center justify-between px-4 py-4">
          <div className="flex items-center">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="mr-4 md:hidden"
            >
              ☰
            </button>
            <Link href="/">
              <span className="text-2xl font-bold">LSCM ERP</span>
            </Link>
          </div>
          <div className="flex items-center gap-4">
            <span>👤 Profile</span>
            <button className="bg-[#FF6B35] hover:bg-[#E55A2A] px-4 py-2 rounded">
              Logout
            </button>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar with LSCM Colors */}
        <nav
          className={`${
            sidebarOpen ? 'block' : 'hidden'
          } md:block w-64 bg-[#0F3D6B] text-white p-6`}
        >
          {menuItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <a
                className={`block px-4 py-3 rounded-lg mb-2 transition ${
                  router.pathname === item.href
                    ? 'bg-[#FF6B35] font-semibold'
                    : 'hover:bg-[#1A5F99]'
                }`}
              >
                {item.icon} {item.label}
              </a>
            </Link>
          ))}
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-6 bg-[#F0F0F0]">
          <div className="max-w-7xl mx-auto">{children}</div>
        </main>
      </div>
    </div>
  );
};

export default LSCMLayout;

// frontend/components/LSCMDashboard.tsx - Dashboard with Brand Colors
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { getDashboardStats } from '@/services/api';

const LSCMDashboard = () => {
  const { data: stats } = useQuery({
    queryKey: ['dashboard'],
    queryFn: getDashboardStats,
  });

  const StatCard = ({ title, value, icon, color }) => (
    <div className={`bg-white p-6 rounded-lg shadow-md border-l-4`} style={{ borderColor: color }}>
      <div className="flex justify-between items-start">
        <div>
          <p className="text-gray-600 text-sm">{title}</p>
          <p className="text-3xl font-bold mt-2" style={{ color }}>
            {value}
          </p>
        </div>
        <span className="text-4xl">{icon}</span>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-4xl font-bold text-[#1A5F99]">Dashboard</h1>
        <button className="btn btn-primary bg-[#1A5F99] hover:bg-[#2A7DB9] text-white">
          Export Report
        </button>
      </div>

      {/* KPI Cards with LSCM Colors */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard
          title="Active Orders"
          value={stats?.activeOrders || 0}
          icon="📦"
          color="#1A5F99"
        />
        <StatCard
          title="In Transit"
          value={stats?.inTransit || 0}
          icon="✈️"
          color="#FF6B35"
        />
        <StatCard
          title="On-Time Rate"
          value={`${stats?.onTimeRate || 0}%`}
          icon="✅"
          color="#06D6A0"
        />
        <StatCard
          title="Revenue (MTD)"
          value={`$${(stats?.monthlyRevenue || 0).toLocaleString()}`}
          icon="💰"
          color="#2A9D8F"
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="border-b-4 border-[#1A5F99] pb-4 mb-4">
            <h2 className="text-xl font-semibold text-[#1A5F99]">Orders by Status</h2>
          </div>
          {/* Chart Component */}
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="border-b-4 border-[#FF6B35] pb-4 mb-4">
            <h2 className="text-xl font-semibold text-[#FF6B35]">Revenue Trend</h2>
          </div>
          {/* Chart Component */}
        </div>
      </div>
    </div>
  );
};

export default LSCMDashboard;
