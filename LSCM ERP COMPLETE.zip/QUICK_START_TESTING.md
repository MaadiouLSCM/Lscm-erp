# 🚀 QUICK START TESTING GUIDE

**Verifie TOUT en 3 commandes!**

---

## ⚡ OPTION 1: TESTS COMPLETS (Recommandé)

### Étape 1: Préparer les scripts
```bash
cd /path/to/outputs
chmod +x test-all.sh
chmod +x scripts/*.sh
```

### Étape 2: Lancer TOUS les tests
```bash
./test-all.sh
```

**Ce qu'il va faire:**
- ✅ Vérifier Docker, Node.js, curl, etc
- ✅ Compiler TypeScript
- ✅ Démarrer Docker Compose
- ✅ Initialiser PostgreSQL + Redis
- ✅ Migrer la base de données
- ✅ Tester chaque endpoint API
- ✅ Créer une commande de test
- ✅ Vérifier la performance
- ✅ Afficher un rapport final

**Durée:** 15-20 minutes  
**Résultat:** ✅ ALL TESTS PASSED!

---

## ⚡ OPTION 2: TESTS RAPIDES (5 minutes)

```bash
# 1. Démarrer le système
docker-compose up -d

# 2. Attendre 30 secondes
sleep 30

# 3. Tester la santé
curl http://localhost:3000/health

# 4. Ouvrir l'API
open http://localhost:3000/api/docs
```

**Résultat attendu:**
```json
{
  "status": "ok",
  "timestamp": "2025-03-05T10:30:00Z"
}
```

---

## ⚡ OPTION 3: TESTS DÉTAILLÉS (Par étapes)

### Étape 1: Vérifier les prérequis
```bash
chmod +x scripts/verify-prerequisites.sh
./scripts/verify-prerequisites.sh
```

**Résultat attendu:**
```
✅ Docker installed
✅ Docker Compose installed
✅ Node.js installed
✅ npm installed
✅ kubectl installed
✅ curl available
✅ Disk: 50GB available
✅ All prerequisites verified!
```

### Étape 2: Santé du système
```bash
chmod +x scripts/test-basic-health.sh
./scripts/test-basic-health.sh
```

**Résultat attendu:**
```
API Tests:
✅ Health (HTTP 200)
✅ Metrics (HTTP 200)
✅ API Docs (HTTP 200)

Database Tests:
✅ PostgreSQL connection

Cache Tests:
✅ Redis connection

====================
Results: 6 PASSED, 0 FAILED
✅ All health checks passed!
```

### Étape 3: Tests des endpoints API
```bash
chmod +x scripts/test-api-endpoints.sh
./scripts/test-api-endpoints.sh
```

**Résultat attendu:**
```
▶ GET /orders
  Response Code: 200
  ✅ PASSED

▶ POST /orders
  Response Code: 201
  ✅ PASSED

▶ GET /documents
  Response Code: 200
  ✅ PASSED

... (15+ endpoints tested)

Results: 15 PASSED, 0 FAILED
```

### Étape 4: Workflow complet
```bash
chmod +x scripts/test-complete-workflow.sh
./scripts/test-complete-workflow.sh
```

**Résultat attendu:**
```
STEP 1: Create Order
✅ Order created: SNIM-26020001

STEP 2: Get Order Details
✅ Order retrieved

STEP 3: Auto-Generate Documents
✅ Documents generated: 3 documents

STEP 4: List Order Documents
✅ Documents listed

STEP 5: Schedule Pickup
✅ Pickup scheduled

STEP 6: Record Proof of Collection (POC)
✅ POC recorded

STEP 7: Request Green Light (3-Party Approval)
✅ Green Light requested (BLOCKING ORDER)

STEP 8: Record 3-Party Approvals
✅ CLIENT approved
✅ CUSTOMS_BROKER approved
✅ CARRIER approved
✅ All 3 parties approved - ORDER UNBLOCKED

STEP 9: Book Carrier
✅ Carrier booked (Turkish Airlines TK 451)

STEP 10: Record Loading & Survey Report
✅ Survey Report recorded

STEP 11: Simulate Transit
✅ Shipment in transit

STEP 12: Generate Daily Status Report (DSR)
✅ DSR generated and sent to client

STEP 13: Simulate Delivery
✅ Order delivered (simulated)

STEP 14: Generate Invoice
✅ Invoice generated: INV-2025-00001

STEP 15: Record Payment (Access Bank)
✅ Payment recorded and verified with Access Bank

STEP 16: Generate Job Completion Report (JCR)
✅ JCR generated: JCR-2025-00001

================================================
✅ COMPLETE WORKFLOW TEST PASSED!
Total Steps: 16/16 ✅
```

---

## 📊 TESTER MANUELLEMENT LES ENDPOINTS (Curl)

### 1. Lister les commandes
```bash
curl -X GET http://localhost:3000/api/v1/orders
```

### 2. Créer une commande
```bash
curl -X POST http://localhost:3000/api/v1/orders \
  -H "Content-Type: application/json" \
  -d '{
    "supplierId": "SNIM",
    "supplierName": "SNIM",
    "supplierCountry": "Mauritania",
    "buyerId": "BUYER-001",
    "buyerName": "South African Buyer",
    "buyerCountry": "South Africa",
    "commodityCode": "2601",
    "description": "Iron Ore",
    "quantity": 25,
    "grossWeight": 8500,
    "originLocation": "NKC",
    "destLocation": "JNB",
    "incoterm": "FOB",
    "transportMode": "AIR",
    "createdBy": "test@lscm.com"
  }'
```

**Réponse attendue:**
```json
{
  "id": "clu123xyz",
  "orderReference": "SNIM-26020001",
  "status": "DRAFT",
  "phase": "PREPARATION",
  ...
}
```

### 3. Générer les documents
```bash
curl -X POST http://localhost:3000/api/v1/documents/clu123xyz/generate
```

**Réponse attendue:**
```json
[
  {
    "id": "doc1",
    "type": "RFC",
    "documentNumber": "RFC-SNIM-26020001",
    "status": "DRAFT"
  },
  {
    "id": "doc2",
    "type": "JEP",
    "documentNumber": "JEP-SNIM-26020001",
    "status": "DRAFT"
  },
  ...
]
```

### 4. Vérifier les métriques
```bash
curl http://localhost:3000/metrics | grep http_request
```

### 5. Consulter la santé
```bash
curl http://localhost:3000/health | jq .
```

---

## 🎯 VÉRIFICATIONS CLÉS

| Check | Commande | Résultat attendu |
|-------|----------|-----------------|
| API Health | `curl http://localhost:3000/health` | `{"status":"ok"}` |
| Metrics | `curl http://localhost:3000/metrics` | Contient `http_request_duration_seconds` |
| API Docs | `open http://localhost:3000/api/docs` | Page Swagger se charge |
| DB Query | `docker-compose exec postgres psql -U lscm_user -d lscm_erp -c "SELECT 1;"` | `(1 row)` |
| Redis Ping | `docker-compose exec redis redis-cli ping` | `PONG` |
| Create Order | `curl -X POST ... /orders` | HTTP 201 + JSON order |
| List Orders | `curl http://localhost:3000/api/v1/orders` | HTTP 200 + JSON array |

---

## 🐛 TROUBLESHOOTING

### Les conteneurs ne démarrent pas?
```bash
# Voir les logs
docker-compose logs

# Redémarrer
docker-compose down
docker-compose up -d

# Reset complet (attention: supprime les données!)
docker-compose down -v
docker-compose up -d
```

### L'API ne répond pas?
```bash
# Vérifier le statut
docker-compose ps

# Voir les logs backend
docker-compose logs backend

# Vérifier que port 3000 est libre
lsof -i :3000
```

### La base de données n'initialise pas?
```bash
# Forcer les migrations
docker-compose exec backend npx prisma migrate deploy

# Forcer le seed
docker-compose exec backend npx prisma db seed

# Vérifier les migrations
docker-compose exec postgres psql -U lscm_user -d lscm_erp -c "\dt"
```

### Redis ne fonctionne pas?
```bash
# Teste la connexion
docker-compose exec redis redis-cli ping

# Voir la mémoire
docker-compose exec redis redis-cli info memory

# Redémarrer Redis
docker-compose restart redis
```

---

## 📈 INTERPRÉTATION DES RÉSULTATS

### ✅ Tout fonctionne si:
- ✅ Tous les tests passent
- ✅ Pas de messages d'erreur (`❌`)
- ✅ Les APIs répondent en < 500ms
- ✅ Les endpoints retournent des codes HTTP corrects (200, 201, etc)
- ✅ La base de données a des données
- ✅ Redis fonctionne

### ⚠️ Attention si:
- ⚠️ Des warnings (⚠️) mais pas de failures
- ⚠️ Response time > 500ms (mais acceptable)
- ⚠️ Metrics not available (c'est normal au démarrage)

### ❌ Problème si:
- ❌ Tests FAILED
- ❌ API returns 500 errors
- ❌ Database connection failed
- ❌ Redis connection failed
- ❌ Containers not running

---

## 🎓 EXEMPLES D'UTILISATION

### Tester le workflow complet avec Postman

1. Ouvrir Postman
2. Importer la collection depuis: `http://localhost:3000/api/docs`
3. Exécuter les requêtes dans cet ordre:
   ```
   1. POST /orders (créer commande)
   2. POST /documents/{orderId}/generate (générer docs)
   3. POST /pickup/{orderId}/schedule (planifier pickup)
   4. POST /pickup/{orderId}/poc (enregistrer POC)
   5. POST /customs/{orderId}/greenlight (demander GL)
   6. POST /customs/{orderId}/approve (approuver)
   7. POST /transport/{orderId}/book (réserver transporteur)
   8. POST /transport/{orderId}/loading (charger)
   9. POST /invoices/{orderId}/generate (facture)
   10. POST /invoices/{invoiceId}/payment (paiement)
   ```

### Tester avec VS Code REST Client

Créer un fichier `test.http`:
```
### Get Health
GET http://localhost:3000/health

### Create Order
POST http://localhost:3000/api/v1/orders
Content-Type: application/json

{
  "supplierId": "SNIM",
  ...
}

### Get Orders
GET http://localhost:3000/api/v1/orders
```

---

## 📋 CHECKLIST FINALE

Avant de déployer en production:

- [ ] Tous les tests passent (`test-all.sh`)
- [ ] API répond rapidement (< 500ms)
- [ ] Base de données fonctionne
- [ ] Redis fonctionne
- [ ] DSR génère correctement à 17:00
- [ ] Green Light gate fonctionne (3-party approval)
- [ ] Invoices génèrent avec VAT 7.5%
- [ ] Paiements vérifiés avec Access Bank
- [ ] Logs sont complets
- [ ] Monitoring fonctionne (Prometheus/Grafana)

---

## 🎉 RÉSUMÉ

Vous avez maintenant:
- ✅ Scripts de test automatisés
- ✅ Tests manuels (curl examples)
- ✅ Vérifications de santé
- ✅ Tests de workflow complet
- ✅ Troubleshooting guide

**Prêt à déployer?** ✅

