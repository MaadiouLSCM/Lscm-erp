# CONSTRAINT MANAGEMENT GUIDE - COMPLETE EXAMPLES
## LSCM ERP - Advanced Loading Plan System

===================================================================
PARTIE 1: COMPRENDRE LES CONTRAINTES
===================================================================

## 1. STACKABLE CONSTRAINTS (Empilabilité)

### Definition
Définit comment un item peut être empilé sur d'autres items.

### Paramètres

```typescript
StackableConstraint {
  isStackable: boolean;              // Peut être empilé?
  maxStackHeight: number;             // Hauteur max du stack (cm)
  maxItemsOnTop: number;              // Nombre max d'items sur le dessus
  minWeightBearing: number;           // Poids min qu'il peut supporter (kg)
  maxWeightBearing: number;           // Poids max qu'il peut supporter (kg)
  requiresFlatBase: boolean;          // Doit être sur surface plate?
  cannotBeStacked: enum;              // NEVER | FRAGILE_ONLY | ALWAYS
  stackingOrientationRequired: enum;  // UPRIGHT | HORIZONTAL | ANY
}
```

### Exemple 1: Items empilables vs non-empilables

```
ITEM 1: Boîtes en carton
├─ isStackable: true
├─ maxStackHeight: 300 cm
├─ maxItemsOnTop: 5
├─ maxWeightBearing: 500 kg
└─ Result: PEUT être empilé jusqu'à 5 boîtes

ITEM 2: Fragile (verres)
├─ isStackable: false (fragile)
├─ cannotBeStacked: 'NEVER'
├─ maxWeightBearing: 0 (rien sur le dessus)
└─ Result: NE PEUT PAS avoir d'item sur le dessus

ITEM 3: Équipement lourd
├─ isStackable: true
├─ maxItemsOnTop: 1
├─ maxWeightBearing: 100 kg (se casse si > 100kg)
└─ Result: MAX 1 item sur le dessus (< 100kg)
```

### Exemple 2: Gestion du poids (Weight Bearing)

```
VEHICLE LOADING:
Vehicle maxWeight: 20,000 kg

Stack Configuration:
Level 1 (Ground): Item A (100kg) - maxWeightBearing: 5,000 kg
Level 2:          Item B (200kg) - maxWeightBearing: 2,000 kg
Level 3:          Item C (150kg) - maxWeightBearing: 1,000 kg
Level 4:          Item D (100kg)

Validation:
✅ Level 1: A peut supporter 5,000kg, a 450kg au-dessus → OK
✅ Level 2: B peut supporter 2,000kg, a 250kg au-dessus → OK
✅ Level 3: C peut supporter 1,000kg, a 100kg au-dessus → OK
✅ Level 4: D sur le dessus → OK

TOTAL: 100 + 200 + 150 + 100 = 550 kg ✅
```

### Exemple 3: Fragile vs Stackable

```
PROBLÈME: Vouloir empiler des items fragiles

Item: Bouteilles de vin (12)
├─ weight: 50 kg
├─ fragile: true
├─ stackable: {
│   isStackable: false,
│   cannotBeStacked: 'NEVER',
│   maxItemsOnTop: 0
│ }
└─ maxWeightBearing: 5 kg (rien de lourd dessus)

RULE: Rien ne peut être empilé sur fragile!

Placement:
├─ Layer 1 (Ground): Bouteille A (50kg) 
│   ├─ ✅ Peut placer ici
│   └─ ❌ Rien ne peut aller dessus
├─ Layer 2: Bouteille B (50kg)
│   ├─ ✅ Peut placer ici
│   └─ ❌ Rien ne peut aller dessus
└─ Layer 3: Bouteille C (50kg)
    └─ ✅ Peut placer ici

RESULT: 3 bouteilles x 3 layers = 3 stacks séparés (9 bouteilles)
        Reste 3 bouteilles → Besoin d'un autre véhicule ou compartment
```

===================================================================
PARTIE 2: CONSOLIDATION LEVELS (1-5)
===================================================================

## Definition
Indique la PRIORITÉ d'empaquetage ensemble. Plus bas = plus haut priorité.

```
Level 1: ⭐⭐⭐ MUST BE TOGETHER (Priorité absolue)
Level 2: ⭐⭐   SHOULD BE TOGETHER (Très probable)
Level 3: ⭐    TRY TO GROUP (Si possible)
Level 4: ☆    CAN SEPARATE (Séparation acceptable)
Level 5: ☆    NO CONSOLIDATION (Peut éparpiller)
```

### Règles par niveau

```
LEVEL 1 (Consolidation obligatoire)
├─ mustBeInSameCompartment: TRUE
├─ sameVehicleRequired: TRUE
├─ Exemple: Pièces de réparation urgente pour le même équipement
└─ Violation: CRITICAL ❌

LEVEL 2 (Consolidation fortement recommandée)
├─ mustBeInSameCompartment: TRUE
├─ sameVehicleRequired: TRUE
├─ Exemple: Matériaux pour le même projet, même site
└─ Violation: CRITICAL ❌

LEVEL 3 (Groupage conseillé)
├─ mustBeInSameCompartment: FALSE
├─ sameVehicleRequired: FALSE
├─ Exemple: Items du même client mais sites différents
└─ Violation: WARNING ⚠️ (mais packing continuera)

LEVEL 4 (Séparation OK)
├─ Peut être dans compartiments différents
├─ Peut être dans véhicules différents
├─ Exemple: Bulk commodities, non-urgent
└─ Violation: NONE (c'est OK de séparer)

LEVEL 5 (Pas de consolidation)
├─ Scatter items partout
├─ Exemple: Items à haute densité, basé sur volume uniquement
└─ Violation: NONE (optimisation pure)
```

### Exemple complet: Consolidation Levels

```
ORDER: Livraison equipement minier URGENT

ITEMS:
1. Moteur (Level 1) - equipement critique
2. Transmission (Level 1) - avec moteur
3. Oil (Level 2) - pour moteur
4. Filtre (Level 2) - pour moteur
5. Documentation (Level 3) - accessoire
6. Packing matériel (Level 5) - juste du remplissage

PACKING STRATEGY:

✅ CORRECT PACKING:
Vehicle 1:
├─ Moteur (Level 1) ✅
├─ Transmission (Level 1) ✅ (même vehicle, même compartment)
├─ Oil (Level 2) ✅ (avec moteur)
├─ Filtre (Level 2) ✅ (avec moteur)
├─ Documentation (Level 3) ✅ (optionnel)
└─ Packing (Level 5) ✅ (remplissage)

❌ WRONG PACKING:
Vehicle 1:
├─ Moteur (Level 1)
├─ Oil (Level 2)

Vehicle 2:
├─ Transmission (Level 1) ❌ SEPARATION CRITIQUE!
├─ Filtre (Level 2)
└─ Packing

ERROR: Level 1 items (Moteur + Transmission) séparés → CRITICAL VIOLATION!
```

### Consolidation Tolerance (Strictness)

```
ConsolidationLevelConstraint {
  level: 1,
  consolidationTolerance: 95  // 0-100%
}

Meaning:
├─ 95% = Very strict (presque rien ne peut séparer)
├─ 70% = Strict (peut séparer si vraiment nécessaire)
├─ 50% = Medium (séparer est acceptable)
└─ 0%  = No enforcement (advisory only)

Example:
Item avec tolerance: 95
├─ Doit rester avec autres Level 1 items: 95% du temps
├─ Peut séparer seulement si: Pas assez de place, sinon violation

Item avec tolerance: 50
├─ Peut séparer si nécessaire
├─ Mais mieux avec autres Level 1
└─ Violation sera INFO seulement
```

===================================================================
PARTIE 3: GROUPING CONSTRAINTS (Groupage)
===================================================================

## Definition
Groupe items qui doivent rester ensemble ou proches.

```typescript
GroupingConstraint {
  groupId: string;                    // Identifiant unique du groupe
  groupName: string;                  // Nom lisible
  groupType: enum;                    // Type de groupe
  mustStayTogether: boolean;          // Obligation de rester ensemble?
  canBeSeparated: boolean;            // Peut être séparé?
  preferredCompartment?: string;      // Compartment préféré
  itemsInGroup: string[];             // SKUs du groupe
}
```

### Types de groupage

```
1. GROUP_TYPE = 'CUSTOMER'
   ├─ Tous les items pour CUSTOMER A doivent rester ensemble
   ├─ mustStayTogether: true
   └─ Exemple: Commande client unique

2. GROUP_TYPE = 'SUPPLIER'
   ├─ Items du même supplier, peuvent être séparés
   ├─ canBeSeparated: true
   └─ Exemple: Commande groupée de 5 suppliers

3. GROUP_TYPE = 'DESTINATION'
   ├─ Items allant au même site
   ├─ mustStayTogether: false (mais préféré)
   └─ Exemple: Matériaux pour projet Abuja

4. GROUP_TYPE = 'PRODUCT_LINE'
   ├─ Items du même type de produit
   ├─ Groupage logistique, pas physique
   └─ Exemple: Toutes les pièces électroniques

5. GROUP_TYPE = 'CUSTOM'
   ├─ Groupage personnalisé
   ├─ Selon règles métier spécifiques
   └─ Exemple: Ensemble "Urgent Friday delivery"
```

### Exemple: Groupage complet

```
ORDER LSCM-2025-001

GROUP 1: Shipment for CLIENT A (CUSTOMER)
├─ Item 1: Machine pump (100kg, Level 1)
├─ Item 2: Spare parts kit (20kg, Level 1)
├─ Item 3: Manual PDF (0.5kg, Level 2)
└─ Constraint: mustStayTogether = true

GROUP 2: Shipment for CLIENT B (CUSTOMER)
├─ Item 4: Compressor (150kg, Level 2)
├─ Item 5: Oil (50kg, Level 2)
└─ Constraint: canBeSeparated = true

GROUP 3: Supplier ABC materials (SUPPLIER)
├─ Item 1: Machine pump (100kg)
├─ Item 4: Compressor (150kg)
└─ Constraint: canBeSeparated = false (but not critical)

PACKING LOGIC:
Vehicle 1 (40ft Container):
├─ GROUP 1 (CLIENT A) - All together ✅
│  ├─ Machine pump (100kg)
│  ├─ Spare parts kit (20kg)
│  └─ Manual (0.5kg)
├─ GROUP 2 items (CLIENT B) - Can split ✅
│  └─ Compressor (150kg) + Oil (50kg)
└─ Free space left

Result:
✅ GROUP 1 stays together (constraint: must)
✅ GROUP 2 can split if needed (constraint: can separate)
✅ SUPPLIER ABC items across vehicles (not critical)
```

### Max Distance Between Group Items

```
GroupingConstraint {
  maxDistanceBetweenItems: 500  // 5 meters within compartment
}

Meaning:
└─ Items du groupe doivent être dans 500cm l'un de l'autre

CORRECT PACKING:
Compartment 1:
├─ Item A at position (0,0,0)
├─ Item B at position (300,200,100) - distance: 361cm ✅
└─ OK: 361cm < 500cm max

WRONG PACKING:
Compartment 1:
├─ Item A at position (0,0,0)
├─ Item B at position (4000,2000,500) - distance: 4472cm ❌
└─ ERROR: 4472cm > 500cm max (items trop éloignés)
```

===================================================================
PARTIE 4: EXAMPLES CONCRETS - CAS D'USAGE
===================================================================

## Example 1: Équipement minier d'urgence

```
ORDER: Equipment de remplacement pour mine GOLD, site JNB

ITEMS:
1. Motor électrique (500kg)
   ├─ stackable: { isStackable: true, maxWeightBearing: 2000kg, maxItemsOnTop: 3 }
   ├─ consolidation: Level 1 (critical equipment)
   └─ grouping: groupId="MOTOR_SET"

2. Bearing set (100kg)
   ├─ stackable: { isStackable: true, maxWeightBearing: 500kg, maxItemsOnTop: 5 }
   ├─ consolidation: Level 1 (go with motor)
   └─ grouping: groupId="MOTOR_SET"

3. Drive belt (10kg)
   ├─ stackable: { isStackable: true, maxWeightBearing: 100kg, maxItemsOnTop: 10 }
   ├─ consolidation: Level 2 (support motor)
   └─ grouping: groupId="MOTOR_SET"

4. Documentation set (2kg)
   ├─ stackable: { isStackable: true }
   ├─ consolidation: Level 3 (nice to have together)
   └─ grouping: groupId="DOCS"

5. Packing material (50kg)
   ├─ consolidation: Level 5 (fill space)
   └─ grouping: groupId="FILLER"

CONSTRAINTS SUMMARY:
✅ MOTOR_SET group: Must stay together (Level 1 + Level 2)
✅ Motor supports 2000kg (can stack 3 items on top)
✅ All stackable
✅ Total weight: 662kg (fits in any container)

OPTIMAL PACKING:
Layer 1 (Ground): Motor (500kg)
├─ Can support up to 2000kg more
Layer 2: Bearing set (100kg) ✅
├─ Total on motor: 100kg (well under 2000kg limit)
Layer 3: Drive belt (10kg) ✅
├─ Total on motor: 110kg (well under 2000kg limit)
Layer 4: Documentation (2kg) ✅
Layer 5+: Packing material (fill space)

FINAL CONFIGURATION:
✅ All MOTOR_SET items together (Level 1 constraint)
✅ Weight distributed correctly
✅ All stackable constraints respected
✅ Stable stack
✅ Efficient space usage
```

## Example 2: Multiple customers, different consolidation needs

```
ORDER: Bulk shipment, 3 clients, Multiple destinations

CLIENT A (Abuja, Urgent):
├─ Item A1: Industrial pump (200kg) - Level 1 (must go with A2)
├─ Item A2: Pump support (50kg) - Level 1 (must go with A1)
├─ Item A3: Oil (30kg) - Level 2 (should go with A1/A2)
├─ grouping: mustStayTogether = true
└─ consolidation: All Level 1-2 (high priority)

CLIENT B (Lagos, Normal):
├─ Item B1: Spare parts kit (80kg) - Level 3 (try to group)
├─ Item B2: Bearings (20kg) - Level 3 (try to group)
├─ Item B3: Lubricant (40kg) - Level 4 (can separate)
├─ grouping: canBeSeparated = true
└─ consolidation: Mixed level 3-4

CLIENT C (Port Harcourt, Low priority):
├─ Item C1: General parts (150kg) - Level 5 (no consolidation)
├─ Item C2: Materials (100kg) - Level 5 (no consolidation)
└─ grouping: canBeSeparated = true

VEHICLES AVAILABLE:
- Vehicle 1: 40ft container (30,000kg capacity)
- Vehicle 2: 40ft container (30,000kg capacity)

PACKING LOGIC:
Step 1: Place Level 1 items first (CLIENT A, must stay together)
Vehicle 1:
├─ Item A1: Pump (200kg) - bottom
├─ Item A2: Support (50kg) - on pump ✅
├─ Item A3: Oil (30kg) - on pump ✅
└─ Subtotal: 280kg, 1 group ✅

Step 2: Place Level 2 items (CLIENT A support items)
Vehicle 1:
├─ [Items A1+A2+A3 as above]
└─ [Other A items if any]

Step 3: Place Level 3 items (CLIENT B, try to group)
Vehicle 1:
├─ [CLIENT A items: 280kg]
├─ Item B1: Parts kit (80kg) ✅
├─ Item B2: Bearings (20kg) ✅
└─ Subtotal: 380kg ✅

Step 4: Place Level 4 items (CLIENT B, can separate)
Vehicle 1:
├─ [Previous items: 380kg]
├─ Item B3: Lubricant (40kg) ✅ (optional, could go to V2)
└─ Subtotal: 420kg

Step 5: Place Level 5 items (CLIENT C, no consolidation)
Vehicle 1:
├─ [Previous items: 420kg]
├─ Item C1: General parts (150kg) ✅
├─ Item C2: Materials (100kg) ✅
└─ Subtotal: 670kg ✅ (plenty of space left)

FINAL RESULT:
Vehicle 1: 670kg
├─ CLIENT A (Level 1-2): 280kg - All together ✅
├─ CLIENT B (Level 3-4): 140kg - Mostly together, B3 optional
└─ CLIENT C (Level 5): 250kg - Scattered OK

Vehicle 2: Empty (reserve for urgent shipments)

CONSTRAINT SATISFACTION:
✅ Level 1: Perfect (CLIENT A all together)
✅ Level 2: Perfect (CLIENT A items with A1/A2)
✅ Level 3: Good (B1+B2 together)
✅ Level 4: OK (B3 in same vehicle)
✅ Level 5: Perfect (C items scattered by volume)
✅ Grouping: CLIENT A must stay ✅, CLIENT B can separate ✅
```

## Example 3: Fragile + Consolidation conflict resolution

```
ORDER: Glass items + Industrial equipment

Items:
1. Industrial motor (400kg) - Level 1, stackable
2. Glass containers (50kg) - Level 2, fragile, NOT stackable
3. Glass sheets (30kg) - Level 2, fragile, NOT stackable
4. Metal frame (100kg) - Level 1, stackable
5. Packing (20kg) - Level 5

PROBLEM: Fragile items cannot have anything on top, but Level 1-2 need consolidation!

SOLUTION STRATEGY:

Approach 1: Separate compartments
├─ Compartment 1 (Non-fragile): Motor + Frame + Packing
│  ├─ Layer 1: Motor (400kg)
│  ├─ Layer 2: Frame (100kg) on motor ✅
│  └─ Layer 3: Packing (20kg)
├─ Compartment 2 (Fragile): Glass items
│  ├─ Item 1: Glass containers (50kg)
│  └─ Item 2: Glass sheets (30kg)
│  └─ RULE: Each on separate layer, nothing on top
└─ Both in SAME vehicle (Level 1-2 consolidation) ✅

Result:
✅ Level 1 items (Motor + Frame) in same vehicle ✅
✅ Level 2 items (Glass) in same vehicle ✅
✅ Fragile constraint: nothing on glass ✅
✅ Stackable constraint: motor supports frame ✅

Weight distribution:
├─ Compartment 1: 400+100+20 = 520kg
├─ Compartment 2: 50+30 = 80kg
└─ Total: 600kg (well within limits)
```

===================================================================
PARTIE 5: API EXAMPLES
===================================================================

## Create constrained items

```json
POST /api/v1/loading-plans/advanced/generate

{
  "orderId": "ORDER-2025-001",
  "items": [
    {
      "id": "item-motor",
      "sku": "MOTOR-500W",
      "description": "Industrial electric motor 500W",
      "weight": 500,
      "length": 60,
      "width": 50,
      "height": 50,
      "quantity": 1,
      
      "stackable": {
        "isStackable": true,
        "maxStackHeight": 300,
        "maxItemsOnTop": 3,
        "maxWeightBearing": 2000,
        "requiresFlatBase": true,
        "cannotBeStacked": "NEVER"
      },
      
      "consolidation": {
        "level": 1,
        "mustBeInSameCompartment": true,
        "sameVehicleRequired": true,
        "consolidationTolerance": 95
      },
      
      "grouping": {
        "groupId": "MOTOR_SET",
        "groupName": "Motor Assembly",
        "groupType": "PRODUCT_LINE",
        "mustStayTogether": true,
        "canBeSeparated": false
      },
      
      "fragile": false,
      "hazmat": false,
      "requiresCooling": false
    },
    {
      "id": "item-glass",
      "sku": "GLASS-CONTAINERS",
      "description": "Glass containers",
      "weight": 50,
      "fragile": true,
      
      "stackable": {
        "isStackable": false,
        "maxWeightBearing": 0,
        "cannotBeStacked": "NEVER"
      },
      
      "consolidation": {
        "level": 2,
        "mustBeInSameCompartment": false,
        "consolidationTolerance": 60
      },
      
      "grouping": {
        "groupId": "FRAGILE_SET",
        "groupType": "CUSTOM",
        "mustStayTogether": false,
        "canBeSeparated": true
      }
    }
  ],
  "vehicle": {
    "type": "CONTAINER_40FT",
    "compartments": [
      { "type": "GENERAL", "maxWeight": 25000, "maxVolume": 67 },
      { "type": "FRAGILE", "maxWeight": 5000, "maxVolume": 10 }
    ]
  }
}
```

## Validate constraints

```json
POST /api/v1/loading-plans/constraints/validate

Response:
{
  "violations": 2,
  "critical": 0,
  "warnings": 2,
  "details": [
    {
      "type": "CONSOLIDATION",
      "severity": "WARNING",
      "message": "Level 2 items should be grouped together",
      "resolution": "Try to place level 2 items in same compartment"
    },
    {
      "type": "GROUPING",
      "severity": "INFO",
      "message": "Group MOTOR_SET items should be within 500cm of each other",
      "resolution": "Keep group items close together in compartment"
    }
  ]
}
```

## Pack with constraints

```json
POST /api/v1/loading-plans/constraints/pack

Response:
{
  "placedItems": [
    {
      "itemId": "item-motor",
      "position": { "x": 0, "y": 0, "z": 0, "level": 1 },
      "compartmentId": "compartment-1"
    },
    {
      "itemId": "item-glass",
      "position": { "x": 200, "y": 0, "z": 0, "level": 1 },
      "compartmentId": "compartment-2"
    }
  ],
  "violations": [],
  "score": 98,
  "consolidationScore": 92,
  "groupingScore": 95,
  "efficiency": 94
}
```

===================================================================
CONCLUSION
===================================================================

KEY POINTS:

1. STACKABLE constraints define HOW items can be stacked
   ├─ Weight bearing
   ├─ Height limits
   ├─ Max items on top
   └─ Fragile handling

2. CONSOLIDATION LEVELS define PRIORITY of grouping
   ├─ Level 1: Absolutely must be together
   ├─ Level 2: Should be together
   ├─ Level 3: Try to group
   ├─ Level 4: Can separate
   └─ Level 5: No consolidation

3. GROUPING CONSTRAINTS define GROUP relationships
   ├─ Must stay together
   ├─ Can be separated
   ├─ Preferred compartments
   └─ Max distance between items

4. All constraints are VALIDATED and SCORED
   ├─ Violations are detected
   ├─ Resolutions are suggested
   ├─ Score reflects constraint satisfaction
   └─ Recommendations for optimization

5. INTELLIGENT PACKING respects ALL constraints
   ├─ Places items in priority order
   ├─ Respects physical constraints
   ├─ Maintains grouping relationships
   └─ Maximizes space utilization
