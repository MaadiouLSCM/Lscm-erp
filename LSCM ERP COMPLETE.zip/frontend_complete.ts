// frontend/package.json
{
  "name": "lscm-frontend",
  "version": "1.0.0",
  "description": "LSCM ERP Frontend - Next.js React Application",
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "eslint . --ext .ts,.tsx",
    "test": "jest",
    "test:watch": "jest --watch",
    "export": "next export"
  },
  "dependencies": {
    "next": "^14.0.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "@tanstack/react-query": "^5.0.0",
    "axios": "^1.6.0",
    "tailwindcss": "^3.3.0",
    "recharts": "^2.10.0",
    "zustand": "^4.4.0",
    "jwt-decode": "^4.0.0",
    "react-hot-toast": "^2.4.0",
    "date-fns": "^2.30.0",
    "react-hook-form": "^7.48.0",
    "zod": "^3.22.0",
    "@hookform/resolvers": "^3.3.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.0",
    "@types/node": "^20.0.0",
    "typescript": "^5.0.0",
    "eslint": "^8.0.0",
    "eslint-config-next": "^14.0.0",
    "@testing-library/react": "^14.0.0",
    "jest": "^29.0.0",
    "@testing-library/jest-dom": "^6.0.0"
  }
}

// frontend/tsconfig.json
{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "jsx": "preserve",
    "module": "ESNext",
    "moduleResolution": "node",
    "resolveJsonModule": true,
    "allowJs": true,
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "incremental": true,
    "paths": {
      "@/*": ["./*"],
      "@/components/*": ["./components/*"],
      "@/pages/*": ["./pages/*"],
      "@/services/*": ["./services/*"],
      "@/hooks/*": ["./hooks/*"],
      "@/store/*": ["./store/*"]
    },
    "baseUrl": "."
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx"],
  "exclude": ["node_modules"]
}

// frontend/pages/_app.tsx
import React from 'react';
import type { AppProps } from 'next/app';
import { QueryClientProvider, QueryClient } from '@tanstack/react-query';
import { useStore } from '@/store/authStore';
import '@/styles/globals.css';
import Layout from '@/components/Layout';

const queryClient = new QueryClient();

export default function App({ Component, pageProps }: AppProps) {
  const { user } = useStore();

  return (
    <QueryClientProvider client={queryClient}>
      <Layout>
        <Component {...pageProps} />
      </Layout>
    </QueryClientProvider>
  );
}

// frontend/pages/index.tsx
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { getDashboardStats } from '@/services/api';
import DashboardCard from '@/components/DashboardCard';
import StatChart from '@/components/StatChart';

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: getDashboardStats,
  });

  if (isLoading) {
    return <div className="p-8">Loading...</div>;
  }

  return (
    <div className="space-y-8 p-8">
      <h1 className="text-3xl font-bold">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <DashboardCard
          title="Active Orders"
          value={stats?.activeOrders || 0}
          icon="📦"
          trend={stats?.ordersTrend}
        />
        <DashboardCard
          title="In Transit"
          value={stats?.inTransit || 0}
          icon="✈️"
          trend={stats?.transitTrend}
        />
        <DashboardCard
          title="On-Time Rate"
          value={`${stats?.onTimeRate || 0}%`}
          icon="✅"
          trend={stats?.onTimeRateTrend}
        />
        <DashboardCard
          title="Revenue (MTD)"
          value={`$${stats?.monthlyRevenue || 0}`}
          icon="💰"
          trend={stats?.revenueTrend}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <StatChart
          title="Orders by Status"
          data={stats?.ordersByStatus}
          type="pie"
        />
        <StatChart
          title="Lead Time Trend"
          data={stats?.leadTimeTrend}
          type="line"
        />
      </div>
    </div>
  );
}

// frontend/pages/orders/index.tsx
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { listOrders } from '@/services/api';
import OrdersTable from '@/components/OrdersTable';
import OrderFilters from '@/components/OrderFilters';
import CreateOrderButton from '@/components/CreateOrderButton';

export default function Orders() {
  const [filters, setFilters] = useState({ status: '', page: 0, limit: 50 });

  const { data: ordersData, isLoading } = useQuery({
    queryKey: ['orders', filters],
    queryFn: () => listOrders(filters),
  });

  return (
    <div className="space-y-6 p-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Orders</h1>
        <CreateOrderButton />
      </div>

      <OrderFilters onFilterChange={setFilters} />

      {isLoading ? (
        <div>Loading orders...</div>
      ) : (
        <OrdersTable
          orders={ordersData?.data || []}
          pagination={ordersData?.pagination}
          onPageChange={(page) => setFilters({ ...filters, page })}
        />
      )}
    </div>
  );
}

// frontend/pages/orders/[id].tsx
import React from 'react';
import { useRouter } from 'next/router';
import { useQuery } from '@tanstack/react-query';
import { getOrder, getOrderTimeline, calculateKPIs } from '@/services/api';
import OrderDetail from '@/components/OrderDetail';
import OrderTimeline from '@/components/OrderTimeline';
import OrderKPIs from '@/components/OrderKPIs';
import DocumentList from '@/components/DocumentList';

export default function OrderDetailPage() {
  const router = useRouter();
  const { id } = router.query;

  const { data: order } = useQuery({
    queryKey: ['order', id],
    queryFn: () => getOrder(id as string),
    enabled: !!id,
  });

  const { data: timeline } = useQuery({
    queryKey: ['order-timeline', id],
    queryFn: () => getOrderTimeline(id as string),
    enabled: !!id,
  });

  const { data: kpis } = useQuery({
    queryKey: ['order-kpis', id],
    queryFn: () => calculateKPIs(id as string),
    enabled: !!id,
  });

  if (!order) return <div>Loading...</div>;

  return (
    <div className="space-y-6 p-8">
      <OrderDetail order={order} />
      <OrderTimeline timeline={timeline} />
      <OrderKPIs kpis={kpis} />
      <DocumentList orderId={id as string} />
    </div>
  );
}

// frontend/pages/tracking/index.tsx
import React, { useState } from 'react';
import TrackingMap from '@/components/TrackingMap';
import TrackingSearch from '@/components/TrackingSearch';

export default function Tracking() {
  const [selectedOrder, setSelectedOrder] = useState(null);

  return (
    <div className="space-y-6 p-8">
      <h1 className="text-3xl font-bold">Real-Time Tracking</h1>

      <TrackingSearch onSelectOrder={setSelectedOrder} />

      {selectedOrder && (
        <TrackingMap order={selectedOrder} />
      )}
    </div>
  );
}

// frontend/pages/invoices/index.tsx
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { listInvoices } from '@/services/api';
import InvoicesTable from '@/components/InvoicesTable';

export default function Invoices() {
  const { data: invoices, isLoading } = useQuery({
    queryKey: ['invoices'],
    queryFn: listInvoices,
  });

  return (
    <div className="space-y-6 p-8">
      <h1 className="text-3xl font-bold">Invoices</h1>

      {isLoading ? (
        <div>Loading invoices...</div>
      ) : (
        <InvoicesTable invoices={invoices || []} />
      )}
    </div>
  );
}

// frontend/services/api.ts
import axios from 'axios';
import { useStore } from '@/store/authStore';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000/api/v1';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
});

// Add JWT token to requests
apiClient.interceptors.request.use((config) => {
  const { token } = useStore.getState();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const authAPI = {
  login: (email: string, password: string) =>
    apiClient.post('/auth/login', { email, password }),
  register: (data: any) =>
    apiClient.post('/auth/register', data),
  getCurrentUser: () =>
    apiClient.get('/auth/me'),
};

export const ordersAPI = {
  listOrders: (filters?: any) =>
    apiClient.get('/orders', { params: filters }),
  getOrder: (id: string) =>
    apiClient.get(`/orders/${id}`),
  createOrder: (data: any) =>
    apiClient.post('/orders', data),
  updateOrder: (id: string, data: any) =>
    apiClient.put(`/orders/${id}`, data),
  getOrderTimeline: (id: string) =>
    apiClient.get(`/orders/${id}/timeline`),
  calculateKPIs: (id: string) =>
    apiClient.get(`/orders/${id}/kpis`),
};

export const documentsAPI = {
  autoGenerate: (orderId: string) =>
    apiClient.post(`/documents/${orderId}/generate`),
  getOrderDocuments: (orderId: string) =>
    apiClient.get(`/documents/${orderId}`),
  approveDocument: (docId: string) =>
    apiClient.put(`/documents/${docId}/approve`),
};

export const invoicesAPI = {
  listInvoices: () =>
    apiClient.get('/invoices'),
  generateInvoice: (orderId: string) =>
    apiClient.post(`/invoices/${orderId}/generate`),
  recordPayment: (invoiceId: string, data: any) =>
    apiClient.post(`/invoices/${invoiceId}/payment`, data),
};

// ============================================================================
// Re-export functions for easier usage
// ============================================================================
export const listOrders = (filters?: any) => ordersAPI.listOrders(filters);
export const getOrder = (id: string) => ordersAPI.getOrder(id);
export const getOrderTimeline = (id: string) => ordersAPI.getOrderTimeline(id);
export const calculateKPIs = (id: string) => ordersAPI.calculateKPIs(id);
export const listInvoices = () => invoicesAPI.listInvoices();
export const getDashboardStats = () => apiClient.get('/dashboard/stats');

// frontend/store/authStore.ts
import { create } from 'zustand';

interface AuthStore {
  user: any | null;
  token: string | null;
  login: (user: any, token: string) => void;
  logout: () => void;
  setUser: (user: any) => void;
}

export const useStore = create<AuthStore>((set) => ({
  user: null,
  token: typeof window !== 'undefined' ? localStorage.getItem('token') : null,

  login: (user, token) => {
    localStorage.setItem('token', token);
    set({ user, token });
  },

  logout: () => {
    localStorage.removeItem('token');
    set({ user: null, token: null });
  },

  setUser: (user) => {
    set({ user });
  },
}));

// frontend/components/Layout.tsx
import React from 'react';
import Sidebar from './Sidebar';
import Header from './Header';
import { useStore } from '@/store/authStore';
import { useRouter } from 'next/router';

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user } = useStore();
  const router = useRouter();

  // Redirect to login if not authenticated
  React.useEffect(() => {
    if (!user && !router.pathname.startsWith('/auth')) {
      router.push('/auth/login');
    }
  }, [user, router]);

  if (!user && !router.pathname.startsWith('/auth')) {
    return null;
  }

  return (
    <div className="flex h-screen bg-gray-100">
      {user && <Sidebar />}
      <div className="flex-1 flex flex-col overflow-hidden">
        {user && <Header />}
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

// frontend/components/DashboardCard.tsx
import React from 'react';

interface DashboardCardProps {
  title: string;
  value: string | number;
  icon: string;
  trend?: number;
}

export default function DashboardCard({
  title,
  value,
  icon,
  trend,
}: DashboardCardProps) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-gray-600 text-sm font-medium">{title}</p>
          <p className="text-3xl font-bold mt-2">{value}</p>
          {trend && (
            <p className={`text-sm mt-2 ${trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
              {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}%
            </p>
          )}
        </div>
        <span className="text-4xl">{icon}</span>
      </div>
    </div>
  );
}

// frontend/.env.example
NEXT_PUBLIC_API_URL=http://localhost:3000/api/v1
NEXT_PUBLIC_APP_NAME=LSCM ERP
