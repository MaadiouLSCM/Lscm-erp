// frontend/pages/_app.tsx
import type { AppProps } from 'next/app';
import { QueryClientProvider, QueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { useAuthStore } from '@/store/authStore';
import Layout from '@/components/Layout';
import '@/styles/globals.css';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 1000 * 60 * 5 },
  },
});

export default function App({ Component, pageProps }: AppProps) {
  const { initAuth } = useAuthStore();

  useEffect(() => {
    initAuth();
  }, [initAuth]);

  return (
    <QueryClientProvider client={queryClient}>
      <Layout>
        <Component {...pageProps} />
      </Layout>
    </QueryClientProvider>
  );
}

// frontend/pages/dashboard.tsx
import { useQuery } from '@tanstack/react-query';
import { getDashboardStats } from '@/services/api';
import DashboardCard from '@/components/DashboardCard';
import OrderChart from '@/components/OrderChart';
import RevenueChart from '@/components/RevenueChart';
import OnTimeChart from '@/components/OnTimeChart';

export default function Dashboard() {
  const { data: stats, isLoading, error } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: getDashboardStats,
    refetchInterval: 60000,
  });

  if (error) return <div className="error">Failed to load dashboard</div>;
  if (isLoading) return <div className="loading">Loading...</div>;

  return (
    <div className="space-y-8 p-8 bg-gray-50 min-h-screen">
      <div>
        <h1 className="text-4xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-2">Welcome back! Here's your logistics overview.</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <DashboardCard
          title="Active Orders"
          value={stats?.activeOrders || 0}
          icon="📦"
          trend={stats?.ordersTrend}
          color="blue"
        />
        <DashboardCard
          title="In Transit"
          value={stats?.inTransit || 0}
          icon="✈️"
          trend={stats?.transitTrend}
          color="purple"
        />
        <DashboardCard
          title="On-Time Rate"
          value={`${stats?.onTimeRate || 0}%`}
          icon="✅"
          trend={stats?.onTimeRateTrend}
          color="green"
        />
        <DashboardCard
          title="Revenue (MTD)"
          value={`$${(stats?.monthlyRevenue || 0).toLocaleString()}`}
          icon="💰"
          trend={stats?.revenueTrend}
          color="amber"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Orders by Status</h2>
          <OrderChart data={stats?.ordersByStatus} />
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Revenue Trend</h2>
          <RevenueChart data={stats?.revenueTrend} />
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">On-Time Delivery Rate</h2>
        <OnTimeChart data={stats?.onTimeTrend} />
      </div>

      {/* Recent Orders */}
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Recent Orders</h2>
        <RecentOrdersTable orders={stats?.recentOrders} />
      </div>
    </div>
  );
}

// frontend/pages/orders/index.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { listOrders } from '@/services/api';
import OrdersTable from '@/components/OrdersTable';
import OrderFilters from '@/components/OrderFilters';
import CreateOrderModal from '@/components/CreateOrderModal';
import ExportButton from '@/components/ExportButton';

export default function OrdersPage() {
  const [filters, setFilters] = useState({
    status: '',
    phase: '',
    transportMode: '',
    page: 0,
    limit: 50,
  });
  const [showCreateModal, setShowCreateModal] = useState(false);

  const { data: ordersData, isLoading, error, refetch } = useQuery({
    queryKey: ['orders', filters],
    queryFn: () => listOrders(filters),
  });

  return (
    <div className="space-y-6 p-8 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Orders</h1>
          <p className="text-gray-600">Manage your shipments and logistics operations</p>
        </div>
        <div className="flex gap-3">
          <ExportButton data={ordersData?.data} filename="orders.csv" />
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
          >
            + New Order
          </button>
        </div>
      </div>

      {/* Filters */}
      <OrderFilters onFilterChange={setFilters} currentFilters={filters} />

      {/* Table */}
      {error && <div className="bg-red-50 p-4 rounded-lg text-red-800">Error loading orders</div>}
      {isLoading && <div className="text-center py-8">Loading orders...</div>}
      {ordersData && (
        <OrdersTable
          orders={ordersData.data}
          pagination={ordersData.pagination}
          onPageChange={(page) => setFilters({ ...filters, page })}
          onRefresh={refetch}
        />
      )}

      {/* Create Modal */}
      {showCreateModal && (
        <CreateOrderModal onClose={() => setShowCreateModal(false)} onSuccess={() => { refetch(); setShowCreateModal(false); }} />
      )}
    </div>
  );
}

// frontend/pages/orders/[id].tsx
import { useRouter } from 'next/router';
import { useQuery } from '@tanstack/react-query';
import { getOrder, getOrderTimeline, calculateKPIs } from '@/services/api';
import OrderDetailCard from '@/components/OrderDetailCard';
import OrderTimelineView from '@/components/OrderTimelineView';
import KPIMetrics from '@/components/KPIMetrics';
import DocumentsList from '@/components/DocumentsList';
import ActivityLog from '@/components/ActivityLog';
import ActionButtons from '@/components/ActionButtons';

export default function OrderDetailPage() {
  const router = useRouter();
  const { id } = router.query;

  const { data: order, isLoading: orderLoading } = useQuery({
    queryKey: ['order', id],
    queryFn: () => getOrder(id as string),
    enabled: !!id,
  });

  const { data: timeline } = useQuery({
    queryKey: ['order-timeline', id],
    queryFn: () => getOrderTimeline(id as string),
    enabled: !!id,
  });

  const { data: kpis } = useQuery({
    queryKey: ['order-kpis', id],
    queryFn: () => calculateKPIs(id as string),
    enabled: !!id,
  });

  if (orderLoading) return <div className="p-8">Loading...</div>;
  if (!order) return <div className="p-8 text-red-600">Order not found</div>;

  return (
    <div className="space-y-6 p-8 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold">{order.orderReference}</h1>
          <div className="flex gap-4 mt-2 text-sm text-gray-600">
            <span>{order.supplierName}</span>
            <span>→</span>
            <span>{order.buyerName}</span>
          </div>
        </div>
        <ActionButtons orderId={id as string} orderStatus={order.status} />
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Order Details & Timeline */}
        <div className="lg:col-span-2 space-y-6">
          <OrderDetailCard order={order} />
          <OrderTimelineView timeline={timeline} />
          <ActivityLog orderId={id as string} />
        </div>

        {/* Right: KPIs & Documents */}
        <div className="space-y-6">
          <KPIMetrics kpis={kpis} />
          <DocumentsList orderId={id as string} />
        </div>
      </div>
    </div>
  );
}

// frontend/pages/tracking.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import TrackingMap from '@/components/TrackingMap';
import TrackingSearch from '@/components/TrackingSearch';
import TrackingDetails from '@/components/TrackingDetails';

export default function TrackingPage() {
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  const { data: tracking } = useQuery({
    queryKey: ['tracking', selectedOrderId],
    queryFn: () => selectedOrderId ? fetchTracking(selectedOrderId) : null,
    enabled: !!selectedOrderId,
  });

  return (
    <div className="space-y-6 p-8 bg-gray-50 min-h-screen">
      <div>
        <h1 className="text-3xl font-bold">Real-Time Tracking</h1>
        <p className="text-gray-600">Track your shipments in real-time</p>
      </div>

      <TrackingSearch onSelectOrder={setSelectedOrderId} />

      {selectedOrderId && tracking && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <TrackingMap order={tracking.order} segments={tracking.segments} />
          </div>
          <div>
            <TrackingDetails order={tracking.order} segments={tracking.segments} />
          </div>
        </div>
      )}
    </div>
  );
}

// frontend/pages/invoices/index.tsx
import { useQuery } from '@tanstack/react-query';
import { listInvoices } from '@/services/api';
import InvoicesTable from '@/components/InvoicesTable';
import InvoiceFilters from '@/components/InvoiceFilters';
import InvoiceStats from '@/components/InvoiceStats';

export default function InvoicesPage() {
  const { data: invoices, isLoading } = useQuery({
    queryKey: ['invoices'],
    queryFn: listInvoices,
  });

  return (
    <div className="space-y-6 p-8 bg-gray-50 min-h-screen">
      <div>
        <h1 className="text-3xl font-bold">Invoices</h1>
        <p className="text-gray-600">Manage and track your invoices</p>
      </div>

      {invoices && <InvoiceStats invoices={invoices} />}

      <InvoiceFilters />

      {isLoading ? (
        <div>Loading invoices...</div>
      ) : (
        <InvoicesTable invoices={invoices || []} />
      )}
    </div>
  );
}

// frontend/pages/reports/dsr.tsx
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { getDSR } from '@/services/api';
import DSRViewer from '@/components/DSRViewer';
import DSRList from '@/components/DSRList';

export default function DSRPage() {
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  const { data: dsr } = useQuery({
    queryKey: ['dsr', selectedOrderId],
    queryFn: () => selectedOrderId ? getDSR(selectedOrderId) : null,
    enabled: !!selectedOrderId,
  });

  return (
    <div className="space-y-6 p-8 bg-gray-50 min-h-screen">
      <div>
        <h1 className="text-3xl font-bold">Daily Status Reports</h1>
        <p className="text-gray-600">Auto-generated at 17:00 UTC daily</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          {dsr && <DSRViewer dsr={dsr} />}
        </div>
        <div>
          <DSRList onSelectOrder={setSelectedOrderId} />
        </div>
      </div>
    </div>
  );
}

// frontend/pages/reports/jcr.tsx
import { useQuery } from '@tanstack/react-query';
import { listJCRs } from '@/services/api';
import JCRTable from '@/components/JCRTable';

export default function JCRPage() {
  const { data: jcrs, isLoading } = useQuery({
    queryKey: ['jcrs'],
    queryFn: listJCRs,
  });

  return (
    <div className="space-y-6 p-8 bg-gray-50 min-h-screen">
      <div>
        <h1 className="text-3xl font-bold">Job Completion Reports</h1>
        <p className="text-gray-600">Final order consolidation and closure</p>
      </div>

      {isLoading ? (
        <div>Loading...</div>
      ) : (
        <JCRTable jcrs={jcrs || []} />
      )}
    </div>
  );
}

// frontend/components/Layout.tsx
import Sidebar from './Sidebar';
import Header from './Header';
import { useAuthStore } from '@/store/authStore';
import { useRouter } from 'next/router';
import { useEffect } from 'react';

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuthStore();
  const router = useRouter();

  useEffect(() => {
    if (!isLoading && !user && !router.pathname.startsWith('/auth')) {
      router.push('/auth/login');
    }
  }, [user, isLoading, router]);

  if (isLoading) return <div className="flex items-center justify-center h-screen">Loading...</div>;
  if (!user && !router.pathname.startsWith('/auth')) return null;

  return (
    <div className="flex h-screen bg-gray-100">
      {user && <Sidebar />}
      <div className="flex-1 flex flex-col overflow-hidden">
        {user && <Header />}
        <main className="flex-1 overflow-auto">{children}</main>
      </div>
    </div>
  );
}

// frontend/store/authStore.ts
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { authAPI } from '@/services/api';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
}

interface AuthStore {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  initAuth: () => void;
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isLoading: true,

      login: async (email: string, password: string) => {
        try {
          const { accessToken, user } = await authAPI.login(email, password);
          set({ user, token: accessToken, isLoading: false });
          localStorage.setItem('token', accessToken);
        } catch (error) {
          set({ isLoading: false });
          throw error;
        }
      },

      logout: () => {
        set({ user: null, token: null });
        localStorage.removeItem('token');
      },

      initAuth: async () => {
        const token = localStorage.getItem('token');
        if (token) {
          try {
            set({ token });
            const user = await authAPI.getCurrentUser();
            set({ user, isLoading: false });
          } catch {
            localStorage.removeItem('token');
            set({ isLoading: false });
          }
        } else {
          set({ isLoading: false });
        }
      },
    }),
    { name: 'auth-storage' },
  ),
);

// frontend/components/DashboardCard.tsx
interface Props {
  title: string;
  value: string | number;
  icon: string;
  trend?: number;
  color?: string;
}

export default function DashboardCard({
  title,
  value,
  icon,
  trend,
  color = 'blue',
}: Props) {
  const colors = {
    blue: 'bg-blue-50 border-blue-200',
    green: 'bg-green-50 border-green-200',
    purple: 'bg-purple-50 border-purple-200',
    amber: 'bg-amber-50 border-amber-200',
  };

  return (
    <div className={`${colors[color as keyof typeof colors]} border rounded-lg p-6`}>
      <div className="flex justify-between items-start">
        <div>
          <p className="text-gray-600 text-sm font-medium">{title}</p>
          <p className="text-3xl font-bold mt-2">{value}</p>
          {trend && (
            <p className={`text-sm mt-2 ${trend > 0 ? 'text-green-600' : 'text-red-600'}`}>
              {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}%
            </p>
          )}
        </div>
        <span className="text-4xl">{icon}</span>
      </div>
    </div>
  );
}

// frontend/services/api.ts
import axios from 'axios';
import { useAuthStore } from '@/store/authStore';

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000/api/v1';

const apiClient = axios.create({ baseURL: BASE_URL });

apiClient.interceptors.request.use((config) => {
  const { token } = useAuthStore.getState();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const authAPI = {
  login: async (email: string, password: string) => {
    const { data } = await apiClient.post('/auth/login', { email, password });
    return data;
  },
  getCurrentUser: async () => {
    const { data } = await apiClient.get('/auth/me');
    return data;
  },
};

export const ordersAPI = {
  list: (filters?: any) => apiClient.get('/orders', { params: filters }),
  get: (id: string) => apiClient.get(`/orders/${id}`),
  create: (data: any) => apiClient.post('/orders', data),
  getTimeline: (id: string) => apiClient.get(`/orders/${id}/timeline`),
  getKPIs: (id: string) => apiClient.get(`/orders/${id}/kpis`),
};

export const listOrders = async (filters?: any) => {
  const { data } = await ordersAPI.list(filters);
  return data;
};

export const getOrder = async (id: string) => {
  const { data } = await ordersAPI.get(id);
  return data;
};

export const getOrderTimeline = async (id: string) => {
  const { data } = await ordersAPI.getTimeline(id);
  return data;
};

export const calculateKPIs = async (id: string) => {
  const { data } = await ordersAPI.getKPIs(id);
  return data;
};

export const getDashboardStats = async () => {
  const { data } = await apiClient.get('/dashboard/stats');
  return data;
};

export const getDSR = async (orderId: string) => {
  const { data } = await apiClient.get(`/reporting/${orderId}/dsr`);
  return data;
};

export const listInvoices = async () => {
  const { data } = await apiClient.get('/invoices');
  return data;
};

export const listJCRs = async () => {
  const { data } = await apiClient.get('/reporting/jcrs');
  return data;
};

export const fetchTracking = async (orderId: string) => {
  const { data } = await apiClient.get(`/tracking/${orderId}`);
  return data;
};
