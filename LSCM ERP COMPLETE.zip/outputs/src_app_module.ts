// src/app.module.ts
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { OrdersModule } from './orders/orders.module';
import { DocumentsModule } from './documents/documents.module';
import { PickupModule } from './pickup/pickup.module';
import { CustomsModule } from './customs/customs.module';
import { TransportModule } from './transport/transport.module';
import { InvoiceModule } from './invoice/invoice.module';
import { ReportingModule } from './reporting/reporting.module';
import { IntegrationModule } from './integrations/integration.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    PrismaModule,
    AuthModule,
    OrdersModule,
    DocumentsModule,
    PickupModule,
    CustomsModule,
    TransportModule,
    InvoiceModule,
    ReportingModule,
    IntegrationModule,
  ],
  providers: [],
  controllers: [],
})
export class AppModule {}
