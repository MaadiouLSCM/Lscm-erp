// src/orders/orders.service.ts
import { Injectable, BadRequestException, NotFoundException, ConflictException } from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import { CreateOrderDto, UpdateOrderDto, OrderFilterDto } from './dtos';
import { ShipmentOrder } from '@prisma/client';

@Injectable()
export class OrdersService {
  constructor(private prisma: PrismaService) {}

  /**
   * Create new shipment order
   * Auto-populate from SAP BW PO data if available
   */
  async createOrder(dto: CreateOrderDto): Promise<ShipmentOrder> {
    // Check if PO already exists
    if (dto.poNumber) {
      const existing = await this.prisma.shipmentOrder.findFirst({
        where: { poNumber: dto.poNumber },
      });

      if (existing) {
        throw new ConflictException(`PO ${dto.poNumber} already exists`);
      }
    }

    // Generate unique order reference
    const orderRef = this.generateOrderReference(dto.supplierId);

    // Create order
    const order = await this.prisma.shipmentOrder.create({
      data: {
        orderReference: orderRef,
        poNumber: dto.poNumber,
        supplierId: dto.supplierId,
        supplierName: dto.supplierName,
        supplierCountry: dto.supplierCountry,
        buyerId: dto.buyerId,
        buyerName: dto.buyerName,
        buyerCountry: dto.buyerCountry,
        buyerEmail: dto.buyerEmail,
        commodityCode: dto.commodityCode,
        description: dto.description,
        itemNumber: dto.itemNumber,
        quantity: dto.quantity,
        unitOfMeasure: dto.unitOfMeasure,
        grossWeight: dto.grossWeight,
        netWeight: dto.netWeight,
        length: dto.length,
        width: dto.width,
        height: dto.height,
        cbm: this.calculateCBM(dto.length, dto.width, dto.height),
        originLocation: dto.originLocation,
        destLocation: dto.destLocation,
        incoterm: dto.incoterm,
        transportMode: dto.transportMode,
        currencyCode: dto.currencyCode || 'USD',
        status: 'DRAFT',
        phase: 'PREPARATION',
        createdBy: dto.createdBy,
      },
    });

    console.log(`✅ Order created: ${orderRef}`);
    return order;
  }

  /**
   * Get order by ID
   */
  async getOrder(id: string): Promise<ShipmentOrder> {
    const order = await this.prisma.shipmentOrder.findUnique({
      where: { id },
    });

    if (!order) {
      throw new NotFoundException(`Order ${id} not found`);
    }

    return order;
  }

  /**
   * Get order by reference
   */
  async getOrderByReference(reference: string): Promise<ShipmentOrder> {
    const order = await this.prisma.shipmentOrder.findUnique({
      where: { orderReference: reference },
    });

    if (!order) {
      throw new NotFoundException(`Order ${reference} not found`);
    }

    return order;
  }

  /**
   * Update order
   */
  async updateOrder(id: string, dto: UpdateOrderDto, updatedBy: string): Promise<ShipmentOrder> {
    const order = await this.getOrder(id);

    // Validate status transition rules
    if (dto.status) {
      this.validateStatusTransition(order.status, dto.status);
    }

    const updated = await this.prisma.shipmentOrder.update({
      where: { id },
      data: {
        ...dto,
        updatedAt: new Date(),
        updatedBy,
      },
    });

    console.log(`✅ Order updated: ${order.orderReference} → ${updated.status}`);
    return updated;
  }

  /**
   * List orders with filtering
   */
  async listOrders(filter: OrderFilterDto) {
    const where: any = {};

    if (filter.status) where.status = filter.status;
    if (filter.phase) where.phase = filter.phase;
    if (filter.supplierId) where.supplierId = filter.supplierId;
    if (filter.buyerId) where.buyerId = filter.buyerId;
    if (filter.transportMode) where.transportMode = filter.transportMode;

    if (filter.createdAfter) {
      where.createdAt = { gte: new Date(filter.createdAfter) };
    }

    const orders = await this.prisma.shipmentOrder.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: filter.limit || 50,
      skip: (filter.page || 0) * (filter.limit || 50),
    });

    const total = await this.prisma.shipmentOrder.count({ where });

    return {
      data: orders,
      pagination: {
        total,
        page: filter.page || 0,
        limit: filter.limit || 50,
      },
    };
  }

  /**
   * Update order status (with validation)
   */
  async updateOrderStatus(id: string, newStatus: string, updatedBy: string): Promise<ShipmentOrder> {
    const order = await this.getOrder(id);
    this.validateStatusTransition(order.status, newStatus);

    return this.updateOrder(id, { status: newStatus }, updatedBy);
  }

  /**
   * Calculate order KPIs
   */
  async calculateOrderKPIs(id: string): Promise<OrderKPIs> {
    const order = await this.getOrder(id);

    const daysInPickup = order.pickupDate
      ? Math.floor((order.pickupDate.getTime() - order.createdAt.getTime()) / (1000 * 60 * 60 * 24))
      : null;

    const daysInTransit = order.actualDeparture && order.actualArrival
      ? Math.floor((order.actualArrival.getTime() - order.actualDeparture.getTime()) / (1000 * 60 * 60 * 24))
      : null;

    const totalLeadTime = order.deliveryDate
      ? Math.floor((order.deliveryDate.getTime() - order.createdAt.getTime()) / (1000 * 60 * 60 * 24))
      : null;

    const onTime = order.actualArrival && order.estimatedArrival
      ? order.actualArrival <= order.estimatedArrival
      : null;

    const costVariance = order.actualCost && order.estimatedCost
      ? ((order.actualCost - order.estimatedCost) / order.estimatedCost) * 100
      : null;

    return {
      daysInPickup,
      daysInTransit,
      totalLeadTime,
      onTime,
      costVariance,
      onTimeStatus: this.determineOnTimeStatus(daysInPickup, daysInTransit, order.transportMode),
    };
  }

  /**
   * Get order timeline
   */
  async getOrderTimeline(id: string) {
    const order = await this.getOrder(id);
    const segments = await this.prisma.transportSegment.findMany({
      where: { orderId: id },
      orderBy: { legNumber: 'asc' },
    });

    return {
      order: {
        reference: order.orderReference,
        status: order.status,
        phase: order.phase,
      },
      milestones: [
        {
          phase: 'PREPARATION',
          scheduled: order.createdAt,
          actual: null,
        },
        {
          phase: 'PICKUP',
          scheduled: null,
          actual: order.pickupDate,
        },
        ...segments.map((seg, i) => ({
          phase: `LEG_${i + 1}`,
          scheduled: seg.estimatedDeparture,
          actual: seg.actualArrival,
        })),
        {
          phase: 'DELIVERY',
          scheduled: order.estimatedArrival,
          actual: order.deliveryDate,
        },
      ],
    };
  }

  /**
   * Helper: Generate unique order reference
   */
  private generateOrderReference(supplierId: string): string {
    const timestamp = Date.now();
    return `ORD-${supplierId}-${timestamp}`;
  }

  /**
   * Helper: Calculate CBM
   */
  private calculateCBM(length?: number, width?: number, height?: number): number | null {
    if (!length || !width || !height) return null;
    // Convert cm to m: (L × W × H) / 1,000,000
    return (length * width * height) / 1000000;
  }

  /**
   * Helper: Validate status transitions
   */
  private validateStatusTransition(currentStatus: string, newStatus: string) {
    const validTransitions: Record<string, string[]> = {
      DRAFT: ['CONFIRMED', 'CANCELLED'],
      CONFIRMED: ['RFC_SENT', 'CANCELLED'],
      RFC_SENT: ['PFI_PENDING', 'CANCELLED'],
      PFI_PENDING: ['PICKUP_SCHEDULED', 'CANCELLED'],
      PICKUP_SCHEDULED: ['IN_TRANSIT', 'CANCELLED'],
      IN_TRANSIT: ['DELIVERED', 'CANCELLED'],
      DELIVERED: ['INVOICED'],
      INVOICED: ['PAID', 'OVERDUE'],
      PAID: ['CLOSED'],
      OVERDUE: ['PAID', 'CLOSED'],
      CLOSED: [],
      CANCELLED: [],
    };

    if (!validTransitions[currentStatus]?.includes(newStatus)) {
      throw new BadRequestException(
        `Cannot transition from ${currentStatus} to ${newStatus}`,
      );
    }
  }

  /**
   * Helper: Determine on-time status
   */
  private determineOnTimeStatus(
    daysInPickup: number | null,
    daysInTransit: number | null,
    transportMode: string,
  ): string {
    // KPI thresholds
    const pickupThreshold = 5;
    const transitThresholdAir = 10;
    const transitThresholdSea = 35;

    if (daysInPickup && daysInPickup > pickupThreshold) {
      return 'DELAYED';
    }

    if (daysInTransit) {
      const threshold = transportMode === 'AIR' ? transitThresholdAir : transitThresholdSea;
      if (daysInTransit > threshold) {
        return 'DELAYED';
      }
    }

    return 'ON_TIME';
  }
}

// src/orders/dtos/create-order.dto.ts
import { IsString, IsNumber, IsOptional, IsEmail } from 'class-validator';

export class CreateOrderDto {
  @IsString()
  supplierId: string;

  @IsString()
  supplierName: string;

  @IsString()
  supplierCountry: string;

  @IsString()
  buyerId: string;

  @IsString()
  buyerName: string;

  @IsString()
  buyerCountry: string;

  @IsOptional()
  @IsEmail()
  buyerEmail?: string;

  @IsOptional()
  @IsString()
  poNumber?: string;

  @IsString()
  commodityCode: string;

  @IsString()
  description: string;

  @IsOptional()
  @IsString()
  itemNumber?: string;

  @IsNumber()
  quantity: number;

  @IsOptional()
  @IsString()
  unitOfMeasure?: string;

  @IsNumber()
  grossWeight: number;

  @IsOptional()
  @IsNumber()
  netWeight?: number;

  @IsOptional()
  @IsNumber()
  length?: number;

  @IsOptional()
  @IsNumber()
  width?: number;

  @IsOptional()
  @IsNumber()
  height?: number;

  @IsString()
  originLocation: string;

  @IsString()
  destLocation: string;

  @IsString()
  incoterm: string;

  @IsString()
  transportMode: string;

  @IsOptional()
  @IsString()
  currencyCode?: string;

  @IsString()
  createdBy: string;
}

export class UpdateOrderDto {
  @IsOptional()
  @IsString()
  status?: string;

  @IsOptional()
  @IsString()
  phase?: string;

  @IsOptional()
  @IsNumber()
  estimatedCost?: number;

  @IsOptional()
  @IsNumber()
  actualCost?: number;

  @IsOptional()
  @IsNumber()
  serviceCharges?: number;

  @IsOptional()
  @IsNumber()
  handlingFees?: number;

  @IsOptional()
  @IsNumber()
  customsFees?: number;

  @IsOptional()
  @IsNumber()
  insurance?: number;

  @IsOptional()
  notes?: string;
}

export class OrderFilterDto {
  @IsOptional()
  @IsString()
  status?: string;

  @IsOptional()
  @IsString()
  phase?: string;

  @IsOptional()
  @IsString()
  supplierId?: string;

  @IsOptional()
  @IsString()
  buyerId?: string;

  @IsOptional()
  @IsString()
  transportMode?: string;

  @IsOptional()
  @IsString()
  createdAfter?: string;

  @IsOptional()
  @IsNumber()
  page?: number;

  @IsOptional()
  @IsNumber()
  limit?: number;
}

// KPI Response type
export interface OrderKPIs {
  daysInPickup: number | null;
  daysInTransit: number | null;
  totalLeadTime: number | null;
  onTime: boolean | null;
  costVariance: number | null;
  onTimeStatus: string;
}
