// src/reporting/reporting.service.ts
import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import * as PDFDocument from 'pdfkit';
import * as fs from 'fs';
import * as path from 'path';
import * as cron from 'node-cron';

@Injectable()
export class ReportingService {
  constructor(private prisma: PrismaService) {
    this.initializeAutoDSR();
  }

  /**
   * Initialize automatic DSR generation (17:00 UTC daily)
   */
  private initializeAutoDSR(): void {
    cron.schedule('0 17 * * *', async () => {
      console.log('⏰ [17:00] Generating daily status reports...');
      
      const activeOrders = await this.prisma.shipmentOrder.findMany({
        where: {
          status: {
            in: ['PICKED_UP', 'IN_TRANSIT', 'CUSTOMS_HOLD', 'BOOKING_CONFIRMED', 'LOADED'],
          },
        },
      });

      for (const order of activeOrders) {
        try {
          await this.generateDSR(order.id);
        } catch (error) {
          console.error(`❌ Failed to generate DSR for ${order.orderReference}:`, error);
        }
      }

      console.log(`✅ DSR generation completed for ${activeOrders.length} orders`);
    });
  }

  /**
   * Generate Daily Status Report (DSR)
   * Called daily at 17:00 or on-demand
   */
  async generateDSR(orderId: string): Promise<any> {
    const order = await this.prisma.shipmentOrder.findUnique({
      where: { id: orderId },
    });

    if (!order) {
      throw new NotFoundException(`Order ${orderId} not found`);
    }

    // Get segments
    const segments = await this.prisma.transportSegment.findMany({
      where: { orderId },
      orderBy: { legNumber: 'asc' },
    });

    // Get latest incidents
    const incidents = await this.prisma.incident.findMany({
      where: {
        segment: { orderId },
      },
      orderBy: { reportedAt: 'desc' },
      take: 10,
    });

    // Calculate KPIs
    const daysInPickup = order.pickupDate
      ? Math.floor((order.pickupDate.getTime() - order.createdAt.getTime()) / (1000 * 60 * 60 * 24))
      : null;

    const daysSinceDeparture = order.actualDeparture
      ? Math.floor((new Date().getTime() - order.actualDeparture.getTime()) / (1000 * 60 * 60 * 24))
      : null;

    const onTimeStatus =
      order.actualArrival && order.estimatedArrival
        ? order.actualArrival <= order.estimatedArrival
          ? 'ON_TIME'
          : 'DELAYED'
        : 'AT_RISK';

    // Current segment
    const currentSegment = segments.find((s) => !s.actualArrival) || segments[segments.length - 1];

    // Create DSR
    const dsr = await this.prisma.dailyStatusReport.create({
      data: {
        orderId,
        reportDate: new Date(),
        reportTime: new Date().toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit' }),
        currentPhase: order.phase,
        currentStatus: order.status,
        currentLocation: currentSegment?.currentLocation || order.originLocation,
        currentSegment: currentSegment?.segmentId,
        eta: currentSegment?.estimatedArrival,
        etaLocation: currentSegment?.destName,
        lastAction: this.generateLastAction(order, segments),
        lastActionTime: order.actualDeparture || order.pickupDate || order.createdAt,
        daysInPickup,
        daysSinceDeparture,
        onTimeStatus,
        incidents: JSON.stringify(
          incidents.map((i) => ({
            type: i.type,
            description: i.description,
            reportedAt: i.reportedAt,
            resolved: !!i.resolvedAt,
          })),
        ),
        nextMilestone: this.getNextMilestone(order),
        upcomingActions: JSON.stringify(this.getUpcomingActions(order)),
        sentToClient: false,
        createdBy: 'SYSTEM',
      },
    });

    // Send to client (email)
    await this.sendDSRToClient(orderId, dsr);

    return dsr;
  }

  /**
   * Send DSR to client via email
   */
  async sendDSRToClient(orderId: string, dsr: any): Promise<void> {
    const order = await this.prisma.shipmentOrder.findUnique({
      where: { id: orderId },
    });

    if (!order || !order.buyerEmail) {
      console.log(`⚠️ Cannot send DSR - no email for ${order?.orderReference}`);
      return;
    }

    // Generate PDF
    const pdfPath = await this.generateDSRPDF(order, dsr);

    // TODO: Send email via SendGrid/AWS SES
    const emailBody = `
Dear ${order.buyerName},

Daily Status Update - ${new Date().toLocaleDateString()}

Order Reference: ${order.orderReference}
Current Status: ${dsr.currentStatus}
Current Location: ${dsr.currentLocation}
Estimated Arrival: ${dsr.eta?.toLocaleDateString()}

Key Metrics:
- Days in Pickup: ${dsr.daysInPickup}
- On-Time Status: ${dsr.onTimeStatus}
- Incidents: ${dsr.incidents}

Next Milestone: ${dsr.nextMilestone}

Detailed report attached.

Best regards,
LSCM Logistics & Supply Chain Management
    `;

    // Update DSR status
    await this.prisma.dailyStatusReport.update({
      where: { id: dsr.id },
      data: {
        sentToClient: true,
        sentAt: new Date(),
      },
    });

    console.log(`📧 DSR sent to ${order.buyerEmail}`);
  }

  /**
   * Generate Weekly Status Report (WSR)
   */
  async generateWSR(startDate: Date, endDate: Date): Promise<any> {
    // Get all orders updated in period
    const orders = await this.prisma.shipmentOrder.findMany({
      where: {
        updatedAt: {
          gte: startDate,
          lte: endDate,
        },
      },
    });

    const stats = {
      totalOrders: orders.length,
      ordersDelivered: orders.filter((o) => o.status === 'DELIVERED').length,
      ordersInTransit: orders.filter((o) => o.status === 'IN_TRANSIT').length,
      ordersDelayed: orders.filter((o) => o.actualArrival && o.actualArrival > o.estimatedArrival).length,
      avgLeadTime: Math.round(
        orders.reduce((sum, o) => {
          if (o.deliveryDate && o.createdAt) {
            return (
              sum + (o.deliveryDate.getTime() - o.createdAt.getTime()) / (1000 * 60 * 60 * 24)
            );
          }
          return sum;
        }, 0) / Math.max(orders.length, 1),
      ),
      onTimePercentage: Math.round(
        ((orders.filter((o) => o.actualArrival && o.actualArrival <= o.estimatedArrival).length /
          orders.length) *
          100) as any,
      ),
      totalRevenue: orders.reduce((sum, o) => sum + (o.totalCost || 0), 0),
      avgRevenuePerOrder: Math.round(
        orders.reduce((sum, o) => sum + (o.totalCost || 0), 0) / Math.max(orders.length, 1),
      ),
    };

    const wsr = await this.prisma.weeklyStatusReport.create({
      data: {
        wsrId: `WSR-${startDate.toISOString().split('T')[0]}`,
        weekStart: startDate,
        weekEnd: endDate,
        generatedAt: new Date(),
        totalOrders: stats.totalOrders,
        ordersDelivered: stats.ordersDelivered,
        ordersInTransit: stats.ordersInTransit,
        ordersDelayed: stats.ordersDelayed,
        avgLeadTime: stats.avgLeadTime,
        onTimePercentage: stats.onTimePercentage,
        totalRevenue: stats.totalRevenue,
        avgRevenuePerOrder: stats.avgRevenuePerOrder,
        detailedOrders: JSON.stringify(
          orders.map((o) => ({
            reference: o.orderReference,
            status: o.status,
            leadTime: o.deliveryDate && o.createdAt
              ? (o.deliveryDate.getTime() - o.createdAt.getTime()) / (1000 * 60 * 60 * 24)
              : null,
            revenue: o.totalCost,
          })),
        ),
      },
    });

    return wsr;
  }

  /**
   * Generate Job Completion Report (JCR)
   * Called post-payment to finalize order
   */
  async generateJCR(orderId: string): Promise<any> {
    const order = await this.prisma.shipmentOrder.findUnique({
      where: { id: orderId },
    });

    if (!order) {
      throw new NotFoundException(`Order ${orderId} not found`);
    }

    // Collect all documents
    const documents = await this.prisma.document.findMany({
      where: { orderId },
    });

    const segments = await this.prisma.transportSegment.findMany({
      where: { orderId },
      orderBy: { legNumber: 'asc' },
    });

    const invoice = await this.prisma.invoice.findFirst({
      where: { orderId },
      orderBy: { createdAt: 'desc' },
    });

    // Calculate final KPIs
    const kpis = {
      daysInPickup: order.pickupDate
        ? (order.pickupDate.getTime() - order.createdAt.getTime()) / (1000 * 60 * 60 * 24)
        : null,
      daysInTransit: order.actualDeparture && order.actualArrival
        ? (order.actualArrival.getTime() - order.actualDeparture.getTime()) / (1000 * 60 * 60 * 24)
        : null,
      totalLeadTime: order.deliveryDate
        ? (order.deliveryDate.getTime() - order.createdAt.getTime()) / (1000 * 60 * 60 * 24)
        : null,
      onTime: order.actualArrival && order.estimatedArrival
        ? order.actualArrival <= order.estimatedArrival
        : null,
      costVariance: order.actualCost && order.estimatedCost
        ? ((order.actualCost - order.estimatedCost) / order.estimatedCost) * 100
        : null,
    };

    const jcrNumber = `JCR-${new Date().getFullYear()}-${String(Math.random() * 100000).split('.')[0].padStart(5, '0')}`;

    // Create JCR
    const jcr = await this.prisma.jobCompletionReport.create({
      data: {
        orderId,
        jcrId: jcrNumber,
        jcrNumber,
        jcrDate: new Date(),
        orderReference: order.orderReference,
        shipper: order.supplierName,
        consignee: order.buyerName,
        origin: order.originLocation,
        destination: order.destLocation,
        totalLeadDays: Math.round(kpis.totalLeadTime || 0),
        actualDeparture: order.actualDeparture,
        actualArrival: order.actualArrival,
        attachedDocuments: JSON.stringify(
          documents.map((d) => ({
            type: d.type,
            reference: d.documentNumber,
          })),
        ),
        daysInPickup: Math.round(kpis.daysInPickup || 0),
        daysInTransit: Math.round(kpis.daysInTransit || 0),
        totalLeadTime: Math.round(kpis.totalLeadTime || 0),
        onTime: kpis.onTime,
        costVariance: kpis.costVariance,
        chargeWeight: order.grossWeight,
        serviceCharges: order.serviceCharges,
        vat: order.vat,
        total: order.totalCost,
        invoiced: invoice?.invoiceNumber,
        paid: invoice?.status === 'PAID',
        paymentReference: invoice?.paymentReference,
        status: 'FINALIZED',
        finalizedAt: new Date(),
        finalizedBy: 'SYSTEM',
      },
    });

    // Generate PDF
    const pdfPath = await this.generateJCRPDF(order, jcr, documents);

    // Update JCR with file
    await this.prisma.jobCompletionReport.update({
      where: { id: jcr.id },
      data: { fileUrl: pdfPath },
    });

    // Update order status
    await this.prisma.shipmentOrder.update({
      where: { id: orderId },
      data: {
        status: 'CLOSED',
        phase: 'CLOSURE',
        updatedAt: new Date(),
      },
    });

    console.log(`✅ JCR finalized: ${jcrNumber}`);

    return jcr;
  }

  // ========== HELPERS ==========

  private generateLastAction(order: any, segments: any[]): string {
    if (order.deliveryDate) return `Delivered on ${order.deliveryDate.toLocaleDateString()}`;
    if (order.actualArrival) return `Arrived at ${segments[segments.length - 1]?.destName}`;
    if (order.actualDeparture) return `Departed from ${segments[0]?.originName}`;
    if (order.pickupDate) return `Picked up on ${order.pickupDate.toLocaleDateString()}`;
    return `Order created on ${order.createdAt.toLocaleDateString()}`;
  }

  private getNextMilestone(order: any): string {
    if (order.status === 'DRAFT' || order.status === 'CONFIRMED') return 'Awaiting pickup';
    if (order.status === 'PICKED_UP') return 'Export customs clearance';
    if (order.status === 'IN_TRANSIT') return 'Awaiting arrival';
    if (order.status === 'DELIVERED') return 'Invoice generation';
    if (order.status === 'INVOICED') return 'Awaiting payment';
    if (order.status === 'PAID') return 'Order closure';
    return 'Order closed';
  }

  private getUpcomingActions(order: any): string[] {
    const actions = [];

    if (!order.pickupDate) actions.push('Schedule and execute pickup');
    if (order.status === 'IN_TRANSIT') actions.push('Monitor transit progress');
    if (!order.deliveryDate && order.status === 'IN_TRANSIT') actions.push('Prepare for import customs');
    if (order.status === 'DELIVERED' && !order.totalCost) actions.push('Generate invoice');
    if (order.status === 'INVOICED') actions.push('Follow up on payment');
    if (order.status === 'PAID') actions.push('Generate JCR and close order');

    return actions.length > 0 ? actions : ['Monitor order status'];
  }

  private async generateDSRPDF(order: any, dsr: any): Promise<string> {
    const fileName = `DSR-${order.orderReference}-${new Date().toISOString().split('T')[0]}.pdf`;
    const filePath = path.join(process.cwd(), 'uploads', fileName);

    const doc = new PDFDocument();
    const stream = fs.createWriteStream(filePath);
    doc.pipe(stream);

    doc.fontSize(16).font('Helvetica-Bold').text('DAILY STATUS REPORT', { align: 'center' });
    doc.fontSize(10).text(`${new Date().toLocaleDateString()}`, { align: 'center' });
    doc.moveDown();

    doc.fontSize(12).font('Helvetica-Bold').text('SHIPMENT STATUS');
    doc.fontSize(10).font('Helvetica')
      .text(`Order Reference: ${order.orderReference}`)
      .text(`Current Status: ${dsr.currentStatus}`)
      .text(`Current Location: ${dsr.currentLocation}`)
      .text(`ETA: ${dsr.eta?.toLocaleDateString()}`)
      .moveDown();

    doc.fontSize(12).font('Helvetica-Bold').text('KPI ASSESSMENT');
    doc.fontSize(10).font('Helvetica')
      .text(`Days in Pickup: ${dsr.daysInPickup}`)
      .text(`On-Time Status: ${dsr.onTimeStatus}`)
      .text(`Next Milestone: ${dsr.nextMilestone}`)
      .moveDown();

    doc.end();

    await new Promise((resolve) => stream.on('finish', resolve));

    return `/uploads/${fileName}`;
  }

  private async generateJCRPDF(order: any, jcr: any, documents: any[]): Promise<string> {
    const fileName = `${jcr.jcrNumber}.pdf`;
    const filePath = path.join(process.cwd(), 'uploads', fileName);

    const doc = new PDFDocument();
    const stream = fs.createWriteStream(filePath);
    doc.pipe(stream);

    doc.fontSize(16).font('Helvetica-Bold').text('JOB COMPLETION REPORT', { align: 'center' });
    doc.fontSize(10).text(`${jcr.jcrNumber}`, { align: 'center' });
    doc.moveDown();

    doc.fontSize(12).font('Helvetica-Bold').text('SHIPMENT SUMMARY');
    doc.fontSize(10).font('Helvetica')
      .text(`Shipper: ${jcr.shipper}`)
      .text(`Consignee: ${jcr.consignee}`)
      .text(`Route: ${jcr.origin} → ${jcr.destination}`)
      .text(`Total Lead Time: ${jcr.totalLeadDays} days`)
      .moveDown();

    doc.fontSize(12).font('Helvetica-Bold').text('FINAL KPIs');
    doc.fontSize(10).font('Helvetica')
      .text(`On-Time Delivery: ${jcr.onTime ? 'YES' : 'NO'}`)
      .text(`Cost Variance: ${(jcr.costVariance || 0).toFixed(2)}%`)
      .text(`Total Cost: ${jcr.total} ${order.currencyCode}`)
      .moveDown();

    doc.fontSize(12).font('Helvetica-Bold').text('ATTACHED DOCUMENTS');
    const attachedDocs = JSON.parse(jcr.attachedDocuments || '[]');
    attachedDocs.forEach((doc_: any) => {
      doc.fontSize(9).font('Helvetica').text(`✓ ${doc_.type} - ${doc_.reference}`);
    });

    doc.end();

    await new Promise((resolve) => stream.on('finish', resolve));

    return `/uploads/${fileName}`;
  }
}

// src/reporting/reporting.module.ts
import { Module } from '@nestjs/common';
import { ReportingService } from './reporting.service';

@Module({
  providers: [ReportingService],
  exports: [ReportingService],
})
export class ReportingModule {}
