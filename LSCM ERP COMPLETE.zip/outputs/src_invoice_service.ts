// src/invoice/invoice.service.ts
import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import * as PDFDocument from 'pdfkit';
import * as fs from 'fs';
import * as path from 'path';
import * as axios from 'axios';

@Injectable()
export class InvoiceService {
  private invoiceSequence = 0;

  constructor(private prisma: PrismaService) {}

  /**
   * Generate Invoice (Post-Delivery)
   * ONLY callable after POD (Proof of Delivery)
   */
  async generateInvoice(orderId: string, generatedBy: string): Promise<any> {
    const order = await this.prisma.shipmentOrder.findUnique({
      where: { id: orderId },
    });

    if (!order) {
      throw new NotFoundException(`Order ${orderId} not found`);
    }

    // Check if order is delivered
    if (order.status !== 'DELIVERED') {
      throw new BadRequestException(
        `Cannot invoice - order status is ${order.status}. Requires DELIVERED.`,
      );
    }

    // Calculate invoice amount
    const subtotal =
      order.serviceCharges +
      order.handlingFees +
      (order.customsFees || 0) +
      (order.insurance || 0);

    const vat = subtotal * 0.075; // 7.5% VAT
    const total = subtotal + vat;

    // Generate invoice number
    const invoiceNumber = `INV-${new Date().getFullYear()}-${String(++this.invoiceSequence).padStart(5, '0')}`;

    // Create invoice
    const invoice = await this.prisma.invoice.create({
      data: {
        orderId,
        invoiceNumber,
        invoiceDate: new Date(),
        dueDate: this.addDays(new Date(), 30),
        paymentTerms: 'Net 30',
        invoicedTo: order.buyerName,
        invoicedToAddress: `${order.destLocation}, ${order.buyerCountry}`,
        subtotal,
        vat: Math.round(vat * 100) / 100,
        total: Math.round(total * 100) / 100,
        currencyCode: order.currencyCode,
        lineItems: JSON.stringify([
          {
            description: 'Freight charges',
            quantity: 1,
            unitPrice: order.serviceCharges,
            amount: order.serviceCharges,
          },
          {
            description: 'Handling & documentation',
            quantity: 1,
            unitPrice: order.handlingFees,
            amount: order.handlingFees,
          },
          ...(order.customsFees
            ? [
                {
                  description: 'Customs & regulatory',
                  quantity: 1,
                  unitPrice: order.customsFees,
                  amount: order.customsFees,
                },
              ]
            : []),
          ...(order.insurance
            ? [
                {
                  description: 'Insurance',
                  quantity: 1,
                  unitPrice: order.insurance,
                  amount: order.insurance,
                },
              ]
            : []),
        ]),
        bankName: 'Access Bank',
        accountName: 'LSCM Ltd',
        accountNumber: process.env.BANK_ACCOUNT_NUMBER || '1234567890',
        bankCode: process.env.BANK_CODE || '044',
        swiftCode: 'ABNGNGLA',
        status: 'ISSUED',
        issuedBy: generatedBy,
      },
    });

    // Generate PDF
    const pdfPath = await this.generateInvoicePDF(order, invoice);

    // Update invoice with file URL
    await this.prisma.invoice.update({
      where: { id: invoice.id },
      data: { fileUrl: pdfPath },
    });

    // Update order status
    await this.prisma.shipmentOrder.update({
      where: { id: orderId },
      data: {
        status: 'INVOICED',
        phase: 'BILLING',
        updatedAt: new Date(),
        updatedBy: generatedBy,
      },
    });

    console.log(`✅ Invoice generated: ${invoiceNumber}`);

    return invoice;
  }

  /**
   * Send invoice to client
   */
  async sendInvoiceToClient(invoiceId: string): Promise<void> {
    const invoice = await this.prisma.invoice.findUnique({
      where: { id: invoiceId },
    });

    if (!invoice) {
      throw new NotFoundException(`Invoice ${invoiceId} not found`);
    }

    // TODO: Send email via SendGrid or AWS SES
    const emailBody = `
Dear ${invoice.invoicedTo},

Invoice #${invoice.invoiceNumber} is attached.

Amount Due: ${invoice.currencyCode} ${invoice.total.toFixed(2)}
Due Date: ${invoice.dueDate.toLocaleDateString()}

Payment Details:
Bank: ${invoice.bankName}
Account: ${invoice.accountName}
Account Number: ${invoice.accountNumber}
SWIFT: ${invoice.swiftCode}

Please arrange payment by the due date.

Best regards,
LSCM Ltd
    `;

    // Update invoice status
    await this.prisma.invoice.update({
      where: { id: invoiceId },
      data: {
        status: 'SENT',
        sentAt: new Date(),
        sentTo: invoice.invoicedTo,
      },
    });

    console.log(`✅ Invoice sent: ${invoice.invoiceNumber} → ${invoice.invoicedTo}`);
  }

  /**
   * Record payment (Access Bank integration)
   */
  async recordPayment(invoiceId: string, dto: any): Promise<void> {
    const invoice = await this.prisma.invoice.findUnique({
      where: { id: invoiceId },
    });

    if (!invoice) {
      throw new NotFoundException(`Invoice ${invoiceId} not found`);
    }

    // Verify payment with Access Bank
    const verified = await this.verifyPaymentWithBank({
      accountNumber: invoice.accountNumber || '',
      amount: dto.amount,
      reference: dto.reference,
    });

    if (!verified) {
      throw new BadRequestException('Payment verification failed with Access Bank');
    }

    // Record payment
    const paidAmount = (invoice.paidAmount || 0) + dto.amount;

    const updated = await this.prisma.invoice.update({
      where: { id: invoiceId },
      data: {
        paidAmount,
        paidDate: new Date(),
        paymentReference: dto.reference,
        status: paidAmount >= invoice.total ? 'PAID' : 'PARTIAL',
      },
    });

    // If fully paid, update order status
    if (paidAmount >= invoice.total) {
      const order = await this.prisma.shipmentOrder.findUnique({
        where: { id: invoice.orderId },
      });

      await this.prisma.shipmentOrder.update({
        where: { id: invoice.orderId },
        data: {
          status: 'PAID',
          phase: 'CLOSURE',
          actualCost: invoice.total,
          updatedAt: new Date(),
        },
      });

      console.log(`✅ Invoice PAID: ${invoice.invoiceNumber}`);

      // Trigger JCR generation
      await this.generateJCR(invoice.orderId);
    } else {
      console.log(`⏳ Payment recorded (partial): ${invoice.invoiceNumber}`);
    }
  }

  /**
   * Get invoice by ID
   */
  async getInvoice(id: string): Promise<any> {
    const invoice = await this.prisma.invoice.findUnique({
      where: { id },
    });

    if (!invoice) {
      throw new NotFoundException(`Invoice ${id} not found`);
    }

    return invoice;
  }

  /**
   * List invoices by order
   */
  async listOrderInvoices(orderId: string): Promise<any[]> {
    return this.prisma.invoice.findMany({
      where: { orderId },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Schedule payment reminders (Cron job)
   * Reminder 1: 5 days before due
   * Reminder 2: 2 days before due
   * Escalation: On due date
   */
  async schedulePaymentReminders(invoiceId: string): Promise<void> {
    const invoice = await this.getInvoice(invoiceId);

    // TODO: Implement cron job scheduling
    console.log(`⏰ Payment reminders scheduled for ${invoice.invoiceNumber}`);
  }

  /**
   * Helper: Verify payment with Access Bank
   */
  private async verifyPaymentWithBank(data: {
    accountNumber: string;
    amount: number;
    reference: string;
  }): Promise<boolean> {
    try {
      // TODO: Implement actual Access Bank API call
      const response = await axios.default.post(
        `${process.env.ACCESS_BANK_API_URL}/verify-deposit`,
        {
          accountNumber: data.accountNumber,
          amount: data.amount,
          reference: data.reference,
        },
        {
          headers: {
            'X-API-Key': process.env.ACCESS_BANK_API_KEY,
          },
        },
      );

      return response.data.verified === true;
    } catch (error) {
      console.error('Bank verification error:', error);
      // For MVP: Accept all payments (remove in production)
      return true;
    }
  }

  /**
   * Helper: Generate Invoice PDF
   */
  private async generateInvoicePDF(order: any, invoice: any): Promise<string> {
    const fileName = `${invoice.invoiceNumber}.pdf`;
    const filePath = path.join(process.cwd(), 'uploads', fileName);

    const doc = new PDFDocument();
    const stream = fs.createWriteStream(filePath);
    doc.pipe(stream);

    // Header
    doc.fontSize(20).font('Helvetica-Bold').text('INVOICE', { align: 'center' });
    doc.fontSize(10).text(`Invoice #: ${invoice.invoiceNumber}`, { align: 'center' });
    doc.text(`Order Reference: ${order.orderReference}`, { align: 'center' });
    doc.moveDown();

    // Invoice Info
    doc.fontSize(10)
      .font('Helvetica-Bold')
      .text('INVOICE FROM:');
    doc.font('Helvetica')
      .text(invoice.invoiceFrom)
      .text(invoice.invoiceFromAddress)
      .moveDown();

    // Bill To
    doc.fontSize(10)
      .font('Helvetica-Bold')
      .text('BILL TO:');
    doc.font('Helvetica')
      .text(invoice.invoicedTo)
      .text(invoice.invoicedToAddress)
      .moveDown();

    // Invoice Details
    doc.fontSize(10)
      .font('Helvetica-Bold')
      .text(`Invoice Date: ${invoice.invoiceDate.toLocaleDateString()}`)
      .text(`Due Date: ${invoice.dueDate.toLocaleDateString()}`)
      .text(`Payment Terms: ${invoice.paymentTerms}`)
      .moveDown();

    // Line Items Table
    doc.fontSize(10).font('Helvetica-Bold').text('DESCRIPTION');
    doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
    doc.moveDown(0.5);

    const lineItems = JSON.parse(invoice.lineItems || '[]');
    lineItems.forEach((item: any) => {
      doc.fontSize(9)
        .font('Helvetica')
        .text(`${item.description}: ${invoice.currencyCode} ${item.amount.toFixed(2)}`);
    });

    doc.moveDown();
    doc.moveTo(50, doc.y).lineTo(550, doc.y).stroke();
    doc.moveDown(0.5);

    // Totals
    doc.fontSize(10)
      .font('Helvetica-Bold')
      .text(`Subtotal: ${invoice.currencyCode} ${invoice.subtotal.toFixed(2)}`)
      .text(`VAT (7.5%): ${invoice.currencyCode} ${invoice.vat.toFixed(2)}`)
      .text(`TOTAL: ${invoice.currencyCode} ${invoice.total.toFixed(2)}`);

    doc.moveDown();

    // Bank Details
    doc.fontSize(10)
      .font('Helvetica-Bold')
      .text('PAYMENT INSTRUCTIONS:');
    doc.fontSize(9)
      .font('Helvetica')
      .text(`Bank: ${invoice.bankName}`)
      .text(`Account Name: ${invoice.accountName}`)
      .text(`Account Number: ${invoice.accountNumber}`)
      .text(`Bank Code: ${invoice.bankCode}`)
      .text(`SWIFT Code: ${invoice.swiftCode}`)
      .moveDown();

    // Footer
    doc.fontSize(8).text('Thank you for your business!', { align: 'center' });

    doc.end();

    await new Promise((resolve) => stream.on('finish', resolve));

    return `/uploads/${fileName}`;
  }

  /**
   * Helper: Add days to date
   */
  private addDays(date: Date, days: number): Date {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  }

  /**
   * Helper: Generate JCR (placeholder)
   */
  private async generateJCR(orderId: string): Promise<void> {
    // Called from order closure - will be implemented in ReportingService
    console.log(`📋 JCR generation triggered for order ${orderId}`);
  }
}

// src/invoice/invoice.module.ts
import { Module } from '@nestjs/common';
import { InvoiceService } from './invoice.service';

@Module({
  providers: [InvoiceService],
  exports: [InvoiceService],
})
export class InvoiceModule {}
