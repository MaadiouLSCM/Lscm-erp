// test/orders.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { OrdersService } from '@/orders/orders.service';
import { PrismaService } from '@/prisma/prisma.service';

describe('OrdersService', () => {
  let service: OrdersService;
  let prisma: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        OrdersService,
        {
          provide: PrismaService,
          useValue: {
            shipmentOrder: {
              create: jest.fn(),
              findUnique: jest.fn(),
              update: jest.fn(),
              findMany: jest.fn(),
              count: jest.fn(),
            },
            transportSegment: {
              findMany: jest.fn(),
            },
          },
        },
      ],
    }).compile();

    service = module.get<OrdersService>(OrdersService);
    prisma = module.get<PrismaService>(PrismaService);
  });

  describe('createOrder', () => {
    it('should create a new order', async () => {
      const dto = {
        supplierId: 'SNIM',
        supplierName: 'SNIM',
        supplierCountry: 'Mauritania',
        buyerId: 'BUYER-001',
        buyerName: 'South African Buyer',
        buyerCountry: 'South Africa',
        commodityCode: '2601',
        description: 'Iron Ore',
        quantity: 25,
        grossWeight: 8500,
        originLocation: 'NKC',
        destLocation: 'JNB',
        incoterm: 'FOB',
        transportMode: 'AIR',
        createdBy: 'test@lscm.com',
      };

      const mockOrder = {
        id: 'ord-123',
        orderReference: 'ORD-SNIM-123456',
        ...dto,
        status: 'DRAFT',
        phase: 'PREPARATION',
        createdAt: new Date(),
      };

      (prisma.shipmentOrder.create as jest.Mock).mockResolvedValue(mockOrder);

      const result = await service.createOrder(dto);

      expect(result).toEqual(mockOrder);
      expect(prisma.shipmentOrder.create).toHaveBeenCalled();
    });

    it('should throw ConflictException if PO already exists', async () => {
      const dto = {
        supplierId: 'SNIM',
        supplierName: 'SNIM',
        supplierCountry: 'Mauritania',
        buyerId: 'BUYER-001',
        buyerName: 'South African Buyer',
        buyerCountry: 'South Africa',
        commodityCode: '2601',
        description: 'Iron Ore',
        quantity: 25,
        grossWeight: 8500,
        originLocation: 'NKC',
        destLocation: 'JNB',
        incoterm: 'FOB',
        transportMode: 'AIR',
        poNumber: 'PO-4560184557',
        createdBy: 'test@lscm.com',
      };

      (prisma.shipmentOrder.findFirst as jest.Mock).mockResolvedValue({
        id: 'ord-123',
      });

      await expect(service.createOrder(dto)).rejects.toThrow();
    });
  });

  describe('getOrder', () => {
    it('should return order by ID', async () => {
      const mockOrder = {
        id: 'ord-123',
        orderReference: 'SNIM-26020001',
        status: 'DRAFT',
      };

      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);

      const result = await service.getOrder('ord-123');

      expect(result).toEqual(mockOrder);
      expect(prisma.shipmentOrder.findUnique).toHaveBeenCalledWith({
        where: { id: 'ord-123' },
      });
    });

    it('should throw NotFoundException if order not found', async () => {
      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(null);

      await expect(service.getOrder('invalid-id')).rejects.toThrow();
    });
  });

  describe('updateOrderStatus', () => {
    it('should update order status with valid transition', async () => {
      const mockOrder = {
        id: 'ord-123',
        status: 'DRAFT',
      };

      const updatedOrder = {
        ...mockOrder,
        status: 'CONFIRMED',
      };

      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);
      (prisma.shipmentOrder.update as jest.Mock).mockResolvedValue(updatedOrder);

      const result = await service.updateOrderStatus('ord-123', 'CONFIRMED', 'user@lscm.com');

      expect(result.status).toBe('CONFIRMED');
    });

    it('should reject invalid status transition', async () => {
      const mockOrder = {
        id: 'ord-123',
        status: 'CLOSED',
      };

      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);

      await expect(
        service.updateOrderStatus('ord-123', 'DRAFT', 'user@lscm.com'),
      ).rejects.toThrow();
    });
  });

  describe('calculateOrderKPIs', () => {
    it('should calculate KPIs correctly', async () => {
      const createdDate = new Date('2025-03-01');
      const pickupDate = new Date('2025-03-03');
      const deliveryDate = new Date('2025-03-20');

      const mockOrder = {
        id: 'ord-123',
        createdAt: createdDate,
        pickupDate,
        deliveryDate,
        estimatedArrival: new Date('2025-03-25'),
        actualArrival: deliveryDate,
        transportMode: 'AIR',
        estimatedCost: 4500,
        actualCost: 4550,
      };

      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);

      const kpis = await service.calculateOrderKPIs('ord-123');

      expect(kpis.daysInPickup).toBeGreaterThan(0);
      expect(kpis.totalLeadTime).toBeGreaterThan(0);
      expect(kpis.onTime).toBe(true);
      expect(kpis.costVariance).toBeGreaterThan(0);
    });
  });

  describe('listOrders', () => {
    it('should list orders with filtering', async () => {
      const mockOrders = [
        { id: 'ord-1', orderReference: 'ORD-001', status: 'DRAFT' },
        { id: 'ord-2', orderReference: 'ORD-002', status: 'CONFIRMED' },
      ];

      (prisma.shipmentOrder.findMany as jest.Mock).mockResolvedValue(mockOrders);
      (prisma.shipmentOrder.count as jest.Mock).mockResolvedValue(2);

      const result = await service.listOrders({ status: 'DRAFT', limit: 50, page: 0 });

      expect(result.data).toHaveLength(2);
      expect(result.pagination.total).toBe(2);
    });
  });
});

// test/documents.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { DocumentsService } from '@/documents/documents.service';
import { PrismaService } from '@/prisma/prisma.service';

describe('DocumentsService', () => {
  let service: DocumentsService;
  let prisma: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        DocumentsService,
        {
          provide: PrismaService,
          useValue: {
            shipmentOrder: {
              findUnique: jest.fn(),
            },
            document: {
              create: jest.fn(),
              findMany: jest.fn(),
              findUnique: jest.fn(),
              update: jest.fn(),
            },
          },
        },
      ],
    }).compile();

    service = module.get<DocumentsService>(DocumentsService);
    prisma = module.get<PrismaService>(PrismaService);
  });

  describe('autoGenerateDocuments', () => {
    it('should generate RFC, JEP, and SM documents', async () => {
      const mockOrder = {
        id: 'ord-123',
        orderReference: 'SNIM-26020001',
        description: 'Iron Ore',
        quantity: 25,
        transportMode: 'AIR',
      };

      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);
      (prisma.document.create as jest.Mock).mockResolvedValue({
        id: 'doc-123',
        type: 'RFC',
      });

      const docs = await service.autoGenerateDocuments('ord-123');

      expect(docs.length).toBeGreaterThanOrEqual(3);
      expect(prisma.document.create).toHaveBeenCalled();
    });

    it('should generate AWB for air freight', async () => {
      const mockOrder = {
        id: 'ord-123',
        orderReference: 'SNIM-26020001',
        description: 'Iron Ore',
        quantity: 25,
        transportMode: 'AIR',
      };

      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);
      (prisma.document.create as jest.Mock).mockResolvedValue({
        id: 'doc-awb',
        type: 'AWB',
      });

      const docs = await service.autoGenerateDocuments('ord-123');

      const awbDoc = docs.find((d) => d.type === 'AWB');
      expect(awbDoc).toBeDefined();
    });

    it('should generate BL for sea freight', async () => {
      const mockOrder = {
        id: 'ord-123',
        orderReference: 'EGI-OIL-250302',
        description: 'Oilfield Equipment',
        quantity: 200,
        transportMode: 'SEA',
      };

      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);
      (prisma.document.create as jest.Mock).mockResolvedValue({
        id: 'doc-bl',
        type: 'BL',
      });

      const docs = await service.autoGenerateDocuments('ord-123');

      const blDoc = docs.find((d) => d.type === 'BL');
      expect(blDoc).toBeDefined();
    });
  });

  describe('approveDocument', () => {
    it('should approve document', async () => {
      const mockDoc = {
        id: 'doc-123',
        status: 'PENDING_REVIEW',
      };

      const approvedDoc = {
        ...mockDoc,
        status: 'APPROVED',
        approvedBy: 'approver@lscm.com',
        approvedAt: new Date(),
      };

      (prisma.document.findUnique as jest.Mock).mockResolvedValue(mockDoc);
      (prisma.document.update as jest.Mock).mockResolvedValue(approvedDoc);

      const result = await service.approveDocument('doc-123', 'approver@lscm.com');

      expect(result.status).toBe('APPROVED');
      expect(result.approvedBy).toBe('approver@lscm.com');
    });
  });
});

// test/customs.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { CustomsService } from '@/customs/customs.service';
import { PrismaService } from '@/prisma/prisma.service';

describe('CustomsService - Green Light 3-Party Gate', () => {
  let service: CustomsService;
  let prisma: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CustomsService,
        {
          provide: PrismaService,
          useValue: {
            shipmentOrder: {
              findUnique: jest.fn(),
              update: jest.fn(),
            },
            document: {
              findMany: jest.fn(),
              findFirst: jest.fn(),
              create: jest.fn(),
              update: jest.fn(),
            },
          },
        },
      ],
    }).compile();

    service = module.get<CustomsService>(CustomsService);
    prisma = module.get<PrismaService>(PrismaService);
  });

  describe('requestGreenLight', () => {
    it('should create Green Light request (BLOCKING order)', async () => {
      const mockOrder = {
        id: 'ord-123',
        orderReference: 'SNIM-26020001',
        status: 'PICKED_UP',
      };

      const mockDocs = [
        { type: 'RFC', status: 'APPROVED' },
        { type: 'JEP', status: 'APPROVED' },
        { type: 'CI', status: 'APPROVED' },
        { type: 'PL', status: 'APPROVED' },
        { type: 'SM', status: 'APPROVED' },
      ];

      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);
      (prisma.document.findMany as jest.Mock).mockResolvedValue(mockDocs);
      (prisma.document.create as jest.Mock).mockResolvedValue({
        id: 'gl-123',
        status: 'PENDING',
      });

      const glRequest = await service.requestGreenLight('ord-123', {});

      expect(glRequest.status).toBe('PENDING');
      expect(glRequest.requiredApprovals.client.status).toBe('PENDING');
      expect(glRequest.requiredApprovals.customsBroker.status).toBe('PENDING');
      expect(glRequest.requiredApprovals.carrier.status).toBe('PENDING');
    });

    it('should reject GL if docs incomplete', async () => {
      const mockOrder = {
        id: 'ord-123',
        orderReference: 'SNIM-26020001',
        status: 'PICKED_UP',
      };

      const incompleteDocs = [
        { type: 'RFC', status: 'APPROVED' },
        // Missing JEP, CI, PL, SM
      ];

      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);
      (prisma.document.findMany as jest.Mock).mockResolvedValue(incompleteDocs);

      await expect(service.requestGreenLight('ord-123', {})).rejects.toThrow();
    });
  });

  describe('recordApproval', () => {
    it('should record CLIENT approval', async () => {
      const glRequest = {
        requiredApprovals: {
          client: { status: 'PENDING' },
          customsBroker: { status: 'PENDING' },
          carrier: { status: 'PENDING' },
        },
        status: 'PENDING',
      };

      const mockGLDoc = {
        id: 'gl-123',
        approvalStatus: JSON.stringify(glRequest),
      };

      (prisma.document.findFirst as jest.Mock).mockResolvedValue(mockGLDoc);
      (prisma.document.update as jest.Mock).mockResolvedValue({
        ...mockGLDoc,
        status: 'PENDING_REVIEW',
      });

      const result = await service.recordApproval('ord-123', 'CLIENT', true);

      expect(result.requiredApprovals.client.status).toBe('APPROVED');
      // Still PENDING overall because other 2 parties haven't approved
      expect(result.status).toBe('PENDING');
    });

    it('should UNBLOCK order when ALL 3 parties approve', async () => {
      const glRequest = {
        requiredApprovals: {
          client: { status: 'APPROVED' },
          customsBroker: { status: 'APPROVED' },
          carrier: { status: 'PENDING' },
        },
        status: 'PENDING',
      };

      const mockOrder = {
        id: 'ord-123',
        orderReference: 'SNIM-26020001',
        status: 'IN_EXPORT_CUSTOMS',
      };

      const mockGLDoc = {
        id: 'gl-123',
        approvalStatus: JSON.stringify(glRequest),
      };

      (prisma.document.findFirst as jest.Mock).mockResolvedValue(mockGLDoc);
      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);

      // Record CARRIER approval (the last one)
      (prisma.document.update as jest.Mock).mockResolvedValue({
        ...mockGLDoc,
        status: 'APPROVED',
      });
      (prisma.shipmentOrder.update as jest.Mock).mockResolvedValue({
        ...mockOrder,
        status: 'BOOKING_READY',
        phase: 'BOOKING',
      });

      const result = await service.recordApproval('ord-123', 'CARRIER', true);

      expect(result.status).toBe('APPROVED');
      expect(prisma.shipmentOrder.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            status: 'BOOKING_READY',
            phase: 'BOOKING',
          }),
        }),
      );
    });

    it('should CANCEL order if ANY party rejects GL', async () => {
      const glRequest = {
        requiredApprovals: {
          client: { status: 'PENDING' },
          customsBroker: { status: 'PENDING' },
          carrier: { status: 'PENDING' },
        },
        status: 'PENDING',
      };

      const mockOrder = {
        id: 'ord-123',
        orderReference: 'SNIM-26020001',
        status: 'IN_EXPORT_CUSTOMS',
      };

      const mockGLDoc = {
        id: 'gl-123',
        approvalStatus: JSON.stringify(glRequest),
      };

      (prisma.document.findFirst as jest.Mock).mockResolvedValue(mockGLDoc);
      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);

      (prisma.document.update as jest.Mock).mockResolvedValue({
        ...mockGLDoc,
        status: 'REJECTED',
      });
      (prisma.shipmentOrder.update as jest.Mock).mockResolvedValue({
        ...mockOrder,
        status: 'CANCELLED',
        phase: 'CLOSURE',
      });

      const result = await service.recordApproval('ord-123', 'CUSTOMS_BROKER', false);

      expect(result.status).toBe('REJECTED');
      expect(prisma.shipmentOrder.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({
            status: 'CANCELLED',
          }),
        }),
      );
    });
  });
});

// test/invoice.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { InvoiceService } from '@/invoice/invoice.service';
import { PrismaService } from '@/prisma/prisma.service';

describe('InvoiceService', () => {
  let service: InvoiceService;
  let prisma: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        InvoiceService,
        {
          provide: PrismaService,
          useValue: {
            shipmentOrder: {
              findUnique: jest.fn(),
              update: jest.fn(),
            },
            invoice: {
              create: jest.fn(),
              findUnique: jest.fn(),
              findMany: jest.fn(),
              update: jest.fn(),
            },
          },
        },
      ],
    }).compile();

    service = module.get<InvoiceService>(InvoiceService);
    prisma = module.get<PrismaService>(PrismaService);
  });

  describe('generateInvoice', () => {
    it('should generate invoice with 7.5% VAT', async () => {
      const mockOrder = {
        id: 'ord-123',
        orderReference: 'SNIM-26020001',
        buyerName: 'South African Buyer',
        destLocation: 'JNB',
        buyerCountry: 'South Africa',
        status: 'DELIVERED',
        currencyCode: 'USD',
        serviceCharges: 3200,
        handlingFees: 400,
        customsFees: 150,
        insurance: 500,
      };

      const mockInvoice = {
        id: 'inv-123',
        invoiceNumber: 'INV-2025-00001',
        subtotal: 4250,
        vat: 318.75, // 4250 * 0.075
        total: 4568.75,
        status: 'ISSUED',
      };

      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);
      (prisma.invoice.create as jest.Mock).mockResolvedValue(mockInvoice);

      const invoice = await service.generateInvoice('ord-123', 'coordinator@lscm.com');

      expect(invoice.status).toBe('ISSUED');
      expect(invoice.vat).toBe(318.75);
      expect(invoice.total).toBe(4568.75);
    });

    it('should reject invoice generation if order not delivered', async () => {
      const mockOrder = {
        id: 'ord-123',
        status: 'IN_TRANSIT',
      };

      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);

      await expect(service.generateInvoice('ord-123', 'coordinator@lscm.com')).rejects.toThrow();
    });
  });

  describe('recordPayment', () => {
    it('should record payment', async () => {
      const mockInvoice = {
        id: 'inv-123',
        total: 4568.75,
        paidAmount: 0,
        status: 'ISSUED',
      };

      (prisma.invoice.findUnique as jest.Mock).mockResolvedValue(mockInvoice);
      (prisma.invoice.update as jest.Mock).mockResolvedValue({
        ...mockInvoice,
        paidAmount: 4568.75,
        status: 'PAID',
      });

      const payment = await service.recordPayment('inv-123', {
        amount: 4568.75,
        reference: 'TXN-2025-001',
      });

      expect(payment.status).toBe('PAID');
      expect(payment.paidAmount).toBe(4568.75);
    });
  });
});

// test/reporting.service.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { ReportingService } from '@/reporting/reporting.service';
import { PrismaService } from '@/prisma/prisma.service';

describe('ReportingService', () => {
  let service: ReportingService;
  let prisma: PrismaService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        ReportingService,
        {
          provide: PrismaService,
          useValue: {
            shipmentOrder: {
              findUnique: jest.fn(),
              findMany: jest.fn(),
              update: jest.fn(),
            },
            transportSegment: {
              findMany: jest.fn(),
            },
            incident: {
              findMany: jest.fn(),
            },
            dailyStatusReport: {
              create: jest.fn(),
              update: jest.fn(),
            },
            weeklyStatusReport: {
              create: jest.fn(),
            },
            jobCompletionReport: {
              create: jest.fn(),
              update: jest.fn(),
            },
            document: {
              findMany: jest.fn(),
            },
            invoice: {
              findFirst: jest.fn(),
            },
          },
        },
      ],
    }).compile();

    service = module.get<ReportingService>(ReportingService);
    prisma = module.get<PrismaService>(PrismaService);
  });

  describe('generateDSR', () => {
    it('should generate Daily Status Report', async () => {
      const mockOrder = {
        id: 'ord-123',
        orderReference: 'SNIM-26020001',
        status: 'IN_TRANSIT',
        phase: 'TRANSIT',
        originLocation: 'NKC',
        buyerEmail: 'buyer@example.com',
        createdAt: new Date('2025-03-01'),
        pickupDate: new Date('2025-03-03'),
        estimatedArrival: new Date('2025-03-10'),
      };

      const mockSegments = [
        {
          segmentId: 'SEG-1',
          originName: 'Nouakchott',
          destName: 'Istanbul',
          estimatedArrival: new Date('2025-03-06'),
          actualArrival: null,
          currentLocation: 'In Transit',
        },
      ];

      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);
      (prisma.transportSegment.findMany as jest.Mock).mockResolvedValue(mockSegments);
      (prisma.incident.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.dailyStatusReport.create as jest.Mock).mockResolvedValue({
        id: 'dsr-123',
        status: 'GENERATED',
      });

      const dsr = await service.generateDSR('ord-123');

      expect(dsr).toBeDefined();
      expect(prisma.dailyStatusReport.create).toHaveBeenCalled();
    });
  });

  describe('generateJCR', () => {
    it('should generate Job Completion Report', async () => {
      const mockOrder = {
        id: 'ord-123',
        orderReference: 'SNIM-26020001',
        supplierName: 'SNIM',
        buyerName: 'Buyer',
        originLocation: 'NKC',
        destLocation: 'JNB',
        totalCost: 4568.75,
        createdAt: new Date('2025-03-01'),
        deliveryDate: new Date('2025-03-10'),
        estimatedArrival: new Date('2025-03-10'),
        actualArrival: new Date('2025-03-10'),
      };

      (prisma.shipmentOrder.findUnique as jest.Mock).mockResolvedValue(mockOrder);
      (prisma.document.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.transportSegment.findMany as jest.Mock).mockResolvedValue([]);
      (prisma.invoice.findFirst as jest.Mock).mockResolvedValue({
        invoiceNumber: 'INV-2025-00001',
        status: 'PAID',
      });
      (prisma.jobCompletionReport.create as jest.Mock).mockResolvedValue({
        id: 'jcr-123',
        jcrNumber: 'JCR-2025-00001',
      });

      const jcr = await service.generateJCR('ord-123');

      expect(jcr).toBeDefined();
      expect(jcr.jcrNumber).toBeDefined();
    });
  });
});
