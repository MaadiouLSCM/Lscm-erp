// src/pickup/pickup.service.ts
import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';

@Injectable()
export class PickupService {
  constructor(private prisma: PrismaService) {}

  /**
   * Schedule pickup
   */
  async schedulePickup(orderId: string, dto: any) {
    const order = await this.prisma.shipmentOrder.findUnique({
      where: { id: orderId },
    });

    if (!order) {
      throw new NotFoundException(`Order ${orderId} not found`);
    }

    const schedule = await this.prisma.pickupSchedule.create({
      data: {
        orderId,
        pickupId: `PKP-${order.orderReference}`,
        scheduledDate: new Date(dto.scheduledDate),
        scheduledTime: dto.scheduledTime,
        supplierLocation: dto.supplierLocation,
        agentAssigned: dto.agentAssigned,
        estimatedDuration: dto.estimatedDuration,
        contactPerson: dto.contactPerson,
        status: 'SCHEDULED',
      },
    });

    console.log(`✅ Pickup scheduled: ${schedule.pickupId}`);
    return schedule;
  }

  /**
   * Record Proof of Collection (POC)
   * MANDATORY: minimum 2 photos per package
   */
  async recordPOC(orderId: string, dto: any) {
    const order = await this.prisma.shipmentOrder.findUnique({
      where: { id: orderId },
    });

    if (!order) {
      throw new NotFoundException(`Order ${orderId} not found`);
    }

    // VALIDATION: Check photo requirement
    const requiredPhotos = order.quantity * 2;
    if (dto.photos.length < requiredPhotos) {
      throw new BadRequestException(
        `Insufficient photos. Required: ${requiredPhotos}, Provided: ${dto.photos.length}`,
      );
    }

    // VALIDATION: Check shipping marks
    if (!dto.shippingMarksVerified) {
      throw new BadRequestException('Shipping marks must be verified before POC');
    }

    const poc = await this.prisma.proofOfCollection.create({
      data: {
        orderId,
        pocId: `POC-${order.orderReference}`,
        pickedUpAt: new Date(dto.pickedUpAt),
        pickedUpBy: dto.pickedUpBy,
        location: dto.location,
        packageCount: dto.packageCount,
        actualWeight: dto.actualWeight,
        condition: dto.condition,
        shippingMarksVerified: true,
        documentsCollected: JSON.stringify(dto.documentsCollected),
        photos: JSON.stringify(dto.photos),
        photosVerified: dto.photos.length >= requiredPhotos,
        supplierSignature: dto.supplierSignature,
        agentSignature: dto.agentSignature,
        signatureDate: new Date(dto.signatureDate),
        status: 'VERIFIED',
      },
    });

    // Update order status
    await this.prisma.shipmentOrder.update({
      where: { id: orderId },
      data: {
        status: 'PICKED_UP',
        pickupDate: new Date(dto.pickedUpAt),
        phase: 'DOCUMENTATION',
        updatedAt: new Date(),
        updatedBy: dto.pickedUpBy,
      },
    });

    console.log(`✅ POC recorded: ${poc.pocId}`);
    return poc;
  }

  /**
   * Hub Reception & Quality Check
   */
  async receiveAtHub(orderId: string, dto: any) {
    const order = await this.prisma.shipmentOrder.findUnique({
      where: { id: orderId },
    });

    if (!order) {
      throw new NotFoundException(`Order ${orderId} not found`);
    }

    // Quality checks
    const issues = [];

    if (dto.packageCount !== order.quantity) {
      issues.push(
        `Package count mismatch: Expected ${order.quantity}, Got ${dto.packageCount}`,
      );
    }

    if (dto.weight > order.grossWeight * 1.05) {
      issues.push(`Weight exceeds tolerance: ${dto.weight} kg vs ${order.grossWeight} kg`);
    }

    if (dto.condition === 'DAMAGED') {
      issues.push('Cargo condition: DAMAGED');
    }

    if (issues.length > 0 && !dto.acceptWithIssues) {
      throw new BadRequestException(`Hub reception issues: ${issues.join(', ')}`);
    }

    // Update order status if all checks pass
    if (issues.length === 0) {
      await this.prisma.shipmentOrder.update({
        where: { id: orderId },
        data: {
          status: 'CONFIRMED',
          phase: 'EXPORT_CUSTOMS',
          updatedAt: new Date(),
          updatedBy: dto.receivedBy,
        },
      });
    }

    return {
      orderId,
      receivedAt: new Date(dto.receivedAt),
      receivedBy: dto.receivedBy,
      packageCountVerified: dto.packageCount === order.quantity,
      weightVerified: dto.weight <= order.grossWeight * 1.05,
      conditionOK: dto.condition !== 'DAMAGED',
      smIntact: dto.shippingMarksOK,
      storageLocation: dto.storageLocation,
      issues: issues.length > 0 ? issues : null,
      photos: dto.photos,
      status: issues.length === 0 ? 'RECEIVED' : 'RECEIVED_WITH_ISSUES',
    };
  }

  /**
   * Get POC by order
   */
  async getPOC(orderId: string) {
    return this.prisma.proofOfCollection.findUnique({
      where: { orderId },
    });
  }
}

// src/pickup/pickup.module.ts
import { Module } from '@nestjs/common';
import { PickupService } from './pickup.service';

@Module({
  providers: [PickupService],
  exports: [PickupService],
})
export class PickupModule {}
