// src/tasks/task.entity.ts
import { ObjectType, Field, ID } from '@nestjs/graphql';
import { TaskStatus, TaskPriority, TaskType } from './task.types';

@ObjectType()
export class Task {
  @Field(() => ID)
  id: string;

  @Field()
  title: string;

  @Field({ nullable: true })
  description?: string;

  @Field(() => TaskType)
  type: TaskType;

  @Field(() => TaskStatus)
  status: TaskStatus;

  @Field(() => TaskPriority)
  priority: TaskPriority;

  @Field({ nullable: true })
  orderId?: string;

  @Field({ nullable: true })
  assignedTo?: string;

  @Field()
  createdBy: string;

  @Field()
  dueDate: Date;

  @Field({ nullable: true })
  completedAt?: Date;

  @Field({ nullable: true })
  completedBy?: string;

  @Field(() => [String], { nullable: true })
  dependsOn?: string[];

  @Field({ nullable: true })
  slaDueDate?: Date;

  @Field({ nullable: true })
  slaBreach?: boolean;

  @Field(() => [String], { nullable: true })
  attachments?: string[];

  @Field()
  createdAt: Date;

  @Field()
  updatedAt: Date;
}

// src/tasks/task.types.ts
export enum TaskStatus {
  PENDING = 'PENDING',
  ASSIGNED = 'ASSIGNED',
  IN_PROGRESS = 'IN_PROGRESS',
  BLOCKED = 'BLOCKED',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
  CANCELLED = 'CANCELLED',
}

export enum TaskPriority {
  LOW = 1,
  NORMAL = 2,
  HIGH = 3,
  CRITICAL = 4,
}

export enum TaskType {
  // Order-related
  CREATE_ORDER = 'CREATE_ORDER',
  GENERATE_DOCUMENTS = 'GENERATE_DOCUMENTS',
  SCHEDULE_PICKUP = 'SCHEDULE_PICKUP',
  RECORD_POC = 'RECORD_POC',
  REQUEST_GREEN_LIGHT = 'REQUEST_GREEN_LIGHT',
  APPROVE_GREEN_LIGHT = 'APPROVE_GREEN_LIGHT',
  BOOK_CARRIER = 'BOOK_CARRIER',
  RECORD_LOADING = 'RECORD_LOADING',
  UPDATE_TRACKING = 'UPDATE_TRACKING',

  // Financial
  GENERATE_INVOICE = 'GENERATE_INVOICE',
  VERIFY_PAYMENT = 'VERIFY_PAYMENT',
  SEND_PAYMENT_REMINDER = 'SEND_PAYMENT_REMINDER',

  // Reporting
  GENERATE_DSR = 'GENERATE_DSR',
  GENERATE_WSR = 'GENERATE_WSR',
  GENERATE_JCR = 'GENERATE_JCR',

  // System
  HEALTH_CHECK = 'HEALTH_CHECK',
  DATABASE_BACKUP = 'DATABASE_BACKUP',
  CLEANUP = 'CLEANUP',
}

export interface TaskContext {
  orderId?: string;
  invoiceId?: string;
  segmentId?: string;
  userId?: string;
  metadata?: Record<string, any>;
}

// src/tasks/task.service.ts
import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import { TaskQueue } from './task-queue';
import { TaskScheduler } from './task-scheduler';
import { TaskNotificationService } from './task-notification.service';
import { Task, TaskStatus, TaskPriority, TaskType, TaskContext } from './task.types';
import * as cron from 'node-cron';

@Injectable()
export class TaskService {
  private taskQueue: TaskQueue;
  private taskScheduler: TaskScheduler;

  constructor(
    private prisma: PrismaService,
    private notificationService: TaskNotificationService,
  ) {
    this.taskQueue = new TaskQueue();
    this.taskScheduler = new TaskScheduler(this);
    this.initializeSystemTasks();
  }

  /**
   * Create a new task
   */
  async createTask(
    title: string,
    type: TaskType,
    context: TaskContext,
    options: {
      description?: string;
      priority?: TaskPriority;
      dueDate?: Date;
      assignedTo?: string;
      dependsOn?: string[];
      slaDays?: number;
    } = {},
  ): Promise<Task> {
    const task = await this.prisma.task.create({
      data: {
        title,
        type,
        description: options.description,
        status: TaskStatus.PENDING,
        priority: options.priority || TaskPriority.NORMAL,
        dueDate: options.dueDate || new Date(Date.now() + 24 * 60 * 60 * 1000),
        assignedTo: options.assignedTo,
        orderId: context.orderId,
        dependsOn: options.dependsOn || [],
        slaDueDate: options.slaDays
          ? new Date(Date.now() + options.slaDays * 24 * 60 * 60 * 1000)
          : undefined,
        context: context.metadata || {},
        createdBy: context.userId || 'system',
      },
    });

    console.log(`✅ Task created: ${task.id} (${type})`);

    // Check if dependencies are met
    if (task.dependsOn.length === 0) {
      await this.assignTask(task.id);
    }

    return task;
  }

  /**
   * Assign task (check dependencies first)
   */
  async assignTask(taskId: string): Promise<Task> {
    const task = await this.prisma.task.findUnique({ where: { id: taskId } });
    if (!task) throw new NotFoundException('Task not found');

    // Check if all dependencies are completed
    if (task.dependsOn && task.dependsOn.length > 0) {
      const dependencies = await this.prisma.task.findMany({
        where: { id: { in: task.dependsOn } },
      });

      const allCompleted = dependencies.every((d) => d.status === TaskStatus.COMPLETED);
      if (!allCompleted) {
        throw new BadRequestException('Not all dependencies are completed');
      }
    }

    const updated = await this.prisma.task.update({
      where: { id: taskId },
      data: { status: TaskStatus.ASSIGNED },
    });

    // Add to queue with priority
    this.taskQueue.addTask(updated);

    // Send notification
    if (updated.assignedTo) {
      await this.notificationService.notifyAssignment(updated);
    }

    console.log(`📋 Task assigned: ${taskId}`);
    return updated;
  }

  /**
   * Start executing task
   */
  async startTask(taskId: string, userId: string): Promise<Task> {
    const task = await this.prisma.task.findUnique({ where: { id: taskId } });
    if (!task) throw new NotFoundException('Task not found');

    const updated = await this.prisma.task.update({
      where: { id: taskId },
      data: {
        status: TaskStatus.IN_PROGRESS,
        assignedTo: userId,
      },
    });

    return updated;
  }

  /**
   * Complete task
   */
  async completeTask(
    taskId: string,
    userId: string,
    result?: Record<string, any>,
  ): Promise<Task> {
    const task = await this.prisma.task.findUnique({ where: { id: taskId } });
    if (!task) throw new NotFoundException('Task not found');

    const updated = await this.prisma.task.update({
      where: { id: taskId },
      data: {
        status: TaskStatus.COMPLETED,
        completedAt: new Date(),
        completedBy: userId,
        result: result || {},
      },
    });

    console.log(`✅ Task completed: ${taskId}`);

    // Check for dependent tasks
    const dependentTasks = await this.prisma.task.findMany({
      where: {
        dependsOn: { hasSome: [taskId] },
        status: TaskStatus.PENDING,
      },
    });

    // Assign dependent tasks
    for (const dependent of dependentTasks) {
      const remainingDeps = dependent.dependsOn.filter((id) => {
        return id !== taskId;
      });

      if (remainingDeps.length === 0) {
        await this.assignTask(dependent.id);
      }
    }

    // Send notification
    await this.notificationService.notifyCompletion(updated);

    return updated;
  }

  /**
   * Fail task with retry logic
   */
  async failTask(
    taskId: string,
    error: string,
    userId: string,
    retryCount: number = 0,
  ): Promise<Task> {
    const task = await this.prisma.task.findUnique({ where: { id: taskId } });
    if (!task) throw new NotFoundException('Task not found');

    const MAX_RETRIES = 3;

    if (retryCount < MAX_RETRIES) {
      // Retry with exponential backoff
      const backoffMs = Math.pow(2, retryCount) * 60000; // 1m, 2m, 4m
      const retryTime = new Date(Date.now() + backoffMs);

      const updated = await this.prisma.task.update({
        where: { id: taskId },
        data: {
          status: TaskStatus.PENDING,
          retryCount: (task.retryCount || 0) + 1,
          nextRetryTime: retryTime,
          lastError: error,
        },
      });

      console.log(`🔄 Task retry scheduled: ${taskId} (attempt ${retryCount + 1}/${MAX_RETRIES})`);

      // Schedule retry
      this.taskScheduler.scheduleTask(updated.id, retryTime);

      await this.notificationService.notifyRetry(updated, retryCount + 1, MAX_RETRIES);

      return updated;
    } else {
      // Move to dead letter queue
      const updated = await this.prisma.task.update({
        where: { id: taskId },
        data: {
          status: TaskStatus.FAILED,
          lastError: error,
          deadLetterAt: new Date(),
        },
      });

      console.log(`❌ Task moved to dead letter queue: ${taskId}`);

      // Add to dead letter queue
      this.taskQueue.addToDeadLetterQueue(updated);

      // Critical notification
      await this.notificationService.notifyCritical(
        updated,
        `Task failed after ${MAX_RETRIES} retries: ${error}`,
      );

      return updated;
    }
  }

  /**
   * Block task (waiting for dependency or approval)
   */
  async blockTask(taskId: string, reason: string): Promise<Task> {
    const updated = await this.prisma.task.update({
      where: { id: taskId },
      data: {
        status: TaskStatus.BLOCKED,
        blockReason: reason,
      },
    });

    console.log(`🚫 Task blocked: ${taskId} - ${reason}`);
    return updated;
  }

  /**
   * Unblock task
   */
  async unblockTask(taskId: string): Promise<Task> {
    const updated = await this.prisma.task.update({
      where: { id: taskId },
      data: {
        status: TaskStatus.PENDING,
        blockReason: null,
      },
    });

    await this.assignTask(taskId);
    console.log(`✅ Task unblocked: ${taskId}`);

    return updated;
  }

  /**
   * List tasks with filters
   */
  async listTasks(
    filters: {
      status?: TaskStatus;
      priority?: TaskPriority;
      assignedTo?: string;
      type?: TaskType;
      overdue?: boolean;
      slaBreached?: boolean;
      page?: number;
      limit?: number;
    },
  ): Promise<{ data: Task[]; pagination: any }> {
    const where: any = {};

    if (filters.status) where.status = filters.status;
    if (filters.priority) where.priority = filters.priority;
    if (filters.assignedTo) where.assignedTo = filters.assignedTo;
    if (filters.type) where.type = filters.type;

    if (filters.overdue) {
      where.dueDate = { lt: new Date() };
      where.status = { notIn: [TaskStatus.COMPLETED, TaskStatus.CANCELLED] };
    }

    if (filters.slaBreached) {
      where.slaDueDate = { lt: new Date() };
      where.status = { notIn: [TaskStatus.COMPLETED, TaskStatus.CANCELLED] };
    }

    const total = await this.prisma.task.count({ where });
    const data = await this.prisma.task.findMany({
      where,
      orderBy: [{ priority: 'desc' }, { dueDate: 'asc' }],
      skip: (filters.page || 0) * (filters.limit || 50),
      take: filters.limit || 50,
    });

    return {
      data,
      pagination: {
        total,
        page: filters.page || 0,
        limit: filters.limit || 50,
      },
    };
  }

  /**
   * Initialize system tasks (DSR, WSR, backups, etc)
   */
  private initializeSystemTasks() {
    // Generate DSR daily at 17:00 UTC
    cron.schedule('0 17 * * *', async () => {
      console.log('⏰ Scheduled DSR generation...');
      const orders = await this.prisma.shipmentOrder.findMany({
        where: {
          status: { in: ['PICKED_UP', 'IN_TRANSIT', 'CUSTOMS_HOLD'] },
        },
      });

      for (const order of orders) {
        await this.createTask(
          `Generate DSR for ${order.orderReference}`,
          TaskType.GENERATE_DSR,
          { orderId: order.id, userId: 'system' },
          {
            priority: TaskPriority.HIGH,
            description: `Auto-generated DSR for order ${order.orderReference}`,
          },
        );
      }
    });

    // Generate WSR weekly on Monday 08:00 UTC
    cron.schedule('0 8 * * 1', async () => {
      console.log('⏰ Scheduled WSR generation...');
      await this.createTask(
        'Generate Weekly Status Report',
        TaskType.GENERATE_WSR,
        { userId: 'system' },
        {
          priority: TaskPriority.NORMAL,
          description: 'Auto-generated WSR for the week',
        },
      );
    });

    // Database backup daily at 02:00 UTC
    cron.schedule('0 2 * * *', async () => {
      console.log('⏰ Scheduled database backup...');
      await this.createTask(
        'Database Backup',
        TaskType.DATABASE_BACKUP,
        { userId: 'system' },
        {
          priority: TaskPriority.HIGH,
          description: 'Auto-backup database to S3',
        },
      );
    });

    // Health check every 5 minutes
    cron.schedule('*/5 * * * *', async () => {
      await this.createTask(
        'System Health Check',
        TaskType.HEALTH_CHECK,
        { userId: 'system' },
        { priority: TaskPriority.NORMAL },
      );
    });

    console.log('✅ System tasks initialized');
  }

  /**
   * Get task metrics/dashboard
   */
  async getTaskMetrics(): Promise<any> {
    const total = await this.prisma.task.count();
    const pending = await this.prisma.task.count({
      where: { status: TaskStatus.PENDING },
    });
    const inProgress = await this.prisma.task.count({
      where: { status: TaskStatus.IN_PROGRESS },
    });
    const completed = await this.prisma.task.count({
      where: { status: TaskStatus.COMPLETED },
    });
    const failed = await this.prisma.task.count({
      where: { status: TaskStatus.FAILED },
    });

    const overdue = await this.prisma.task.count({
      where: {
        dueDate: { lt: new Date() },
        status: { notIn: [TaskStatus.COMPLETED, TaskStatus.CANCELLED] },
      },
    });

    const slaBreached = await this.prisma.task.count({
      where: {
        slaDueDate: { lt: new Date() },
        status: { notIn: [TaskStatus.COMPLETED, TaskStatus.CANCELLED] },
      },
    });

    const avgCompletionTime = await this.prisma.task.findMany({
      where: { status: TaskStatus.COMPLETED },
      select: {
        createdAt: true,
        completedAt: true,
      },
    });

    const completionTimes = avgCompletionTime
      .filter((t) => t.completedAt)
      .map((t) => (t.completedAt!.getTime() - t.createdAt.getTime()) / 1000 / 60); // in minutes

    const avgTime =
      completionTimes.length > 0
        ? completionTimes.reduce((a, b) => a + b, 0) / completionTimes.length
        : 0;

    return {
      total,
      pending,
      inProgress,
      completed,
      failed,
      overdue,
      slaBreached,
      averageCompletionTimeMinutes: Math.round(avgTime),
    };
  }
}

// src/tasks/task-queue.ts
import { Task } from './task.types';

interface QueuedTask {
  task: Task;
  addedAt: Date;
}

export class TaskQueue {
  private queue: QueuedTask[] = [];
  private deadLetterQueue: Task[] = [];
  private maxQueueSize = 10000;
  private processInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.startProcessing();
  }

  addTask(task: Task): void {
    if (this.queue.length >= this.maxQueueSize) {
      console.warn('⚠️ Task queue full, task discarded');
      return;
    }

    this.queue.push({
      task,
      addedAt: new Date(),
    });

    // Sort by priority (descending) and due date (ascending)
    this.queue.sort((a, b) => {
      if (a.task.priority !== b.task.priority) {
        return b.task.priority - a.task.priority;
      }
      return a.task.dueDate.getTime() - b.task.dueDate.getTime();
    });

    console.log(`📥 Task added to queue. Queue size: ${this.queue.length}`);
  }

  getNextTask(): Task | null {
    if (this.queue.length === 0) return null;

    const { task } = this.queue[0];
    return task;
  }

  removeTask(taskId: string): void {
    this.queue = this.queue.filter((q) => q.task.id !== taskId);
  }

  addToDeadLetterQueue(task: Task): void {
    this.deadLetterQueue.push(task);
    console.log(`💀 Task added to dead letter queue: ${task.id}`);
  }

  getDeadLetterQueue(): Task[] {
    return this.deadLetterQueue;
  }

  getQueueSize(): number {
    return this.queue.length;
  }

  private startProcessing(): void {
    this.processInterval = setInterval(() => {
      const metrics = {
        queueSize: this.queue.length,
        dlqSize: this.deadLetterQueue.length,
        timestamp: new Date().toISOString(),
      };
      console.log('📊 Queue Metrics:', metrics);
    }, 60000); // Every minute
  }

  destroy(): void {
    if (this.processInterval) {
      clearInterval(this.processInterval);
    }
  }
}

// src/tasks/task-scheduler.ts
import { Task } from './task.types';
import { TaskService } from './task.service';

export class TaskScheduler {
  private scheduledTasks: Map<string, NodeJS.Timeout> = new Map();

  constructor(private taskService: TaskService) {}

  /**
   * Schedule a task for a specific time
   */
  scheduleTask(taskId: string, executeAt: Date): void {
    const now = new Date();
    const delay = executeAt.getTime() - now.getTime();

    if (delay < 0) {
      console.warn(`⚠️ Scheduled time is in the past: ${taskId}`);
      return;
    }

    const timeout = setTimeout(async () => {
      console.log(`⏱️ Executing scheduled task: ${taskId}`);
      try {
        await this.taskService.startTask(taskId, 'system');
        // Execute task logic here
        this.scheduledTasks.delete(taskId);
      } catch (error) {
        console.error(`❌ Error executing scheduled task: ${error}`);
      }
    }, delay);

    this.scheduledTasks.set(taskId, timeout);
    console.log(`📅 Task scheduled: ${taskId} for ${executeAt.toISOString()}`);
  }

  /**
   * Cancel scheduled task
   */
  cancelScheduledTask(taskId: string): void {
    const timeout = this.scheduledTasks.get(taskId);
    if (timeout) {
      clearTimeout(timeout);
      this.scheduledTasks.delete(taskId);
      console.log(`❌ Scheduled task cancelled: ${taskId}`);
    }
  }

  /**
   * Get all scheduled tasks
   */
  getScheduledTasks(): string[] {
    return Array.from(this.scheduledTasks.keys());
  }
}

// src/tasks/task-notification.service.ts
import { Injectable } from '@nestjs/common';
import { Task } from './task.types';
import { SlackService } from '@/integrations/slack.service';
import { EmailService } from '@/integrations/email.service';
import { SMSService } from '@/integrations/sms.service';

@Injectable()
export class TaskNotificationService {
  constructor(
    private slackService: SlackService,
    private emailService: EmailService,
    private smsService: SMSService,
  ) {}

  /**
   * Notify task assignment
   */
  async notifyAssignment(task: Task): Promise<void> {
    const message = `📋 Task assigned: ${task.title}\nType: ${task.type}\nDue: ${task.dueDate.toISOString()}`;

    // Slack
    await this.slackService.sendMessage({
      channel: `@${task.assignedTo}`,
      text: message,
      attachments: [
        {
          color: 'good',
          title: task.title,
          text: task.description,
          fields: [
            { title: 'Priority', value: task.priority.toString(), short: true },
            { title: 'Type', value: task.type, short: true },
            { title: 'Due Date', value: task.dueDate.toISOString(), short: false },
          ],
        },
      ],
    });

    // Email
    if (task.assignedTo) {
      await this.emailService.send({
        to: task.assignedTo,
        subject: `Task Assigned: ${task.title}`,
        template: 'task-assigned',
        data: { task },
      });
    }
  }

  /**
   * Notify task completion
   */
  async notifyCompletion(task: Task): Promise<void> {
    const message = `✅ Task completed: ${task.title}`;

    await this.slackService.sendMessage({
      channel: '#task-notifications',
      text: message,
      attachments: [
        {
          color: 'good',
          title: task.title,
          text: `Completed at ${task.completedAt?.toISOString()}`,
        },
      ],
    });
  }

  /**
   * Notify retry attempt
   */
  async notifyRetry(task: Task, attempt: number, maxRetries: number): Promise<void> {
    const message = `🔄 Task retry: ${task.title}\nAttempt ${attempt}/${maxRetries}`;

    await this.slackService.sendMessage({
      channel: '#task-notifications',
      text: message,
      attachments: [
        {
          color: 'warning',
          title: task.title,
          fields: [
            { title: 'Attempt', value: `${attempt}/${maxRetries}`, short: true },
            { title: 'Next Retry', value: task.nextRetryTime?.toISOString() || 'TBD', short: true },
            { title: 'Last Error', value: task.lastError || 'Unknown', short: false },
          ],
        },
      ],
    });
  }

  /**
   * Critical notification (dead letter queue)
   */
  async notifyCritical(task: Task, message: string): Promise<void> {
    // Slack - Critical channel with mentions
    await this.slackService.sendMessage({
      channel: '#critical-alerts',
      text: `🚨 CRITICAL: ${message}`,
      mentions: ['@devops', '@support'],
      attachments: [
        {
          color: 'danger',
          title: task.title,
          fields: [
            { title: 'Task ID', value: task.id, short: true },
            { title: 'Type', value: task.type, short: true },
            { title: 'Error', value: task.lastError || 'Unknown', short: false },
          ],
        },
      ],
    });

    // Email to admins
    await this.emailService.send({
      to: 'admin@lscm.com',
      subject: `🚨 CRITICAL TASK FAILURE: ${task.title}`,
      template: 'task-critical',
      data: { task, message },
    });

    // SMS to on-call
    await this.smsService.send({
      to: '+1234567890',
      message: `CRITICAL: Task ${task.id} failed after retries. Check Slack #critical-alerts`,
    });
  }

  /**
   * SLA breach notification
   */
  async notifySLABreach(task: Task): Promise<void> {
    const message = `⚠️ SLA BREACH: ${task.title}\nDue: ${task.slaDueDate?.toISOString()}`;

    await this.slackService.sendMessage({
      channel: '#sla-alerts',
      text: message,
      mentions: ['@manager'],
      attachments: [
        {
          color: 'danger',
          title: task.title,
          fields: [
            { title: 'SLA Due', value: task.slaDueDate?.toISOString() || 'N/A', short: true },
            { title: 'Time Overdue', value: this.calculateOverdue(task.slaDueDate), short: true },
          ],
        },
      ],
    });
  }

  /**
   * Webhook notifications (integrate with external systems)
   */
  async sendWebhook(
    url: string,
    event: string,
    task: Task,
  ): Promise<void> {
    try {
      const payload = {
        event,
        task,
        timestamp: new Date().toISOString(),
      };

      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        console.error(`❌ Webhook failed: ${url} - ${response.statusText}`);
      }
    } catch (error) {
      console.error(`❌ Webhook error: ${error}`);
    }
  }

  private calculateOverdue(dueDate?: Date): string {
    if (!dueDate) return 'N/A';
    const now = new Date();
    const diff = now.getTime() - dueDate.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m overdue`;
  }
}

// src/tasks/task.controller.ts
import {
  Controller,
  Get,
  Post,
  Put,
  Body,
  Param,
  Query,
  UseGuards,
  Request,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { TaskService } from './task.service';
import { JwtAuthGuard } from '@/auth/guards/jwt-auth.guard';
import { TaskStatus, TaskPriority, TaskType } from './task.types';

@ApiTags('Tasks')
@Controller({ path: 'tasks', version: '1' })
@UseGuards(JwtAuthGuard)
@ApiBearerAuth('JWT')
export class TaskController {
  constructor(private taskService: TaskService) {}

  @Post()
  async createTask(@Body() dto: any, @Request() req: any) {
    return this.taskService.createTask(
      dto.title,
      dto.type as TaskType,
      { userId: req.user.sub, orderId: dto.orderId },
      {
        description: dto.description,
        priority: dto.priority,
        dueDate: dto.dueDate ? new Date(dto.dueDate) : undefined,
        assignedTo: dto.assignedTo,
        dependsOn: dto.dependsOn,
        slaDays: dto.slaDays,
      },
    );
  }

  @Get()
  async listTasks(
    @Query('status') status?: TaskStatus,
    @Query('priority') priority?: TaskPriority,
    @Query('assignedTo') assignedTo?: string,
    @Query('type') type?: TaskType,
    @Query('overdue') overdue?: boolean,
    @Query('page') page?: number,
    @Query('limit') limit?: number,
  ) {
    return this.taskService.listTasks({
      status,
      priority: priority ? parseInt(priority as any) : undefined,
      assignedTo,
      type,
      overdue: overdue === 'true',
      page: page ? parseInt(page as any) : 0,
      limit: limit ? parseInt(limit as any) : 50,
    });
  }

  @Get('metrics')
  async getMetrics() {
    return this.taskService.getTaskMetrics();
  }

  @Get(':id')
  async getTask(@Param('id') id: string) {
    return this.taskService.getTask(id);
  }

  @Put(':id/start')
  async startTask(@Param('id') id: string, @Request() req: any) {
    return this.taskService.startTask(id, req.user.sub);
  }

  @Put(':id/complete')
  async completeTask(@Param('id') id: string, @Body() dto: any, @Request() req: any) {
    return this.taskService.completeTask(id, req.user.sub, dto.result);
  }

  @Put(':id/fail')
  async failTask(@Param('id') id: string, @Body() dto: any, @Request() req: any) {
    return this.taskService.failTask(id, dto.error, req.user.sub);
  }

  @Put(':id/block')
  async blockTask(@Param('id') id: string, @Body() dto: any) {
    return this.taskService.blockTask(id, dto.reason);
  }

  @Put(':id/unblock')
  async unblockTask(@Param('id') id: string) {
    return this.taskService.unblockTask(id);
  }
}

// src/tasks/task.module.ts
import { Module } from '@nestjs/common';
import { TaskService } from './task.service';
import { TaskController } from './task.controller';
import { TaskNotificationService } from './task-notification.service';
import { SlackModule } from '@/integrations/slack.module';
import { EmailModule } from '@/integrations/email.module';
import { SMSModule } from '@/integrations/sms.module';

@Module({
  imports: [SlackModule, EmailModule, SMSModule],
  controllers: [TaskController],
  providers: [TaskService, TaskNotificationService],
  exports: [TaskService],
})
export class TaskModule {}
