// prisma/seed.ts
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seeding...');

  // ========================================================================
  // SAMPLE USERS
  // ========================================================================
  const coordinator = await prisma.user.create({
    data: {
      email: 'coordinator@lscm.com',
      password: 'hashed_password', // TODO: Hash with bcrypt
      firstName: 'John',
      lastName: 'Smith',
      role: 'COORDINATOR',
      isActive: true,
    },
  });

  const manager = await prisma.user.create({
    data: {
      email: 'manager@lscm.com',
      password: 'hashed_password',
      firstName: 'Sarah',
      lastName: 'Johnson',
      role: 'MANAGER',
      isActive: true,
    },
  });

  console.log('✅ Users created');

  // ========================================================================
  // SAMPLE ORDER 1: SNIM Air Freight (NKC → JNB)
  // ========================================================================
  const snimOrder = await prisma.shipmentOrder.create({
    data: {
      orderReference: 'SNIM-26020001',
      poNumber: '4560184557',
      supplierId: 'SNIM',
      supplierName: 'SNIM (Société Nationale Industrielle et Minière)',
      supplierCountry: 'Mauritania',
      buyerId: 'JNB-CLIENT-001',
      buyerName: 'South African Buyer Co.',
      buyerCountry: 'South Africa',
      buyerEmail: 'buyer@southafrica.com',
      commodityCode: '2601',
      description: 'Iron Ore Pellets - Testing Samples',
      itemNumber: 'FE-SAMPLE-001',
      quantity: 25,
      unitOfMeasure: 'CBM',
      grossWeight: 8500,
      netWeight: 8200,
      length: 120,
      width: 100,
      height: 150,
      cbm: 1.8,
      originLocation: 'NKC',
      originAirport: 'Nouakchott International',
      destLocation: 'JNB',
      destAirport: 'Johannesburg International',
      incoterm: 'FOB',
      transportMode: 'AIR',
      chargeWeight: 8500,
      currencyCode: 'USD',
      serviceCharges: 3200,
      handlingFees: 400,
      customsFees: 150,
      insurance: 500,
      vat: 300.75,
      totalCost: 4550.75,
      estimatedCost: 4500,
      status: 'DRAFT',
      phase: 'PREPARATION',
      createdBy: coordinator.email,
      createdAt: new Date('2025-03-01'),
    },
  });

  // Create segments for SNIM order
  await prisma.transportSegment.create({
    data: {
      orderId: snimOrder.id,
      segmentId: 'SEG-SNIM-26020001-1',
      legNumber: 1,
      originCode: 'NKC',
      originName: 'Nouakchott',
      originType: 'AIRPORT',
      destCode: 'IST',
      destName: 'Istanbul',
      destType: 'AIRPORT',
      mode: 'AIR',
      carrierName: 'Turkish Airlines',
      carrierReference: 'TK 451',
      estimatedDeparture: new Date('2025-03-05'),
      estimatedArrival: new Date('2025-03-06'),
      allocatedWeight: 8500,
      allocatedCBM: 25,
      status: 'SCHEDULED',
    },
  });

  await prisma.transportSegment.create({
    data: {
      orderId: snimOrder.id,
      segmentId: 'SEG-SNIM-26020001-2',
      legNumber: 2,
      originCode: 'IST',
      originName: 'Istanbul',
      originType: 'AIRPORT',
      destCode: 'JNB',
      destName: 'Johannesburg',
      destType: 'AIRPORT',
      mode: 'AIR',
      carrierName: 'Turkish Airlines',
      carrierReference: 'TK 452',
      estimatedDeparture: new Date('2025-03-07'),
      estimatedArrival: new Date('2025-03-10'),
      allocatedWeight: 8500,
      allocatedCBM: 25,
      status: 'SCHEDULED',
    },
  });

  console.log(`✅ SNIM Order created: ${snimOrder.orderReference}`);

  // ========================================================================
  // SAMPLE ORDER 2: EGI Sea Freight (Port Harcourt → Pretoria)
  // ========================================================================
  const egiOrder = await prisma.shipmentOrder.create({
    data: {
      orderReference: 'EGI-OIL-250302',
      poNumber: 'PO-EGI-8521',
      supplierId: 'EGI-NIG',
      supplierName: 'EGI Services Nigeria Ltd',
      supplierCountry: 'Nigeria',
      buyerId: 'PRETORIA-CLIENT-001',
      buyerName: 'Pretoria Industrial Corp',
      buyerCountry: 'South Africa',
      buyerEmail: 'buyer@pretoria.co.za',
      commodityCode: '8431',
      description: 'Oilfield Services Equipment - Pump Seals & Valves',
      itemNumber: 'OIL-EQUIP-2025-001',
      quantity: 200,
      unitOfMeasure: 'CBM',
      grossWeight: 52000,
      netWeight: 50000,
      length: 1200,
      width: 900,
      height: 1400,
      cbm: 15.12,
      originLocation: 'PRH',
      originPort: 'Port Harcourt Port',
      destLocation: 'PRETORIA',
      destPort: 'Ngqura Port',
      incoterm: 'CIF',
      transportMode: 'SEA',
      chargeWeight: 52000,
      currencyCode: 'USD',
      serviceCharges: 8500,
      handlingFees: 1200,
      customsFees: 450,
      insurance: 2000,
      vat: 827.75,
      totalCost: 12977.75,
      estimatedCost: 13000,
      status: 'DRAFT',
      phase: 'PREPARATION',
      createdBy: coordinator.email,
      createdAt: new Date('2025-03-02'),
    },
  });

  // Create segment for EGI order
  await prisma.transportSegment.create({
    data: {
      orderId: egiOrder.id,
      segmentId: 'SEG-EGI-250302-1',
      legNumber: 1,
      originCode: 'PRH',
      originName: 'Port Harcourt',
      originType: 'SEAPORT',
      destCode: 'NGQURA',
      destName: 'Ngqura Port (Pretoria)',
      destType: 'SEAPORT',
      mode: 'SEA',
      carrierName: 'MSC - Mediterranean Shipping Company',
      carrierReference: 'MSC GULSUN 5G',
      estimatedDeparture: new Date('2025-03-08'),
      estimatedArrival: new Date('2025-03-28'),
      allocatedWeight: 52000,
      allocatedCBM: 200,
      status: 'SCHEDULED',
    },
  });

  console.log(`✅ EGI Order created: ${egiOrder.orderReference}`);

  // ========================================================================
  // SAMPLE ORDER 3: LADOL Consolidation (Multi-supplier)
  // ========================================================================
  const ladolOrder = await prisma.shipmentOrder.create({
    data: {
      orderReference: 'LADOL-CONS-250303',
      poNumber: null,
      supplierId: 'LADOL-FZ',
      supplierName: 'LADOL Free Zone Hub',
      supplierCountry: 'Nigeria',
      buyerId: 'GLOBAL-BUYER-001',
      buyerName: 'Global Industrial Supply Co.',
      buyerCountry: 'Multiple',
      buyerEmail: 'procurement@globalind.com',
      commodityCode: '8483',
      description: 'Consolidated Industrial Components - Multiple Suppliers',
      itemNumber: 'CONS-2025-001',
      quantity: 45,
      unitOfMeasure: 'CBM',
      grossWeight: 125000,
      netWeight: 115000,
      length: 2000,
      width: 1600,
      height: 1800,
      cbm: 57.6,
      originLocation: 'LOS',
      originWarehouse: 'LADOL Free Zone',
      destLocation: 'ROTTERDAM',
      destPort: 'Rotterdam Port',
      incoterm: 'DDP',
      transportMode: 'MULTIMODAL',
      chargeWeight: 125000,
      currencyCode: 'EUR',
      serviceCharges: 12000,
      handlingFees: 2500,
      customsFees: 800,
      insurance: 3000,
      vat: 1237.5,
      totalCost: 19537.5,
      estimatedCost: 19500,
      status: 'DRAFT',
      phase: 'PREPARATION',
      createdBy: coordinator.email,
      createdAt: new Date('2025-03-03'),
      tags: JSON.stringify(['LADOL_FZ', 'CONSOLIDATION', 'MULTIMODAL']),
    },
  });

  // Create segments for consolidation order
  await prisma.transportSegment.create({
    data: {
      orderId: ladolOrder.id,
      segmentId: 'SEG-LADOL-250303-1',
      legNumber: 1,
      originCode: 'LOS',
      originName: 'Lagos (LADOL Free Zone)',
      originType: 'WAREHOUSE',
      destCode: 'SAGAMOSO',
      destName: 'Sagamoso Port',
      destType: 'SEAPORT',
      mode: 'LAND',
      carrierName: 'NIPCO Logistics',
      carrierReference: 'TRUCK-NLD-001',
      estimatedDeparture: new Date('2025-03-10'),
      estimatedArrival: new Date('2025-03-12'),
      allocatedWeight: 125000,
      allocatedCBM: 45,
      status: 'SCHEDULED',
    },
  });

  await prisma.transportSegment.create({
    data: {
      orderId: ladolOrder.id,
      segmentId: 'SEG-LADOL-250303-2',
      legNumber: 2,
      originCode: 'SAGAMOSO',
      originName: 'Sagamoso Port',
      originType: 'SEAPORT',
      destCode: 'ROTTERDAM',
      destName: 'Rotterdam',
      destType: 'SEAPORT',
      mode: 'SEA',
      carrierName: 'Maersk Line',
      carrierReference: 'MAERSK ESSEX',
      estimatedDeparture: new Date('2025-03-14'),
      estimatedArrival: new Date('2025-04-02'),
      allocatedWeight: 125000,
      allocatedCBM: 45,
      status: 'SCHEDULED',
    },
  });

  console.log(`✅ LADOL Order created: ${ladolOrder.orderReference}`);

  // ========================================================================
  // SAMPLE DOCUMENTS FOR FIRST ORDER
  // ========================================================================
  await prisma.document.createMany({
    data: [
      {
        orderId: snimOrder.id,
        type: 'RFC',
        documentNumber: 'RFC-SNIM-26020001',
        version: 'FINAL',
        isAutoGenerated: true,
        fileUrl: '/documents/RFC-SNIM-26020001.pdf',
        fileName: 'RFC-SNIM-26020001.pdf',
        status: 'DRAFT',
        createdAt: new Date(),
      },
      {
        orderId: snimOrder.id,
        type: 'JEP',
        documentNumber: 'JEP-SNIM-26020001',
        version: 'FINAL',
        isAutoGenerated: true,
        fileUrl: '/documents/JEP-SNIM-26020001.pdf',
        fileName: 'JEP-SNIM-26020001.pdf',
        status: 'DRAFT',
        createdAt: new Date(),
      },
    ],
  });

  console.log('✅ Sample documents created');

  // ========================================================================
  // SAMPLE INVOICES
  // ========================================================================
  await prisma.invoice.create({
    data: {
      orderId: snimOrder.id,
      invoiceNumber: 'INV-2025-00001',
      invoiceDate: new Date(),
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      invoicedTo: 'South African Buyer Co.',
      invoicedToAddress: 'Johannesburg, South Africa',
      subtotal: snimOrder.totalCost * 0.927, // Remove VAT for subtotal
      vat: snimOrder.vat,
      total: snimOrder.totalCost,
      currencyCode: 'USD',
      bankName: 'Access Bank',
      accountName: 'LSCM Ltd',
      accountNumber: '1234567890',
      status: 'DRAFT',
      issuedBy: coordinator.email,
    },
  });

  console.log('✅ Sample invoices created');

  console.log('🌱 Database seeding completed successfully!');
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error('❌ Seeding failed:', e);
    await prisma.$disconnect();
    process.exit(1);
  });
