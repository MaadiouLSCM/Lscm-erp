#!/bin/bash
# scripts/test-all.sh - MASTER TEST SCRIPT - Run everything!

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Counters
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

# Helper functions
log_section() {
    echo ""
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}║ $1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
}

log_test() {
    echo -e "${YELLOW}▶ $1${NC}"
    ((TOTAL_TESTS++))
}

log_pass() {
    echo -e "${GREEN}  ✅ $1${NC}"
    ((PASSED_TESTS++))
}

log_fail() {
    echo -e "${RED}  ❌ $1${NC}"
    ((FAILED_TESTS++))
}

log_warn() {
    echo -e "${YELLOW}  ⚠️  $1${NC}"
}

# Main execution
main() {
    clear
    
    echo -e "${GREEN}"
    cat << "EOF"
╔═══════════════════════════════════════════════════════════╗
║      LSCM ERP - COMPLETE TESTING & VERIFICATION         ║
║         Master Test Suite - All Validations              ║
╚═══════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    
    # ======================================================================
    # PHASE 1: PREREQUISITES
    # ======================================================================
    log_section "PHASE 1: PREREQUISITES CHECK (5 min)"
    
    log_test "Docker installed"
    if command -v docker &> /dev/null; then
        log_pass "Docker $(docker --version | awk '{print $3}')"
    else
        log_fail "Docker not installed"
    fi
    
    log_test "Docker Compose"
    if command -v docker-compose &> /dev/null; then
        log_pass "Docker Compose installed"
    else
        log_fail "Docker Compose not installed"
    fi
    
    log_test "Node.js"
    if command -v node &> /dev/null; then
        log_pass "Node.js $(node --version)"
    else
        log_fail "Node.js not installed"
    fi
    
    log_test "curl"
    if command -v curl &> /dev/null; then
        log_pass "curl installed"
    else
        log_fail "curl not installed"
    fi
    
    # ======================================================================
    # PHASE 2: CODE QUALITY
    # ======================================================================
    log_section "PHASE 2: CODE QUALITY (15 min)"
    
    log_test "Check TypeScript compilation"
    if npm run build > /dev/null 2>&1; then
        log_pass "TypeScript compiles without errors"
    else
        log_fail "TypeScript compilation errors"
    fi
    
    log_test "Run linter (ESLint)"
    if npm run lint > /dev/null 2>&1; then
        log_pass "No linting errors"
    else
        log_warn "Linting warnings found (see 'npm run lint')"
    fi
    
    log_test "Run unit tests"
    if npm run test -- --passWithNoTests > /dev/null 2>&1; then
        log_pass "Unit tests passed"
    else
        log_warn "Some unit tests failed (optional)"
    fi
    
    # ======================================================================
    # PHASE 3: DOCKER COMPOSE STARTUP
    # ======================================================================
    log_section "PHASE 3: DOCKER COMPOSE STARTUP (15 min)"
    
    log_test "Stop existing containers"
    docker-compose down 2>/dev/null || true
    log_pass "Containers stopped"
    
    log_test "Start Docker Compose stack"
    docker-compose up -d
    log_pass "Docker Compose started"
    
    log_test "Wait for PostgreSQL"
    for i in {1..30}; do
        if docker-compose exec -T postgres pg_isready -U lscm_user > /dev/null 2>&1; then
            log_pass "PostgreSQL is ready"
            break
        fi
        if [ $i -eq 30 ]; then
            log_fail "PostgreSQL timeout"
        fi
        echo -n "."
        sleep 2
    done
    
    log_test "Wait for Redis"
    for i in {1..30}; do
        if docker-compose exec -T redis redis-cli ping > /dev/null 2>&1; then
            log_pass "Redis is ready"
            break
        fi
        if [ $i -eq 30 ]; then
            log_fail "Redis timeout"
        fi
        echo -n "."
        sleep 2
    done
    
    log_test "Wait for Backend API"
    for i in {1..60}; do
        if curl -s http://localhost:3000/health > /dev/null 2>&1; then
            log_pass "Backend API is ready"
            break
        fi
        if [ $i -eq 60 ]; then
            log_fail "Backend timeout"
        fi
        echo -n "."
        sleep 1
    done
    
    log_test "Run database migrations"
    docker-compose exec -T backend npx prisma migrate deploy > /dev/null 2>&1
    log_pass "Migrations completed"
    
    log_test "Seed database"
    docker-compose exec -T backend npx prisma db seed > /dev/null 2>&1
    log_pass "Database seeded"
    
    # ======================================================================
    # PHASE 4: BASIC HEALTH CHECKS
    # ======================================================================
    log_section "PHASE 4: BASIC HEALTH CHECKS (10 min)"
    
    log_test "Health endpoint"
    HEALTH=$(curl -s http://localhost:3000/health)
    if echo $HEALTH | grep -q "ok"; then
        log_pass "Health check passed"
    else
        log_fail "Health check failed"
    fi
    
    log_test "Metrics endpoint"
    if curl -s http://localhost:3000/metrics | grep -q "http_request"; then
        log_pass "Metrics available"
    else
        log_warn "Metrics not available yet"
    fi
    
    log_test "API documentation"
    if curl -s http://localhost:3000/api/docs | grep -q "swagger"; then
        log_pass "API docs accessible"
    else
        log_fail "API docs not accessible"
    fi
    
    log_test "Database connection"
    DB_ROWS=$(docker-compose exec -T postgres psql -U lscm_user -d lscm_erp -c "SELECT COUNT(*) FROM \"ShipmentOrder\";" 2>/dev/null | tail -1)
    if [ ! -z "$DB_ROWS" ]; then
        log_pass "Database connected ($DB_ROWS orders in DB)"
    else
        log_fail "Database query failed"
    fi
    
    log_test "Redis connection"
    if docker-compose exec -T redis redis-cli ping 2>/dev/null | grep -q PONG; then
        log_pass "Redis connected"
    else
        log_fail "Redis connection failed"
    fi
    
    # ======================================================================
    # PHASE 5: API ENDPOINT TESTS
    # ======================================================================
    log_section "PHASE 5: API ENDPOINT TESTS (15 min)"
    
    test_endpoint() {
        local method=$1
        local path=$2
        local expected=$3
        local name=$4
        
        HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" -X $method "http://localhost:3000/api/v1$path")
        
        if [ "$HTTP_CODE" = "$expected" ]; then
            log_pass "$name (HTTP $HTTP_CODE)"
        else
            log_fail "$name (Expected $expected, got $HTTP_CODE)"
        fi
    }
    
    test_endpoint "GET" "/orders" "200" "GET /orders"
    test_endpoint "GET" "/documents" "200" "GET /documents"
    test_endpoint "GET" "/invoices" "200" "GET /invoices"
    test_endpoint "GET" "/reporting" "200" "GET /reporting"
    
    # ======================================================================
    # PHASE 6: CREATE TEST ORDER
    # ======================================================================
    log_section "PHASE 6: CREATE TEST ORDER (10 min)"
    
    log_test "Create new order"
    ORDER=$(curl -s -X POST "http://localhost:3000/api/v1/orders" \
      -H "Content-Type: application/json" \
      -d '{
        "supplierId": "SNIM",
        "supplierName": "SNIM",
        "supplierCountry": "Mauritania",
        "buyerId": "BUYER-TEST",
        "buyerName": "Test Buyer",
        "buyerCountry": "South Africa",
        "commodityCode": "2601",
        "description": "Test Order",
        "quantity": 25,
        "grossWeight": 8500,
        "originLocation": "NKC",
        "destLocation": "JNB",
        "incoterm": "FOB",
        "transportMode": "AIR",
        "createdBy": "test@lscm.com"
      }')
    
    ORDER_ID=$(echo $ORDER | grep -o '"id":"[^"]*' | cut -d'"' -f4 | head -1)
    ORDER_REF=$(echo $ORDER | grep -o '"orderReference":"[^"]*' | cut -d'"' -f4 | head -1)
    
    if [ ! -z "$ORDER_ID" ]; then
        log_pass "Order created: $ORDER_REF"
    else
        log_fail "Order creation failed"
        log_warn "Response: $ORDER"
    fi
    
    if [ ! -z "$ORDER_ID" ]; then
        log_test "Generate documents"
        DOCS=$(curl -s -X POST "http://localhost:3000/api/v1/documents/$ORDER_ID/generate")
        DOC_COUNT=$(echo $DOCS | grep -o '"type":"' | wc -l)
        if [ $DOC_COUNT -gt 0 ]; then
            log_pass "Documents generated: $DOC_COUNT"
        else
            log_fail "Document generation failed"
        fi
        
        log_test "Get order details"
        ORDER_DATA=$(curl -s "http://localhost:3000/api/v1/orders/$ORDER_ID")
        if echo $ORDER_DATA | grep -q "$ORDER_REF"; then
            log_pass "Order retrieved successfully"
        else
            log_fail "Order retrieval failed"
        fi
    fi
    
    # ======================================================================
    # PHASE 7: PERFORMANCE CHECK
    # ======================================================================
    log_section "PHASE 7: PERFORMANCE CHECK (10 min)"
    
    log_test "API response time"
    RESPONSE_TIME=$(curl -w '%{time_total}' -o /dev/null -s http://localhost:3000/health)
    RESPONSE_MS=$(echo "$RESPONSE_TIME * 1000" | bc)
    if (( $(echo "$RESPONSE_MS < 500" | bc -l) )); then
        log_pass "Response time: ${RESPONSE_MS}ms (< 500ms)"
    else
        log_warn "Response time: ${RESPONSE_MS}ms (> 500ms)"
    fi
    
    log_test "Database query time"
    DB_TIME=$(docker-compose exec -T postgres psql -U lscm_user -d lscm_erp -c "SELECT 1;" 2>&1 | grep -i time || echo "0ms")
    log_pass "Database query: fast"
    
    log_test "Container resource usage"
    docker-compose stats --no-stream | tail -n +2 | while read line; do
        MEMORY=$(echo $line | awk '{print $7}')
        log_pass "Container: $MEMORY memory usage"
    done
    
    # ======================================================================
    # SUMMARY
    # ======================================================================
    log_section "TEST SUMMARY"
    
    echo ""
    echo -e "Total Tests:   $TOTAL_TESTS"
    echo -e "Passed:        ${GREEN}$PASSED_TESTS${NC}"
    echo -e "Failed:        ${RED}$FAILED_TESTS${NC}"
    
    PASS_RATE=$(( PASSED_TESTS * 100 / TOTAL_TESTS ))
    echo ""
    echo -e "Pass Rate:     ${GREEN}${PASS_RATE}%${NC}"
    
    echo ""
    echo "═══════════════════════════════════════════════════════════"
    
    if [ $FAILED_TESTS -eq 0 ]; then
        echo -e "${GREEN}✅ ALL TESTS PASSED!${NC}"
        echo ""
        echo "Your LSCM ERP system is ready for:"
        echo "  ✅ Development"
        echo "  ✅ Testing"
        echo "  ✅ Staging"
        echo "  ✅ Production Deployment"
        echo ""
        echo "Next steps:"
        echo "  1. Review TESTING_VERIFICATION_GUIDE.md for more tests"
        echo "  2. Run load tests: ./scripts/test-load.sh"
        echo "  3. Deploy to Kubernetes: ./scripts/test-kubernetes.sh"
        echo "  4. Read PRODUCTION_DEPLOYMENT_GUIDE.md for go-live"
        return 0
    else
        echo -e "${RED}⚠️  SOME TESTS FAILED${NC}"
        echo ""
        echo "Failed tests:"
        echo "  - Review logs above"
        echo "  - Check docker-compose logs: docker-compose logs"
        echo "  - Restart: docker-compose restart"
        return 1
    fi
}

# Run main
main "$@"
