// src/orders/orders.controller.ts
import { Controller, Get, Post, Put, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { OrdersService } from './orders.service';
import { CreateOrderDto, UpdateOrderDto, OrderFilterDto } from './dtos';

@ApiTags('Orders')
@ApiBearerAuth('JWT')
@Controller({ path: 'orders', version: '1' })
export class OrdersController {
  constructor(private ordersService: OrdersService) {}

  /**
   * POST /api/v1/orders
   * Create new shipment order
   */
  @Post()
  @ApiOperation({ summary: 'Create new shipment order' })
  async create(@Body() dto: CreateOrderDto) {
    return this.ordersService.createOrder(dto);
  }

  /**
   * GET /api/v1/orders/:id
   * Get order by ID
   */
  @Get(':id')
  @ApiOperation({ summary: 'Get order by ID' })
  async getOrder(@Param('id') id: string) {
    return this.ordersService.getOrder(id);
  }

  /**
   * GET /api/v1/orders/reference/:reference
   * Get order by reference
   */
  @Get('reference/:reference')
  @ApiOperation({ summary: 'Get order by reference' })
  async getOrderByReference(@Param('reference') reference: string) {
    return this.ordersService.getOrderByReference(reference);
  }

  /**
   * GET /api/v1/orders
   * List orders with filtering & pagination
   */
  @Get()
  @ApiOperation({ summary: 'List orders' })
  async listOrders(@Query() filter: OrderFilterDto) {
    return this.ordersService.listOrders(filter);
  }

  /**
   * PUT /api/v1/orders/:id
   * Update order
   */
  @Put(':id')
  @ApiOperation({ summary: 'Update order' })
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateOrderDto,
  ) {
    const userId = 'system'; // TODO: Get from JWT context
    return this.ordersService.updateOrder(id, dto, userId);
  }

  /**
   * PUT /api/v1/orders/:id/status/:status
   * Update order status
   */
  @Put(':id/status/:status')
  @ApiOperation({ summary: 'Update order status' })
  async updateStatus(
    @Param('id') id: string,
    @Param('status') status: string,
  ) {
    const userId = 'system'; // TODO: Get from JWT context
    return this.ordersService.updateOrderStatus(id, status, userId);
  }

  /**
   * GET /api/v1/orders/:id/kpis
   * Calculate order KPIs
   */
  @Get(':id/kpis')
  @ApiOperation({ summary: 'Get order KPIs' })
  async getKPIs(@Param('id') id: string) {
    return this.ordersService.calculateOrderKPIs(id);
  }

  /**
   * GET /api/v1/orders/:id/timeline
   * Get order timeline
   */
  @Get(':id/timeline')
  @ApiOperation({ summary: 'Get order timeline' })
  async getTimeline(@Param('id') id: string) {
    return this.ordersService.getOrderTimeline(id);
  }
}

// src/orders/orders.module.ts
import { Module } from '@nestjs/common';
import { OrdersService } from './orders.service';
import { OrdersController } from './orders.controller';

@Module({
  controllers: [OrdersController],
  providers: [OrdersService],
  exports: [OrdersService],
})
export class OrdersModule {}
