// src/integrations/integration.service.ts
import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import * as axios from 'axios';

@Injectable()
export class IntegrationService {
  private clearClient = axios.default.create({
    baseURL: process.env.CLEAR_API_URL || 'https://api.clearlogistics.com',
    headers: {
      'X-API-Key': process.env.CLEAR_API_KEY,
    },
  });

  private sapClient = axios.default.create({
    baseURL: process.env.SAP_BW_API_URL || 'https://sap-bw.example.com/api',
    headers: {
      'Authorization': `Bearer ${process.env.SAP_BW_API_TOKEN}`,
    },
  });

  constructor(private prisma: PrismaService) {}

  /**
   * === CLEAR INTEGRATION ===
   * Import order from CLEAR system
   */
  async importOrderFromCLEAR(clearJobId: string): Promise<any> {
    try {
      const response = await this.clearClient.get(`/jobs/${clearJobId}`);
      const clearData = response.data;

      // Map CLEAR fields to our Order model
      const order = await this.prisma.shipmentOrder.create({
        data: {
          orderReference: clearData.reference,
          poNumber: clearData.po_number,
          supplierId: clearData.supplier_id,
          supplierName: clearData.supplier_name,
          supplierCountry: clearData.supplier_country,
          buyerId: clearData.buyer_id,
          buyerName: clearData.buyer_name,
          buyerCountry: clearData.buyer_country,
          buyerEmail: clearData.buyer_email,
          commodityCode: clearData.hs_code,
          description: clearData.commodity_description,
          itemNumber: clearData.item_number,
          quantity: clearData.quantity,
          unitOfMeasure: clearData.unit_of_measure,
          grossWeight: clearData.gross_weight_kg,
          netWeight: clearData.net_weight_kg,
          originLocation: clearData.origin_code,
          destLocation: clearData.destination_code,
          incoterm: clearData.incoterm,
          transportMode: clearData.transport_mode,
          currencyCode: clearData.currency,
          status: 'DRAFT',
          phase: 'PREPARATION',
          createdBy: 'CLEAR_IMPORT',
        },
      });

      console.log(`✅ Order imported from CLEAR: ${order.orderReference}`);
      return order;
    } catch (error) {
      console.error('CLEAR API error:', error);
      throw new BadRequestException(`Failed to import from CLEAR: ${error.message}`);
    }
  }

  /**
   * Sync order status back to CLEAR system
   */
  async syncOrderToCLEAR(orderId: string): Promise<void> {
    try {
      const order = await this.prisma.shipmentOrder.findUnique({
        where: { id: orderId },
      });

      if (!order) throw new Error(`Order ${orderId} not found`);

      const documents = await this.prisma.document.findMany({
        where: { orderId },
      });

      const segments = await this.prisma.transportSegment.findMany({
        where: { orderId },
      });

      // Sync to CLEAR
      await this.clearClient.put(`/jobs/${order.orderReference}`, {
        status: order.status,
        phase: order.phase,
        estimated_arrival: order.estimatedArrival,
        actual_arrival: order.actualArrival,
        documents: documents.map((d) => ({
          type: d.type,
          reference: d.documentNumber,
          status: d.status,
        })),
        segments: segments.map((s) => ({
          leg: s.legNumber,
          origin: s.originCode,
          destination: s.destCode,
          status: s.status,
          eta: s.estimatedArrival,
        })),
      });

      console.log(`✅ Order synced to CLEAR: ${order.orderReference}`);
    } catch (error) {
      console.error('CLEAR sync error:', error);
    }
  }

  /**
   * === SAP BW INTEGRATION ===
   * Fetch PO data from SAP BW
   */
  async getPurchaseOrderFromSAPBW(poNumber: string): Promise<any> {
    try {
      const response = await this.sapClient.get(`/purchase-orders/${poNumber}`);
      const poData = response.data;

      return {
        poNumber: poData.PO_NUMBER,
        vendorCode: poData.VENDOR_CODE,
        vendorName: poData.VENDOR_NAME,
        buyerId: poData.BUYER_ID,
        buyerName: poData.BUYER_NAME,
        materials: poData.ITEMS.map((item: any) => ({
          materialNumber: item.MATERIAL_NUMBER,
          description: item.DESCRIPTION,
          hsCode: item.HS_CODE,
          quantity: item.QUANTITY,
          unitPrice: item.UNIT_PRICE,
          totalValue: item.TOTAL_VALUE,
        })),
        grValue: poData.GR_VALUE,
        invoiceValue: poData.IV_VALUE,
        deliveryDate: new Date(poData.DELIVERY_DATE),
        incoterm: poData.INCOTERM,
      };
    } catch (error) {
      console.error('SAP BW API error:', error);
      throw new BadRequestException(`Failed to fetch PO from SAP BW: ${error.message}`);
    }
  }

  /**
   * === CARRIER INTEGRATION ===
   * Get real-time tracking from carrier APIs
   */
  async getCarrierTracking(carrier: string, reference: string): Promise<any> {
    try {
      let trackingData;

      switch (carrier.toUpperCase()) {
        case 'TURKISH_AIRLINES':
          trackingData = await this.trackTurkishAirlines(reference);
          break;

        case 'MSC':
          trackingData = await this.trackMSC(reference);
          break;

        case 'FEDEX':
          trackingData = await this.trackFedEx(reference);
          break;

        default:
          throw new BadRequestException(`Unsupported carrier: ${carrier}`);
      }

      return trackingData;
    } catch (error) {
      console.error(`Carrier tracking error (${carrier}):`, error);
      throw error;
    }
  }

  private async trackTurkishAirlines(flightNumber: string): Promise<any> {
    try {
      const response = await axios.default.get(
        `https://www.thy.com/api/flight-status/${flightNumber}`,
      );
      return {
        carrier: 'Turkish Airlines',
        reference: flightNumber,
        status: response.data.status,
        location: response.data.current_location,
        eta: new Date(response.data.estimated_arrival),
        departureActual: new Date(response.data.actual_departure),
        arrivalActual: response.data.actual_arrival ? new Date(response.data.actual_arrival) : null,
        lastUpdate: new Date(),
      };
    } catch (error) {
      console.log(`Note: Turkish Airlines API mock data (not connected in dev)`);
      return {
        carrier: 'Turkish Airlines',
        reference: flightNumber,
        status: 'IN_TRANSIT',
        location: 'Istanbul (IST)',
        eta: new Date(Date.now() + 24 * 60 * 60 * 1000),
        departureActual: new Date(),
        arrivalActual: null,
        lastUpdate: new Date(),
      };
    }
  }

  private async trackMSC(vesselName: string): Promise<any> {
    try {
      const response = await axios.default.get(
        `https://www.msc.com/api/vessel-tracking/${vesselName}`,
      );
      return {
        carrier: 'MSC',
        reference: vesselName,
        status: response.data.status,
        location: response.data.current_port,
        eta: new Date(response.data.eta_destination),
        departureActual: new Date(response.data.departure_date),
        arrivalActual: response.data.arrival_date ? new Date(response.data.arrival_date) : null,
        lastUpdate: new Date(),
      };
    } catch (error) {
      console.log(`Note: MSC API mock data (not connected in dev)`);
      return {
        carrier: 'MSC',
        reference: vesselName,
        status: 'IN_TRANSIT',
        location: 'At Sea',
        eta: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000),
        departureActual: new Date(),
        arrivalActual: null,
        lastUpdate: new Date(),
      };
    }
  }

  private async trackFedEx(trackingNumber: string): Promise<any> {
    try {
      const response = await axios.default.get(
        `https://apis.fedex.com/track/v1/trackingnumbers/${trackingNumber}`,
        {
          headers: {
            'X-FEDEX-API-KEY': process.env.FEDEX_API_KEY,
          },
        },
      );
      return {
        carrier: 'FedEx',
        reference: trackingNumber,
        status: response.data.statusCode,
        location: response.data.latestStatusDetail.location,
        eta: new Date(response.data.estimatedDeliveryTimestamp),
        departureActual: new Date(response.data.shipmentDetails.shipDate),
        arrivalActual: null,
        lastUpdate: new Date(),
      };
    } catch (error) {
      console.log(`Note: FedEx API mock data (not connected in dev)`);
      return {
        carrier: 'FedEx',
        reference: trackingNumber,
        status: 'IN_TRANSIT',
        location: 'In Transit',
        eta: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
        departureActual: new Date(),
        arrivalActual: null,
        lastUpdate: new Date(),
      };
    }
  }

  /**
   * === BANK INTEGRATION (Access Bank) ===
   * Verify payment with bank
   */
  async verifyPaymentWithAccessBank(data: {
    accountNumber: string;
    amount: number;
    reference: string;
  }): Promise<boolean> {
    try {
      const response = await axios.default.post(
        `${process.env.ACCESS_BANK_API_URL || 'https://api.accessbankng.com'}/verify-deposit`,
        {
          accountNumber: data.accountNumber,
          amount: data.amount,
          transactionReference: data.reference,
        },
        {
          headers: {
            'X-API-Key': process.env.ACCESS_BANK_API_KEY,
          },
        },
      );

      return response.data.verified === true;
    } catch (error) {
      console.error('Access Bank verification error:', error);
      // In MVP: Accept all payments (remove in production)
      console.log('⚠️ Bank verification skipped (dev mode)');
      return true;
    }
  }

  /**
   * === WEBHOOK HANDLERS ===
   * Receive carrier webhook (status update)
   */
  async handleCarrierWebhook(webhook: any): Promise<void> {
    try {
      // Parse webhook payload
      const reference = webhook.shipmentReference || webhook.trackingNumber;
      const status = webhook.status;
      const location = webhook.currentLocation;

      // Find segment
      const segment = await this.prisma.transportSegment.findFirst({
        where: {
          carrierReference: reference,
        },
      });

      if (!segment) {
        console.log(`⚠️ No segment found for carrier reference: ${reference}`);
        return;
      }

      // Update segment
      await this.prisma.transportSegment.update({
        where: { id: segment.id },
        data: {
          status,
          currentLocation: location,
          lastUpdate: new Date(),
        },
      });

      console.log(`✅ Carrier webhook processed: ${reference} → ${status}`);
    } catch (error) {
      console.error('Webhook handler error:', error);
    }
  }

  /**
   * === BANK WEBHOOK HANDLER ===
   * Receive payment notification from bank
   */
  async handleBankWebhook(webhook: any): Promise<void> {
    try {
      const accountNumber = webhook.accountNumber;
      const amount = webhook.amount;
      const reference = webhook.reference;

      // Find invoice by payment reference
      const invoice = await this.prisma.invoice.findFirst({
        where: {
          accountNumber,
        },
      });

      if (!invoice) {
        console.log(`⚠️ No invoice found for account: ${accountNumber}`);
        return;
      }

      // Record payment
      const paidAmount = (invoice.paidAmount || 0) + amount;

      await this.prisma.invoice.update({
        where: { id: invoice.id },
        data: {
          paidAmount,
          paidDate: new Date(),
          paymentReference: reference,
          status: paidAmount >= invoice.total ? 'PAID' : 'PARTIAL',
        },
      });

      console.log(`✅ Bank webhook processed: Payment received ${reference}`);
    } catch (error) {
      console.error('Bank webhook handler error:', error);
    }
  }
}

// src/integrations/integration.module.ts
import { Module } from '@nestjs/common';
import { IntegrationService } from './integration.service';

@Module({
  providers: [IntegrationService],
  exports: [IntegrationService],
})
export class IntegrationModule {}
