// k8s/monitoring/prometheus-configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: prometheus-config
  namespace: lscm-prod
data:
  prometheus.yml: |
    global:
      scrape_interval: 15s
      evaluation_interval: 15s
      external_labels:
        cluster: 'lscm-prod'
        environment: 'production'

    scrape_configs:
    - job_name: 'lscm-backend'
      static_configs:
      - targets: ['lscm-backend:3000']
      metrics_path: '/metrics'
      scrape_interval: 5s

    - job_name: 'kubernetes-pods'
      kubernetes_sd_configs:
      - role: pod
        namespaces:
          names:
          - lscm-prod
      relabel_configs:
      - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_scrape]
        action: keep
        regex: true
      - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_path]
        action: replace
        target_label: __metrics_path__
        regex: (.+)
      - source_labels: [__address__, __meta_kubernetes_pod_annotation_prometheus_io_port]
        action: replace
        regex: ([^:]+)(?::\d+)?;(\d+)
        replacement: $1:$2
        target_label: __address__

    alerting:
      alertmanagers:
      - static_configs:
        - targets:
          - alertmanager:9093

    rule_files:
    - '/etc/prometheus/rules/*.yml'

---
// k8s/monitoring/prometheus-rules.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: prometheus-rules
  namespace: lscm-prod
data:
  alert-rules.yml: |
    groups:
    - name: lscm-alerts
      interval: 30s
      rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.05
        for: 5m
        labels:
          severity: critical
          team: backend
        annotations:
          summary: "High error rate detected"
          description: "Error rate is {{ $value }}"

      - alert: HighLatency
        expr: histogram_quantile(0.95, http_request_duration_seconds) > 1
        for: 5m
        labels:
          severity: warning
          team: backend
        annotations:
          summary: "High API latency"
          description: "p95 latency is {{ $value }}s"

      - alert: DatabaseConnectionPoolExhausted
        expr: database_connection_pool_available < 2
        for: 5m
        labels:
          severity: critical
          team: backend
        annotations:
          summary: "Database connection pool exhausted"
          description: "Available connections: {{ $value }}"

      - alert: PodCrashLooping
        expr: rate(kube_pod_container_status_restarts_total[15m]) > 0.1
        for: 5m
        labels:
          severity: critical
          team: devops
        annotations:
          summary: "Pod is crash looping"
          description: "Pod {{ $labels.pod }} in {{ $labels.namespace }}"

      - alert: HighMemoryUsage
        expr: container_memory_usage_bytes / container_spec_memory_limit_bytes > 0.9
        for: 5m
        labels:
          severity: warning
          team: devops
        annotations:
          summary: "High memory usage"
          description: "Pod {{ $labels.pod }} using {{ $value | humanizePercentage }}"

---
// k8s/monitoring/prometheus-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: prometheus
  namespace: lscm-prod
spec:
  replicas: 1
  selector:
    matchLabels:
      app: prometheus
  template:
    metadata:
      labels:
        app: prometheus
    spec:
      serviceAccountName: prometheus
      containers:
      - name: prometheus
        image: prom/prometheus:latest
        args:
          - '--config.file=/etc/prometheus/prometheus.yml'
          - '--storage.tsdb.path=/prometheus'
          - '--storage.tsdb.retention.time=30d'
        ports:
        - containerPort: 9090
        volumeMounts:
        - name: prometheus-config
          mountPath: /etc/prometheus
        - name: prometheus-rules
          mountPath: /etc/prometheus/rules
        - name: prometheus-storage
          mountPath: /prometheus
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "1Gi"
            cpu: "1000m"
      volumes:
      - name: prometheus-config
        configMap:
          name: prometheus-config
      - name: prometheus-rules
        configMap:
          name: prometheus-rules
      - name: prometheus-storage
        emptyDir: {}

---
// k8s/monitoring/grafana-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: grafana
  namespace: lscm-prod
spec:
  replicas: 1
  selector:
    matchLabels:
      app: grafana
  template:
    metadata:
      labels:
        app: grafana
    spec:
      containers:
      - name: grafana
        image: grafana/grafana:latest
        ports:
        - containerPort: 3000
        env:
        - name: GF_SECURITY_ADMIN_PASSWORD
          valueFrom:
            secretKeyRef:
              name: grafana-admin
              key: password
        - name: GF_INSTALL_PLUGINS
          value: grafana-piechart-panel
        volumeMounts:
        - name: grafana-datasources
          mountPath: /etc/grafana/provisioning/datasources
        - name: grafana-dashboards
          mountPath: /etc/grafana/provisioning/dashboards
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
      volumes:
      - name: grafana-datasources
        configMap:
          name: grafana-datasources
      - name: grafana-dashboards
        configMap:
          name: grafana-dashboards

---
// k8s/monitoring/loki-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: loki
  namespace: lscm-prod
spec:
  replicas: 1
  selector:
    matchLabels:
      app: loki
  template:
    metadata:
      labels:
        app: loki
    spec:
      containers:
      - name: loki
        image: grafana/loki:latest
        ports:
        - containerPort: 3100
        volumeMounts:
        - name: loki-config
          mountPath: /etc/loki
        - name: loki-storage
          mountPath: /loki
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
      volumes:
      - name: loki-config
        configMap:
          name: loki-config
      - name: loki-storage
        emptyDir: {}

---
// src/monitoring/metrics.ts
import { register, Counter, Histogram, Gauge } from 'prom-client';

// HTTP Metrics
export const httpRequestsTotal = new Counter({
  name: 'http_requests_total',
  help: 'Total HTTP requests',
  labelNames: ['method', 'route', 'status'],
});

export const httpRequestDuration = new Histogram({
  name: 'http_request_duration_seconds',
  help: 'HTTP request latency',
  labelNames: ['method', 'route', 'status'],
  buckets: [0.1, 0.5, 1, 2, 5, 10],
});

// Database Metrics
export const dbQueryDuration = new Histogram({
  name: 'db_query_duration_seconds',
  help: 'Database query latency',
  labelNames: ['query_type', 'table'],
  buckets: [0.01, 0.05, 0.1, 0.5, 1, 5],
});

export const dbConnectionPoolAvailable = new Gauge({
  name: 'database_connection_pool_available',
  help: 'Available database connections',
});

// Business Metrics
export const ordersCreatedTotal = new Counter({
  name: 'orders_created_total',
  help: 'Total orders created',
  labelNames: ['transport_mode', 'status'],
});

export const ordersDeliveredTotal = new Counter({
  name: 'orders_delivered_total',
  help: 'Total orders delivered',
  labelNames: ['on_time'],
});

export const invoicesGeneratedTotal = new Counter({
  name: 'invoices_generated_total',
  help: 'Total invoices generated',
});

export const invoicesPaidTotal = new Counter({
  name: 'invoices_paid_total',
  help: 'Total invoices paid',
  labelNames: ['currency'],
});

export const documentsGeneratedTotal = new Counter({
  name: 'documents_generated_total',
  help: 'Total documents generated',
  labelNames: ['type'],
});

export const dsrGeneratedTotal = new Counter({
  name: 'dsr_generated_total',
  help: 'Daily Status Reports generated',
});

// DSR Metrics
export const dsrGenerationDuration = new Histogram({
  name: 'dsr_generation_duration_seconds',
  help: 'DSR generation latency',
  buckets: [0.5, 1, 2, 5, 10, 30],
});

export const metricsEndpoint = (): string => {
  return register.metrics();
};

// src/monitoring/logging.ts
import winston from 'winston';
import * as Sentry from '@sentry/node';

const isDevelopment = process.env.NODE_ENV === 'development';

export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json(),
  ),
  defaultMeta: {
    service: 'lscm-erp',
    environment: process.env.NODE_ENV,
    version: process.env.APP_VERSION,
  },
  transports: [
    // Log to console in development
    ...(isDevelopment
      ? [
          new winston.transports.Console({
            format: winston.format.combine(
              winston.format.colorize(),
              winston.format.simple(),
            ),
          }),
        ]
      : []),

    // Log errors to separate file
    new winston.transports.File({
      filename: 'logs/error.log',
      level: 'error',
      maxsize: 5242880, // 5MB
      maxFiles: 5,
    }),

    // Log everything to combined file
    new winston.transports.File({
      filename: 'logs/combined.log',
      maxsize: 5242880,
      maxFiles: 5,
    }),
  ],
});

// Sentry error tracking
if (process.env.SENTRY_DSN && !isDevelopment) {
  Sentry.init({
    dsn: process.env.SENTRY_DSN,
    environment: process.env.NODE_ENV,
    tracesSampleRate: 0.1,
  });
}

export { Sentry };

// src/monitoring/middleware.ts
import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { httpRequestsTotal, httpRequestDuration } from './metrics';
import { logger } from './logging';

@Injectable()
export class MetricsMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction) {
    const startTime = Date.now();
    const route = `${req.method} ${req.baseUrl}`;

    res.on('finish', () => {
      const duration = (Date.now() - startTime) / 1000;

      // Record metrics
      httpRequestsTotal
        .labels(req.method, req.baseUrl, res.statusCode)
        .inc();

      httpRequestDuration
        .labels(req.method, req.baseUrl, res.statusCode)
        .observe(duration);

      // Log request
      logger.info('HTTP Request', {
        method: req.method,
        url: req.originalUrl,
        status: res.statusCode,
        duration: `${duration.toFixed(3)}s`,
        ip: req.ip,
        userAgent: req.get('user-agent'),
      });
    });

    next();
  }
}

// src/app.module.ts (add monitoring)
import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common';
import { MetricsMiddleware } from './monitoring/middleware';

@Module({
  // ... existing imports
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer.apply(MetricsMiddleware).forRoutes('*');
  }
}

// src/main.ts (add metrics endpoint)
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { metricsEndpoint } from './monitoring/metrics';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Add metrics endpoint
  app.get('/metrics', () => metricsEndpoint());

  await app.listen(3000);
}

bootstrap();
