#!/bin/bash
# gcp/deploy-to-gcp.sh - Complete GCP Deployment Script

set -e

# ============================================================================
# GCP DEPLOYMENT SCRIPT - LSCM ERP SYSTEM
# ============================================================================
# Components: GKE (Kubernetes), Cloud SQL, Memorystore, Cloud CDN, Cloud Load Balancing

GCP_PROJECT=${GCP_PROJECT:-"lscm-erp-prod"}
GCP_REGION=${GCP_REGION:-"us-central1"}
GCP_ZONE="${GCP_REGION}-a"
CLUSTER_NAME="lscm-erp-cluster"
APP_NAME="lscm-erp"
ENVIRONMENT="production"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# ============================================================================
# FUNCTIONS
# ============================================================================

log_section() {
    echo ""
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}║ $1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
}

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_gcloud() {
    if ! command -v gcloud &> /dev/null; then
        log_error "gcloud CLI not installed"
        exit 1
    fi
    
    if ! gcloud auth list | grep -q ACTIVE; then
        log_error "gcloud not authenticated"
        exit 1
    fi
    
    log_info "gcloud authenticated for project: $GCP_PROJECT"
}

# Create GKE cluster
create_gke_cluster() {
    log_section "Creating GKE Cluster"
    
    if gcloud container clusters describe "$CLUSTER_NAME" \
        --zone "$GCP_ZONE" \
        --project "$GCP_PROJECT" > /dev/null 2>&1; then
        log_info "GKE cluster already exists"
    else
        log_info "Creating GKE cluster..."
        
        gcloud container clusters create "$CLUSTER_NAME" \
            --zone "$GCP_ZONE" \
            --project "$GCP_PROJECT" \
            --num-nodes 3 \
            --machine-type n1-standard-2 \
            --enable-stackdriver-kubernetes \
            --enable-ip-alias \
            --enable-autorepair \
            --enable-autoupgrade \
            --enable-autoscaling \
            --min-nodes 1 \
            --max-nodes 10 \
            --addons HttpLoadBalancing,HttpsLoadBalancing \
            --workload-pool "$GCP_PROJECT.svc.id.goog" \
            --enable-shielded-nodes
        
        log_info "GKE cluster created"
    fi
    
    # Get cluster credentials
    gcloud container clusters get-credentials "$CLUSTER_NAME" \
        --zone "$GCP_ZONE" \
        --project "$GCP_PROJECT"
    
    log_info "Cluster credentials configured"
}

# Create Cloud SQL PostgreSQL instance
create_cloud_sql() {
    log_section "Creating Cloud SQL PostgreSQL Instance"
    
    SQL_INSTANCE="$APP_NAME-postgres"
    
    if gcloud sql instances describe "$SQL_INSTANCE" \
        --project "$GCP_PROJECT" > /dev/null 2>&1; then
        log_info "Cloud SQL instance already exists"
    else
        log_info "Creating Cloud SQL PostgreSQL instance..."
        
        gcloud sql instances create "$SQL_INSTANCE" \
            --project "$GCP_PROJECT" \
            --database-version=POSTGRES_15 \
            --tier=db-f1-micro \
            --region="$GCP_REGION" \
            --storage-size=100GB \
            --storage-auto-increase \
            --backup-start-time 02:00 \
            --enable-bin-log \
            --retained-backups-count=30 \
            --transaction-log-retention-days=7 \
            --enable-point-in-time-recovery \
            --require-ssl
        
        log_info "Cloud SQL instance created"
    fi
    
    # Create database
    log_info "Creating database..."
    gcloud sql databases create lscm_erp \
        --instance="$SQL_INSTANCE" \
        --project "$GCP_PROJECT" 2>/dev/null || true
    
    # Get SQL instance connection name
    SQL_CONNECTION=$(gcloud sql instances describe "$SQL_INSTANCE" \
        --project "$GCP_PROJECT" \
        --format='value(connectionName)')
    
    echo "$SQL_CONNECTION"
}

# Create Memorystore Redis instance
create_memorystore_redis() {
    log_section "Creating Memorystore Redis Instance"
    
    REDIS_INSTANCE="$APP_NAME-redis"
    
    if gcloud redis instances describe "$REDIS_INSTANCE" \
        --region="$GCP_REGION" \
        --project "$GCP_PROJECT" > /dev/null 2>&1; then
        log_info "Memorystore Redis instance already exists"
    else
        log_info "Creating Memorystore Redis instance..."
        
        gcloud redis instances create "$REDIS_INSTANCE" \
            --project "$GCP_PROJECT" \
            --region="$GCP_REGION" \
            --size=2 \
            --redis-version=7.0 \
            --tier=standard \
            --auth-enabled \
            --transit-encryption-mode=SERVER_AUTHENTICATION
        
        log_info "Memorystore Redis instance created"
    fi
    
    # Get Redis host
    REDIS_HOST=$(gcloud redis instances describe "$REDIS_INSTANCE" \
        --region="$GCP_REGION" \
        --project "$GCP_PROJECT" \
        --format='value(host)')
    
    REDIS_PORT=$(gcloud redis instances describe "$REDIS_INSTANCE" \
        --region="$GCP_REGION" \
        --project "$GCP_PROJECT" \
        --format='value(port)')
    
    echo "$REDIS_HOST:$REDIS_PORT"
}

# Create Container Registry and build image
build_and_push_image_gcr() {
    log_section "Building and Pushing Docker Image to GCR"
    
    GCR_IMAGE="gcr.io/$GCP_PROJECT/$APP_NAME:latest"
    
    log_info "Building Docker image..."
    docker build -t "$GCR_IMAGE" .
    
    log_info "Configuring gcloud for Docker..."
    gcloud auth configure-docker --project "$GCP_PROJECT"
    
    log_info "Pushing image to GCR..."
    docker push "$GCR_IMAGE"
    
    log_info "Image pushed: $GCR_IMAGE"
    echo "$GCR_IMAGE"
}

# Create Kubernetes secrets
create_k8s_secrets() {
    log_section "Creating Kubernetes Secrets"
    
    log_info "Creating namespace..."
    kubectl create namespace "$APP_NAME" 2>/dev/null || true
    
    log_info "Creating database credentials secret..."
    kubectl create secret generic lscm-db-credentials \
        --from-literal=username=lscm_user \
        --from-literal=password="$(openssl rand -base64 32)" \
        -n "$APP_NAME" \
        --dry-run=client -o yaml | kubectl apply -f -
    
    log_info "Creating JWT secret..."
    kubectl create secret generic lscm-jwt-secret \
        --from-literal=secret="$(openssl rand -base64 32)" \
        -n "$APP_NAME" \
        --dry-run=client -o yaml | kubectl apply -f -
    
    log_info "Secrets created"
}

# Deploy application to GKE
deploy_to_gke() {
    log_section "Deploying Application to GKE"
    
    GCR_IMAGE=$1
    SQL_CONNECTION=$2
    REDIS_HOST=$3
    
    log_info "Creating deployment manifest..."
    
    cat > /tmp/k8s-deployment.yaml << EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: $APP_NAME-backend
  namespace: $APP_NAME
spec:
  replicas: 3
  selector:
    matchLabels:
      app: $APP_NAME-backend
  template:
    metadata:
      labels:
        app: $APP_NAME-backend
    spec:
      containers:
      - name: $APP_NAME-backend
        image: $GCR_IMAGE
        ports:
        - containerPort: 3000
        env:
        - name: NODE_ENV
          value: "production"
        - name: CLOUD_SQL_CONNECTION_NAME
          value: "$SQL_CONNECTION"
        - name: REDIS_HOST
          value: "${REDIS_HOST%:*}"
        - name: REDIS_PORT
          value: "${REDIS_HOST##*:}"
        envFrom:
        - secretRef:
            name: lscm-db-credentials
        - secretRef:
            name: lscm-jwt-secret
        resources:
          requests:
            cpu: 500m
            memory: 512Mi
          limits:
            cpu: 1000m
            memory: 1024Mi
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 10
          periodSeconds: 5

---
apiVersion: v1
kind: Service
metadata:
  name: $APP_NAME-service
  namespace: $APP_NAME
spec:
  type: LoadBalancer
  selector:
    app: $APP_NAME-backend
  ports:
  - port: 80
    targetPort: 3000
    protocol: TCP

---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: $APP_NAME-hpa
  namespace: $APP_NAME
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: $APP_NAME-backend
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
EOF
    
    log_info "Applying deployment..."
    kubectl apply -f /tmp/k8s-deployment.yaml
    
    log_info "Waiting for deployment to be ready..."
    kubectl rollout status deployment/$APP_NAME-backend -n "$APP_NAME" --timeout=300s
    
    log_info "Deployment successful"
    
    # Get LoadBalancer IP
    sleep 30
    LB_IP=$(kubectl get service $APP_NAME-service -n "$APP_NAME" -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
    
    if [ ! -z "$LB_IP" ]; then
        echo "Service IP: $LB_IP"
    fi
}

# Setup Cloud Load Balancing and Cloud CDN
setup_cloud_cdn() {
    log_section "Setting up Cloud Load Balancing and CDN"
    
    log_info "Creating health check..."
    
    gcloud compute health-checks create http "$APP_NAME-health-check" \
        --project "$GCP_PROJECT" \
        --port=3000 \
        --request-path=/health \
        --check-interval=10s \
        --timeout=5s 2>/dev/null || true
    
    log_info "Creating backend service..."
    
    gcloud compute backend-services create "$APP_NAME-backend-service" \
        --protocol=HTTP \
        --health-checks="$APP_NAME-health-check" \
        --project "$GCP_PROJECT" \
        --global \
        --enable-cdn 2>/dev/null || true
    
    log_info "Cloud CDN configured"
}

# Setup Cloud Monitoring
setup_cloud_monitoring() {
    log_section "Setting up Cloud Monitoring"
    
    log_info "Enabling monitoring APIs..."
    
    gcloud services enable monitoring.googleapis.com \
        logging.googleapis.com \
        cloudtrace.googleapis.com \
        --project "$GCP_PROJECT"
    
    log_info "Cloud Monitoring enabled"
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================

main() {
    clear
    
    echo -e "${GREEN}"
    cat << "EOF"
╔═══════════════════════════════════════════════════════════╗
║         LSCM ERP - GCP DEPLOYMENT SCRIPT                 ║
║    Complete deployment to GCP (GKE, Cloud SQL, Redis)    ║
╚═══════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    
    echo ""
    echo "GCP Project: $GCP_PROJECT"
    echo "Region: $GCP_REGION"
    echo "Cluster: $CLUSTER_NAME"
    echo ""
    
    # Pre-flight checks
    log_section "Pre-Flight Checks"
    check_gcloud
    
    # Step 1: Create GKE cluster
    create_gke_cluster
    
    # Step 2: Create Cloud SQL
    SQL_CONNECTION=$(create_cloud_sql)
    log_info "SQL Instance: $SQL_CONNECTION"
    
    # Step 3: Create Memorystore Redis
    REDIS_HOST=$(create_memorystore_redis)
    log_info "Redis Instance: $REDIS_HOST"
    
    # Step 4: Build and push image
    GCR_IMAGE=$(build_and_push_image_gcr)
    
    # Step 5: Create K8s secrets
    create_k8s_secrets
    
    # Step 6: Deploy to GKE
    deploy_to_gke "$GCR_IMAGE" "$SQL_CONNECTION" "$REDIS_HOST"
    
    # Step 7: Setup Cloud CDN
    setup_cloud_cdn
    
    # Step 8: Setup monitoring
    setup_cloud_monitoring
    
    # Completion
    log_section "Deployment Complete!"
    
    echo -e "${GREEN}✅ GCP deployment successful!${NC}"
    echo ""
    echo "Next steps:"
    echo "  1. Get service IP: kubectl get service -n $APP_NAME"
    echo "  2. Configure domain DNS"
    echo "  3. View logs: gcloud logging read --limit 50"
    echo "  4. Monitor: https://console.cloud.google.com/monitoring"
    echo ""
}

trap 'log_error "Deployment failed at line $LINENO"' ERR

main "$@"
