// ============================================================================
// LOADING PLAN MODULE - 3,000+ LINES
// Containers & Trucks Optimization with 2D/3D Planning
// ============================================================================
// LSCM Colors: Primary #1A5F99 | Secondary #FF6B35 | Accent #2A9D8F

// src/loading/loading-plan.service.ts
import { Injectable } from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';

interface Item {
  id: string;
  sku: string;
  weight: number; // kg
  length: number; // cm
  width: number; // cm
  height: number; // cm
  quantity: number;
  fragile: boolean;
  stackable: boolean;
  hazmat: boolean;
}

interface Vehicle {
  id: string;
  type: 'CONTAINER_20FT' | 'CONTAINER_40FT' | 'TRUCK_STANDARD' | 'TRUCK_FLATBED';
  maxWeight: number; // kg
  maxVolume: number; // m³
  length: number; // cm
  width: number; // cm
  height: number; // cm
  compartments?: number;
}

interface LoadingPlan {
  planId: string;
  orderId: string;
  vehicle: Vehicle;
  items: Array<{
    itemId: string;
    quantity: number;
    position: {
      x: number;
      y: number;
      z: number;
    };
  }>;
  totalWeight: number;
  totalVolume: number;
  weightUtilization: number; // percentage
  volumeUtilization: number; // percentage
  balanceScore: number; // 0-100
  efficiency: number; // 0-100
  warnings: string[];
}

@Injectable()
export class LoadingPlanService {
  constructor(private prisma: PrismaService) {}

  /**
   * Generate optimal loading plan
   */
  async generateLoadingPlan(
    orderId: string,
    items: Item[],
    vehicle: Vehicle,
  ): Promise<LoadingPlan> {
    console.log(
      `📦 Generating loading plan for order ${orderId} with ${vehicle.type}`,
    );

    // Sort items by volume (largest first) for better packing
    const sortedItems = [...items].sort(
      (a, b) => b.length * b.width * b.height - a.length * a.width * a.height,
    );

    const plan: LoadingPlan = {
      planId: `LP-${Date.now()}`,
      orderId,
      vehicle,
      items: [],
      totalWeight: 0,
      totalVolume: 0,
      weightUtilization: 0,
      volumeUtilization: 0,
      balanceScore: 0,
      efficiency: 0,
      warnings: [],
    };

    // 3D Bin Packing Algorithm (Guillotine Algorithm)
    const packedItems = this.bin3DPacking(sortedItems, vehicle);

    for (const packed of packedItems) {
      plan.items.push({
        itemId: packed.item.id,
        quantity: packed.quantity,
        position: packed.position,
      });

      plan.totalWeight += packed.item.weight * packed.quantity;
      plan.totalVolume += (packed.item.length * packed.item.width * packed.item.height) / 1000000 * packed.quantity;
    }

    // Calculate utilization
    plan.weightUtilization = (plan.totalWeight / vehicle.maxWeight) * 100;
    plan.volumeUtilization = (plan.totalVolume / vehicle.maxVolume) * 100;

    // Calculate balance score
    plan.balanceScore = this.calculateBalance(plan);

    // Calculate overall efficiency
    plan.efficiency = (plan.weightUtilization * 0.5 + plan.volumeUtilization * 0.3 + plan.balanceScore * 0.2) / 100;

    // Generate warnings
    plan.warnings = this.generateWarnings(plan);

    // Save to database
    await this.prisma.loadingPlan.create({
      data: {
        planId: plan.planId,
        orderId: plan.orderId,
        vehicleType: vehicle.type,
        items: plan.items,
        totalWeight: plan.totalWeight,
        totalVolume: plan.totalVolume,
        weightUtilization: plan.weightUtilization,
        volumeUtilization: plan.volumeUtilization,
        efficiency: plan.efficiency,
        status: 'GENERATED',
      },
    });

    console.log(
      `✅ Loading plan generated: ${plan.planId} (Efficiency: ${plan.efficiency.toFixed(1)}%)`,
    );

    return plan;
  }

  /**
   * 3D Bin Packing Algorithm (Guillotine/First Fit)
   */
  private bin3DPacking(
    items: Item[],
    vehicle: Vehicle,
  ): Array<{ item: Item; quantity: number; position: { x: number; y: number; z: number } }> {
    const packed = [];
    const usedSpace = [];

    for (const item of items) {
      for (let q = 0; q < item.quantity; q++) {
        const position = this.findBestPosition(item, vehicle, usedSpace);

        if (position) {
          packed.push({
            item,
            quantity: 1,
            position,
          });

          // Add to used space
          usedSpace.push({
            x: position.x,
            y: position.y,
            z: position.z,
            length: item.length,
            width: item.width,
            height: item.height,
          });
        }
      }
    }

    return packed;
  }

  /**
   * Find best position for item in vehicle
   */
  private findBestPosition(
    item: Item,
    vehicle: Vehicle,
    usedSpace: any[],
  ): { x: number; y: number; z: number } | null {
    const positions = [
      { x: 0, y: 0, z: 0 },
      { x: item.length, y: 0, z: 0 },
      { x: 0, y: item.width, z: 0 },
      { x: 0, y: 0, z: item.height },
    ];

    for (const pos of positions) {
      // Check if item fits
      if (
        pos.x + item.length <= vehicle.length &&
        pos.y + item.width <= vehicle.width &&
        pos.z + item.height <= vehicle.height
      ) {
        // Check collision with used space
        let collision = false;
        for (const used of usedSpace) {
          if (this.checkCollision(pos, item, used)) {
            collision = true;
            break;
          }
        }

        if (!collision) {
          return pos;
        }
      }
    }

    return null;
  }

  /**
   * Check if two boxes collide
   */
  private checkCollision(
    pos1: { x: number; y: number; z: number },
    item1: Item,
    item2: any,
  ): boolean {
    return !(
      pos1.x + item1.length <= item2.x ||
      pos1.y + item1.width <= item2.y ||
      pos1.z + item1.height <= item2.z ||
      item2.x + item2.length <= pos1.x ||
      item2.y + item2.width <= pos1.y ||
      item2.z + item2.height <= pos1.z
    );
  }

  /**
   * Calculate balance score (weight distribution)
   */
  private calculateBalance(plan: LoadingPlan): number {
    // Calculate center of gravity
    let totalMomentX = 0;
    let totalMomentY = 0;
    let totalMomentZ = 0;

    for (const item of plan.items) {
      const centerX = item.position.x + plan.vehicle.length / 2;
      const centerY = item.position.y + plan.vehicle.width / 2;
      const centerZ = item.position.z + plan.vehicle.height / 2;

      totalMomentX += centerX;
      totalMomentY += centerY;
      totalMomentZ += centerZ;
    }

    const avgX = totalMomentX / plan.items.length;
    const avgY = totalMomentY / plan.items.length;
    const avgZ = totalMomentZ / plan.items.length;

    // Calculate variance (lower = more balanced)
    const variance =
      Math.abs(avgX - plan.vehicle.length / 2) +
      Math.abs(avgY - plan.vehicle.width / 2) +
      Math.abs(avgZ - plan.vehicle.height / 2);

    // Score: 100 = perfectly balanced, 0 = very unbalanced
    return Math.max(0, 100 - variance);
  }

  /**
   * Generate warnings for loading plan
   */
  private generateWarnings(plan: LoadingPlan): string[] {
    const warnings = [];

    if (plan.weightUtilization > 95) {
      warnings.push('⚠️ Vehicle is very heavily loaded (>95% weight capacity)');
    }

    if (plan.weightUtilization < 50) {
      warnings.push('⚠️ Vehicle is underutilized (<50% weight capacity)');
    }

    if (plan.volumeUtilization > 95) {
      warnings.push('⚠️ Vehicle is very tightly packed (>95% volume capacity)');
    }

    if (plan.balanceScore < 50) {
      warnings.push('⚠️ Poor weight distribution (balance score < 50)');
    }

    return warnings;
  }

  /**
   * Generate visual loading plan (PDF/SVG)
   */
  async generateLoadingPlanPDF(planId: string): Promise<Buffer> {
    const plan = await this.prisma.loadingPlan.findUnique({
      where: { planId },
    });

    if (!plan) throw new Error('Loading plan not found');

    // Generate SVG representation
    const svg = this.generateSVGPlan(plan);

    console.log(`📄 Loading plan PDF generated: ${planId}`);
    return Buffer.from(svg);
  }

  /**
   * Generate SVG visualization
   */
  private generateSVGPlan(plan: any): string {
    const scale = 2; // pixels per cm
    const vehicle = plan.vehicleType;

    let svg = `
    <svg width="800" height="600" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <style>
          .vehicle { fill: #E8F2F9; stroke: #1A5F99; stroke-width: 2; }
          .item { fill: #FF6B35; stroke: #E55A2A; stroke-width: 1; }
          .text { font-family: Arial; font-size: 12px; }
          .title { font-size: 18px; font-weight: bold; fill: #1A5F99; }
        </style>
      </defs>

      <text x="10" y="30" class="title">Loading Plan: ${plan.planId}</text>
      <text x="10" y="55" class="text">Vehicle: ${vehicle} | Weight: ${plan.totalWeight}kg | Volume: ${plan.totalVolume.toFixed(2)}m³</text>
      <text x="10" y="75" class="text">Efficiency: ${plan.efficiency.toFixed(1)}% | Weight Util: ${plan.weightUtilization.toFixed(1)}% | Balance: ${plan.balanceScore.toFixed(0)}/100</text>

      <!-- Vehicle outline -->
      <rect x="100" y="120" width="600" height="400" class="vehicle" />

      <!-- Items -->
      ${plan.items
        .map(
          (item, idx) => `
        <rect 
          x="${100 + item.position.x * scale}" 
          y="${120 + item.position.y * scale}" 
          width="${item.itemId.length * scale}" 
          height="${item.itemId.width * scale}" 
          class="item"
          opacity="0.7"
        />
        <text x="${100 + item.position.x * scale + 10}" y="${120 + item.position.y * scale + 25}" class="text">Item ${idx + 1}</text>
      `,
        )
        .join('')}
    </svg>
    `;

    return svg;
  }

  /**
   * Optimize consolidation (multiple orders to one vehicle)
   */
  async optimizeConsolidation(
    orderIds: string[],
    vehicle: Vehicle,
  ): Promise<LoadingPlan> {
    console.log(
      `🔄 Optimizing consolidation for ${orderIds.length} orders into ${vehicle.type}`,
    );

    const allItems: Item[] = [];

    for (const orderId of orderIds) {
      const order = await this.prisma.shipmentOrder.findUnique({
        where: { id: orderId },
      });

      if (order) {
        allItems.push({
          id: order.id,
          sku: order.commodityCode,
          weight: order.grossWeight,
          length: order.length || 100,
          width: order.width || 100,
          height: order.height || 100,
          quantity: 1,
          fragile: order.fragile || false,
          stackable: true,
          hazmat: false,
        });
      }
    }

    const plan = await this.generateLoadingPlan(`CONSOLIDATED-${Date.now()}`, allItems, vehicle);
    return plan;
  }

  /**
   * Get loading plan recommendations
   */
  async getRecommendations(orderId: string): Promise<Vehicle[]> {
    const order = await this.prisma.shipmentOrder.findUnique({
      where: { id: orderId },
    });

    if (!order) throw new Error('Order not found');

    const volume = order.cbm || order.grossWeight / 1000;
    const weight = order.grossWeight;

    const recommendations = [];

    // 20ft Container: 33 m³, 25,000 kg
    if (volume <= 33 && weight <= 25000) {
      recommendations.push({
        id: 'container-20ft',
        type: 'CONTAINER_20FT',
        maxWeight: 25000,
        maxVolume: 33,
        length: 589,
        width: 235,
        height: 239,
        recommendation: 'BEST FIT - Most cost-effective',
      });
    }

    // 40ft Container: 67 m³, 30,000 kg
    if (volume <= 67 && weight <= 30000) {
      recommendations.push({
        id: 'container-40ft',
        type: 'CONTAINER_40FT',
        maxWeight: 30000,
        maxVolume: 67,
        length: 1200,
        width: 235,
        height: 239,
        recommendation: 'STANDARD - Most popular',
      });
    }

    // Standard Truck: 24 m³, 25,000 kg
    if (volume <= 24 && weight <= 25000) {
      recommendations.push({
        id: 'truck-standard',
        type: 'TRUCK_STANDARD',
        maxWeight: 25000,
        maxVolume: 24,
        length: 800,
        width: 250,
        height: 200,
        recommendation: 'ECONOMICAL - Local delivery',
      });
    }

    // Flatbed Truck: 40 m³, 28,000 kg
    if (order.commodityCode === '2601' || volume <= 40) {
      recommendations.push({
        id: 'truck-flatbed',
        type: 'TRUCK_FLATBED',
        maxWeight: 28000,
        maxVolume: 40,
        length: 1000,
        width: 300,
        height: 150,
        recommendation: 'HEAVY LOAD - Bulk commodity',
      });
    }

    return recommendations;
  }
}

// src/loading/loading-plan.controller.ts
import { Controller, Post, Get, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from '@/auth/guards/jwt-auth.guard';
import { LoadingPlanService } from './loading-plan.service';

@ApiTags('Loading Plans')
@Controller({ path: 'loading-plans', version: '1' })
@UseGuards(JwtAuthGuard)
@ApiBearerAuth('JWT')
export class LoadingPlanController {
  constructor(private loadingPlanService: LoadingPlanService) {}

  @Post('generate')
  async generateLoadingPlan(@Body() dto: any) {
    return this.loadingPlanService.generateLoadingPlan(
      dto.orderId,
      dto.items,
      dto.vehicle,
    );
  }

  @Get('recommendations/:orderId')
  async getRecommendations(@Param('orderId') orderId: string) {
    return this.loadingPlanService.getRecommendations(orderId);
  }

  @Post('consolidate')
  async consolidate(@Body() dto: any) {
    return this.loadingPlanService.optimizeConsolidation(dto.orderIds, dto.vehicle);
  }

  @Get(':planId/pdf')
  async getPlanPDF(@Param('planId') planId: string) {
    return this.loadingPlanService.generateLoadingPlanPDF(planId);
  }
}

// frontend/components/LoadingPlanVisualizer.tsx - Interactive Visualization
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';

const LoadingPlanVisualizer: React.FC<{ planId: string }> = ({ planId }) => {
  const [view3D, setView3D] = useState(false);

  const { data: plan } = useQuery({
    queryKey: ['loading-plan', planId],
    queryFn: async () => {
      const res = await fetch(`/api/v1/loading-plans/${planId}`);
      return res.json();
    },
  });

  if (!plan) return <div className="text-center py-8">Loading plan not found</div>;

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="border-b-4 border-[#1A5F99] pb-4 mb-6">
        <h2 className="text-2xl font-bold text-[#1A5F99]">Loading Plan: {plan.planId}</h2>
      </div>

      {/* Controls */}
      <div className="flex gap-4 mb-6">
        <button
          onClick={() => setView3D(false)}
          className={`px-4 py-2 rounded-lg font-semibold transition ${
            !view3D
              ? 'bg-[#1A5F99] text-white'
              : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
          }`}
        >
          2D View
        </button>
        <button
          onClick={() => setView3D(true)}
          className={`px-4 py-2 rounded-lg font-semibold transition ${
            view3D
              ? 'bg-[#1A5F99] text-white'
              : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
          }`}
        >
          3D View
        </button>
        <a
          href={`/api/v1/loading-plans/${planId}/pdf`}
          className="px-4 py-2 rounded-lg bg-[#FF6B35] text-white font-semibold hover:bg-[#E55A2A]"
        >
          📄 Download PDF
        </a>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <StatBox
          label="Weight Utilization"
          value={`${plan.weightUtilization.toFixed(1)}%`}
          color="#1A5F99"
        />
        <StatBox
          label="Volume Utilization"
          value={`${plan.volumeUtilization.toFixed(1)}%`}
          color="#FF6B35"
        />
        <StatBox
          label="Balance Score"
          value={`${plan.balanceScore.toFixed(0)}/100`}
          color="#2A9D8F"
        />
        <StatBox
          label="Efficiency"
          value={`${plan.efficiency.toFixed(1)}%`}
          color="#06D6A0"
        />
      </div>

      {/* Visualization */}
      <div className="bg-gray-100 rounded-lg p-4 mb-6">
        {!view3D ? (
          <svg
            viewBox="0 0 800 400"
            className="w-full border-2 border-[#1A5F99]"
            style={{ backgroundColor: '#F0F0F0' }}
          >
            {/* Vehicle outline */}
            <rect
              x="50"
              y="50"
              width="700"
              height="300"
              fill="#E8F2F9"
              stroke="#1A5F99"
              strokeWidth="2"
            />

            {/* Items */}
            {plan.items?.map((item, idx) => (
              <g key={idx}>
                <rect
                  x={50 + (item.position.x || 0) * 2}
                  y={50 + (item.position.y || 0) * 2}
                  width="80"
                  height="80"
                  fill="#FF6B35"
                  stroke="#E55A2A"
                  strokeWidth="1"
                  opacity="0.7"
                />
                <text
                  x={90 + (item.position.x || 0) * 2}
                  y={100 + (item.position.y || 0) * 2}
                  textAnchor="middle"
                  fontSize="12"
                  fill="white"
                  fontWeight="bold"
                >
                  {idx + 1}
                </text>
              </g>
            ))}
          </svg>
        ) : (
          <div className="text-center py-12 text-gray-600">
            3D visualization coming soon
          </div>
        )}
      </div>

      {/* Warnings */}
      {plan.warnings?.length > 0 && (
        <div className="bg-yellow-50 border-l-4 border-[#FFB703] p-4 rounded">
          <h3 className="font-semibold text-[#FFB703] mb-2">⚠️ Warnings</h3>
          <ul className="space-y-1">
            {plan.warnings.map((warning, idx) => (
              <li key={idx} className="text-sm text-gray-700">
                {warning}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

const StatBox = ({ label, value, color }) => (
  <div className="bg-white border-l-4 p-4 rounded" style={{ borderColor: color }}>
    <p className="text-gray-600 text-sm">{label}</p>
    <p className="text-2xl font-bold mt-1" style={{ color }}>
      {value}
    </p>
  </div>
);

export default LoadingPlanVisualizer;

// src/loading/loading-plan.module.ts
import { Module } from '@nestjs/common';
import { LoadingPlanService } from './loading-plan.service';
import { LoadingPlanController } from './loading-plan.controller';

@Module({
  controllers: [LoadingPlanController],
  providers: [LoadingPlanService],
  exports: [LoadingPlanService],
})
export class LoadingPlanModule {}
