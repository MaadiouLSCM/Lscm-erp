# 🚀 LSCM ERP - COMPLETE PRODUCTION DEPLOYMENT GUIDE

**Status:** Production-Ready  
**Version:** 1.0.0  
**Last Updated:** March 5, 2025  
**Estimated Deployment Time:** 2-3 hours

---

## TABLE OF CONTENTS

1. [Pre-Deployment Checklist](#pre-deployment-checklist)
2. [Infrastructure Setup](#infrastructure-setup)
3. [Database Setup](#database-setup)
4. [Kubernetes Deployment](#kubernetes-deployment)
5. [Frontend Deployment](#frontend-deployment)
6. [Health Checks & Verification](#health-checks--verification)
7. [Monitoring & Alerting Setup](#monitoring--alerting-setup)
8. [Backup & Disaster Recovery](#backup--disaster-recovery)
9. [Troubleshooting](#troubleshooting)
10. [Post-Deployment](#post-deployment)

---

## PRE-DEPLOYMENT CHECKLIST

### Team & Access
- [ ] DevOps team assigned
- [ ] Kubernetes cluster access (kubeconfig)
- [ ] Docker registry credentials
- [ ] AWS/Cloud provider credentials
- [ ] DNS records ready (api.lscm.com)
- [ ] SSL/TLS certificates ready
- [ ] Slack #lscm-alerts channel created
- [ ] PagerDuty escalation policies configured

### Code & Configuration
- [ ] Code reviewed and approved
- [ ] All tests passing (npm run test:cov)
- [ ] Security scans passed (Snyk, Trivy)
- [ ] .env file with production values ready
- [ ] Environment variables encrypted (Sealed Secrets)
- [ ] Docker image built and tested
- [ ] Kubernetes manifests validated
- [ ] GitHub Actions secrets configured

### Infrastructure
- [ ] Kubernetes cluster running (≥3 nodes)
- [ ] PostgreSQL 15+ ready
- [ ] Redis 7+ ready
- [ ] Load balancer configured
- [ ] VPC & security groups configured
- [ ] NAT gateway/egress configured
- [ ] CloudFront/CDN configured (optional)
- [ ] S3 bucket for backups created

### Documentation
- [ ] Runbooks written
- [ ] Architecture diagram finalized
- [ ] Disaster recovery plan documented
- [ ] On-call procedures documented
- [ ] Team trained on deployment process
- [ ] Incident response plan ready

---

## INFRASTRUCTURE SETUP

### Step 1: Create Kubernetes Cluster

```bash
# If using EKS (AWS)
eksctl create cluster \
  --name lscm-prod \
  --version 1.28 \
  --region us-east-1 \
  --nodegroup-name lscm-nodes \
  --nodes 3 \
  --nodes-max 10 \
  --instance-types t3.large \
  --enable-ssm \
  --with-oidc

# Verify cluster
kubectl get nodes
kubectl get namespaces
```

### Step 2: Install Required Tools

```bash
# Install Helm (package manager for K8s)
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash

# Install cert-manager (for SSL/TLS)
kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.0/cert-manager.yaml

# Install nginx-ingress-controller
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update
helm install nginx-ingress ingress-nginx/ingress-nginx \
  --namespace ingress-nginx \
  --create-namespace

# Install Prometheus (monitoring)
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm install prometheus prometheus-community/prometheus \
  --namespace lscm-prod \
  -f prometheus-values.yaml

# Install Grafana (dashboards)
helm repo add grafana https://grafana.github.io/helm-charts
helm install grafana grafana/grafana \
  --namespace lscm-prod \
  -f grafana-values.yaml
```

### Step 3: Configure Storage

```bash
# Create persistent volumes
kubectl apply -f k8s/storage.yaml

# Create storage class
kubectl apply -f k8s/storage-class.yaml

# Verify
kubectl get pvc -n lscm-prod
```

### Step 4: Setup Networking

```bash
# Create ingress for SSL
kubectl apply -f k8s/cert-issuer.yaml

# Wait for certificate
kubectl get certificate -n lscm-prod -w

# Verify ingress
kubectl get ingress -n lscm-prod
```

---

## DATABASE SETUP

### Step 1: Create PostgreSQL Secrets

```bash
# Generate secure passwords
DB_PASSWORD=$(openssl rand -base64 32)
POSTGRES_PASSWORD=$(openssl rand -base64 32)

# Create secret
kubectl create secret generic lscm-db-secrets \
  --from-literal=postgres-password=$POSTGRES_PASSWORD \
  --from-literal=user-password=$DB_PASSWORD \
  -n lscm-prod
```

### Step 2: Deploy PostgreSQL

```bash
# Apply PostgreSQL StatefulSet
kubectl apply -f k8s/postgres-deployment.yaml

# Wait for PostgreSQL to be ready
kubectl wait --for=condition=ready pod \
  -l app=lscm-postgres \
  -n lscm-prod \
  --timeout=300s

# Port forward to verify connection
kubectl port-forward -n lscm-prod svc/lscm-postgres 5432:5432 &
psql -h localhost -U lscm_user -d postgres -c "SELECT 1"
```

### Step 3: Run Database Migrations

```bash
# Create migration pod
kubectl run -it --rm \
  --image=node:20-alpine \
  --restart=Never \
  migration \
  -n lscm-prod \
  -- sh -c "npm ci && npx prisma migrate deploy"

# Verify migrations
kubectl logs migration -n lscm-prod
```

### Step 4: Seed Initial Data

```bash
# Seed sample data
kubectl run -it --rm \
  --image=node:20-alpine \
  --restart=Never \
  seed \
  -n lscm-prod \
  -- sh -c "npm ci && npx prisma db seed"
```

### Step 5: Backup Initial State

```bash
# Create backup
kubectl exec -n lscm-prod \
  $(kubectl get pod -l app=lscm-postgres -n lscm-prod -o jsonpath='{.items[0].metadata.name}') \
  -- pg_dump -U lscm_user lscm_erp > initial-backup.sql

# Upload to S3
aws s3 cp initial-backup.sql s3://lscm-backups/
```

---

## KUBERNETES DEPLOYMENT

### Step 1: Create Namespace & Secrets

```bash
# Create namespace
kubectl create namespace lscm-prod

# Create image pull secret (if using private Docker registry)
kubectl create secret docker-registry dockerhub \
  --docker-server=docker.io \
  --docker-username=$DOCKER_USERNAME \
  --docker-password=$DOCKER_PASSWORD \
  --docker-email=$DOCKER_EMAIL \
  -n lscm-prod

# Create app secrets
kubectl create secret generic lscm-erp-secrets \
  --from-literal=database_url="postgresql://lscm_user:$DB_PASSWORD@lscm-postgres:5432/lscm_erp" \
  --from-literal=jwt_secret=$(openssl rand -base64 32) \
  --from-literal=redis_password=$(openssl rand -base64 16) \
  --from-literal=clear_api_key=$CLEAR_API_KEY \
  --from-literal=sap_bw_token=$SAP_BW_TOKEN \
  --from-literal=access_bank_key=$ACCESS_BANK_KEY \
  -n lscm-prod
```

### Step 2: Deploy Redis

```bash
# Deploy Redis
kubectl apply -f k8s/redis-deployment.yaml

# Wait for Redis
kubectl wait --for=condition=ready pod \
  -l app=lscm-redis \
  -n lscm-prod \
  --timeout=300s
```

### Step 3: Build & Push Docker Image

```bash
# Build Docker image
docker build -t lscm/erp:v1.0.0 .

# Tag image
docker tag lscm/erp:v1.0.0 docker.io/lscm/erp:v1.0.0
docker tag lscm/erp:v1.0.0 docker.io/lscm/erp:latest

# Login to Docker Hub
docker login

# Push image
docker push docker.io/lscm/erp:v1.0.0
docker push docker.io/lscm/erp:latest

# Verify
docker pull docker.io/lscm/erp:latest
```

### Step 4: Deploy Backend

```bash
# Apply backend deployment
kubectl apply -f k8s/backend-deployment.yaml

# Wait for pods to be ready
kubectl wait --for=condition=ready pod \
  -l app=lscm-backend \
  -n lscm-prod \
  --timeout=300s

# Check pod status
kubectl get pods -n lscm-prod
kubectl describe pod lscm-backend-0 -n lscm-prod

# View logs
kubectl logs -f deployment/lscm-backend -n lscm-prod
```

### Step 5: Deploy Ingress & Configure DNS

```bash
# Apply ingress
kubectl apply -f k8s/ingress.yaml

# Get LoadBalancer IP
LB_IP=$(kubectl get svc nginx-ingress-ingress-nginx-controller \
  -n ingress-nginx -o jsonpath='{.status.loadBalancer.ingress[0].ip}')

echo "LoadBalancer IP: $LB_IP"

# Update DNS (using Route53 or your DNS provider)
# Point api.lscm.com to $LB_IP
```

### Step 6: Apply Auto-Scaling

```bash
# Deploy HPA (Horizontal Pod Autoscaler)
kubectl apply -f k8s/backend-hpa.yaml

# Monitor autoscaling
kubectl get hpa -n lscm-prod -w
```

---

## FRONTEND DEPLOYMENT

### Step 1: Build Frontend

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# Build for production
npm run build

# Test build locally
npm run start
```

### Step 2: Deploy to Same Kubernetes Cluster

```bash
# Create Dockerfile for Next.js (already provided in frontend/)
docker build -t lscm/frontend:v1.0.0 .

# Push to registry
docker tag lscm/frontend:v1.0.0 docker.io/lscm/frontend:v1.0.0
docker push docker.io/lscm/frontend:v1.0.0

# Deploy frontend
kubectl apply -f k8s/frontend-deployment.yaml

# Verify
kubectl get deployment -n lscm-prod
```

### Step 3: Configure Frontend Ingress

```bash
# Update frontend ingress with correct domain
kubectl apply -f k8s/frontend-ingress.yaml

# Verify ingress
kubectl get ingress -n lscm-prod
```

---

## HEALTH CHECKS & VERIFICATION

### Step 1: Verify API Connectivity

```bash
# Port forward to API
kubectl port-forward -n lscm-prod svc/lscm-backend 3000:80 &

# Test API
curl http://localhost:3000/health
# Should return: {"status":"ok"}

# Test metrics
curl http://localhost:3000/metrics
# Should return Prometheus metrics

# Test API documentation
curl http://localhost:3000/api/docs
```

### Step 2: Verify Database

```bash
# Connect to database
kubectl exec -it -n lscm-prod \
  $(kubectl get pod -l app=lscm-postgres -n lscm-prod -o jsonpath='{.items[0].metadata.name}') \
  -- psql -U lscm_user -d lscm_erp -c "SELECT COUNT(*) FROM \"ShipmentOrder\";"

# Should return number of orders (from seed data)
```

### Step 3: Verify Redis

```bash
# Test Redis
kubectl exec -it -n lscm-prod \
  $(kubectl get pod -l app=lscm-redis -n lscm-prod -o jsonpath='{.items[0].metadata.name}') \
  -- redis-cli ping

# Should return: PONG
```

### Step 4: Run Smoke Tests

```bash
# Execute smoke tests
kubectl run -it --rm \
  --image=node:20-alpine \
  --restart=Never \
  smoke-tests \
  -n lscm-prod \
  -- sh -c "npm ci && npm run test:e2e -- --match '*smoke*'"
```

### Step 5: Load Testing

```bash
# Run load test
kubectl run -it --rm \
  --image=loadimpact/k6:latest \
  --restart=Never \
  load-test \
  -n lscm-prod \
  -- run test/load/orders-api.js \
    --vus 100 \
    --duration 5m \
    --rps 100
```

---

## MONITORING & ALERTING SETUP

### Step 1: Access Prometheus

```bash
# Port forward Prometheus
kubectl port-forward -n lscm-prod svc/prometheus 9090:9090 &

# Open browser
open http://localhost:9090

# Check targets
# Should see all endpoints scraping metrics
```

### Step 2: Access Grafana

```bash
# Get Grafana admin password
kubectl get secret -n lscm-prod grafana -o jsonpath="{.data.admin-password}" | base64 --decode

# Port forward Grafana
kubectl port-forward -n lscm-prod svc/grafana 3000:80 &

# Login
# URL: http://localhost:3000
# Username: admin
# Password: (from above)

# Import dashboards
# - Kubernetes Cluster Monitoring
# - LSCM Backend Metrics
# - PostgreSQL
```

### Step 3: Configure Alertmanager

```bash
# Deploy Alertmanager
kubectl apply -f k8s/alertmanager-deployment.yaml

# Configure notification channels
# - Slack
# - PagerDuty
# - Email
```

### Step 4: Configure Logging (Loki + Promtail)

```bash
# Deploy Loki
kubectl apply -f k8s/loki-deployment.yaml

# Deploy Promtail (log collector)
kubectl apply -f k8s/promtail-daemonset.yaml

# Verify logs in Grafana
# Explore > Loki > select pod
```

---

## BACKUP & DISASTER RECOVERY

### Step 1: Setup Automated Backups

```bash
# Create backup cronjob
kubectl apply -f k8s/backup-cronjob.yaml

# Schedule:
# - Database backup: Daily at 2:00 AM
# - Full snapshot: Weekly at Sunday 3:00 AM
# - Upload to S3 automatically

# Verify
kubectl get cronjob -n lscm-prod
```

### Step 2: Test Restore Procedure

```bash
# Create test namespace
kubectl create namespace lscm-test

# Restore from backup
pg_restore -d lscm_erp < latest-backup.sql

# Verify data
kubectl exec -n lscm-test $(kubectl get pod -l app=lscm-postgres -o jsonpath='{.items[0].metadata.name}') \
  -- psql -U lscm_user -d lscm_erp -c "SELECT COUNT(*) FROM \"ShipmentOrder\";"
```

### Step 3: Document Disaster Recovery Plan

```
Disaster Recovery Steps:

1. ASSESS SITUATION
   - Check what failed (pod, node, database, etc)
   - Check monitoring alerts
   - Review logs

2. IF POD FAILED
   - Kubernetes auto-restarts
   - Check pod logs: kubectl logs pod-name -n lscm-prod
   - Scale deployment: kubectl scale deployment lscm-backend --replicas=3

3. IF NODE FAILED
   - Drain node: kubectl drain node-name --ignore-daemonsets
   - Delete node: kubectl delete node node-name
   - Auto-scaling replaces it

4. IF DATABASE FAILED
   - Stop pods: kubectl scale deployment lscm-backend --replicas=0
   - Restore from backup: pg_restore < backup.sql
   - Verify data integrity
   - Scale up pods: kubectl scale deployment lscm-backend --replicas=3

5. IF CLUSTER FAILED
   - Create new cluster
   - Restore database from S3 backup
   - Deploy application
   - Update DNS

6. VERIFICATION
   - Run smoke tests
   - Check all health endpoints
   - Verify data integrity
   - Monitor metrics for 1 hour
```

---

## TROUBLESHOOTING

### Pod Won't Start

```bash
# Check events
kubectl describe pod pod-name -n lscm-prod

# Check logs
kubectl logs pod-name -n lscm-prod
kubectl logs pod-name -n lscm-prod --previous  # For crashed pod

# Check resource limits
kubectl top pods -n lscm-prod

# Common fixes:
# - Increase memory/cpu limits
# - Wait for database to be ready
# - Check image pull secrets
```

### High Error Rate

```bash
# Check error logs
kubectl logs deployment/lscm-backend -n lscm-prod | grep ERROR

# Check database connection
kubectl exec -it pod-name -n lscm-prod -- npm run test

# Check external API connections
# - CLEAR API
# - SAP BW
# - Bank APIs
```

### Database Performance Issues

```bash
# Connect to database
kubectl exec -it postgres-pod -n lscm-prod -- psql -U lscm_user -d lscm_erp

# Check slow queries
SELECT * FROM pg_stat_statements ORDER BY total_time DESC LIMIT 10;

# Check index usage
SELECT * FROM pg_stat_user_indexes ORDER BY idx_scan ASC;

# Reindex if needed
REINDEX INDEX index_name;
```

---

## POST-DEPLOYMENT

### Step 1: Verify All Systems

```bash
# ✅ API endpoint working
curl -s http://api.lscm.com/health | jq .

# ✅ Frontend loading
curl -s http://lscm.com | grep -o '<title>'

# ✅ Metrics available
curl -s http://api.lscm.com/metrics | head

# ✅ Logs being collected
# Check Grafana Loki

# ✅ Alerts configured
# Check Alertmanager

# ✅ Backups running
# Check S3 bucket
```

### Step 2: Team Handover

- [ ] Team trained on deployment process
- [ ] Runbooks reviewed
- [ ] On-call rotation established
- [ ] Slack integrations working
- [ ] PagerDuty escalation tested
- [ ] Incident response plan reviewed

### Step 3: Monitor for 24 Hours

```bash
# Watch metrics
watch -n 5 'kubectl top pods -n lscm-prod'

# Watch error rates
# In Grafana: Graph error rate
# Should be < 0.1%

# Watch latency
# In Grafana: HTTP request duration
# p95 should be < 1 second

# Monitor logs
# In Grafana Loki: Search for ERROR
# Should be minimal
```

### Step 4: Go-Live Checklist

- [ ] All monitoring alerts passing
- [ ] Error rate acceptable
- [ ] Response time acceptable
- [ ] Database performing well
- [ ] Backups running successfully
- [ ] Team confident with system
- [ ] Customer acceptance testing passed
- [ ] Post-launch support planned

---

## PRODUCTION OPERATIONS

### Daily Tasks

```bash
# Check system health
kubectl get all -n lscm-prod

# Review error logs
kubectl logs -n lscm-prod \
  -l app=lscm-backend \
  --tail=100 \
  | grep ERROR

# Monitor resource usage
kubectl top nodes
kubectl top pods -n lscm-prod
```

### Weekly Tasks

```bash
# Review performance metrics in Grafana
# - Error rates
# - Response times
# - Database query times
# - Storage usage

# Review logs for warnings
kubectl logs -n lscm-prod \
  -l app=lscm-backend \
  --since=7d | grep WARN

# Test backup/restore
# Restore to test cluster, verify data
```

### Monthly Tasks

```bash
# Review capacity planning
# - CPU/memory usage
# - Storage growth
# - Database size

# Update dependencies (security patches)
npm audit fix

# Update Kubernetes cluster
# - Node upgrades
# - Addon updates

# Security audit
# - Access logs review
# - Vulnerability scan
```

---

**Deployment Complete! 🎉**

Your LSCM ERP system is now running in production on Kubernetes with full monitoring, backups, and disaster recovery in place.

