# 🚚 TAKAMUL-ATOMAI → ERP INTEGRATION ANALYSIS

## Contexte: Du Phase 0 Théorique au Réel Opérationnel

**Document analysé:** Plan Logistique Routier TAKAMUL-ATOMAI (Corridor Mauritanie → Europe)  
**Cas d'usage réel:** Expédition TAKA146 - Échantillons miniers (5,659 kg) vers Aachen, Allemagne  
**Mode de transport:** Land (routier multimodal) + Maritime (ferry Tanger→Algésiras)  
**Incoterm:** DDP (Delivered Duty Paid)  
**Documents:** CMR, T1, DAU, POA, Custom declarations

---

## 📊 ANALYSE: LACUNES Phase 0 vs RÉALITÉS TAKAMUL

### A. MODES DE TRANSPORT

#### Phase 0 (Actuel):
```typescript
type TransportMode = 'AIR' | 'SEA' | 'LAND';
// Basique: pas de distinction par type de véhicule
```

#### TAKAMUL (Réel):
```
LAND Routes:
├─ Road (Truck): Mauritanie → Guerguerat
├─ Ferry: Tanger Med → Algésiras (véhicule + cargo)
├─ Road multi-countries: Spain → Germany
│  ├─ Transhipment at Casablanca
│  ├─ Transhipment at Algésiras
│  └─ Transhipment at Irun (Spanish border)
└─ Customs crossing: 7 country borders

Segments:
├─ Segment 1: Nouakchott → Guerguerat (2.5 days)
├─ Segment 2: Guerguerat → Casablanca (24h)
├─ Segment 3: Casablanca → Tanger Med (6h)
├─ Segment 4: Ferry + Loading (12h)
├─ Segment 5: Algésiras → Madrid → Burgos → Irun (48h)
├─ Segment 6: Irun → Bordeaux → Paris → Lille (40h)
├─ Segment 7: Lille → Aachen customs (12h)
└─ Segment 8: Customs processing (24h)
```

**LACUNE:** Phase 0 ne supporte PAS les segments multiples + transhipments

---

### B. DOCUMENTS REQUIS

#### Phase 0 (Actuel):
```typescript
DocumentType = 'CI' | 'PL' | 'BL' | 'AWB' | 'POD' | 'JCR';
// Pas de documents douaniers spécifiques
```

#### TAKAMUL (Réel):
```
MANDATORY DOCUMENTS:
├─ SHIPPER DOCS:
│  ├─ RFC (Request for Collection)
│  ├─ CI (Commercial Invoice)
│  ├─ PL (Packing List)
│  └─ BW (Business Warehouse - SAP data)
│
├─ TRANSPORT DOCS:
│  ├─ CMR (International road transport - Draft + Original)
│  ├─ Waybill (LSCM internal document)
│  ├─ T1 (Transit Type 1 document - EU customs transit)
│  ├─ MRN (Movement Reference Number - from T1)
│  └─ SM (Shipping Marks - labels on packages)
│
├─ CUSTOMS EXPORT:
│  ├─ Export declaration (Mauritanie)
│  ├─ DUM (Document Unique de Marchandises - Morocco)
│  └─ DAU (Document Administratif Unique - EU)
│
├─ CUSTOMS IMPORT:
│  ├─ PAAR (Pre-Arrival Assessment Report) - if applicable
│  ├─ Form M - if applicable
│  └─ Import declaration (Germany)
│
└─ AUTHORIZATION DOCS:
   ├─ POA (Power of Attorney - for customs broker)
   ├─ SR (Survey Report - with photos)
   ├─ ATB (Customs processing notice)
   └─ ATC (Customs clearance confirmation)
```

**LACUNE:** Phase 0 n'a PAS d'architecture pour CMR, T1, DAU, POA, ATB, ATC

---

### C. INCOTERMS & RESPONSIBILITIES

#### Phase 0:
```typescript
incoterm: 'FCA' | 'FOB' | 'CIF';
// Pas de logique associée
```

#### TAKAMUL (Réel - DDP):
```
DDP = Delivered Duty Paid
└─ LSCM Responsible for:
   ├─ ✓ Pickup from supplier
   ├─ ✓ Export customs clearance
   ├─ ✓ International transportation
   ├─ ✓ Border crossings (7 countries)
   ├─ ✓ Transit customs (T1 handling)
   ├─ ✓ Import customs clearance
   ├─ ✓ Final delivery to consignee
   ├─ ✓ Duty payment
   └─ ✓ Risk & insurance until delivery

Meaning: LSCM controls END-TO-END process
```

**LACUNE:** Phase 0 n'implémente PAS la logique DDP (border crossings, duty payment, import clearance)

---

### D. WORKFLOW GATES & STATUS

#### Phase 0 (Actuel):
```typescript
Status: 'DRAFT' | 'CONFIRMED' | 'IN_TRANSIT' | 'DELIVERED' | 'COMPLETED';
// ~6 statuses
```

#### TAKAMUL (Réel):
```
DETAILED STATUS FLOW (11 phases, 50+ micro-statuses):

1. PREPARATION (Pickup schedule)
   ├─ SCHEDULED
   ├─ OUT_FOR_PICKUP
   ├─ PICKED_UP
   ├─ DELAYED_PICKUP
   └─ POSTPONED_PICKUP

2. HUB RECEPTION (Hub quality check)
   ├─ RECEIVED_AT_HUB
   ├─ QC_IN_PROGRESS
   ├─ QC_PASSED
   ├─ QC_FAILED
   └─ WAREHOUSE_STORED

3. EXPORT CUSTOMS (Pre-clearance & approval)
   ├─ EXPORT_DOCS_SUBMITTED
   ├─ EXPORT_CUSTOMS_CLEARED ← GATE 1 (GL approval needed)
   ├─ EXPORT_CUSTOMS_HOLD
   └─ EXPORT_CUSTOMS_REJECTED

4. BOOKING (Carrier reservation)
   ├─ BOOKING_REQUESTED
   ├─ SPACE_CONFIRMED
   └─ BOOKED_FOR_DEPARTURE

5. LOADING (Stuffing & Survey)
   ├─ LOADING_SCHEDULED
   ├─ LOADING_IN_PROGRESS
   ├─ LOADING_COMPLETED
   ├─ SURVEY_REPORT_GENERATED
   └─ READY_FOR_DISPATCH

6. DEPARTURE (Truck leaves)
   ├─ DEP_ON_TIME
   ├─ DEP_DELAYED
   └─ DEP_POSTPONED

7. SEGMENT TRANSIT (Segment 1-8 tracking)
   ├─ SEG1_IN_TRANSIT (Nouakchott→Guerguerat)
   ├─ SEG1_ARRIVED
   ├─ SEG2_BORDER_CROSSING_MAURITANIA (Customs Check 1)
   ├─ SEG2_CLEARED
   ├─ SEG3_IN_TRANSIT (Maroc)
   ├─ SEG3_TRANSHIPMENT_CASABLANCA
   ├─ SEG4_FERRY_BOARDED
   ├─ SEG4_FERRY_ARRIVED_ALGECIRAS
   ├─ SEG5_BORDER_CROSSING_SPAIN (Customs Check 2 - T1 validation)
   ├─ SEG5_T1_VALIDATED_EU_TRANSIT ← GATE 2 (T1 must be validated)
   ├─ ... (more segments)
   └─ SEG8_ARRIVED_AACHEN

8. IMPORT CUSTOMS (Destination customs)
   ├─ IMPORT_DOCS_SUBMITTED
   ├─ CUSTOMS_DECLARED
   ├─ CUSTOMS_INSPECTION_SCHEDULED
   ├─ CUSTOMS_INSPECTION_IN_PROGRESS
   ├─ CUSTOMS_CLEARED ← GATE 3 (Clearance obtained)
   ├─ CUSTOMS_HOLD
   ├─ ATB_RECEIVED (Processing Notice)
   └─ ATC_RECEIVED (Clearance Confirmation)

9. DELIVERY (Final mile)
   ├─ DELIVERY_SCHEDULED
   ├─ OUT_FOR_DELIVERY
   ├─ DELIVERED
   └─ POD_SIGNED

10. BILLING (Invoice & Payment)
    ├─ INVOICE_CREATED
    ├─ INVOICE_SENT
    ├─ PAYMENT_PENDING
    └─ PAID

11. JOB CLOSURE
    ├─ JCR_GENERATED
    ├─ JCR_SENT_TO_CLIENT
    └─ JOB_CLOSED
```

**LACUNE:** Phase 0 a ~6 statuses. TAKAMUL a 50+. Besoin d'une architecture flexible.

---

### E. CUSTOMS PROCESSING GATES

#### TAKAMUL Critical Gates:
```
GATE 1: GL (Greenlight) Approval
├─ WHO: Client + Customs Broker + Transporter
├─ WHAT: Kit documentaire (CI, PL, CMR, DAU/DUM)
├─ WHEN: Before truck departure
├─ IF REJECTED: Job stopped, renegotiate
└─ ACTION: Pre-alert can be sent only after GL approval

GATE 2: T1 Validation (EU Transit)
├─ WHO: Spanish customs at Algésiras
├─ WHAT: T1/MRN document validated for EU transit
├─ WHEN: At ferry arrival (crossing into EU)
├─ ACTION: ATB (processing notice) issued
└─ STATUS: T1_VALIDATED allows truck to continue

GATE 3: Import Customs Clearance
├─ WHO: German customs at Aachen
├─ WHAT: Import declaration + inspection (if needed)
├─ WHEN: At destination
├─ ACTION: ATC (clearance confirmation) issued
└─ RESULT: POD can be signed only after ATC received
```

**LACUNE:** Phase 0 n'a PAS de logic pour multi-gate approvals + conditional blocking

---

### F. DAILY STATUS REPORTING

#### Phase 0:
```
No DSR functionality
```

#### TAKAMUL:
```
DAILY STATUS REPORT (DSR) - Shared with client

Format: Update in CLEAR + Email to client daily at 17:00

Fields:
├─ Shipment reference: TAKA146
├─ Current status: e.g., "SEG5_IN_TRANSIT"
├─ Current location: e.g., "Madrid, Spain"
├─ ETA: Estimated Time of Arrival at next checkpoint
├─ Last action: e.g., "Crossed Mauritania-Morocco border"
├─ Incidents: e.g., "Border delay 2h due to documentation review"
├─ Critical points: e.g., "Awaiting T1 validation at Algésiras"
└─ Next milestone: e.g., "Expected ferry boarding in 6h"

Example DSR Entry:
"Status: IN_TRANSIT_SEG5 | Location: Madrid | ETA Irun: 18:00 | 
 Last: Departed Algésiras 08:00 after customs release |
 Incidents: None | Critical: Approaching Irun (last EU checkpoint before France) |
 Next: Border crossing at Irun, then 40h to Aachen"

Frequency: Daily until delivery
Visibility: CLIENT + LSCM TEAM
```

**LACUNE:** Phase 0 n'a PAS de DSR system avec timestamps + location tracking

---

## 🔧 MODIFICATIONS NÉCESSAIRES AU CODE PHASE 0

### 1. TRANSPORT MODE EXPANSION

**Current:**
```typescript
// models/Order.ts
transportMode: 'AIR' | 'SEA' | 'LAND';
```

**Required:**
```typescript
type TransportMode = 'AIR' | 'SEA' | 'LAND';

type TransportSubMode = 
  | 'AIR_FREIGHT'
  | 'AIR_COURIER'
  | 'SEA_FCL'      // Full Container Load
  | 'SEA_LCL'      // Less than Container Load
  | 'ROAD_TRUCK'   // Land transport
  | 'ROAD_FERRY'   // Maritime + Road combo
  | 'MULTIMODAL';  // Multiple modes in one shipment

interface TransportSegment {
  segmentId: string;           // SEG1, SEG2, etc
  origin: string;              // 'Nouakchott'
  destination: string;         // 'Guerguerat'
  mode: TransportMode;         // 'LAND'
  subMode: TransportSubMode;   // 'ROAD_TRUCK'
  carrier: string;             // Carrier name/ID
  vehicle: string;             // Truck #, Flight #, Vessel
  estimatedDuration: number;   // hours
  estimatedCost: number;       // USD
  status: SegmentStatus;       // IN_TRANSIT, ARRIVED, DELAYED
  actualDeparture?: Date;
  actualArrival?: Date;
  incidents?: string[];        // ['Border delay 2h', 'Weather delay']
}

interface Order {
  // ... existing fields
  transportMode: TransportMode;
  segments: TransportSegment[];  // NEW: Multi-segment support
  totalLeadTime: number;         // Sum of all segments
}
```

---

### 2. DOCUMENT TYPES EXPANSION

**Current:**
```typescript
type DocumentType = 'CI' | 'PL' | 'BL' | 'AWB' | 'POD' | 'JCR';
```

**Required:**
```typescript
type DocumentType =
  // === SHIPPER DOCS ===
  | 'RFC'          // Request for Collection
  | 'CI'           // Commercial Invoice
  | 'PL'           // Packing List
  | 'BW'           // Business Warehouse (SAP data)
  | 'SM'           // Shipping Marks (labels)
  
  // === TRANSPORT DOCS ===
  | 'CMR'          // International Road Consignment Note
  | 'WAYBILL'      // LSCM internal waybill
  | 'T1'           // EU Transit Document Type 1
  | 'T1_MRN'       // Movement Reference Number (from T1)
  
  // === CUSTOMS EXPORT ===
  | 'EXPORT_DECL'  // Export declaration
  | 'DUM'          // Document Unique de Marchandises (Morocco)
  | 'DAU'          // Document Administratif Unique (EU)
  | 'CCVO'         // Certificate of Value & Origin
  
  // === CUSTOMS IMPORT ===
  | 'PAAR'         // Pre-Arrival Assessment Report
  | 'FORM_M'       // Import license
  | 'IMPORT_DECL'  // Import declaration
  
  // === AUTHORIZATION ===
  | 'POA'          // Power of Attorney (customs broker)
  | 'ATB'          // Avis de Traitement Douanier (processing notice)
  | 'ATC'          // Customs clearance confirmation
  
  // === VERIFICATION ===
  | 'SR'           // Survey Report (with photos)
  | 'POC'          // Proof of Collection
  | 'POR'          // Proof of Receipt
  | 'POD'          // Proof of Delivery
  
  // === COMPLETION ===
  | 'JCR';         // Job Completion Report

interface Document {
  id: string;
  orderId: string;
  type: DocumentType;
  
  // Metadata
  reference?: string;          // Document reference number
  status: DocumentStatus;      // DRAFT, SUBMITTED, APPROVED, REJECTED, SIGNED
  
  // Version control
  version: number;             // Draft, Original, Final
  isDraft?: boolean;           // true for draft docs
  isOriginal?: boolean;        // true for original signed docs
  
  // File storage
  fileUrl: string;
  fileName: string;
  uploadedAt: Date;
  uploadedBy: string;
  
  // Approval workflow
  requiredApprovals?: string[];        // Who needs to approve?
  approvalStatus?: Record<string, ApprovalStatus>;
  approvedAt?: Date;
  approvedBy?: string;
  
  // Customs-specific
  customsReference?: string;   // Customs office reference
  mrnNumber?: string;          // Movement Reference Number
  
  // Metadata
  createdAt: Date;
  updatedAt: Date;
}

type DocumentStatus = 
  | 'DRAFT'
  | 'PENDING_REVIEW'
  | 'SUBMITTED'
  | 'APPROVED'
  | 'REJECTED'
  | 'SIGNED'
  | 'ARCHIVED';

interface ApprovalStatus {
  approver: string;            // CLIENT, CUSTOMS_BROKER, CARRIER, LSCM_MGMT
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  approvedAt?: Date;
  reason?: string;
}
```

---

### 3. STATUS ARCHITECTURE - FROM 6 TO 50+

**Current:**
```typescript
type OrderStatus = 'DRAFT' | 'CONFIRMED' | 'IN_TRANSIT' | 'DELIVERED' | 'COMPLETED' | 'CANCELLED';
```

**Required - Hierarchical:**
```typescript
// Main phases
type OrderPhase = 
  | 'PREPARATION'       // Phase 1
  | 'HUB_RECEPTION'     // Phase 2
  | 'EXPORT_CUSTOMS'    // Phase 3
  | 'BOOKING'           // Phase 4
  | 'LOADING'           // Phase 5
  | 'DEPARTURE'         // Phase 6
  | 'TRANSIT'           // Phase 7 (multi-segment)
  | 'IMPORT_CUSTOMS'    // Phase 8
  | 'DELIVERY'          // Phase 9
  | 'BILLING'           // Phase 10
  | 'CLOSURE';          // Phase 11

type OrderStatus = 
  // Phase 1
  | 'PICKUP_SCHEDULED'
  | 'OUT_FOR_PICKUP'
  | 'PICKED_UP'
  | 'DELAYED_PICKUP'
  | 'POSTPONED_PICKUP'
  
  // Phase 2
  | 'RECEIVED_AT_HUB'
  | 'QC_IN_PROGRESS'
  | 'QC_PASSED'
  | 'QC_FAILED'
  | 'WAREHOUSE_STORED'
  
  // Phase 3
  | 'EXPORT_DOCS_SUBMITTED'
  | 'EXPORT_CUSTOMS_CLEARED'
  | 'EXPORT_CUSTOMS_HOLD'
  | 'EXPORT_CUSTOMS_REJECTED'
  
  // Phase 4
  | 'BOOKING_REQUESTED'
  | 'SPACE_CONFIRMED'
  | 'BOOKED_FOR_DEPARTURE'
  
  // Phase 5
  | 'LOADING_SCHEDULED'
  | 'LOADING_IN_PROGRESS'
  | 'LOADING_COMPLETED'
  | 'SURVEY_REPORT_GENERATED'
  | 'READY_FOR_DISPATCH'
  
  // Phase 6
  | 'DEP_ON_TIME'
  | 'DEP_DELAYED'
  | 'DEP_POSTPONED'
  
  // Phase 7 - Per Segment
  | 'SEG_IN_TRANSIT'
  | 'SEG_ARRIVED'
  | 'SEG_BORDER_CROSSING'
  | 'SEG_CUSTOMS_CHECK'
  | 'SEG_CLEARED'
  | 'SEG_TRANSHIPMENT'
  | 'SEG_DELAYED'
  
  // Phase 8
  | 'IMPORT_DOCS_SUBMITTED'
  | 'CUSTOMS_DECLARED'
  | 'CUSTOMS_INSPECTION_SCHEDULED'
  | 'CUSTOMS_INSPECTION_IN_PROGRESS'
  | 'CUSTOMS_CLEARED'
  | 'CUSTOMS_HOLD'
  | 'ATB_RECEIVED'
  | 'ATC_RECEIVED'
  
  // Phase 9
  | 'DELIVERY_SCHEDULED'
  | 'OUT_FOR_DELIVERY'
  | 'DELIVERED'
  | 'POD_SIGNED'
  
  // Phase 10
  | 'INVOICE_CREATED'
  | 'INVOICE_SENT'
  | 'PAYMENT_PENDING'
  | 'PAID'
  
  // Phase 11
  | 'JCR_GENERATED'
  | 'JCR_SENT_TO_CLIENT'
  | 'JOB_CLOSED'
  
  // General
  | 'CANCELLED';

interface OrderStatusDetail {
  order Id: string;
  phase: OrderPhase;
  status: OrderStatus;
  statusTimestamp: Date;
  location?: string;
  eta?: Date;
  lastAction?: string;
  incidents?: Incident[];
  
  // Progress tracking
  completionPercentage: number;  // 0-100%
  milestonesCompleted: string[]; // Array of passed milestones
}

interface Incident {
  type: 'DELAY' | 'HOLD' | 'DAMAGE' | 'DOCUMENTATION' | 'WEATHER' | 'MECHANICAL' | 'OTHER';
  description: string;
  reportedAt: Date;
  resolvedAt?: Date;
  impact: 'LOW' | 'MEDIUM' | 'HIGH';
}
```

---

### 4. CUSTOMS GATES LOGIC

**New Service:**
```typescript
// services/CustomsGateService.ts

interface Gate {
  gateId: 'GL' | 'T1_VALIDATION' | 'IMPORT_CLEARANCE';
  name: string;
  requiredApprovals: string[];  // ['CLIENT', 'CUSTOMS_BROKER', 'CARRIER']
  requiredDocuments: DocumentType[];
  stage: OrderPhase;
  blockingStatus: OrderStatus;  // If gate not approved, order stuck in this status
}

class CustomsGateService {
  
  // Gate 1: Greenlight Approval
  async checkGreenLightGate(orderId: string): Promise<GateStatus> {
    const order = await Order.findById(orderId);
    
    // Check required docs
    const hasCI = order.documents.some(d => d.type === 'CI' && d.status === 'APPROVED');
    const hasPL = order.documents.some(d => d.type === 'PL' && d.status === 'APPROVED');
    const hasCMR = order.documents.some(d => d.type === 'CMR' && d.status === 'DRAFT');
    
    // Check approvals
    const clientApproved = order.approvals.CLIENT === 'APPROVED';
    const brokerApproved = order.approvals.CUSTOMS_BROKER === 'APPROVED';
    const carrierApproved = order.approvals.CARRIER === 'APPROVED';
    
    if (hasCI && hasPL && hasCMR && clientApproved && brokerApproved && carrierApproved) {
      return { gateStatus: 'APPROVED', blockRemoved: true };
    } else {
      return { gateStatus: 'BLOCKED', missingApprovals: [...] };
    }
  }
  
  // Gate 2: T1 Validation (EU Transit)
  async checkT1ValidationGate(orderId: string): Promise<GateStatus> {
    const order = await Order.findById(orderId);
    
    // Check if T1 document exists and has MRN
    const t1Doc = order.documents.find(d => d.type === 'T1');
    if (!t1Doc || !t1Doc.mrnNumber) {
      return { gateStatus: 'BLOCKED', reason: 'T1 document not yet issued' };
    }
    
    // Check if MRN has been validated by EU customs
    const mrnValidated = await checkMRNValidation(t1Doc.mrnNumber);
    if (!mrnValidated) {
      return { gateStatus: 'BLOCKED', reason: 'MRN awaiting EU customs validation' };
    }
    
    // Check for ATB (processing notice)
    const atbDoc = order.documents.find(d => d.type === 'ATB');
    if (atbDoc) {
      return { gateStatus: 'APPROVED', blockRemoved: true };
    }
  }
  
  // Gate 3: Import Customs Clearance
  async checkImportClearanceGate(orderId: string): Promise<GateStatus> {
    const order = await Order.findById(orderId);
    
    // Check if ATC (clearance confirmation) received
    const atcDoc = order.documents.find(d => d.type === 'ATC');
    if (!atcDoc) {
      return { gateStatus: 'BLOCKED', reason: 'Awaiting customs clearance confirmation' };
    }
    
    // If ATC exists and dated
    if (atcDoc.approvedAt) {
      return { gateStatus: 'APPROVED', blockRemoved: true };
    }
  }
}
```

---

### 5. DSR (DAILY STATUS REPORT) SYSTEM

**New Entity:**
```typescript
// models/DailyStatusReport.ts

interface DailyStatusReport {
  dsrId: string;
  orderId: string;
  reportDate: Date;
  reportTime: string;  // 'HH:MM' e.g., '17:00'
  
  // Current state
  currentPhase: OrderPhase;
  currentStatus: OrderStatus;
  currentLocation: string;
  currentSegment?: string;
  
  // Progress
  eta: Date;  // Estimated Time of Arrival at next checkpoint
  etaSegment: string;  // Next expected milestone
  lastAction: string;  // What happened since last report
  lastActionTime: Date;
  
  // Issues
  incidents: Incident[];
  delays: {
    source: string;           // 'CUSTOMS' | 'WEATHER' | 'TRAFFIC' | 'MECHANICAL'
    duration: number;         // minutes
    expectedResolution: Date;
  }[];
  
  // Critical points
  criticalNotes: string;  // Special attention needed?
  upcomingMilestones: string[];
  
  // Visibility
  sentToClient: boolean;
  sentAt?: Date;
  clientAcknowledged?: boolean;
  
  createdAt: Date;
  createdBy: string;  // Coordinator name
}

// DSR Automation
class DSRService {
  async generateDSR(orderId: string): Promise<DailyStatusReport> {
    const order = await Order.findById(orderId);
    const lastDSR = await DailyStatusReport.findOne({ orderId }).sort({ reportDate: -1 });
    
    // Fetch latest segment data from carrier
    const segmentUpdate = await getCarrierTracking(order.carrier, order.reference);
    
    const dsr = new DailyStatusReport({
      orderId,
      currentPhase: order.phase,
      currentStatus: order.status,
      currentLocation: segmentUpdate.location,
      eta: segmentUpdate.eta,
      lastAction: generateActionSummary(lastDSR, segmentUpdate),
      incidents: segmentUpdate.incidents || [],
    });
    
    // Send to client daily at 17:00
    await this.sendToClient(dsr);
    return dsr;
  }
  
  async sendToClient(dsr: DailyStatusReport): Promise<void> {
    const client = await Company.findById(dsr.order.clientId);
    const emailBody = this.formatDSREmail(dsr);
    
    await emailService.send({
      to: client.email,
      subject: `Daily Status - Shipment ${dsr.order.reference}`,
      html: emailBody,
    });
    
    dsr.sentToClient = true;
    dsr.sentAt = new Date();
    await dsr.save();
  }
}
```

---

## 📋 IMPLEMENTATION ROADMAP FOR PHASE 1A

### Sprint 1: Document Architecture (Week 1)
```
☐ Extend DocumentType enum
☐ Create Document model with approval workflow
☐ Implement CMR, T1, DAU, POA document templates
☐ Add version control (Draft vs Original)
```

### Sprint 2: Transport Segments (Week 2)
```
☐ Create TransportSegment model
☐ Link multiple segments to Order
☐ Implement segment status tracking
☐ Add carrier integration for tracking
```

### Sprint 3: Status Hierarchy (Week 2-3)
```
☐ Expand OrderStatus enum to 50+ values
☐ Implement OrderPhase concept
☐ Create phase-specific workflows
☐ Add status transition validation rules
```

### Sprint 4: Customs Gates (Week 3)
```
☐ Implement CustomsGateService
☐ Create 3 major gates (GL, T1, Import Clearance)
☐ Add blocking logic (status stuck until gate approved)
☐ Implement multi-party approval workflow
```

### Sprint 5: DSR System (Week 4)
```
☐ Create DailyStatusReport model
☐ Implement auto-generation at 17:00 daily
☐ Add email delivery to client
☐ Create tracking dashboard showing latest DSR
```

### Sprint 6: Integration & Testing (Week 4-5)
```
☐ Test Takamul-Atomai workflow end-to-end
☐ Validate all 50+ statuses reached correctly
☐ Verify gates block/unblock status correctly
☐ Load test DSR generation (daily volume)
```

---

## 🎯 METRICS TO TRACK (Phase 1A)

```typescript
interface ImplementationMetrics {
  documentsSupported: number;           // Current: 6 → Target: 20+
  statusesSupported: number;            // Current: 6 → Target: 50+
  customsGates: number;                 // Current: 0 → Target: 3+
  transportSegments: number;            // Current: 1 → Target: 8 (TAKAMUL)
  approvalWorkflows: number;            // Current: 0 → Target: 3 (GL, T1, Import)
  dsrGenerations_per_day: number;       // Current: 0 → Target: ~50 (for all active orders)
  multiCountrySupport: number;          // Current: 2 → Target: 50+ countries
  customsDeclarationsSupported: number; // Current: 0 → Target: 10+ (DAU, DUM, etc)
}
```

---

## ✅ TAKAMUL SUCCESS CRITERIA

```
✓ Ingest RFC, CI, PL from client
✓ Auto-generate CMR, T1, DAU templates
✓ Create 8 transport segments for Mauritanie→Germany route
✓ Block shipment until GL approved (3-way approval)
✓ Track through 7 country borders with customs holds
✓ Validate T1/MRN at Spain border (Gate 2)
✓ Block delivery until ATC received (Gate 3)
✓ Generate daily DSR shared with client at 17:00
✓ Consolidate 15+ documents into final JCR
✓ Support DDP Incoterm (LSCM pays all duties)
```

---

**Document Status:** Ready for development sprint planning
**Next Step:** Code Phase 1A modifications
**Owner:** LSCM Development Team
