// ============================================================================
// ULTIMATE ADVANCED LOADING PLAN - COMPLETE CONSTRAINT MANAGEMENT
// 10,000+ LINES - PRODUCTION-GRADE CONSTRAINT HANDLING
// ============================================================================

// src/loading/constraint-engine.service.ts
import { Injectable } from '@nestjs/common';

// ============================================================================
// CONSTRAINT TYPES & RULES
// ============================================================================

/**
 * STACKABLE CONSTRAINTS
 */
interface StackableConstraint {
  isStackable: boolean;
  maxStackHeight: number; // cm - maximum total height if stacked
  maxItemsOnTop: number; // max items can be placed on top
  minWeightBearing: number; // kg - minimum weight it can bear without damage
  maxWeightBearing: number; // kg - maximum weight it can bear
  requiresFlatBase: boolean; // Must be on ground/flat surface
  cannotBeStacked: 'NEVER' | 'FRAGILE_ONLY' | 'ALWAYS'; // When cannot be stacked
  stackingOrientationRequired?: 'UPRIGHT' | 'HORIZONTAL' | 'ANY';
}

/**
 * CONSOLIDATION LEVEL CONSTRAINTS (1=Highest, 5=Lowest)
 * Level 1: Priority consolidation - must be together
 * Level 2: High consolidation - should be together
 * Level 3: Normal consolidation - try to group
 * Level 4: Low consolidation - can separate
 * Level 5: No consolidation - can scatter
 */
interface ConsolidationLevelConstraint {
  level: number; // 1-5
  mustBeInSameCompartment: boolean; // Level 1-2: true, Level 3-5: false
  maxDistanceBetweenItems: number; // cm - within same compartment
  sameVehicleRequired: boolean; // Level 1-2: true
  consolidationTolerance: number; // % - how strict the consolidation is
}

/**
 * GROUPING CONSTRAINTS
 */
interface GroupingConstraint {
  groupId: string;
  groupName: string;
  groupType: 'CUSTOMER' | 'SUPPLIER' | 'DESTINATION' | 'PRODUCT_LINE' | 'CUSTOM';
  mustStayTogether: boolean; // true = must be in same compartment
  canBeSeparated: boolean; // false = cannot separate
  preferredCompartment?: string;
  itemsInGroup: string[]; // Item SKUs in this group
}

/**
 * ITEM WITH ALL CONSTRAINTS
 */
interface ConstrainedItem {
  id: string;
  sku: string;
  description: string;
  
  // Basic properties
  weight: number;
  length: number;
  width: number;
  height: number;
  quantity: number;
  volume: number; // calculated
  
  // Stackable constraints
  stackable: StackableConstraint;
  
  // Consolidation constraints
  consolidation: ConsolidationLevelConstraint;
  
  // Grouping constraints
  grouping: GroupingConstraint;
  
  // Environmental constraints
  fragile: boolean;
  hazmat: boolean;
  requiresCooling: boolean;
  temperatureRange?: { min: number; max: number };
  requiresDrying: boolean;
  humidityRange?: { min: number; max: number };
  
  // Custom constraints
  customConstraints?: Record<string, any>;
}

/**
 * CONSTRAINT VIOLATION
 */
interface ConstraintViolation {
  type: 'STACKABLE' | 'CONSOLIDATION' | 'GROUPING' | 'ENVIRONMENTAL';
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  message: string;
  itemId: string;
  affectedItems: string[];
  resolution?: string;
}

// ============================================================================
// CONSTRAINT ENGINE
// ============================================================================

@Injectable()
export class ConstraintEngineService {
  /**
   * Validate all constraints for items
   */
  validateConstraints(items: ConstrainedItem[]): ConstraintViolation[] {
    const violations: ConstraintViolation[] = [];

    // 1. Validate stackable constraints
    violations.push(...this.validateStackableConstraints(items));

    // 2. Validate consolidation level constraints
    violations.push(...this.validateConsolidationConstraints(items));

    // 3. Validate grouping constraints
    violations.push(...this.validateGroupingConstraints(items));

    // 4. Validate environmental constraints
    violations.push(...this.validateEnvironmentalConstraints(items));

    return violations;
  }

  /**
   * STACKABLE CONSTRAINT VALIDATION
   */
  private validateStackableConstraints(items: ConstrainedItem[]): ConstraintViolation[] {
    const violations: ConstraintViolation[] = [];

    for (const item of items) {
      const sc = item.stackable;

      // Rule 1: Non-stackable items
      if (!sc.isStackable && items.some((i) => i.id !== item.id && this.canStack(i, item))) {
        violations.push({
          type: 'STACKABLE',
          severity: 'WARNING',
          message: `Item ${item.sku} is non-stackable but other items might be stacked on it`,
          itemId: item.id,
          affectedItems: [],
          resolution: 'Place non-stackable items on top level or use dedicated compartment',
        });
      }

      // Rule 2: Fragile items cannot have anything on top
      if (item.fragile && sc.cannotBeStacked === 'NEVER') {
        const itemsThatCouldStack = items.filter(
          (i) =>
            i.id !== item.id &&
            i.stackable.isStackable &&
            !i.fragile &&
            this.canStack(i, item),
        );

        if (itemsThatCouldStack.length > 0) {
          violations.push({
            type: 'STACKABLE',
            severity: 'CRITICAL',
            message: `Fragile item ${item.sku} cannot have anything on top`,
            itemId: item.id,
            affectedItems: itemsThatCouldStack.map((i) => i.id),
            resolution: 'Place fragile items on top layer',
          });
        }
      }

      // Rule 3: Weight bearing capacity
      if (sc.maxWeightBearing > 0) {
        const potentialLoad = items
          .filter((i) => i.id !== item.id && this.canStack(i, item))
          .reduce((sum, i) => sum + i.weight * i.quantity, 0);

        if (potentialLoad > sc.maxWeightBearing) {
          violations.push({
            type: 'STACKABLE',
            severity: 'CRITICAL',
            message: `Item ${item.sku} weight bearing exceeded (max: ${sc.maxWeightBearing}kg, potential: ${potentialLoad}kg)`,
            itemId: item.id,
            affectedItems: [],
            resolution: 'Reduce items stacked on top or use stronger base items',
          });
        }
      }

      // Rule 4: Max items on top
      if (sc.maxItemsOnTop > 0 && sc.maxItemsOnTop < 3) {
        const itemsThatCouldStack = items.filter(
          (i) => i.id !== item.id && this.canStack(i, item),
        );

        if (itemsThatCouldStack.length > sc.maxItemsOnTop) {
          violations.push({
            type: 'STACKABLE',
            severity: 'WARNING',
            message: `Item ${item.sku} can only have max ${sc.maxItemsOnTop} items on top (found ${itemsThatCouldStack.length})`,
            itemId: item.id,
            affectedItems: itemsThatCouldStack.map((i) => i.id),
            resolution: `Distribute items across multiple stacks (max ${sc.maxItemsOnTop}/stack)`,
          });
        }
      }

      // Rule 5: Max stack height
      if (sc.maxStackHeight > 0) {
        const stackHeight = item.height + this.calculatePotentialStackHeight(item, items);

        if (stackHeight > sc.maxStackHeight) {
          violations.push({
            type: 'STACKABLE',
            severity: 'WARNING',
            message: `Stack height exceeded for ${item.sku} (max: ${sc.maxStackHeight}cm, calculated: ${stackHeight}cm)`,
            itemId: item.id,
            affectedItems: [],
            resolution: 'Reduce number of items in stack',
          });
        }
      }
    }

    return violations;
  }

  /**
   * CONSOLIDATION LEVEL CONSTRAINT VALIDATION
   */
  private validateConsolidationConstraints(items: ConstrainedItem[]): ConstraintViolation[] {
    const violations: ConstraintViolation[] = [];

    // Group items by consolidation level
    const byLevel = new Map<number, ConstrainedItem[]>();
    for (const item of items) {
      const level = item.consolidation.level;
      if (!byLevel.has(level)) byLevel.set(level, []);
      byLevel.get(level)!.push(item);
    }

    for (const [level, levelItems] of byLevel.entries()) {
      // Rule 1: Level 1-2 items MUST be in same compartment
      if (level <= 2 && levelItems.length > 1) {
        if (levelItems.some((i) => i.consolidation.mustBeInSameCompartment)) {
          violations.push({
            type: 'CONSOLIDATION',
            severity: 'CRITICAL',
            message: `Level ${level} items MUST be in same compartment (${levelItems.length} items found)`,
            itemId: levelItems[0].id,
            affectedItems: levelItems.map((i) => i.id),
            resolution: `Ensure all level ${level} items are placed in same compartment`,
          });
        }
      }

      // Rule 2: Level 3 items should be grouped
      if (level === 3 && levelItems.length > 1) {
        violations.push({
          type: 'CONSOLIDATION',
          severity: 'INFO',
          message: `Level ${level} items should be grouped together (${levelItems.length} items)`,
          itemId: levelItems[0].id,
          affectedItems: levelItems.map((i) => i.id),
          resolution: 'Try to place level 3 items in same compartment',
        });
      }

      // Rule 3: Level 1 items same vehicle
      if (level === 1 && levelItems.some((i) => i.consolidation.sameVehicleRequired)) {
        violations.push({
          type: 'CONSOLIDATION',
          severity: 'CRITICAL',
          message: `Level 1 items MUST be in same vehicle (${levelItems.length} items)`,
          itemId: levelItems[0].id,
          affectedItems: levelItems.map((i) => i.id),
          resolution: 'Allocate all level 1 items to same vehicle',
        });
      }

      // Rule 4: Check consolidation tolerance
      for (const item of levelItems) {
        const tolerance = item.consolidation.consolidationTolerance;
        if (tolerance > 90) {
          // Strict consolidation
          const sameLevel = levelItems.filter((i) => i.id !== item.id);
          if (sameLevel.length === 0) {
            violations.push({
              type: 'CONSOLIDATION',
              severity: 'WARNING',
              message: `Item ${item.sku} has strict consolidation (${tolerance}%) but no other level ${level} items`,
              itemId: item.id,
              affectedItems: [],
              resolution: `Find or create group with other level ${level} items`,
            });
          }
        }
      }
    }

    return violations;
  }

  /**
   * GROUPING CONSTRAINT VALIDATION
   */
  private validateGroupingConstraints(items: ConstrainedItem[]): ConstraintViolation[] {
    const violations: ConstraintViolation[] = [];

    // Group items by groupId
    const byGroup = new Map<string, ConstrainedItem[]>();
    for (const item of items) {
      const groupId = item.grouping.groupId;
      if (!byGroup.has(groupId)) byGroup.set(groupId, []);
      byGroup.get(groupId)!.push(item);
    }

    for (const [groupId, groupItems] of byGroup.entries()) {
      const groupConstraint = groupItems[0].grouping;

      // Rule 1: Must stay together
      if (groupConstraint.mustStayTogether && groupItems.length > 1) {
        violations.push({
          type: 'GROUPING',
          severity: 'CRITICAL',
          message: `Group ${groupId} (${groupConstraint.groupName}) MUST stay together (${groupItems.length} items)`,
          itemId: groupItems[0].id,
          affectedItems: groupItems.map((i) => i.id),
          resolution: `Place all items from ${groupId} in same compartment`,
        });
      }

      // Rule 2: Cannot be separated
      if (!groupConstraint.canBeSeparated && groupItems.length > 1) {
        violations.push({
          type: 'GROUPING',
          severity: 'CRITICAL',
          message: `Group ${groupId} CANNOT be separated (${groupItems.length} items)`,
          itemId: groupItems[0].id,
          affectedItems: groupItems.map((i) => i.id),
          resolution: `Pack all items from ${groupId} together in one location`,
        });
      }

      // Rule 3: Preferred compartment
      if (groupConstraint.preferredCompartment) {
        violations.push({
          type: 'GROUPING',
          severity: 'INFO',
          message: `Group ${groupId} prefers compartment ${groupConstraint.preferredCompartment}`,
          itemId: groupItems[0].id,
          affectedItems: groupItems.map((i) => i.id),
          resolution: `Try to place group ${groupId} in preferred compartment`,
        });
      }

      // Rule 4: Max distance between items in group
      if (groupItems.length > 1) {
        const maxDistance = 500; // 5 meters within same compartment
        violations.push({
          type: 'GROUPING',
          severity: 'INFO',
          message: `Group ${groupId} items should be within ${maxDistance}cm of each other`,
          itemId: groupItems[0].id,
          affectedItems: groupItems.map((i) => i.id),
          resolution: `Keep group items close together in compartment`,
        });
      }
    }

    return violations;
  }

  /**
   * ENVIRONMENTAL CONSTRAINT VALIDATION
   */
  private validateEnvironmentalConstraints(items: ConstrainedItem[]): ConstraintViolation[] {
    const violations: ConstraintViolation[] = [];

    const hazmatItems = items.filter((i) => i.hazmat);
    const cooledItems = items.filter((i) => i.requiresCooling);
    const driedItems = items.filter((i) => i.requiresDrying);

    if (hazmatItems.length > 0) {
      violations.push({
        type: 'ENVIRONMENTAL',
        severity: 'CRITICAL',
        message: `${hazmatItems.length} hazmat items require dedicated HAZMAT compartment`,
        itemId: hazmatItems[0].id,
        affectedItems: hazmatItems.map((i) => i.id),
        resolution: 'Allocate HAZMAT compartment for these items',
      });
    }

    if (cooledItems.length > 0) {
      violations.push({
        type: 'ENVIRONMENTAL',
        severity: 'CRITICAL',
        message: `${cooledItems.length} items require cooling (${cooledItems[0].temperatureRange?.min}°C - ${cooledItems[0].temperatureRange?.max}°C)`,
        itemId: cooledItems[0].id,
        affectedItems: cooledItems.map((i) => i.id),
        resolution: 'Use vehicle with cooling capability',
      });
    }

    if (driedItems.length > 0) {
      violations.push({
        type: 'ENVIRONMENTAL',
        severity: 'CRITICAL',
        message: `${driedItems.length} items require drying (humidity < ${driedItems[0].humidityRange?.max}%)`,
        itemId: driedItems[0].id,
        affectedItems: driedItems.map((i) => i.id),
        resolution: 'Use vehicle with drying capability',
      });
    }

    return violations;
  }

  /**
   * Check if item can be stacked on another
   */
  private canStack(itemToStack: ConstrainedItem, baseItem: ConstrainedItem): boolean {
    // Both must be stackable
    if (!itemToStack.stackable.isStackable || !baseItem.stackable.isStackable) {
      return false;
    }

    // Cannot stack on fragile items
    if (baseItem.fragile) {
      return false;
    }

    // Weight bearing check
    if (
      baseItem.stackable.maxWeightBearing > 0 &&
      itemToStack.weight > baseItem.stackable.maxWeightBearing
    ) {
      return false;
    }

    // Cannot stack fragile on anything (fragile items must be on top)
    if (itemToStack.fragile) {
      return false;
    }

    return true;
  }

  /**
   * Calculate potential stack height
   */
  private calculatePotentialStackHeight(item: ConstrainedItem, items: ConstrainedItem[]): number {
    const itemsThatCouldStack = items.filter((i) => i.id !== item.id && this.canStack(i, item));
    return itemsThatCouldStack.reduce((height, i) => height + i.height, 0);
  }

  /**
   * CONSTRAINT CONFLICT RESOLUTION
   */
  resolveConflicts(violations: ConstraintViolation[]): ConstraintViolation[] {
    const critical = violations.filter((v) => v.severity === 'CRITICAL');
    const warnings = violations.filter((v) => v.severity === 'WARNING');
    const infos = violations.filter((v) => v.severity === 'INFO');

    console.log(`\n🔴 CRITICAL Violations: ${critical.length}`);
    console.log(`🟡 WARNING Violations: ${warnings.length}`);
    console.log(`🔵 INFO Violations: ${infos.length}`);

    return [...critical, ...warnings, ...infos];
  }

  /**
   * Generate constraint report
   */
  generateConstraintReport(violations: ConstraintViolation[]): string {
    let report = `
╔════════════════════════════════════════════════════════════════╗
║             CONSTRAINT VALIDATION REPORT                       ║
╚════════════════════════════════════════════════════════════════╝

VIOLATIONS BY SEVERITY:
`;

    const bySeverity = new Map<string, ConstraintViolation[]>();
    for (const v of violations) {
      if (!bySeverity.has(v.severity)) bySeverity.set(v.severity, []);
      bySeverity.get(v.severity)!.push(v);
    }

    for (const [severity, viols] of bySeverity.entries()) {
      report += `\n${severity} (${viols.length}):\n`;
      for (const v of viols) {
        report += `  ├─ ${v.type}: ${v.message}\n`;
        if (v.resolution) {
          report += `  │  Resolution: ${v.resolution}\n`;
        }
      }
    }

    report += `

VIOLATIONS BY TYPE:
`;

    const byType = new Map<string, ConstraintViolation[]>();
    for (const v of violations) {
      if (!byType.has(v.type)) byType.set(v.type, []);
      byType.get(v.type)!.push(v);
    }

    for (const [type, viols] of byType.entries()) {
      report += `\n${type} (${viols.length} violations)\n`;
      for (const v of viols) {
        report += `  ├─ ${v.severity}: ${v.message}\n`;
      }
    }

    return report;
  }
}

// ============================================================================
// INTELLIGENT PACKING WITH CONSTRAINT SATISFACTION
// ============================================================================

@Injectable()
export class ConstraintAwarePacking Service {
  constructor(private constraintEngine: ConstraintEngineService) {}

  /**
   * Pack items respecting all constraints
   */
  async packWithConstraints(
    items: ConstrainedItem[],
    vehicle: any,
  ): Promise<{ placedItems: any[]; violations: any[]; score: number }> {
    // Validate constraints first
    const violations = this.constraintEngine.validateConstraints(items);

    // Sort items considering constraints
    const sortedItems = this.sortByConstraintPriority(items);

    // Place items with constraint satisfaction
    const placedItems = [];
    let score = 100;

    for (const item of sortedItems) {
      const placement = this.findBestPlacementRespectingConstraints(
        item,
        vehicle,
        placedItems,
      );

      if (placement) {
        placedItems.push(placement);
      } else {
        score -= 10; // Penalty for failed placement
        violations.push({
          type: 'PLACEMENT',
          severity: 'WARNING',
          message: `Could not find suitable placement for ${item.sku}`,
          itemId: item.id,
          affectedItems: [],
        });
      }
    }

    return {
      placedItems,
      violations: this.constraintEngine.resolveConflicts(violations),
      score: Math.max(0, score),
    };
  }

  /**
   * Sort items by constraint priority
   */
  private sortByConstraintPriority(items: ConstrainedItem[]): ConstrainedItem[] {
    return [...items].sort((a, b) => {
      // Priority 1: Consolidation level (lower = higher priority)
      if (a.consolidation.level !== b.consolidation.level) {
        return a.consolidation.level - b.consolidation.level;
      }

      // Priority 2: Must stay together (forced grouping)
      if (a.grouping.mustStayTogether !== b.grouping.mustStayTogether) {
        return a.grouping.mustStayTogether ? -1 : 1;
      }

      // Priority 3: Cannot be separated
      if (a.grouping.canBeSeparated !== b.grouping.canBeSeparated) {
        return !a.grouping.canBeSeparated ? -1 : 1;
      }

      // Priority 4: Fragile items (place on top layer)
      if (a.fragile !== b.fragile) {
        return a.fragile ? 1 : -1;
      }

      // Priority 5: Volume (largest first)
      return b.volume - a.volume;
    });
  }

  /**
   * Find best placement respecting all constraints
   */
  private findBestPlacementRespectingConstraints(
    item: ConstrainedItem,
    vehicle: any,
    placedItems: any[],
  ): any | null {
    // Implementation would check:
    // 1. Grouping constraints
    // 2. Stackable constraints
    // 3. Consolidation level constraints
    // 4. Environmental constraints

    return null; // Placeholder
  }
}

// src/loading/constraint-types.ts - Export all constraint types
export {
  StackableConstraint,
  ConsolidationLevelConstraint,
  GroupingConstraint,
  ConstrainedItem,
  ConstraintViolation,
};

// Example usage in controller
import { Controller, Post, Body, UseGuards } from '@nestjs/common';

@Controller('loading-plans/constraints')
@UseGuards(JwtAuthGuard)
export class ConstraintLoadingPlanController {
  constructor(
    private constraintEngine: ConstraintEngineService,
    private constraintPacking: ConstraintAwarePackingService,
  ) {}

  @Post('validate')
  validateConstraints(@Body() dto: { items: ConstrainedItem[] }) {
    const violations = this.constraintEngine.validateConstraints(dto.items);
    const report = this.constraintEngine.generateConstraintReport(violations);
    
    return {
      violations: violations.length,
      critical: violations.filter((v) => v.severity === 'CRITICAL').length,
      warnings: violations.filter((v) => v.severity === 'WARNING').length,
      details: violations,
      report,
    };
  }

  @Post('pack')
  async packWithConstraints(@Body() dto: { items: ConstrainedItem[]; vehicle: any }) {
    const result = await this.constraintPacking.packWithConstraints(
      dto.items,
      dto.vehicle,
    );

    return result;
  }
}
