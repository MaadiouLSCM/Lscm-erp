#!/bin/bash
# aws/deploy-to-aws.sh - Complete AWS Deployment Script

set -e

# ============================================================================
# AWS DEPLOYMENT SCRIPT - LSCM ERP SYSTEM
# ============================================================================
# This script deploys the complete LSCM ERP system to AWS
# Components: ECS Fargate, RDS PostgreSQL, ElastiCache Redis, ALB, CloudFront

# Configuration
AWS_REGION=${AWS_REGION:-"us-east-1"}
AWS_ACCOUNT_ID=${AWS_ACCOUNT_ID:-"123456789012"}
ECR_REGISTRY="$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com"
APP_NAME="lscm-erp"
ENVIRONMENT=${ENVIRONMENT:-"production"}
IMAGE_TAG=${IMAGE_TAG:-"latest"}

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# ============================================================================
# FUNCTIONS
# ============================================================================

log_section() {
    echo ""
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}║ $1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
}

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# Check AWS CLI
check_aws_cli() {
    if ! command -v aws &> /dev/null; then
        log_error "AWS CLI not installed"
        exit 1
    fi
    
    # Check credentials
    if ! aws sts get-caller-identity > /dev/null 2>&1; then
        log_error "AWS credentials not configured"
        exit 1
    fi
    
    log_info "AWS CLI configured for account: $AWS_ACCOUNT_ID"
}

# Create ECR repository
create_ecr_repo() {
    log_section "Creating ECR Repository"
    
    if aws ecr describe-repositories \
        --repository-names "$APP_NAME-backend" \
        --region "$AWS_REGION" > /dev/null 2>&1; then
        log_info "ECR repository already exists"
    else
        log_info "Creating ECR repository..."
        aws ecr create-repository \
            --repository-name "$APP_NAME-backend" \
            --region "$AWS_REGION" \
            --image-scanning-configuration scanOnPush=true \
            --encryption-configuration encryptionType=AES
        
        log_info "ECR repository created"
    fi
}

# Build and push Docker image
build_and_push_image() {
    log_section "Building and Pushing Docker Image"
    
    # Login to ECR
    log_info "Logging into ECR..."
    aws ecr get-login-password --region "$AWS_REGION" | \
        docker login --username AWS --password-stdin "$ECR_REGISTRY"
    
    # Build image
    log_info "Building Docker image..."
    docker build -t "$APP_NAME:$IMAGE_TAG" .
    
    # Tag image
    log_info "Tagging image..."
    docker tag "$APP_NAME:$IMAGE_TAG" "$ECR_REGISTRY/$APP_NAME-backend:$IMAGE_TAG"
    docker tag "$APP_NAME:$IMAGE_TAG" "$ECR_REGISTRY/$APP_NAME-backend:latest"
    
    # Push image
    log_info "Pushing image to ECR..."
    docker push "$ECR_REGISTRY/$APP_NAME-backend:$IMAGE_TAG"
    docker push "$ECR_REGISTRY/$APP_NAME-backend:latest"
    
    log_info "Image pushed successfully"
}

# Create RDS PostgreSQL database
create_rds_database() {
    log_section "Creating RDS PostgreSQL Database"
    
    DB_INSTANCE_ID="$APP_NAME-postgres"
    
    if aws rds describe-db-instances \
        --db-instance-identifier "$DB_INSTANCE_ID" \
        --region "$AWS_REGION" > /dev/null 2>&1; then
        log_info "RDS instance already exists"
    else
        log_info "Creating RDS PostgreSQL instance..."
        
        aws rds create-db-instance \
            --db-instance-identifier "$DB_INSTANCE_ID" \
            --db-instance-class db.t3.small \
            --engine postgres \
            --engine-version 15.4 \
            --allocated-storage 100 \
            --storage-type gp3 \
            --storage-encrypted \
            --master-username lscm_admin \
            --master-user-password "$(openssl rand -base64 32)" \
            --db-name lscm_erp \
            --vpc-security-group-ids "sg-xxxxxxxx" \
            --db-subnet-group-name "$APP_NAME-subnet-group" \
            --backup-retention-period 30 \
            --multi-az \
            --enable-cloudwatch-logs-exports postgresql \
            --enable-iam-database-authentication \
            --region "$AWS_REGION"
        
        log_info "RDS instance created (wait 10-15 minutes for availability)"
    fi
    
    # Get RDS endpoint
    RDS_ENDPOINT=$(aws rds describe-db-instances \
        --db-instance-identifier "$DB_INSTANCE_ID" \
        --region "$AWS_REGION" \
        --query 'DBInstances[0].Endpoint.Address' \
        --output text)
    
    echo "$RDS_ENDPOINT"
}

# Create ElastiCache Redis cluster
create_elasticache_redis() {
    log_section "Creating ElastiCache Redis Cluster"
    
    CACHE_CLUSTER_ID="$APP_NAME-redis"
    
    if aws elasticache describe-cache-clusters \
        --cache-cluster-id "$CACHE_CLUSTER_ID" \
        --region "$AWS_REGION" > /dev/null 2>&1; then
        log_info "ElastiCache cluster already exists"
    else
        log_info "Creating ElastiCache Redis cluster..."
        
        aws elasticache create-cache-cluster \
            --cache-cluster-id "$CACHE_CLUSTER_ID" \
            --cache-node-type cache.t3.small \
            --engine redis \
            --engine-version 7.0 \
            --num-cache-nodes 1 \
            --cache-parameter-group-name default.redis7 \
            --cache-subnet-group-name "$APP_NAME-subnet-group" \
            --vpc-security-group-ids "sg-xxxxxxxx" \
            --at-rest-encryption-enabled \
            --transit-encryption-enabled \
            --auth-token "$(openssl rand -base64 32)" \
            --auto-failover-enabled \
            --region "$AWS_REGION"
        
        log_info "ElastiCache cluster created (wait 5-10 minutes for availability)"
    fi
    
    # Get Redis endpoint
    REDIS_ENDPOINT=$(aws elasticache describe-cache-clusters \
        --cache-cluster-id "$CACHE_CLUSTER_ID" \
        --region "$AWS_REGION" \
        --query 'CacheClusters[0].CacheNodes[0].Endpoint.Address' \
        --output text)
    
    echo "$REDIS_ENDPOINT"
}

# Create ECS cluster
create_ecs_cluster() {
    log_section "Creating ECS Cluster"
    
    CLUSTER_NAME="$APP_NAME-cluster"
    
    if aws ecs describe-clusters \
        --clusters "$CLUSTER_NAME" \
        --region "$AWS_REGION" | grep -q "$CLUSTER_NAME"; then
        log_info "ECS cluster already exists"
    else
        log_info "Creating ECS cluster..."
        
        aws ecs create-cluster \
            --cluster-name "$CLUSTER_NAME" \
            --cluster-settings name=containerInsights,value=enabled \
            --region "$AWS_REGION"
        
        log_info "ECS cluster created"
    fi
    
    echo "$CLUSTER_NAME"
}

# Create ECS task definition
create_task_definition() {
    log_section "Creating ECS Task Definition"
    
    RDS_ENDPOINT=$1
    REDIS_ENDPOINT=$2
    
    cat > /tmp/task-definition.json << EOF
{
  "family": "$APP_NAME-backend",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512",
  "memory": "1024",
  "containerDefinitions": [
    {
      "name": "$APP_NAME-backend",
      "image": "$ECR_REGISTRY/$APP_NAME-backend:latest",
      "portMappings": [
        {
          "containerPort": 3000,
          "hostPort": 3000,
          "protocol": "tcp"
        }
      ],
      "essential": true,
      "environment": [
        {
          "name": "NODE_ENV",
          "value": "production"
        },
        {
          "name": "PORT",
          "value": "3000"
        },
        {
          "name": "DATABASE_HOST",
          "value": "$RDS_ENDPOINT"
        },
        {
          "name": "REDIS_HOST",
          "value": "$REDIS_ENDPOINT"
        }
      ],
      "secrets": [
        {
          "name": "DATABASE_PASSWORD",
          "valueFrom": "arn:aws:secretsmanager:$AWS_REGION:$AWS_ACCOUNT_ID:secret:$APP_NAME/db-password"
        },
        {
          "name": "JWT_SECRET",
          "valueFrom": "arn:aws:secretsmanager:$AWS_REGION:$AWS_ACCOUNT_ID:secret:$APP_NAME/jwt-secret"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/$APP_NAME",
          "awslogs-region": "$AWS_REGION",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ]
}
EOF
    
    log_info "Registering task definition..."
    
    aws ecs register-task-definition \
        --cli-input-json file:///tmp/task-definition.json \
        --region "$AWS_REGION"
    
    log_info "Task definition registered"
}

# Create ECS service
create_ecs_service() {
    log_section "Creating ECS Service"
    
    CLUSTER_NAME=$1
    SERVICE_NAME="$APP_NAME-service"
    
    if aws ecs describe-services \
        --cluster "$CLUSTER_NAME" \
        --services "$SERVICE_NAME" \
        --region "$AWS_REGION" | grep -q "$SERVICE_NAME"; then
        log_info "ECS service already exists"
    else
        log_info "Creating ECS service..."
        
        aws ecs create-service \
            --cluster "$CLUSTER_NAME" \
            --service-name "$SERVICE_NAME" \
            --task-definition "$APP_NAME-backend" \
            --desired-count 2 \
            --launch-type FARGATE \
            --network-configuration "awsvpcConfiguration={subnets=[subnet-xxxxx,subnet-yyyyy],securityGroups=[sg-zzzzz],assignPublicIp=ENABLED}" \
            --load-balancers "targetGroupArn=arn:aws:elasticloadbalancing:$AWS_REGION:$AWS_ACCOUNT_ID:targetgroup/$APP_NAME-backend/xxxxx,containerName=$APP_NAME-backend,containerPort=3000" \
            --enable-ecs-managed-tags \
            --region "$AWS_REGION"
        
        log_info "ECS service created"
    fi
}

# Create ALB (Application Load Balancer)
create_alb() {
    log_section "Creating Application Load Balancer"
    
    ALB_NAME="$APP_NAME-alb"
    
    if aws elbv2 describe-load-balancers \
        --names "$ALB_NAME" \
        --region "$AWS_REGION" > /dev/null 2>&1; then
        log_info "ALB already exists"
    else
        log_info "Creating ALB..."
        
        aws elbv2 create-load-balancer \
            --name "$ALB_NAME" \
            --subnets subnet-xxxxx subnet-yyyyy \
            --security-groups sg-zzzzz \
            --scheme internet-facing \
            --type application \
            --ip-address-type ipv4 \
            --region "$AWS_REGION"
        
        log_info "ALB created"
    fi
}

# Setup CloudFront distribution
setup_cloudfront() {
    log_section "Setting up CloudFront Distribution"
    
    log_info "Creating CloudFront distribution..."
    
    cat > /tmp/cloudfront-config.json << EOF
{
  "CallerReference": "$(date +%s)",
  "Comment": "$APP_NAME CloudFront Distribution",
  "DefaultCacheBehavior": {
    "TargetOriginId": "ALBOrigin",
    "ViewerProtocolPolicy": "redirect-to-https",
    "AllowedMethods": ["GET", "HEAD", "OPTIONS", "PUT", "POST", "PATCH", "DELETE"],
    "CachePolicyId": "658327ea-f89d-4fab-a63d-7e88639e58f6",
    "OriginRequestPolicyId": "216adef5-5c7f-47e4-b989-5492eafa07d3"
  },
  "Origins": [
    {
      "Id": "ALBOrigin",
      "DomainName": "lscm-erp-alb-xxxxx.us-east-1.elb.amazonaws.com",
      "CustomOriginConfig": {
        "HTTPPort": 80,
        "HTTPSPort": 443,
        "OriginProtocolPolicy": "http-only"
      }
    }
  ],
  "Enabled": true,
  "HttpVersion": "http2and3"
}
EOF
    
    aws cloudfront create-distribution \
        --distribution-config file:///tmp/cloudfront-config.json \
        --region "$AWS_REGION"
    
    log_info "CloudFront distribution created"
}

# Setup CloudWatch monitoring
setup_cloudwatch() {
    log_section "Setting up CloudWatch Monitoring"
    
    log_info "Creating CloudWatch log groups..."
    
    aws logs create-log-group \
        --log-group-name "/ecs/$APP_NAME" \
        --region "$AWS_REGION" 2>/dev/null || true
    
    log_info "Creating CloudWatch alarms..."
    
    # High CPU alarm
    aws cloudwatch put-metric-alarm \
        --alarm-name "$APP_NAME-high-cpu" \
        --alarm-description "Alert when CPU exceeds 80%" \
        --metric-name CPUUtilization \
        --namespace AWS/ECS \
        --statistic Average \
        --period 300 \
        --threshold 80 \
        --comparison-operator GreaterThanThreshold \
        --evaluation-periods 2 \
        --region "$AWS_REGION"
    
    log_info "CloudWatch alarms created"
}

# ============================================================================
# MAIN EXECUTION
# ============================================================================

main() {
    clear
    
    echo -e "${GREEN}"
    cat << "EOF"
╔═══════════════════════════════════════════════════════════╗
║         LSCM ERP - AWS DEPLOYMENT SCRIPT                 ║
║    Complete deployment to AWS (ECS, RDS, ElastiCache)    ║
╚═══════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    
    echo ""
    echo "AWS Region: $AWS_REGION"
    echo "Account ID: $AWS_ACCOUNT_ID"
    echo "App Name: $APP_NAME"
    echo "Environment: $ENVIRONMENT"
    echo ""
    
    # Pre-flight checks
    log_section "Pre-Flight Checks"
    check_aws_cli
    
    # Step 1: Create ECR
    create_ecr_repo
    
    # Step 2: Build and push image
    build_and_push_image
    
    # Step 3: Create RDS
    RDS_ENDPOINT=$(create_rds_database)
    log_info "RDS Endpoint: $RDS_ENDPOINT"
    
    # Step 4: Create ElastiCache
    REDIS_ENDPOINT=$(create_elasticache_redis)
    log_info "Redis Endpoint: $REDIS_ENDPOINT"
    
    # Step 5: Create ECS Cluster
    CLUSTER_NAME=$(create_ecs_cluster)
    
    # Step 6: Create task definition
    create_task_definition "$RDS_ENDPOINT" "$REDIS_ENDPOINT"
    
    # Step 7: Create ALB
    create_alb
    
    # Step 8: Create ECS Service
    create_ecs_service "$CLUSTER_NAME"
    
    # Step 9: Setup CloudFront
    setup_cloudfront
    
    # Step 10: Setup CloudWatch
    setup_cloudwatch
    
    # Completion
    log_section "Deployment Complete!"
    
    echo -e "${GREEN}✅ AWS deployment successful!${NC}"
    echo ""
    echo "Next steps:"
    echo "  1. Configure domain DNS to CloudFront distribution"
    echo "  2. Monitor deployment in AWS Console"
    echo "  3. Run health checks: ./scripts/test-aws-health.sh"
    echo "  4. View logs: aws logs tail /ecs/$APP_NAME --follow"
    echo ""
}

# Error handling
trap 'log_error "Deployment failed at line $LINENO"' ERR

# Run main
main "$@"
