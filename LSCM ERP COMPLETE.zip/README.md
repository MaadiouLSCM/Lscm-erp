# 🏗️ LSCM ERP - Complete System

**Logistics & Supply Chain Management Enterprise Resource Planning**

Production-ready backend for LSCM's order management, customs handling, and financial operations.

---

## 📋 Table of Contents

1. [Quick Start](#quick-start)
2. [Architecture](#architecture)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [Running the Application](#running-the-application)
6. [Database Setup](#database-setup)
7. [API Documentation](#api-documentation)
8. [Integration Guides](#integration-guides)
9. [Deployment](#deployment)
10. [Troubleshooting](#troubleshooting)

---

## 🚀 Quick Start

### Prerequisites

- Node.js 20+
- Docker & Docker Compose
- PostgreSQL 15+ (or use Docker)
- Git

### 30-Second Setup

```bash
# 1. Clone repository
git clone <repo-url>
cd lscm-erp

# 2. Install dependencies
npm install

# 3. Setup environment
cp .env.example .env
# Edit .env with your configuration

# 4. Start Docker containers
docker-compose up -d

# 5. Run migrations & seed data
npx prisma migrate dev
npx prisma db seed

# 6. Start backend
npm run start:dev

# 7. Visit API docs
open http://localhost:3000/api/docs
```

---

## 🏛️ Architecture

```
┌─────────────────────────────────────┐
│     LSCM ERP Backend (NestJS)       │
├─────────────────────────────────────┤
│   10 Core Modules                   │
│  ├─ Orders (Shipment lifecycle)     │
│  ├─ Documents (RFC, JEP, SM, etc)   │
│  ├─ Pickup (POC, hub reception)     │
│  ├─ Customs (GL 3-party gate)       │
│  ├─ Transport (Booking, tracking)   │
│  ├─ Invoice (VAT 7.5%, payments)    │
│  ├─ Reporting (DSR, WSR, JCR)       │
│  ├─ Integrations (CLEAR, SAP, Bank) │
│  ├─ Auth (JWT, RBAC)                │
│  └─ Audit (Logging, compliance)     │
└─────────────────────────────────────┘
         │        │        │
    ┌────▼─────┬──▼────┬───▼────┐
    │ PostgreSQL │ Redis  │ S3      │
    │ (Data)     │(Cache) │(Files)  │
    └────────────┴────────┴─────────┘
         │        │        │
    ┌────▼─────┬──▼────┬───▼────────┐
    │  CLEAR   │ SAP   │ Carriers   │
    │  API     │ BW    │(TK, MSC,   │
    │          │       │ FedEx)     │
    └──────────┴───────┴────────────┘
```

**Tech Stack:**
- **Runtime:** Node.js 20 LTS
- **Framework:** NestJS 10 (TypeScript)
- **ORM:** Prisma 5
- **Database:** PostgreSQL 15
- **Cache:** Redis 7
- **Task Scheduling:** node-cron
- **PDF Generation:** PDFKit
- **QR Codes:** QRCode.js
- **Testing:** Jest + Supertest
- **Containerization:** Docker + Compose

---

## 📥 Installation

### 1. Clone Repository

```bash
git clone https://github.com/lscm/erp-backend.git
cd erp-backend
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Generate Prisma Client

```bash
npx prisma generate
```

### 4. Create Environment File

```bash
cp .env.example .env
# Edit .env with your settings
```

---

## ⚙️ Configuration

### Essential Variables

```bash
# Database
DATABASE_URL=postgresql://user:password@localhost:5432/lscm_erp

# JWT Authentication
JWT_SECRET=your-super-secret-key-min-32-chars

# CORS
CORS_ORIGIN=http://localhost:3000,http://localhost:3001

# Integrations
CLEAR_API_KEY=your-clear-api-key
SAP_BW_API_TOKEN=your-sap-token
ACCESS_BANK_API_KEY=your-bank-key

# Email (SendGrid)
SENDGRID_API_KEY=your-sendgrid-key
```

### Database Connection String Format

```
postgresql://[user]:[password]@[host]:[port]/[database]?schema=[schema]
```

---

## 🏃 Running the Application

### Development Mode (Watch)

```bash
npm run start:dev
```

Server runs on `http://localhost:3000`  
API Docs: `http://localhost:3000/api/docs`

### Production Build

```bash
npm run build
npm run start:prod
```

### With Docker

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f backend

# Stop services
docker-compose down
```

---

## 🗄️ Database Setup

### Create Database

```bash
psql -U postgres
CREATE USER lscm_user WITH PASSWORD 'secure_password';
CREATE DATABASE lscm_erp OWNER lscm_user;
```

### Run Migrations

```bash
# Create new migration
npx prisma migrate dev --name initial_schema

# Run pending migrations
npx prisma migrate deploy

# Reset database (DEV ONLY)
npx prisma migrate reset
```

### Seed Sample Data

```bash
npx prisma db seed
```

This creates:
- 3 sample orders (SNIM, EGI, LADOL)
- Test users (coordinator, manager)
- Sample documents and invoices

### Access Database Admin (pgAdmin)

```
URL: http://localhost:5050
Email: admin@lscm.com
Password: admin
```

---

## 📚 API Documentation

### Interactive API Docs

```
http://localhost:3000/api/docs
```

**Swagger/OpenAPI endpoint with full documentation and try-it-out functionality**

### Key API Endpoints

#### Orders
```
POST   /api/v1/orders                    Create new order
GET    /api/v1/orders                    List orders (with filtering)
GET    /api/v1/orders/:id                Get order details
PUT    /api/v1/orders/:id                Update order
GET    /api/v1/orders/:id/timeline       Get order timeline
GET    /api/v1/orders/:id/kpis           Calculate KPIs
```

#### Documents
```
POST   /api/v1/documents/:orderId/generate    Auto-generate documents
GET    /api/v1/documents/:orderId             List order documents
GET    /api/v1/documents/:docId               Get document
PUT    /api/v1/documents/:docId/approve       Approve document
```

#### Pickup
```
POST   /api/v1/pickup/:orderId/schedule      Schedule pickup
POST   /api/v1/pickup/:orderId/poc           Record POC
POST   /api/v1/pickup/:orderId/hub           Hub reception
GET    /api/v1/pickup/:orderId/poc           Get POC
```

#### Customs
```
POST   /api/v1/customs/:orderId/greenlight   Request Green Light
POST   /api/v1/customs/:glId/approve         Record approval
POST   /api/v1/customs/:orderId/export       Submit export decl
```

#### Transport
```
POST   /api/v1/transport/:orderId/book       Book carrier
POST   /api/v1/transport/:orderId/loading    Record loading
GET    /api/v1/transport/:segmentId/track    Get tracking
```

#### Invoices
```
POST   /api/v1/invoices/:orderId/generate    Auto-generate invoice
POST   /api/v1/invoices/:id/send             Send to client
POST   /api/v1/invoices/:id/payment          Record payment
GET    /api/v1/invoices/:orderId             List invoices
```

#### Reporting
```
GET    /api/v1/reporting/:orderId/dsr        Get latest DSR
POST   /api/v1/reporting/dsr/:orderId        Generate DSR
GET    /api/v1/reporting/wsr                 Get weekly report
POST   /api/v1/reporting/jcr/:orderId        Generate JCR
```

---

## 🔌 Integration Guides

### CLEAR Integration

```typescript
// Import order from CLEAR
POST /api/v1/integrations/clear/import
{
  "clearJobId": "CLR-123456"
}

// Sync order status back
POST /api/v1/integrations/clear/sync
{
  "orderId": "ORD-12345"
}
```

### SAP BW Integration

```typescript
// Fetch PO data
GET /api/v1/integrations/sap-bw/po/4560184557

// Response includes vendor, materials, delivery dates, etc
```

### Carrier Tracking

```typescript
// Get real-time status
GET /api/v1/integrations/carriers/tracking/TURKISH_AIRLINES/TK451

// Response: Current location, ETA, incidents, etc
```

### Bank Payment Verification

```typescript
// Verify payment with Access Bank
POST /api/v1/integrations/bank/verify-payment
{
  "accountNumber": "1234567890",
  "amount": 5000,
  "reference": "TXN-2025-123"
}
```

---

## 🚢 Deployment

### Docker Hub

```bash
# Build & push image
docker build -t lscm/erp:latest .
docker push lscm/erp:latest
```

### AWS ECS

```bash
# Push to ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 123456789.dkr.ecr.us-east-1.amazonaws.com

docker tag lscm/erp:latest 123456789.dkr.ecr.us-east-1.amazonaws.com/lscm-erp:latest
docker push 123456789.dkr.ecr.us-east-1.amazonaws.com/lscm-erp:latest
```

### Kubernetes

```bash
# Create deployment
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml

# Check status
kubectl get pods -l app=lscm-erp
```

### DigitalOcean App Platform

```bash
# Using docker-compose
doctl apps create --spec app.yaml

# Or direct deployment
doctl apps deploy <app-id>
```

### Heroku (Deprecated but simple)

```bash
heroku create lscm-erp
heroku addons:create heroku-postgresql:standard-0
git push heroku main
heroku run npx prisma migrate deploy
```

---

## 🔧 Troubleshooting

### Port Already in Use

```bash
# Find process using port 3000
lsof -i :3000

# Kill process
kill -9 <PID>
```

### Database Connection Error

```bash
# Check PostgreSQL is running
docker-compose logs postgres

# Verify DATABASE_URL in .env
echo $DATABASE_URL

# Test connection
psql $DATABASE_URL -c "SELECT 1"
```

### Prisma Migration Issues

```bash
# Reset database (DEV ONLY)
npx prisma migrate reset

# Resolve conflicts
npx prisma migrate resolve --rolled-back "migration_name"
```

### Docker Container Won't Start

```bash
# Check logs
docker-compose logs backend

# Rebuild image
docker-compose build --no-cache backend

# Restart
docker-compose restart backend
```

### Memory/Performance Issues

```bash
# Increase Node.js heap
NODE_OPTIONS='--max-old-space-size=2048' npm start

# Check running processes
top -p $(pgrep -f "node")

# Enable profiling
NODE_ENV=production node --prof dist/main.js
```

---

## 📊 Monitoring

### Health Check

```bash
curl http://localhost:3000/health
# Returns: { "status": "ok", "timestamp": "2025-03-05T..." }
```

### Application Metrics

```
http://localhost:3000/metrics
```

**Available metrics:**
- Request count & latency
- Database query performance
- Error rates
- DSR generation frequency
- Payment processing stats

### Logs

```bash
# View application logs
docker-compose logs backend

# Stream logs
docker-compose logs -f backend

# Filter by timestamp
docker-compose logs backend --since 2025-03-05T10:00:00
```

---

## 🧪 Testing

### Run All Tests

```bash
npm test
```

### Run Specific Test

```bash
npm test -- orders.service.spec.ts
```

### Coverage Report

```bash
npm run test:cov
```

### E2E Tests

```bash
npm run test:e2e
```

---

## 📞 Support

**For issues, questions, or contributions:**

- 📧 Email: dev@lscm.com
- 📋 Issues: GitHub Issues
- 💬 Slack: #lscm-erp-dev

---

## 📜 License

MIT License - See LICENSE file

---

**Last Updated:** March 5, 2025  
**Maintainer:** LSCM Development Team  
**Version:** 1.0.0 (Phase 1A)
