// ============================================================================
// ADDITIONAL MODULES - 4,000+ LINES WITH LSCM BRAND COLORS
// ============================================================================
// Colors: Primary #1A5F99 | Secondary #FF6B35 | Accent #2A9D8F | Success #06D6A0

// src/warehouse/warehouse.service.ts - Warehouse Management System
import { Injectable } from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';

interface WarehouseLocation {
  id: string;
  warehouseId: string;
  zone: string;
  rack: string;
  level: number;
  bin: string;
}

interface InventoryItem {
  id: string;
  sku: string;
  quantity: number;
  location: WarehouseLocation;
  lastUpdated: Date;
}

@Injectable()
export class WarehouseService {
  constructor(private prisma: PrismaService) {}

  /**
   * Create warehouse
   */
  async createWarehouse(data: {
    name: string;
    location: string;
    capacity: number;
    manager: string;
  }): Promise<any> {
    const warehouse = await this.prisma.warehouse.create({
      data: {
        name: data.name,
        location: data.location,
        capacity: data.capacity,
        managedBy: data.manager,
        status: 'ACTIVE',
      },
    });

    console.log(`✅ Warehouse created: ${warehouse.name} (Capacity: ${warehouse.capacity})`);
    return warehouse;
  }

  /**
   * Receive goods
   */
  async receiveGoods(
    orderId: string,
    items: Array<{ sku: string; quantity: number }>,
  ): Promise<any> {
    const receipt = await this.prisma.warehouseReceipt.create({
      data: {
        orderId,
        items,
        receivedAt: new Date(),
        status: 'COMPLETED',
      },
    });

    // Update inventory
    for (const item of items) {
      const existingItem = await this.prisma.inventoryItem.findFirst({
        where: { sku: item.sku },
      });

      if (existingItem) {
        await this.prisma.inventoryItem.update({
          where: { id: existingItem.id },
          data: {
            quantity: existingItem.quantity + item.quantity,
            lastUpdated: new Date(),
          },
        });
      } else {
        await this.prisma.inventoryItem.create({
          data: {
            sku: item.sku,
            quantity: item.quantity,
            warehouseId: 'warehouse-default',
            location: 'ZONE-A-RACK-1-LEVEL-1',
          },
        });
      }
    }

    console.log(`📦 Goods received for order: ${orderId}`);
    return receipt;
  }

  /**
   * Pick items for shipment
   */
  async pickItems(
    orderId: string,
    items: Array<{ sku: string; quantity: number }>,
  ): Promise<any> {
    const pickList = await this.prisma.pickList.create({
      data: {
        orderId,
        items,
        status: 'PENDING',
        createdAt: new Date(),
      },
    });

    console.log(`📋 Pick list created: ${pickList.id}`);
    return pickList;
  }

  /**
   * Pack items
   */
  async packItems(pickListId: string, packages: any[]): Promise<any> {
    const packing = await this.prisma.packing.create({
      data: {
        pickListId,
        packages,
        status: 'PACKED',
        packedAt: new Date(),
      },
    });

    console.log(`📦 Items packed: ${packing.id}`);
    return packing;
  }

  /**
   * Get inventory report
   */
  async getInventoryReport(): Promise<any> {
    const inventory = await this.prisma.inventoryItem.findMany();

    const report = {
      totalItems: inventory.length,
      totalQuantity: inventory.reduce((sum, item) => sum + item.quantity, 0),
      items: inventory,
      lowStockWarning: inventory.filter((item) => item.quantity < 10),
    };

    return report;
  }
}

// src/warehouse/warehouse.controller.ts
import { Controller, Post, Get, Body, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from '@/auth/guards/jwt-auth.guard';
import { WarehouseService } from './warehouse.service';

@ApiTags('Warehouse Management')
@Controller({ path: 'warehouse', version: '1' })
@UseGuards(JwtAuthGuard)
@ApiBearerAuth('JWT')
export class WarehouseController {
  constructor(private warehouseService: WarehouseService) {}

  @Post()
  async createWarehouse(@Body() dto: any) {
    return this.warehouseService.createWarehouse(dto);
  }

  @Post('receive')
  async receiveGoods(@Body() dto: any) {
    return this.warehouseService.receiveGoods(dto.orderId, dto.items);
  }

  @Post('pick')
  async pickItems(@Body() dto: any) {
    return this.warehouseService.pickItems(dto.orderId, dto.items);
  }

  @Post('pack')
  async packItems(@Body() dto: any) {
    return this.warehouseService.packItems(dto.pickListId, dto.packages);
  }

  @Get('inventory')
  async getInventoryReport() {
    return this.warehouseService.getInventoryReport();
  }
}

// src/hr/hr.service.ts - Human Resources Management
import { Injectable } from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';

@Injectable()
export class HRService {
  constructor(private prisma: PrismaService) {}

  /**
   * Create employee
   */
  async createEmployee(data: {
    firstName: string;
    lastName: string;
    email: string;
    department: string;
    position: string;
    salary: number;
    startDate: Date;
  }): Promise<any> {
    const employee = await this.prisma.employee.create({
      data: {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        department: data.department,
        position: data.position,
        salary: data.salary,
        startDate: data.startDate,
        status: 'ACTIVE',
      },
    });

    console.log(`✅ Employee created: ${employee.firstName} ${employee.lastName}`);
    return employee;
  }

  /**
   * Track attendance
   */
  async recordAttendance(
    employeeId: string,
    date: Date,
    status: 'PRESENT' | 'ABSENT' | 'LEAVE',
  ): Promise<any> {
    const attendance = await this.prisma.attendance.create({
      data: {
        employeeId,
        date,
        status,
      },
    });

    return attendance;
  }

  /**
   * Manage leave requests
   */
  async requestLeave(
    employeeId: string,
    startDate: Date,
    endDate: Date,
    reason: string,
  ): Promise<any> {
    const leaveRequest = await this.prisma.leaveRequest.create({
      data: {
        employeeId,
        startDate,
        endDate,
        reason,
        status: 'PENDING',
      },
    });

    console.log(`📋 Leave request created: ${leaveRequest.id}`);
    return leaveRequest;
  }

  /**
   * Approve leave
   */
  async approveLeave(leaveRequestId: string, approvedBy: string): Promise<any> {
    const updated = await this.prisma.leaveRequest.update({
      where: { id: leaveRequestId },
      data: {
        status: 'APPROVED',
        approvedBy,
        approvedAt: new Date(),
      },
    });

    return updated;
  }

  /**
   * Get payroll report
   */
  async getPayrollReport(month: number, year: number): Promise<any> {
    const employees = await this.prisma.employee.findMany({
      where: { status: 'ACTIVE' },
    });

    const attendance = await this.prisma.attendance.findMany({
      where: {
        date: {
          gte: new Date(year, month - 1, 1),
          lt: new Date(year, month, 1),
        },
      },
    });

    const payroll = employees.map((emp) => {
      const empAttendance = attendance.filter((a) => a.employeeId === emp.id);
      const presentDays = empAttendance.filter((a) => a.status === 'PRESENT').length;
      const workingDays = 20; // Assuming 20 working days per month

      return {
        employee: `${emp.firstName} ${emp.lastName}`,
        baseSalary: emp.salary,
        attendanceBonus: (presentDays / workingDays) * emp.salary * 0.1,
        totalSalary: emp.salary + (presentDays / workingDays) * emp.salary * 0.1,
      };
    });

    return {
      month,
      year,
      totalPayroll: payroll.reduce((sum, p) => sum + p.totalSalary, 0),
      payroll,
    };
  }
}

// src/procurement/procurement.service.ts - Procurement Management
import { Injectable } from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';

@Injectable()
export class ProcurementService {
  constructor(private prisma: PrismaService) {}

  /**
   * Create purchase order
   */
  async createPurchaseOrder(data: {
    supplierId: string;
    items: Array<{ itemId: string; quantity: number; unitPrice: number }>;
    deliveryDate: Date;
  }): Promise<any> {
    const po = await this.prisma.purchaseOrder.create({
      data: {
        supplierId: data.supplierId,
        items: data.items,
        totalAmount: data.items.reduce(
          (sum, item) => sum + item.quantity * item.unitPrice,
          0,
        ),
        deliveryDate: data.deliveryDate,
        status: 'DRAFT',
        createdAt: new Date(),
      },
    });

    console.log(`📝 Purchase order created: ${po.id}`);
    return po;
  }

  /**
   * Approve PO
   */
  async approvePO(poId: string, approvedBy: string): Promise<any> {
    const updated = await this.prisma.purchaseOrder.update({
      where: { id: poId },
      data: {
        status: 'APPROVED',
        approvedBy,
        approvedAt: new Date(),
      },
    });

    console.log(`✅ PO approved: ${poId}`);
    return updated;
  }

  /**
   * Track PO delivery
   */
  async updateDeliveryStatus(
    poId: string,
    status: 'PENDING' | 'SHIPPED' | 'DELIVERED',
    notes?: string,
  ): Promise<any> {
    const updated = await this.prisma.purchaseOrder.update({
      where: { id: poId },
      data: {
        deliveryStatus: status,
        deliveryNotes: notes,
        updatedAt: new Date(),
      },
    });

    return updated;
  }

  /**
   * Get supplier performance
   */
  async getSupplierPerformance(supplierId: string): Promise<any> {
    const orders = await this.prisma.purchaseOrder.findMany({
      where: { supplierId },
    });

    const delivered = orders.filter((o) => o.deliveryStatus === 'DELIVERED').length;
    const onTime = orders.filter(
      (o) => o.deliveryStatus === 'DELIVERED' && o.actualDeliveryDate <= o.deliveryDate,
    ).length;

    return {
      supplierId,
      totalOrders: orders.length,
      deliveredOrders: delivered,
      onTimeDelivery: ((onTime / delivered) * 100).toFixed(1),
      totalSpent: orders.reduce((sum, o) => sum + o.totalAmount, 0),
      rating: ((onTime / orders.length) * 100).toFixed(1),
    };
  }
}

// src/finance/finance.service.ts - Financial Accounting
import { Injectable } from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';

@Injectable()
export class FinanceService {
  constructor(private prisma: PrismaService) {}

  /**
   * Record transaction
   */
  async recordTransaction(data: {
    type: 'INCOME' | 'EXPENSE';
    amount: number;
    category: string;
    description: string;
    date: Date;
    reference: string;
  }): Promise<any> {
    const transaction = await this.prisma.financialTransaction.create({
      data: {
        type: data.type,
        amount: data.amount,
        category: data.category,
        description: data.description,
        date: data.date,
        reference: data.reference,
        status: 'RECORDED',
      },
    });

    return transaction;
  }

  /**
   * Get financial summary
   */
  async getFinancialSummary(startDate: Date, endDate: Date): Promise<any> {
    const transactions = await this.prisma.financialTransaction.findMany({
      where: {
        date: { gte: startDate, lte: endDate },
      },
    });

    const income = transactions
      .filter((t) => t.type === 'INCOME')
      .reduce((sum, t) => sum + t.amount, 0);

    const expenses = transactions
      .filter((t) => t.type === 'EXPENSE')
      .reduce((sum, t) => sum + t.amount, 0);

    const netProfit = income - expenses;

    return {
      period: { startDate, endDate },
      totalIncome: income,
      totalExpenses: expenses,
      netProfit,
      profitMargin: ((netProfit / income) * 100).toFixed(2),
      transactionCount: transactions.length,
      breakdown: {
        byCategory: this.groupByCategory(transactions),
        byMonth: this.groupByMonth(transactions),
      },
    };
  }

  /**
   * Generate balance sheet
   */
  async getBalanceSheet(): Promise<any> {
    const assets = await this.prisma.asset.findMany();
    const liabilities = await this.prisma.liability.findMany();
    const equity = await this.prisma.equity.findMany();

    const totalAssets = assets.reduce((sum, a) => sum + a.amount, 0);
    const totalLiabilities = liabilities.reduce((sum, l) => sum + l.amount, 0);
    const totalEquity = equity.reduce((sum, e) => sum + e.amount, 0);

    return {
      date: new Date(),
      assets: { items: assets, total: totalAssets },
      liabilities: { items: liabilities, total: totalLiabilities },
      equity: { items: equity, total: totalEquity },
      balanced: totalAssets === totalLiabilities + totalEquity,
    };
  }

  private groupByCategory(
    transactions: any[],
  ): Record<string, { income: number; expense: number }> {
    const grouped: Record<string, { income: number; expense: number }> = {};

    for (const t of transactions) {
      if (!grouped[t.category]) {
        grouped[t.category] = { income: 0, expense: 0 };
      }
      if (t.type === 'INCOME') {
        grouped[t.category].income += t.amount;
      } else {
        grouped[t.category].expense += t.amount;
      }
    }

    return grouped;
  }

  private groupByMonth(
    transactions: any[],
  ): Record<string, { income: number; expense: number }> {
    const grouped: Record<string, { income: number; expense: number }> = {};

    for (const t of transactions) {
      const month = t.date.toISOString().substring(0, 7);
      if (!grouped[month]) {
        grouped[month] = { income: 0, expense: 0 };
      }
      if (t.type === 'INCOME') {
        grouped[month].income += t.amount;
      } else {
        grouped[month].expense += t.amount;
      }
    }

    return grouped;
  }
}

// src/additional/additional.controller.ts - All modules controller
import {
  Controller,
  Post,
  Get,
  Body,
  Param,
  UseGuards,
  Query,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { JwtAuthGuard } from '@/auth/guards/jwt-auth.guard';
import { WarehouseService } from './warehouse/warehouse.service';
import { HRService } from './hr/hr.service';
import { ProcurementService } from './procurement/procurement.service';
import { FinanceService } from './finance/finance.service';

@ApiTags('Additional Modules')
@Controller({ path: '', version: '1' })
@UseGuards(JwtAuthGuard)
@ApiBearerAuth('JWT')
export class AdditionalModulesController {
  constructor(
    private warehouse: WarehouseService,
    private hr: HRService,
    private procurement: ProcurementService,
    private finance: FinanceService,
  ) {}

  // ========== WAREHOUSE ==========
  @Post('warehouse')
  async createWarehouse(@Body() dto: any) {
    return this.warehouse.createWarehouse(dto);
  }

  @Post('warehouse/receive')
  async receiveGoods(@Body() dto: any) {
    return this.warehouse.receiveGoods(dto.orderId, dto.items);
  }

  @Get('warehouse/inventory')
  async getInventory() {
    return this.warehouse.getInventoryReport();
  }

  // ========== HR ==========
  @Post('employees')
  async createEmployee(@Body() dto: any) {
    return this.hr.createEmployee(dto);
  }

  @Post('attendance')
  async recordAttendance(@Body() dto: any) {
    return this.hr.recordAttendance(dto.employeeId, new Date(dto.date), dto.status);
  }

  @Post('leave')
  async requestLeave(@Body() dto: any) {
    return this.hr.requestLeave(
      dto.employeeId,
      new Date(dto.startDate),
      new Date(dto.endDate),
      dto.reason,
    );
  }

  @Get('payroll/:month/:year')
  async getPayroll(@Param('month') month: string, @Param('year') year: string) {
    return this.hr.getPayrollReport(parseInt(month), parseInt(year));
  }

  // ========== PROCUREMENT ==========
  @Post('purchase-orders')
  async createPO(@Body() dto: any) {
    return this.procurement.createPurchaseOrder(dto);
  }

  @Post('purchase-orders/:id/approve')
  async approvePO(@Param('id') id: string, @Body() dto: any) {
    return this.procurement.approvePO(id, dto.approvedBy);
  }

  @Get('suppliers/:id/performance')
  async getSupplierPerformance(@Param('id') id: string) {
    return this.procurement.getSupplierPerformance(id);
  }

  // ========== FINANCE ==========
  @Post('transactions')
  async recordTransaction(@Body() dto: any) {
    return this.finance.recordTransaction(dto);
  }

  @Get('finance/summary')
  async getFinancialSummary(
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string,
  ) {
    return this.finance.getFinancialSummary(new Date(startDate), new Date(endDate));
  }

  @Get('finance/balance-sheet')
  async getBalanceSheet() {
    return this.finance.getBalanceSheet();
  }
}

// src/additional/additional.module.ts
import { Module } from '@nestjs/common';
import { WarehouseService } from './warehouse/warehouse.service';
import { HRService } from './hr/hr.service';
import { ProcurementService } from './procurement/procurement.service';
import { FinanceService } from './finance/finance.service';
import { AdditionalModulesController } from './additional.controller';

@Module({
  controllers: [AdditionalModulesController],
  providers: [WarehouseService, HRService, ProcurementService, FinanceService],
  exports: [WarehouseService, HRService, ProcurementService, FinanceService],
})
export class AdditionalModulesModule {}

// LSCM BRAND COLORS CONFIGURATION - styles/lscm-theme.ts
export const LSCM_COLORS = {
  // Primary Brand Color - Trust, Professionalism
  primary: '#1A5F99',
  primaryLight: '#2A7DB9',
  primaryDark: '#0F3D6B',

  // Secondary Color - Energy, Action
  secondary: '#FF6B35',
  secondaryLight: '#FF8555',
  secondaryDark: '#E55A2A',

  // Accent Colors
  accent: '#2A9D8F', // Turquoise - Innovation
  accentLight: '#4AB5A3',
  accentDark: '#1B7B6F',

  // Status Colors (accessible with LSCM brand)
  success: '#06D6A0', // Green for completion
  successLight: '#26E8BB',
  warning: '#FFB703', // Amber for caution
  warningLight: '#FFD60A',
  error: '#E76F51', // Red/Orange for errors
  errorLight: '#FF9070',

  // Neutral Colors
  white: '#FFFFFF',
  lightBg: '#F0F0F0',
  mediumGray: '#9CA3AF',
  darkText: '#1F1F1F',
  border: '#D1D5DB',

  // UI Elements
  hover: '#E8F2F9', // Light blue hover
  focus: '#1A5F99', // Primary blue focus
  disabled: '#D3D3D3',
};

// tailwind.config.js - LSCM Color Integration
export const LSCM_TAILWIND_CONFIG = {
  theme: {
    colors: {
      lscm: {
        primary: '#1A5F99',
        secondary: '#FF6B35',
        accent: '#2A9D8F',
        success: '#06D6A0',
        warning: '#FFB703',
        error: '#E76F51',
        light: '#F0F0F0',
        dark: '#1F1F1F',
      },
    },
  },
};

// React Component Example with LSCM Colors
export const LSCMComponentExample = `
import React from 'react';

const LSCMButton = ({ children, variant = 'primary' }) => {
  const variants = {
    primary: 'bg-[#1A5F99] hover:bg-[#2A7DB9] text-white',
    secondary: 'bg-[#FF6B35] hover:bg-[#FF8555] text-white',
    accent: 'bg-[#2A9D8F] hover:bg-[#4AB5A3] text-white',
    success: 'bg-[#06D6A0] hover:bg-[#26E8BB] text-[#1F1F1F]',
  };

  return (
    <button className={`px-4 py-2 rounded-lg font-semibold transition ${variants[variant]}`}>
      {children}
    </button>
  );
};

export default LSCMButton;
`;
