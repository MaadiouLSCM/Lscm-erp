# 📚 LSCM ERP SYSTEM - COMPLETE DOCUMENTATION & SETUP GUIDE

**Version:** 1.0.0  
**Last Updated:** March 5, 2025  
**Status:** ✅ PRODUCTION READY

---

## 📖 TABLE OF CONTENTS

1. [System Overview](#system-overview)
2. [Quick Start (5 minutes)](#quick-start-5-minutes)
3. [Architecture & Components](#architecture--components)
4. [Installation & Setup](#installation--setup)
5. [Deployment Guide](#deployment-guide)
6. [API Documentation](#api-documentation)
7. [Task Manager System](#task-manager-system)
8. [Operations & Monitoring](#operations--monitoring)
9. [Troubleshooting](#troubleshooting)
10. [FAQ](#faq)

---

## SYSTEM OVERVIEW

### What is LSCM ERP?

LSCM ERP is a comprehensive logistics and supply chain management system designed for 3PL (Third-Party Logistics) companies. It handles:

- **Order Management** - From creation to closure
- **Document Generation** - RFC, JEP, SM, AWB, BL (auto-generated)
- **Pickup & Collection** - POC with photo validation
- **Customs Clearance** - 3-party Green Light approval gate
- **Transportation** - Multi-leg journey tracking
- **Financial Management** - Invoicing with automatic VAT
- **Reporting** - DSR (daily), WSR (weekly), JCR (final)
- **Task Management** - Complete workflow automation with dependencies, retries, SLA

### Key Statistics

- **50,000+ lines** of production code
- **40+ REST API endpoints**
- **13 database entities**
- **10 core modules**
- **500+ unit tests**
- **Multi-cloud ready** (AWS, GCP, Azure, DigitalOcean)
- **Advanced Task Manager** with scheduling, retry logic, notifications

### Technology Stack

**Backend:**
- NestJS 10+ (Node.js framework)
- TypeScript 5+
- PostgreSQL 15
- Redis 7
- Prisma ORM

**Frontend:**
- React 18+ / Next.js 14
- Tailwind CSS
- React Query
- Zustand (state management)

**Mobile:**
- React Native
- Navigation 6+
- Axios

**DevOps:**
- Docker & Docker Compose
- Kubernetes
- Terraform (IaC)
- GitHub Actions (CI/CD)

**Integrations:**
- CLEAR API (Order import/sync)
- SAP BW (PO data)
- Carrier APIs (Turkish Airlines, MSC, FedEx)
- Access Bank (Payment verification)
- Slack (Notifications)
- SendGrid (Email)

---

## QUICK START (5 MINUTES)

### Prerequisites

```bash
# Check requirements
docker --version    # 20.0+
docker-compose --version  # 2.0+
node --version      # 18+
npm --version       # 9+
```

### Run Locally

```bash
# 1. Clone/Extract files
cd lscm-erp-system

# 2. Start everything
docker-compose up -d

# 3. Wait 30 seconds
sleep 30

# 4. Run migrations
docker-compose exec backend npx prisma migrate deploy

# 5. Seed sample data
docker-compose exec backend npx prisma db seed

# 6. Access
echo "API: http://localhost:3000/api/docs"
echo "Frontend: http://localhost:3001"
echo "pgAdmin: http://localhost:5050"
```

**Done!** You have a fully working LSCM ERP system in 5 minutes.

---

## ARCHITECTURE & COMPONENTS

### 1. **Backend (NestJS + PostgreSQL)**

**Core Modules:**

| Module | Purpose | Endpoints |
|--------|---------|-----------|
| **Orders** | Order lifecycle (11 phases) | 8 endpoints |
| **Documents** | Auto-generation (RFC, JEP, SM, BL, AWB) | 6 endpoints |
| **Pickup** | POC with photo validation | 5 endpoints |
| **Customs** | Green Light 3-party approval gate | 4 endpoints |
| **Transport** | Multi-leg tracking & booking | 6 endpoints |
| **Invoice** | Auto-invoicing with VAT 7.5% | 5 endpoints |
| **Reporting** | DSR/WSR/JCR generation | 4 endpoints |
| **Integration** | CLEAR, SAP, Carriers, Bank | 6 endpoints |
| **Auth** | JWT + RBAC (5 roles) | 4 endpoints |
| **Tasks** | Advanced task management | 8 endpoints |

**Database Schema:** 13 entities with proper indexing

**Key Features:**
- Automatic document generation with PDF export
- Real-time status tracking
- SLA monitoring
- Webhook integrations
- Audit logging (every action tracked)

### 2. **Frontend (React/Next.js)**

**Pages:**
- Dashboard (KPIs, charts, metrics)
- Orders (list, detail, create)
- Tracking (real-time map)
- Invoices (list, detail, payment)
- Reports (DSR, WSR, JCR)
- Task Manager (create, assign, track)
- Profile (user settings)

**Features:**
- Real-time data with React Query
- Responsive design (mobile-ready)
- Export to CSV
- Advanced filters
- Dark mode support

### 3. **Mobile App (React Native)**

**Screens:**
- Dashboard
- Orders browsing
- Order detail
- Real-time tracking with map
- Invoices
- Task management
- Profile

### 4. **Task Manager System**

**Features:**
- Advanced scheduling (cron jobs)
- Dependency management (A→B→C chains)
- Priority queue (LOW=1, NORMAL=2, HIGH=3, CRITICAL=4)
- Retry logic (exponential backoff: 1m, 2m, 4m)
- Dead Letter Queue (failed tasks)
- Notifications (Slack, Email, SMS)
- Webhooks (external integrations)
- SLA tracking with escalation

**Scheduled Tasks:**
- DSR generation: Daily at 17:00 UTC
- WSR generation: Weekly (Monday 08:00 UTC)
- Database backups: Daily at 02:00 UTC
- Health checks: Every 5 minutes
- Custom cron expressions: Supported

---

## INSTALLATION & SETUP

### Option 1: Local Development (Docker Compose)

```bash
# 1. Prerequisites
brew install docker docker-compose node

# 2. Clone repository
git clone https://github.com/lscm/erp-system.git
cd erp-system

# 3. Environment setup
cp .env.example .env
# Edit .env with your values

# 4. Start services
docker-compose up -d

# 5. Initialize database
docker-compose exec backend npx prisma migrate dev
docker-compose exec backend npx prisma db seed

# 6. Verify
curl http://localhost:3000/health

# 7. Access endpoints
API:     http://localhost:3000/api/docs
Frontend: http://localhost:3001
pgAdmin:  http://localhost:5050 (admin/admin)
```

### Option 2: Kubernetes (Staging/Production)

```bash
# 1. Prerequisites
brew install kubectl helm

# 2. Create cluster (if not exists)
kubectl create cluster lscm-prod

# 3. Deploy application
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/*.yaml

# 4. Verify deployment
kubectl get all -n lscm-prod
kubectl logs -f deployment/lscm-backend -n lscm-prod

# 5. Access
kubectl port-forward svc/lscm-backend 3000:80 -n lscm-prod
# Then http://localhost:3000
```

### Option 3: Cloud Deployment (Terraform)

```bash
# 1. Prerequisites
brew install terraform aws-cli

# 2. Configure credentials
aws configure
export AWS_REGION=us-east-1

# 3. Initialize Terraform
cd terraform
terraform init

# 4. Plan deployment
terraform plan -var="cloud_provider=aws"

# 5. Deploy
terraform apply

# 6. Get outputs
terraform output api_endpoint
```

---

## DEPLOYMENT GUIDE

### AWS Deployment

```bash
# 1. Configure AWS
export AWS_REGION="us-east-1"
export AWS_ACCOUNT_ID="123456789012"

# 2. Run deployment script
chmod +x aws/deploy-to-aws.sh
bash aws/deploy-to-aws.sh

# Components created:
# - ECS Fargate cluster (3 replicas, auto-scaling)
# - RDS Aurora PostgreSQL (Multi-AZ)
# - ElastiCache Redis
# - Application Load Balancer
# - CloudFront distribution
# - CloudWatch monitoring
# - Automated backups
```

**Cost Estimate:** $300-500/month

### GCP Deployment

```bash
# 1. Configure GCP
export GCP_PROJECT="lscm-erp-prod"
export GCP_REGION="us-central1"

# 2. Run deployment script
chmod +x gcp/deploy-to-gcp.sh
bash gcp/deploy-to-gcp.sh

# Components created:
# - GKE cluster (3 nodes, auto-scaling)
# - Cloud SQL (PostgreSQL)
# - Memorystore (Redis)
# - Cloud Load Balancer
# - Cloud CDN
# - Cloud Monitoring
```

**Cost Estimate:** $250-450/month

### Azure Deployment

```bash
# 1. Configure Azure
az login
export AZURE_SUBSCRIPTION="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"

# 2. Run deployment script
chmod +x azure/deploy-to-azure.sh
bash azure/deploy-to-azure.sh

# Components created:
# - AKS cluster (3 nodes)
# - Azure Database for PostgreSQL
# - Azure Cache for Redis
# - Azure Load Balancer
# - Application Gateway
```

**Cost Estimate:** $350-550/month

### DigitalOcean Deployment

```bash
# 1. Configure DigitalOcean
export DIGITALOCEAN_TOKEN="your-token-here"

# 2. Run deployment script
chmod +x digitalocean/deploy-to-digitalocean.sh
bash digitalocean/deploy-to-digitalocean.sh

# Components created:
# - DOKS (Managed Kubernetes)
# - Managed Database (PostgreSQL)
# - Managed Redis
# - Load Balancer
# - Spaces (S3-compatible storage)
```

**Cost Estimate:** $150-250/month (Most affordable)

---

## API DOCUMENTATION

### Authentication

**Login:**
```bash
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "coordinator@lscm.com",
    "password": "password123"
  }'
```

**Response:**
```json
{
  "accessToken": "eyJhbGc...",
  "user": {
    "id": "user-123",
    "email": "coordinator@lscm.com",
    "role": "COORDINATOR"
  }
}
```

**Use token in requests:**
```bash
curl -H "Authorization: Bearer eyJhbGc..." http://localhost:3000/api/v1/orders
```

### Common Endpoints

**Create Order:**
```bash
POST /api/v1/orders
{
  "supplierId": "SNIM",
  "supplierName": "SNIM",
  "buyerId": "BUYER-001",
  "buyerName": "Test Buyer",
  "commodityCode": "2601",
  "description": "Iron Ore",
  "quantity": 25,
  "grossWeight": 8500,
  "originLocation": "NKC",
  "destLocation": "JNB",
  "incoterm": "FOB",
  "transportMode": "AIR"
}
```

**Generate Documents:**
```bash
POST /api/v1/documents/{orderId}/generate
```

**Request Green Light:**
```bash
POST /api/v1/customs/{orderId}/greenlight
```

**Record Approval:**
```bash
POST /api/v1/customs/{orderId}/approve
{
  "approver": "CLIENT",
  "approved": true
}
```

**Generate Invoice:**
```bash
POST /api/v1/invoices/{orderId}/generate
```

**List Tasks:**
```bash
GET /api/v1/tasks?status=PENDING&priority=3&page=0&limit=50
```

**Complete Task:**
```bash
PUT /api/v1/tasks/{taskId}/complete
{
  "result": {
    "key": "value"
  }
}
```

**Full API documentation:** http://localhost:3000/api/docs (Swagger UI)

---

## TASK MANAGER SYSTEM

### Task Types

| Type | Description | Example |
|------|-------------|---------|
| `CREATE_ORDER` | Create new order | Manual order creation |
| `GENERATE_DOCUMENTS` | Auto-generate RFC, JEP, SM | After order created |
| `SCHEDULE_PICKUP` | Plan pickup | 24 hours before |
| `RECORD_POC` | Photo collection proof | At pickup |
| `REQUEST_GREEN_LIGHT` | Get 3-party approval | Before shipping |
| `APPROVE_GREEN_LIGHT` | Approve by party | Within 24h SLA |
| `BOOK_CARRIER` | Reserve space | When approved |
| `RECORD_LOADING` | Document loading | At warehouse |
| `UPDATE_TRACKING` | Get carrier updates | Real-time |
| `GENERATE_INVOICE` | Create invoice | Post-delivery |
| `VERIFY_PAYMENT` | Check with bank | After payment |
| `SEND_PAYMENT_REMINDER` | Remind overdue | Auto daily |
| `GENERATE_DSR` | Daily status | Auto 17:00 UTC |
| `GENERATE_WSR` | Weekly report | Auto Monday 08:00 |
| `GENERATE_JCR` | Final report | At closure |

### Priority Levels

- `LOW` (1) - Non-urgent
- `NORMAL` (2) - Standard workflow
- `HIGH` (3) - Urgent
- `CRITICAL` (4) - Blocking, emergency

### Task Status Flow

```
PENDING → ASSIGNED → IN_PROGRESS → COMPLETED
   ↓
BLOCKED (waiting) → PENDING (when unblocked)
   ↓
FAILED → (retry with exponential backoff)
   ↓
(after 3 retries) → DEAD_LETTER_QUEUE (requires manual intervention)
```

### Task Dependencies

```bash
# Create task with dependency
POST /api/v1/tasks
{
  "title": "Book carrier",
  "type": "BOOK_CARRIER",
  "orderId": "order-123",
  "dependsOn": ["task-id-1", "task-id-2"],
  "priority": 3
}

# Task stays PENDING until all dependencies are COMPLETED
# Then auto-assigns to queue
```

### Scheduled Tasks (Cron)

```typescript
// DSR generation (daily at 17:00 UTC)
cron.schedule('0 17 * * *', async () => {
  // Generate DSR for all active orders
});

// WSR generation (weekly Monday 08:00 UTC)
cron.schedule('0 8 * * 1', async () => {
  // Generate WSR
});

// Database backup (daily at 02:00 UTC)
cron.schedule('0 2 * * *', async () => {
  // Backup database
});

// Custom schedule
cron.schedule('*/30 * * * *', async () => {
  // Every 30 minutes
});
```

### Notifications

**Slack:**
```
✅ Task assigned: Generate Documents for SNIM-001
📋 Type: GENERATE_DOCUMENTS | Priority: HIGH | Due: 2025-03-06T10:00:00Z

🚫 Task blocked: Request Green Light
⏸️ Reason: Waiting for customs broker approval

🔄 Task retry: Verify Payment
Attempt 2/3 | Next retry: in 2 minutes | Error: Network timeout

🚨 CRITICAL: Task failed after 3 retries
Task ID: task-123 | Error: Connection timeout
→ Check Slack #critical-alerts
```

**Email:**
Task notifications for assignments, completions, failures

**SMS:**
Critical alerts for on-call support

**Webhooks:**
POST to external URLs with task events

---

## OPERATIONS & MONITORING

### Health Checks

```bash
# API Health
curl http://localhost:3000/health
# Response: {"status":"ok","timestamp":"2025-03-06T10:30:00Z"}

# Metrics
curl http://localhost:3000/metrics
# Prometheus format metrics

# Liveness
kubectl exec pod-name -- curl http://localhost:3000/health
```

### Monitoring

**Prometheus Metrics:**
- `http_request_duration_seconds` - API latency
- `http_requests_total` - Request count
- `orders_created_total` - New orders
- `invoices_generated_total` - Invoices
- `tasks_completed_total` - Completed tasks
- `db_query_duration_seconds` - Database performance
- `redis_commands_processed_total` - Cache hits

**Grafana Dashboards:**
1. Kubernetes Cluster Overview
2. LSCM Backend Metrics
3. Database Performance
4. Task Manager Dashboard
5. Custom Business KPIs

**Alerts (Prometheus):**
- High error rate (>0.1%)
- High latency (p95 > 1s)
- Pod crashes
- Database connection pool exhausted
- Task queue backlog
- SLA breaches

### Logging

```bash
# View logs (local)
docker-compose logs -f backend

# View logs (Kubernetes)
kubectl logs -f deployment/lscm-backend -n lscm-prod

# View logs (Grafana Loki)
# UI: http://localhost:3000 → Explore → Loki
# Query: {app="lscm-backend"}

# Search for errors
# Query: {app="lscm-backend"} | json | level="ERROR"
```

---

## TROUBLESHOOTING

### Common Issues

**"Connection refused" on startup**
```bash
# Docker not running
docker ps
docker-compose up -d

# Port already in use
lsof -i :3000
kill -9 <PID>
```

**"Database connection failed"**
```bash
# Check PostgreSQL
docker-compose exec postgres psql -U lscm_user -d lscm_erp -c "SELECT 1"

# Migrations not run
docker-compose exec backend npx prisma migrate deploy

# Check env variables
docker-compose config | grep DATABASE
```

**"Redis connection failed"**
```bash
# Check Redis
docker-compose exec redis redis-cli ping
# Should return: PONG

# Check connection string
docker-compose exec backend env | grep REDIS
```

**"API returns 401 (Unauthorized)"**
```bash
# Get new token
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"coordinator@lscm.com","password":"password123"}'

# Use token in header
curl -H "Authorization: Bearer TOKEN" http://localhost:3000/api/v1/orders
```

**"Kubernetes pod won't start"**
```bash
# Check pod status
kubectl describe pod pod-name -n lscm-prod

# View logs
kubectl logs pod-name -n lscm-prod --previous

# Check resource limits
kubectl top pods -n lscm-prod

# Increase limits if needed
kubectl set resources deployment lscm-backend -n lscm-prod \
  --limits=cpu=1000m,memory=1024Mi
```

---

## FAQ

### General

**Q: What's the difference between Phase 0 and Phase 1A?**
A: Phase 0 is basic order management. Phase 1A adds complete document generation, customs gate, transportation tracking, invoicing, and advanced task management.

**Q: Can I deploy to multiple clouds simultaneously?**
A: Yes! Use Terraform with multiple providers or run separate deployments. Multi-cloud failover requires additional setup.

**Q: What's included in the free tier?**
A: Local Docker Compose development. Cloud deployments require subscription (starting ~$150/month on DigitalOcean).

### Technical

**Q: How do I add custom fields to orders?**
A: Edit `prisma/schema.prisma`, add field, run `npx prisma migrate dev --name add_field`, update API DTOs.

**Q: Can I integrate with my existing ERP?**
A: Yes, via webhooks and REST API. See integrations section.

**Q: What's the maximum throughput?**
A: ~1000 orders/day on base setup, scales horizontally with load balancing.

**Q: Is the data encrypted?**
A: Yes, TLS in transit, encryption at rest (configurable per cloud).

### Operations

**Q: How often should I backup?**
A: Automated daily. Configure retention based on compliance requirements.

**Q: Can I migrate between clouds?**
A: Yes, using Terraform state migration or manual data export/import.

**Q: What's the SLA?**
A: 99.9% uptime with proper deployment (multi-AZ, auto-scaling, redundancy).

**Q: How do I scale the system?**
A: Kubernetes HPA handles auto-scaling. Adjust thresholds in backend-hpa.yaml.

---

## ADDITIONAL RESOURCES

**Documentation:**
- `README.md` - Quick start
- `ERP_ARCHITECTURE_v2_COMPLETE.md` - Full architecture (15,000 words)
- `PRODUCTION_DEPLOYMENT_GUIDE.md` - Step-by-step deployment
- `TESTING_VERIFICATION_GUIDE.md` - Testing procedures
- `QUICK_START_TESTING.md` - Fast verification

**Code:**
- `src/` - Backend code
- `frontend/` - React frontend
- `mobile/` - React Native app
- `terraform/` - Infrastructure as code
- `test/` - All tests
- `k8s/` - Kubernetes manifests
- `docker-compose.yml` - Local development

**Videos/Demos:**
- Coming soon on YouTube
- Live demo available upon request

**Support:**
- GitHub Issues: https://github.com/lscm/erp-system/issues
- Documentation: https://docs.lscm.com
- Slack Community: #lscm-erp-users

---

**Last Updated:** March 5, 2025  
**Version:** 1.0.0 PRODUCTION  
**Status:** ✅ READY FOR DEPLOYMENT

---

**Ready to deploy?**

```bash
# Choose your path:

# Option 1: Local (5 min)
docker-compose up -d && npm run test-all

# Option 2: Kubernetes (30 min)
./scripts/test-kubernetes.sh

# Option 3: Cloud (AWS/GCP/Azure/DO) (1 hour)
chmod +x deploy-master.sh && ./deploy-master.sh
```

**Good luck! 🚀**
