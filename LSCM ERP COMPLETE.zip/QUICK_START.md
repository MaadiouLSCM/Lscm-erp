# 🚀 QUICK START GUIDE - Démarrer le Projet

## Prérequis (Vérifiez que vous avez)

```bash
# Vérifier Node.js (v18+)
node --version
# Résultat attendu: v18.x.x ou plus

# Vérifier npm
npm --version
# Résultat attendu: 9.x.x ou plus

# Vérifier Docker
docker --version
docker-compose --version
```

Si vous n'avez pas ces outils, installez-les:
- [Node.js + npm](https://nodejs.org/)
- [Docker Desktop](https://www.docker.com/products/docker-desktop)

---

## ⚡ Setup Initial (5-10 minutes)

### 1️⃣ Extraire les fichiers

```bash
# Télécharger et extraire le dossier erp-lscm
# (Vous devez avoir reçu le dossier complet)

cd erp-lscm
```

### 2️⃣ Configurer les variables d'environnement

```bash
# Créer le fichier .env
cp .env.example .env

# Vérifier que le contenu ressemble à ça:
cat .env
```

Le fichier `.env` devrait contenir:
```
DATABASE_URL=postgresql://lscm_user:lscm_password_dev@localhost:5432/erp_lscm_dev
REDIS_URL=redis://localhost:6379
JWT_SECRET=your_super_secret_jwt_key_change_in_production
PORT=3000
NODE_ENV=development
```

### 3️⃣ Démarrer les services Docker

```bash
# Lancer PostgreSQL et Redis
docker-compose up -d

# Vérifier que tout est OK
docker-compose ps
```

Vous devez voir:
```
NAME                COMMAND             STATUS
erp_lscm_postgres   postgres            Up 10 seconds
erp_lscm_redis      redis               Up 10 seconds
```

### 4️⃣ Installer les dépendances Node

```bash
npm install
```

Cela prendra 2-3 minutes la première fois.

### 5️⃣ Initialiser la base de données

```bash
# Créer les tables et schéma
npm run db:push

# Ajouter des données de test
npm run db:seed
```

Vous devez voir à la fin:
```
✅ Database seeded successfully!

TEST CREDENTIALS:
📦 ADMIN: admin@lscm.com / Admin123!
...
```

### 6️⃣ Démarrer le serveur

```bash
npm run dev
```

Vous devez voir:
```
╔════════════════════════════════════════════════════════════╗
║        🚀 LSCM ERP Server Started                         ║
║        Environment: development                            ║
║        URL: http://localhost:3000                          ║
║        Database: configured                                ║
╚════════════════════════════════════════════════════════════╝
```

✅ **Le serveur tourne maintenant!**

---

## 🧪 Tester l'API

### Via curl (terminal)

```bash
# 1. Health check
curl http://localhost:3000/health

# Résultat attendu:
# {"status":"ok","timestamp":"2024-03-04T...","environment":"development"}
```

```bash
# 2. Login
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@lscm.com",
    "password": "Admin123!"
  }'

# Résultat attendu: tokens générés
```

### Via Postman (recommandé)

1. **Télécharger Postman**: https://www.postman.com/downloads/
2. **Importer la collection** (à créer):
   - File → Import → Url
   - (Je vais créer la collection Postman)
3. **Sélectionner l'environment** `development`
4. **Tester les endpoints**

### Via VS Code REST Client

Installer l'extension: [REST Client](https://marketplace.visualstudio.com/items?itemName=humao.rest-client)

Créer un fichier `test.http`:
```http
### Login
POST http://localhost:3000/api/v1/auth/login
Content-Type: application/json

{
  "email": "admin@lscm.com",
  "password": "Admin123!"
}

### Get Orders (remplacer TOKEN)
GET http://localhost:3000/api/v1/orders
Authorization: Bearer TOKEN_FROM_LOGIN

### Create Order
POST http://localhost:3000/api/v1/orders
Authorization: Bearer TOKEN_FROM_LOGIN
Content-Type: application/json

{
  "clientId": "YOUR_COMPANY_ID",
  "originCountry": "China",
  "destinationCountry": "Senegal",
  "totalWeight": 5000,
  "totalVolume": 20,
  "totalValue": 150000,
  "incoterms": "CIF",
  "preferredMode": "SEA",
  "items": [
    {
      "description": "Equipment",
      "quantity": 10,
      "unitPrice": 10000,
      "weight": 3000,
      "volume": 15
    }
  ]
}
```

Click sur "Send Request" pour tester.

---

## 🗄️ Gérer la Base de Données

### Voir les données (Web UI)

```bash
# Adminer UI
open http://localhost:8080

# Connexion:
# Système: PostgreSQL
# Serveur: postgres
# Utilisateur: lscm_user
# Mot de passe: lscm_password_dev
# Base: erp_lscm_dev
```

### Voir les données (Terminal)

```bash
# Ouvrir Prisma Studio (UI interactive)
npm run db:studio

# Cela ouvrira http://localhost:5555
```

### Réinitialiser la base complètement

```bash
# ⚠️ DESTRUCTIF - efface tout!
npm run db:push -- --force-reset

# Puis re-seed
npm run db:seed
```

---

## 📝 Structure du Projet Expliquée

```
erp-lscm/
│
├── src/                          # Code source TypeScript
│   ├── index.ts                  # Point d'entrée principal
│   ├── middleware/               # Fonctions middleware Express
│   │   └── auth.ts              # Authentification + RBAC
│   ├── routes/                   # Routes API
│   │   ├── auth.ts              # Login, register, refresh
│   │   └── orders.ts            # CRUD commandes
│   ├── services/                 # Logique métier
│   │   ├── AuthService.ts       # Hash password, JWT
│   │   └── OrderService.ts      # Gestion commandes
│   └── utils/                    # Utilitaires
│
├── prisma/
│   ├── schema.prisma             # Définition base de données
│   └── seed.ts                   # Données de test
│
├── dist/                         # Code compilé (généré)
├── node_modules/                 # Dépendances npm (généré)
│
├── package.json                  # Dépendances + scripts npm
├── tsconfig.json                 # Config TypeScript
├── docker-compose.yml            # Services Docker
├── Dockerfile                    # Image production
├── .env.example                  # Template variables env
└── README.md                     # Documentation
```

### Fichiers importants à comprendre:

| Fichier | Rôle | À connaître |
|---------|------|-------------|
| `src/index.ts` | Serveur principal | Port 3000, Socket.io, routes |
| `prisma/schema.prisma` | Structure BD | Tables, relations, enums |
| `src/services/` | Logique métier | Où écrire la business logic |
| `src/routes/` | APIs | Les endpoints disponibles |
| `src/middleware/auth.ts` | Authentification | JWT, rôles, permissions |
| `.env` | Configuration | Variables secrets |

---

## 🔐 Utilisateurs de Test

Après `npm run db:seed`, vous avez 4 utilisateurs:

| Email | Mot de passe | Rôle | Entreprise |
|-------|-------------|------|-----------|
| `admin@lscm.com` | `Admin123!` | ADMIN | LSCM Ltd |
| `coordinator@lscm.com` | `Coord123!` | CUSTOMER_SERVICE | LSCM Ltd |
| `logistics@total.sn` | `Client123!` | CLIENT | Total Senegal |
| `broker@dakarcb.com` | `Broker123!` | CUSTOMS_BROKER | Dakar Customs Brokers |

**Test:** Loginez-vous avec chacun pour voir les différentes permissions!

---

## 📚 Commandes Utiles

```bash
# Développement
npm run dev                    # Démarrer en mode watch (hot reload)
npm run build                  # Compiler TypeScript → JavaScript
npm start                      # Lancer version compilée

# Base de données
npm run db:push               # Appliquer schéma à la BD
npm run db:seed               # Ajouter données de test
npm run db:studio             # Ouvrir UI interactive (http://5555)

# Code quality
npm run lint                   # Vérifier erreurs TypeScript
npm run format                 # Auto-formatter code

# Tests
npm test                       # Lancer tous les tests
npm run test:watch            # Mode watch (re-run on changes)

# Docker
docker-compose up -d          # Démarrer services
docker-compose down           # Arrêter services
docker-compose logs           # Voir les logs
docker-compose ps             # Status des services
```

---

## 🐛 Troubleshooting

### "Cannot find module 'dotenv'"
```bash
npm install
```

### "Port 3000 already in use"
```bash
# Changer le port dans .env
PORT=3001

# Ou tuer le processus qui utilise 3000
lsof -i :3000
kill -9 PID
```

### "PostgreSQL connection refused"
```bash
# Vérifier que Docker est lancé
docker-compose ps

# Si postgres n'est pas UP, relancer:
docker-compose down
docker-compose up -d
```

### "EACCES: permission denied"
```bash
# Sur Mac/Linux, utiliser sudo si nécessaire
sudo npm install
```

### Tests échouent
```bash
# Réinitialiser la base de test
npm run db:push -- --force-reset
npm run db:seed
npm test
```

---

## 🚀 Prochaines Étapes

Une fois que le serveur tourne OK:

### 1. **Explorer les APIs existantes**
- Créer un utilisateur via `/auth/register`
- Créer une commande via `/orders`
- Modifier une commande via `PATCH /orders/:id`
- Voir la structure de réponse

### 2. **Étudier le code**
- Lire `src/services/AuthService.ts` pour comprendre la structure
- Voir comment `src/routes/orders.ts` utilise le service
- Comprendre le middleware auth

### 3. **Modifier & Tester**
- Essayer d'ajouter une route simple
- Ajouter un champ à Order
- Créer un nouveau service basé sur OrderService

### 4. **Préparer Phase 1A**
- Me contacter pour démarrer ShipmentService
- Préparer les spécifications métier (modes transport, routes, etc.)

---

## 📞 Questions Fréquentes

**Q: Je peux modifier le code?**
A: Oui! Le code est vôtre. Modifiez, testez, expérimentez. Utilisez `npm run dev` pour hot reload.

**Q: Les données de test disparaissent?**
A: Oui, après `docker-compose down`. Relancez `npm run db:seed`.

**Q: Comment en production?**
A: Via Docker: `docker build -t erp-lscm . && docker run ...`
Ou: `npm run build && npm start`

**Q: Je veux changer le JWT secret?**
A: Modifiez `.env`:
```
JWT_SECRET=votre_clé_très_secrète_ici
```

**Q: Besoin d'un frontend maintenant?**
A: Frontend React viendra après. Continuons backend d'abord.

---

## ✅ Checklist de Confirmation

Après avoir suivi ce guide, vous devez avoir:

- [ ] Node.js 18+ et npm installés
- [ ] Docker + Docker Compose lancés
- [ ] Dossier `erp-lscm` extrait
- [ ] `npm install` exécuté
- [ ] `npm run db:push` réussi
- [ ] `npm run db:seed` réussi
- [ ] `npm run dev` affiche "Server Started"
- [ ] `curl http://localhost:3000/health` retourne JSON
- [ ] Login possible avec `admin@lscm.com`
- [ ] Commandes listées via `/api/v1/orders`

Si tout ✅, vous êtes **prêt pour continuer le développement!**

---

**Besoin d'aide?**
📧 Répondez à ce message avec votre question ou erreur!

🎉 **Bienvenue dans votre ERP LSCM!**
