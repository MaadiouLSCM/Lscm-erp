#!/bin/bash
# deploy-master.sh - Universal deployment script for all cloud providers

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_section() {
    echo ""
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}║ $1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
}

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

show_menu() {
    clear
    echo -e "${GREEN}"
    cat << "EOF"
╔═══════════════════════════════════════════════════════════╗
║         LSCM ERP - CLOUD DEPLOYMENT MASTER              ║
║          Choose Your Cloud Provider                      ║
╚═══════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    
    echo ""
    echo "Select deployment target:"
    echo ""
    echo -e "${YELLOW}1)${NC} AWS (ECS + RDS + ElastiCache)"
    echo -e "${YELLOW}2)${NC} GCP (GKE + Cloud SQL + Memorystore)"
    echo -e "${YELLOW}3)${NC} Azure (AKS + Azure Database + Cache)"
    echo -e "${YELLOW}4)${NC} DigitalOcean (Managed Kubernetes)"
    echo -e "${YELLOW}5)${NC} Local Docker Compose"
    echo -e "${YELLOW}6)${NC} Deploy to Multiple Clouds"
    echo ""
    echo -e "${YELLOW}0)${NC} Exit"
    echo ""
}

deploy_aws() {
    log_section "AWS Deployment"
    
    echo "Enter AWS configuration:"
    read -p "AWS Region (default: us-east-1): " AWS_REGION
    AWS_REGION=${AWS_REGION:-"us-east-1"}
    
    read -p "AWS Account ID: " AWS_ACCOUNT_ID
    
    export AWS_REGION
    export AWS_ACCOUNT_ID
    
    log_info "Starting AWS deployment..."
    chmod +x aws/deploy-to-aws.sh
    bash aws/deploy-to-aws.sh
}

deploy_gcp() {
    log_section "GCP Deployment"
    
    echo "Enter GCP configuration:"
    read -p "GCP Project ID: " GCP_PROJECT
    read -p "GCP Region (default: us-central1): " GCP_REGION
    GCP_REGION=${GCP_REGION:-"us-central1"}
    
    export GCP_PROJECT
    export GCP_REGION
    
    log_info "Starting GCP deployment..."
    chmod +x gcp/deploy-to-gcp.sh
    bash gcp/deploy-to-gcp.sh
}

deploy_azure() {
    log_section "Azure Deployment"
    
    echo "Enter Azure configuration:"
    read -p "Azure Subscription ID: " AZURE_SUBSCRIPTION
    read -p "Azure Region (default: eastus): " AZURE_REGION
    AZURE_REGION=${AZURE_REGION:-"eastus"}
    
    export AZURE_SUBSCRIPTION
    export AZURE_REGION
    
    log_info "Starting Azure deployment..."
    chmod +x azure/deploy-to-azure.sh
    bash azure/deploy-to-azure.sh
}

deploy_digitalocean() {
    log_section "DigitalOcean Deployment"
    
    echo "Enter DigitalOcean configuration:"
    read -p "DigitalOcean API Token: " DIGITALOCEAN_TOKEN
    read -p "Cluster Region (default: nyc3): " DO_REGION
    DO_REGION=${DO_REGION:-"nyc3"}
    
    export DIGITALOCEAN_TOKEN
    
    log_info "Starting DigitalOcean deployment..."
    chmod +x digitalocean/deploy-to-digitalocean.sh
    bash digitalocean/deploy-to-digitalocean.sh
}

deploy_local() {
    log_section "Local Docker Compose Deployment"
    
    log_info "Starting local deployment..."
    
    docker-compose down 2>/dev/null || true
    docker-compose up -d
    
    log_info "Waiting for services..."
    sleep 30
    
    log_info "Running migrations..."
    docker-compose exec -T backend npx prisma migrate deploy
    
    log_info "Seeding database..."
    docker-compose exec -T backend npx prisma db seed
    
    log_section "Local Deployment Complete!"
    echo ""
    echo "Services available at:"
    echo "  API: http://localhost:3000/api/docs"
    echo "  Frontend: http://localhost:3001"
    echo "  pgAdmin: http://localhost:5050"
    echo ""
}

deploy_all_clouds() {
    log_section "Multi-Cloud Deployment"
    
    echo "This will deploy to all cloud providers"
    read -p "Continue? (y/n): " CONFIRM
    
    if [ "$CONFIRM" != "y" ]; then
        log_info "Deployment cancelled"
        return
    fi
    
    log_info "Deploying to AWS..."
    deploy_aws || log_error "AWS deployment failed"
    
    log_info "Deploying to GCP..."
    deploy_gcp || log_error "GCP deployment failed"
    
    log_info "Deploying to Azure..."
    deploy_azure || log_error "Azure deployment failed"
    
    log_info "Deploying to DigitalOcean..."
    deploy_digitalocean || log_error "DigitalOcean deployment failed"
    
    log_section "Multi-Cloud Deployment Complete!"
}

main() {
    while true; do
        show_menu
        
        read -p "Select option (0-6): " CHOICE
        
        case $CHOICE in
            1)
                deploy_aws
                read -p "Press Enter to continue..."
                ;;
            2)
                deploy_gcp
                read -p "Press Enter to continue..."
                ;;
            3)
                deploy_azure
                read -p "Press Enter to continue..."
                ;;
            4)
                deploy_digitalocean
                read -p "Press Enter to continue..."
                ;;
            5)
                deploy_local
                read -p "Press Enter to continue..."
                ;;
            6)
                deploy_all_clouds
                read -p "Press Enter to continue..."
                ;;
            0)
                log_info "Exiting..."
                exit 0
                ;;
            *)
                log_error "Invalid option"
                read -p "Press Enter to continue..."
                ;;
        esac
    done
}

main "$@"
