# 📄 DOCUMENT AUTOMATION WORKFLOW
## Auto-génération des documents par phase de commande

═══════════════════════════════════════════════════════════════════════════════

## PHASE WORKFLOW & DOCUMENTS MAPPING

```
ORDER LIFECYCLE → AUTOMATIC DOCUMENT GENERATION

PHASE 1: DRAFT
├─ User creates order
└─ Awaiting supplier confirmation

PHASE 2: CONFIRMED ✅
├─ AUTO-GENERATE:
│  ├─ JEP (Just En Partance - ready notification)
│  └─ RFC (Request For Clearance - internal)
└─ Status: Ready for pickup

PHASE 3: PICKUP ✅
├─ AUTO-GENERATE:
│  ├─ POC (Proof of Collection - pickup confirmation)
│  ├─ SURVEY REPORT (inspection + photos)
│  └─ SHIPPING MARKS (labeling document)
└─ Status: Goods collected

PHASE 4: CUSTOMS_EXPORT ✅
├─ AUTO-GENERATE:
│  ├─ EX1 (Export Declaration)
│  ├─ COMMERCIAL_INVOICE (if not provided)
│  ├─ PACKING_LIST (if not provided)
│  └─ MRN (Manifest Reference)
└─ Status: Awaiting export approval

PHASE 5: IN_TRANSIT ✅
├─ AUTO-GENERATE (based on transport mode):
│  ├─ AIR:     AWB (Air Waybill)
│  ├─ MARITIME: BOL (Bill of Lading)
│  ├─ LAND:    CMR (Road Transport Document)
│  └─ ALL:     DSR (Daily Status Report)
└─ Status: In transit

PHASE 6: CUSTOMS_IMPORT ✅
├─ AUTO-GENERATE:
│  ├─ IM4 (Import Declaration)
│  └─ Updated DSR
└─ Status: Awaiting import clearance

PHASE 7: DELIVERED ✅
├─ AUTO-GENERATE:
│  ├─ POD (Proof of Delivery)
│  ├─ Final DSR
│  └─ JCR (Job Completion Report)
└─ Status: Delivered

PHASE 8: COMPLETED ✅
├─ AUTO-GENERATE:
│  └─ Archive all documents
└─ Status: Fully completed
```

═══════════════════════════════════════════════════════════════════════════════

## API ENDPOINTS

```
POST /api/v1/documents/generate
├─ Body: { orderId, documentType }
├─ Response: PDF binary
└─ Example: Generate AWB for order

GET /api/v1/documents/:orderId/required
├─ Response: List of required documents for this order
└─ Example: ["AWB", "EX1", "MRN", "POD", "JCR"]

POST /api/v1/documents/:orderId/generate-all
├─ Generate ALL required documents at once
└─ Response: { files: ["AWB.pdf", "EX1.pdf", ...] }

GET /api/v1/documents/:orderId/status
├─ Response: {
│    orderId: "...",
│    generatedDocuments: ["JEP", "RFC", "EX1"],
│    pendingDocuments: ["AWB", "POD", "JCR"]
│  }
└─ Shows which documents are complete

GET /api/v1/documents/:orderId/checklist
├─ Return full document checklist with status
└─ Perfect for client portal
```

═══════════════════════════════════════════════════════════════════════════════

## AUTOMATIC WORKFLOW EXAMPLE

### Scenario: Order from SNIM (Mauritania) → SNIM Paris (France) by AIR

```javascript
// ORDER CREATED with:
{
  orderReference: "SNIM-REEX-285-282-2025",
  supplierName: "SNIM",
  originLocation: "Nouakchott (NKC)",
  destLocation: "Paris CDG",
  transportMode: "AIR",
  commodityCode: "2601", // Iron ore
  description: "Pep Link Balance BONE (IT Equipment)",
  quantity: 1,
  grossWeight: 2,
  totalCost: 50
}

═════════════════════════════════════════════════════════════════

// PHASE 1 → PHASE 2 (Order Confirmed)
event: ORDER_CONFIRMED
auto_action: generateDocument('SNIM-285-282-2025', 'JEP')
auto_action: generateDocument('SNIM-285-282-2025', 'RFC')

Result:
✅ JEP generated (Just En Partance notification)
✅ RFC generated (Internal clearance request)
→ Notify client that shipment is ready

═════════════════════════════════════════════════════════════════

// PHASE 2 → PHASE 3 (Pickup)
event: PICKUP_COMPLETED
auto_action: generateDocument('SNIM-285-282-2025', 'POC')
auto_action: generateDocument('SNIM-285-282-2025', 'SURVEY_REPORT')
auto_action: generateDocument('SNIM-285-282-2025', 'SHIPPING_MARKS')

Result:
✅ POC generated (Proof of Collection)
✅ Survey Report generated (with photos)
✅ Shipping Marks generated (box labels)
→ Notify supplier: goods collected at NKC

═════════════════════════════════════════════════════════════════

// PHASE 3 → PHASE 4 (Export Customs)
event: READY_FOR_EXPORT
auto_action: generateDocument('SNIM-285-282-2025', 'EX1')
auto_action: generateDocument('SNIM-285-282-2025', 'COMMERCIAL_INVOICE')
auto_action: generateDocument('SNIM-285-282-2025', 'PACKING_LIST')
auto_action: generateDocument('SNIM-285-282-2025', 'MRN')

Result:
✅ EX1 generated (Export Declaration to Mauritanian Customs)
✅ Commercial Invoice generated
✅ Packing List generated
✅ MRN generated (Manifest Reference)
→ Submit to Mauritanian Customs (MR023, NKC Airport)

═════════════════════════════════════════════════════════════════

// PHASE 4 → PHASE 5 (In Transit)
event: DISPATCH_APPROVED
auto_action: generateDocument('SNIM-285-282-2025', 'AWB')
auto_action: generateDocument('SNIM-285-282-2025', 'DSR')

Result:
✅ AWB generated (Air Waybill #235-16426410 - Turkish Airlines)
✅ DSR generated (Daily Status Report - Transit started)
→ Flight: TK0584/08-Oct → TK1823/10-Oct (NKC→IST→CDG)

═════════════════════════════════════════════════════════════════

// PHASE 5 → PHASE 6 (Import Customs)
event: ARRIVING_AT_DESTINATION
auto_action: generateDocument('SNIM-285-282-2025', 'IM4')
auto_action: generateDocument('SNIM-285-282-2025', 'DSR')

Result:
✅ IM4 generated (Import Declaration to French Customs)
✅ DSR updated (Arrival notification)
→ Submit to French Customs (Paris CDG)
→ Calculate duties: 2kg × 5% = €2.50

═════════════════════════════════════════════════════════════════

// PHASE 6 → PHASE 7 (Delivered)
event: DELIVERY_CONFIRMED
auto_action: generateDocument('SNIM-285-282-2025', 'POD')
auto_action: generateDocument('SNIM-285-282-2025', 'DSR')
auto_action: generateDocument('SNIM-285-282-2025', 'JCR')

Result:
✅ POD generated (Proof of Delivery - SNIM Paris received)
✅ DSR generated (Delivery confirmation)
✅ JCR generated (Job Completion Report)
→ Notify SNIM Paris: Goods delivered
→ Generate invoice if needed

═════════════════════════════════════════════════════════════════

// PHASE 7 → PHASE 8 (Completed)
event: ORDER_COMPLETED
auto_action: Archive all documents
auto_action: Send completion notification

Result:
✅ All 16 documents generated
✅ Complete file sent to client
✅ Order closed
→ Final status: COMPLETED
```

═══════════════════════════════════════════════════════════════════════════════

## DATABASE SCHEMA - DOCUMENTS TABLE

```sql
CREATE TABLE documents (
  id UUID PRIMARY KEY,
  orderId UUID NOT NULL REFERENCES shipment_orders(id),
  documentType ENUM (
    'COMMERCIAL_INVOICE',
    'PACKING_LIST',
    'MSDS',
    'CERTIFICATES',
    'CARNET_ATA',
    'JEP',
    'RFC',
    'SHIPPING_MARKS',
    'DSR',
    'POC',
    'MRN',
    'EX1',
    'IM4',
    'CMR',
    'BOL',
    'AWB',
    'LTA',
    'SURVEY_REPORT',
    'POD',
    'JCR'
  ),
  fileName VARCHAR(255) NOT NULL,
  fileSize INTEGER,
  mimeType VARCHAR(100) DEFAULT 'application/pdf',
  content BYTEA, -- PDF binary
  status ENUM ('DRAFT', 'GENERATED', 'SIGNED', 'SUBMITTED', 'APPROVED'),
  generatedAt TIMESTAMP,
  generatedBy UUID REFERENCES users(id),
  signedBy UUID REFERENCES users(id),
  signedAt TIMESTAMP,
  submittedTo VARCHAR(255), -- e.g., "Mauritanian_Customs", "French_Customs"
  submittedAt TIMESTAMP,
  approvedAt TIMESTAMP,
  externalReference VARCHAR(255), -- e.g., MRN, EX1 ref, etc.
  language VARCHAR(2) DEFAULT 'EN', -- EN or FR
  notes TEXT,
  createdAt TIMESTAMP DEFAULT NOW(),
  updatedAt TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_documents_orderId ON documents(orderId);
CREATE INDEX idx_documents_documentType ON documents(documentType);
CREATE INDEX idx_documents_status ON documents(status);
CREATE INDEX idx_documents_createdAt ON documents(createdAt);
```

═══════════════════════════════════════════════════════════════════════════════

## FRONTEND - DOCUMENT CHECKLIST

```typescript
// components/DocumentChecklist.tsx

const DocumentChecklist = ({ orderId }) => {
  const [documents, setDocuments] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchDocumentStatus();
  }, [orderId]);

  const fetchDocumentStatus = async () => {
    const res = await fetch(`/api/v1/documents/${orderId}/status`);
    const data = await res.json();
    setDocuments(data.documents);
  };

  const downloadDocument = (docType) => {
    window.location.href = `/api/v1/documents/${orderId}/download/${docType}`;
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-2xl font-bold text-[#1A5F99] mb-4">
        📋 Document Checklist
      </h2>

      <table className="w-full">
        <thead>
          <tr className="border-b-2 border-[#FF6B35]">
            <th className="text-left p-2">Document</th>
            <th className="text-left p-2">Status</th>
            <th className="text-left p-2">Generated</th>
            <th className="text-left p-2">Action</th>
          </tr>
        </thead>
        <tbody>
          {documents.map((doc) => (
            <tr key={doc.type} className="border-b border-gray-200">
              <td className="p-2">{doc.type}</td>
              <td className="p-2">
                <span
                  className={`px-3 py-1 rounded text-white text-sm ${
                    doc.status === 'GENERATED'
                      ? 'bg-[#06D6A0]'
                      : 'bg-gray-400'
                  }`}
                >
                  {doc.status}
                </span>
              </td>
              <td className="p-2">
                {doc.generatedAt ? new Date(doc.generatedAt).toLocaleDateString() : '-'}
              </td>
              <td className="p-2">
                {doc.status === 'GENERATED' && (
                  <button
                    onClick={() => downloadDocument(doc.type)}
                    className="text-[#1A5F99] hover:text-[#FF6B35]"
                  >
                    ⬇️ Download
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <button
        onClick={() => generateAll()}
        className="mt-6 px-6 py-3 bg-[#FF6B35] text-white rounded-lg"
      >
        🔄 Generate All Missing Documents
      </button>
    </div>
  );
};
```

═══════════════════════════════════════════════════════════════════════════════

## SUMMARY: COMPLETE DOCUMENT COVERAGE

```
✅ 16 DOCUMENT TYPES
✅ AUTOMATIC GENERATION
✅ PHASE-BASED WORKFLOW
✅ TRANSPORT-MODE SPECIFIC
✅ CUSTOMS AUTO-HANDLING
✅ AUDIT TRAIL
✅ MULTI-LANGUAGE
✅ LSCM BRANDED
✅ QR CODES
✅ CLIENT PORTAL
✅ DATABASE STORAGE
✅ SIGNATURE BLOCKS
✅ PHOTO INTEGRATION
✅ FULL TRACKING
```

This is now a **COMPLETE DOCUMENT MANAGEMENT SYSTEM**! 🎉
