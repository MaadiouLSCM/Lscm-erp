#!/bin/bash
# scripts/deploy-to-production.sh
# Complete automated deployment to Kubernetes

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}╔════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║          LSCM ERP - PRODUCTION DEPLOYMENT SCRIPT              ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════════╝${NC}"

# Configuration
NAMESPACE=${NAMESPACE:-"lscm-prod"}
DOCKER_REGISTRY=${DOCKER_REGISTRY:-"docker.io"}
DOCKER_IMAGE=${DOCKER_IMAGE:-"lscm/erp"}
VERSION=${VERSION:-"latest"}
CLUSTER=${CLUSTER:-"prod-cluster"}
REGION=${REGION:-"us-east-1"}

# Functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed"
        exit 1
    fi
    
    # Check kubectl
    if ! command -v kubectl &> /dev/null; then
        log_error "kubectl is not installed"
        exit 1
    fi
    
    # Check kubeconfig
    if [ ! -f "$HOME/.kube/config" ]; then
        log_error "kubeconfig not found"
        exit 1
    fi
    
    log_info "✓ All prerequisites met"
}

build_docker_image() {
    log_info "Building Docker image..."
    
    docker build \
        -t ${DOCKER_REGISTRY}/${DOCKER_IMAGE}:${VERSION} \
        -t ${DOCKER_REGISTRY}/${DOCKER_IMAGE}:latest \
        .
    
    log_info "✓ Docker image built successfully"
}

push_docker_image() {
    log_info "Pushing Docker image to registry..."
    
    docker push ${DOCKER_REGISTRY}/${DOCKER_IMAGE}:${VERSION}
    docker push ${DOCKER_REGISTRY}/${DOCKER_IMAGE}:latest
    
    log_info "✓ Docker image pushed successfully"
}

verify_kubernetes_cluster() {
    log_info "Verifying Kubernetes cluster..."
    
    kubectl cluster-info
    kubectl get nodes
    
    log_info "✓ Cluster is accessible"
}

create_namespace() {
    log_info "Creating namespace..."
    
    kubectl create namespace ${NAMESPACE} --dry-run=client -o yaml | kubectl apply -f -
    
    log_info "✓ Namespace created/verified"
}

create_secrets() {
    log_info "Creating secrets..."
    
    if [ ! -f .env.production ]; then
        log_error ".env.production not found"
        exit 1
    fi
    
    # Load environment variables
    source .env.production
    
    # Create secret (delete if exists)
    kubectl delete secret lscm-erp-secrets -n ${NAMESPACE} 2>/dev/null || true
    
    kubectl create secret generic lscm-erp-secrets \
        --from-literal=DATABASE_URL="$DATABASE_URL" \
        --from-literal=JWT_SECRET="$JWT_SECRET" \
        --from-literal=REDIS_URL="$REDIS_URL" \
        --from-literal=CLEAR_API_KEY="$CLEAR_API_KEY" \
        --from-literal=SAP_BW_API_TOKEN="$SAP_BW_API_TOKEN" \
        --from-literal=ACCESS_BANK_API_KEY="$ACCESS_BANK_API_KEY" \
        --from-literal=SENDGRID_API_KEY="$SENDGRID_API_KEY" \
        -n ${NAMESPACE}
    
    log_info "✓ Secrets created"
}

deploy_infrastructure() {
    log_info "Deploying infrastructure (PostgreSQL, Redis)..."
    
    # Deploy PostgreSQL
    kubectl apply -f k8s/postgres-pvc.yaml -n ${NAMESPACE}
    kubectl apply -f k8s/postgres-deployment.yaml -n ${NAMESPACE}
    
    # Wait for PostgreSQL
    kubectl wait --for=condition=ready pod \
        -l app=lscm-postgres \
        -n ${NAMESPACE} \
        --timeout=300s
    
    # Deploy Redis
    kubectl apply -f k8s/redis-deployment.yaml -n ${NAMESPACE}
    
    # Wait for Redis
    kubectl wait --for=condition=ready pod \
        -l app=lscm-redis \
        -n ${NAMESPACE} \
        --timeout=300s
    
    log_info "✓ Infrastructure deployed"
}

run_migrations() {
    log_info "Running database migrations..."
    
    kubectl run -i --rm \
        --image=${DOCKER_REGISTRY}/${DOCKER_IMAGE}:${VERSION} \
        --restart=Never \
        migration-job-${VERSION} \
        -n ${NAMESPACE} \
        -- npx prisma migrate deploy
    
    log_info "✓ Migrations completed"
}

seed_database() {
    log_info "Seeding database with sample data..."
    
    kubectl run -i --rm \
        --image=${DOCKER_REGISTRY}/${DOCKER_IMAGE}:${VERSION} \
        --restart=Never \
        seed-job-${VERSION} \
        -n ${NAMESPACE} \
        -- npx prisma db seed
    
    log_info "✓ Database seeded"
}

deploy_application() {
    log_info "Deploying application..."
    
    # Update image tag in deployment
    sed "s|IMAGE_TAG|${VERSION}|g" k8s/backend-deployment.yaml | \
        kubectl apply -f - -n ${NAMESPACE}
    
    # Wait for deployment
    kubectl rollout status deployment/lscm-backend \
        -n ${NAMESPACE} \
        --timeout=300s
    
    log_info "✓ Application deployed"
}

deploy_ingress() {
    log_info "Deploying ingress..."
    
    kubectl apply -f k8s/ingress.yaml -n ${NAMESPACE}
    
    # Wait for LoadBalancer IP
    sleep 10
    
    INGRESS_IP=$(kubectl get ingress -n ${NAMESPACE} -o jsonpath='{.items[0].status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "pending")
    
    if [ "$INGRESS_IP" != "pending" ]; then
        log_info "✓ Ingress deployed (IP: $INGRESS_IP)"
    else
        log_warn "Ingress IP pending (may take a few minutes)"
    fi
}

deploy_monitoring() {
    log_info "Deploying monitoring (Prometheus, Grafana)..."
    
    kubectl apply -f k8s/monitoring/prometheus-configmap.yaml -n ${NAMESPACE}
    kubectl apply -f k8s/monitoring/prometheus-deployment.yaml -n ${NAMESPACE}
    kubectl apply -f k8s/monitoring/grafana-deployment.yaml -n ${NAMESPACE}
    
    log_info "✓ Monitoring deployed"
}

health_check() {
    log_info "Running health checks..."
    
    # Wait for deployment
    kubectl wait --for=condition=available --timeout=300s \
        deployment/lscm-backend -n ${NAMESPACE}
    
    # Test API endpoint
    POD=$(kubectl get pod -n ${NAMESPACE} -l app=lscm-backend -o jsonpath='{.items[0].metadata.name}')
    
    if kubectl exec -it ${POD} -n ${NAMESPACE} -- curl -s http://localhost:3000/health > /dev/null; then
        log_info "✓ API health check passed"
    else
        log_error "API health check failed"
        exit 1
    fi
    
    log_info "✓ All health checks passed"
}

create_backup() {
    log_info "Creating baseline backup..."
    
    POD=$(kubectl get pod -n ${NAMESPACE} -l app=lscm-postgres -o jsonpath='{.items[0].metadata.name}')
    
    kubectl exec -it ${POD} -n ${NAMESPACE} -- \
        pg_dump -U lscm_user lscm_erp > backup-$(date +%s).sql
    
    log_info "✓ Backup created"
}

post_deployment() {
    log_info "Post-deployment tasks..."
    
    log_info "✓ Listing deployed resources:"
    kubectl get all -n ${NAMESPACE}
    
    log_info ""
    log_info "============================================"
    log_info "DEPLOYMENT COMPLETE!"
    log_info "============================================"
    log_info ""
    log_info "API Endpoint:"
    kubectl get ingress -n ${NAMESPACE} -o wide
    log_info ""
    log_info "Monitor deployment:"
    log_info "  kubectl logs -f deployment/lscm-backend -n ${NAMESPACE}"
    log_info ""
    log_info "Access dashboards:"
    log_info "  Grafana: kubectl port-forward svc/grafana 3000:80 -n ${NAMESPACE}"
    log_info "  Prometheus: kubectl port-forward svc/prometheus 9090:9090 -n ${NAMESPACE}"
    log_info ""
}

# Main execution
main() {
    check_prerequisites
    build_docker_image
    push_docker_image
    verify_kubernetes_cluster
    create_namespace
    create_secrets
    deploy_infrastructure
    run_migrations
    seed_database
    deploy_application
    deploy_ingress
    deploy_monitoring
    health_check
    create_backup
    post_deployment
}

# Error handling
trap 'log_error "Deployment failed at line $LINENO"' ERR

# Run main
main

#!/bin/bash
# scripts/rollback-deployment.sh
# Rollback to previous version

set -e

NAMESPACE=${NAMESPACE:-"lscm-prod"}

echo "Rolling back LSCM ERP deployment..."

kubectl rollout undo deployment/lscm-backend -n ${NAMESPACE}
kubectl rollout status deployment/lscm-backend -n ${NAMESPACE} --timeout=300s

echo "✓ Rollback completed"

#!/bin/bash
# scripts/health-check.sh
# Verify system health

NAMESPACE=${NAMESPACE:-"lscm-prod"}

echo "🏥 LSCM ERP Health Check"
echo "========================"

# Check pods
echo ""
echo "Pod Status:"
kubectl get pods -n ${NAMESPACE}

# Check services
echo ""
echo "Service Status:"
kubectl get svc -n ${NAMESPACE}

# Check database connection
echo ""
echo "Database Connection:"
DB_POD=$(kubectl get pod -n ${NAMESPACE} -l app=lscm-postgres -o jsonpath='{.items[0].metadata.name}')
if kubectl exec -it ${DB_POD} -n ${NAMESPACE} -- psql -U lscm_user -d lscm_erp -c "SELECT 1" > /dev/null 2>&1; then
    echo "✓ Database: OK"
else
    echo "✗ Database: FAILED"
fi

# Check Redis
echo ""
echo "Redis Connection:"
REDIS_POD=$(kubectl get pod -n ${NAMESPACE} -l app=lscm-redis -o jsonpath='{.items[0].metadata.name}')
if kubectl exec -it ${REDIS_POD} -n ${NAMESPACE} -- redis-cli ping > /dev/null 2>&1; then
    echo "✓ Redis: OK"
else
    echo "✗ Redis: FAILED"
fi

# Check API
echo ""
echo "API Status:"
API_POD=$(kubectl get pod -n ${NAMESPACE} -l app=lscm-backend -o jsonpath='{.items[0].metadata.name}')
if kubectl exec -it ${API_POD} -n ${NAMESPACE} -- curl -s http://localhost:3000/health > /dev/null 2>&1; then
    echo "✓ API: OK"
else
    echo "✗ API: FAILED"
fi

# Check metrics
echo ""
echo "Resource Usage:"
kubectl top pods -n ${NAMESPACE} 2>/dev/null || echo "Metrics not available yet"

echo ""
echo "========================"
echo "Health check completed"

#!/bin/bash
# scripts/setup-monitoring.sh
# Setup Prometheus and Grafana

NAMESPACE=${NAMESPACE:-"lscm-prod"}

echo "Setting up monitoring..."

# Install Prometheus
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

helm upgrade --install prometheus prometheus-community/prometheus \
  --namespace ${NAMESPACE} \
  --values k8s/monitoring/prometheus-values.yaml

# Install Grafana
helm repo add grafana https://grafana.github.io/helm-charts

helm upgrade --install grafana grafana/grafana \
  --namespace ${NAMESPACE} \
  --values k8s/monitoring/grafana-values.yaml

echo "✓ Monitoring setup completed"
echo ""
echo "Access Grafana:"
echo "  kubectl port-forward svc/grafana 3000:80 -n ${NAMESPACE}"
echo ""
echo "Get Grafana password:"
echo "  kubectl get secret grafana -n ${NAMESPACE} -o jsonpath=\"{.data.admin-password}\" | base64 --decode"
