# 🔧 IMPLÉMENTATION TECHNIQUE - NOTIFICATION ENGINE

## Architecture Générale

```
┌──────────────────────────────────────────────────────────┐
│                  NOTIFICATION ENGINE                     │
├──────────────────────────────────────────────────────────┤
│                                                           │
│  EVENT TRIGGERS                                          │
│  ├─ Status change (Order, Shipment, Task)               │
│  ├─ Document upload (completed, approved)               │
│  ├─ Task deadline approaching                           │
│  ├─ Manual trigger (coordinator action)                 │
│  └─ Scheduled (daily reminders, etc)                    │
│           │                                              │
│           ▼                                              │
│  ┌─────────────────────────────────────────┐            │
│  │  RULES ENGINE                           │            │
│  ├─────────────────────────────────────────┤            │
│  │ Rule: If status = PICKED_UP             │            │
│  │   AND documents complete                │            │
│  │   THEN notify client                    │            │
│  └─────────────────────────────────────────┘            │
│           │                                              │
│           ▼                                              │
│  ┌─────────────────────────────────────────┐            │
│  │  TEMPLATE ENGINE                        │            │
│  ├─────────────────────────────────────────┤            │
│  │ Load: EmailTemplate for PICKED_UP       │            │
│  │ Replace: [DATE], [LOCATION], etc        │            │
│  │ Result: Final message ready to send     │            │
│  └─────────────────────────────────────────┘            │
│           │                                              │
│           ▼                                              │
│  ┌─────────────────────────────────────────┐            │
│  │  DISPATCH ENGINE                        │            │
│  ├─────────────────────────────────────────┤            │
│  │ Channel: Email (SendGrid)               │            │
│  │ Channel: SMS (Twilio)                   │            │
│  │ Channel: Push (FCM)                     │            │
│  │ Channel: In-app (Database)              │            │
│  │ Channel: Webhook (Partners)             │            │
│  └─────────────────────────────────────────┘            │
│           │                                              │
│           ▼                                              │
│  ┌─────────────────────────────────────────┐            │
│  │  AUDIT LOGGER                           │            │
│  ├─────────────────────────────────────────┤            │
│  │ Log: What, When, To Whom, Status       │            │
│  │ Store: In AuditLog table                │            │
│  │ Enable: Compliance, Troubleshooting     │            │
│  └─────────────────────────────────────────┘            │
│                                                           │
└──────────────────────────────────────────────────────────┘
```

---

## 1. DATABASE SCHEMA ADDITIONS

### NotificationTemplate Table

```typescript
// prisma/schema.prisma additions

model NotificationTemplate {
  id        String   @id @default(cuid())
  
  // Trigger conditions
  shipmentPhase    String  // PICKUP, RECEPTION, BOOKING, etc
  shipmentStatus   String  // PICKUP_SCHEDULED, PICKED_UP, etc
  triggerEvent     String  // STATUS_CHANGED, DOCUMENT_UPLOADED, DEADLINE, etc
  
  // Recipient
  recipientType    String  // CLIENT, VENDOR, AGENT, BROKER, LSCM_TEAM
  recipientRole    UserRole? // For LSCM_TEAM, which role
  
  // Message content
  messageType      String  // EMAIL, SMS, WHATSAPP, INTERNAL, PUSH
  subject          String?  // For emails
  templateBody     String   // HTML or plain text with placeholders
  placeholders     String[] @default([]) // [DATE], [LOCATION], [REFERENCE]
  
  // Multi-language support
  language         String   @default("EN") // EN, FR, ES, AR
  
  // Conditional rules (JSON for flexibility)
  conditions       Json?   // {"requireDocuments": true, "includeValue": true}
  
  // Priority & retry
  priority         String   @default("NORMAL") // LOW, NORMAL, HIGH, URGENT
  retryOnFailure   Boolean  @default(true)
  maxRetries       Int      @default(3)
  retryInterval    Int      @default(300) // seconds
  
  // Configuration
  isActive         Boolean  @default(true)
  createdAt        DateTime @default(now())
  updatedAt        DateTime @updatedAt
  createdBy        User     @relation(fields: [createdById], references: [id])
  createdById      String

  @@unique([shipmentStatus, recipientType, messageType, language])
  @@index([shipmentStatus])
  @@index([isActive])
}

model Notification {
  id        String   @id @default(cuid())
  
  // What triggered it
  shipment  Shipment @relation(fields: [shipmentId], references: [id])
  shipmentId String
  
  template  NotificationTemplate @relation(fields: [templateId], references: [id])
  templateId String
  
  // Recipient
  recipient User     @relation(fields: [recipientId], references: [id])
  recipientId String
  
  // Message details
  subject   String?
  body      String   // Final rendered message
  channel   String   // EMAIL, SMS, WHATSAPP, etc
  
  // Status tracking
  status    String   @default("PENDING") // PENDING, SENT, DELIVERED, FAILED, BOUNCED
  sentAt    DateTime?
  deliveredAt DateTime?
  failureReason String?
  retryCount Int      @default(0)
  
  // Reference for replies
  externalId String?  // From email service, SMS API, etc
  
  // User interaction tracking
  openedAt  DateTime?
  clickedAt DateTime?
  
  createdAt DateTime  @default(now())
  updatedAt DateTime  @updatedAt
  
  @@index([shipmentId])
  @@index([recipientId])
  @@index([status])
  @@index([createdAt])
}

model NotificationAuditLog {
  id        String   @id @default(cuid())
  
  notification Notification @relation(fields: [notificationId], references: [id])
  notificationId String
  
  action    String   // CREATED, SENT, DELIVERED, FAILED, BOUNCED, RETRIED
  details   Json?    // Additional context
  
  timestamp DateTime @default(now())
  
  @@index([notificationId])
  @@index([timestamp])
}
```

### NotificationRule Table (for automation)

```typescript
model NotificationRule {
  id        String   @id @default(cuid())
  
  name      String
  description String?
  
  // Trigger
  shipmentPhase    String?  // null = all phases
  shipmentStatus   String?  // null = all statuses
  triggerEvent     String   // STATUS_CHANGED, DOCUMENT_UPLOADED, etc
  
  // Conditions (JSON for flexibility)
  conditions Json   // {
               // "hasAllDocuments": true,
               // "delayMinutes": 60,
               // "requiresManualApproval": false
               // }
  
  // Actions
  actions Json   // [
             // {type: "SEND_NOTIFICATION", template: "notif_123"},
             // {type: "CREATE_TASK", assignTo: "COORDINATOR"},
             // {type: "ESCALATE", level: "MANAGER"}
             // ]
  
  // Execution
  isActive         Boolean  @default(true)
  priority         Int      @default(100) // Higher = execute first
  
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  
  @@index([isActive])
  @@index([triggerEvent])
}
```

---

## 2. NOTIFICATION SERVICE

```typescript
// src/services/NotificationService.ts

import { prisma } from '../index';
import { Shipment, User } from '@prisma/client';
import SendGrid from '@sendgrid/mail';
import twilio from 'twilio';

const sgMail = SendGrid.setApiKey(process.env.SENDGRID_API_KEY!);
const twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

interface NotificationPayload {
  shipmentId: string;
  event: string; // STATUS_CHANGED, DOCUMENT_UPLOADED, etc
  metadata?: Record<string, any>;
}

class NotificationService {
  /**
   * Main entry point - triggered by status change
   */
  static async handleShipmentEvent(payload: NotificationPayload): Promise<void> {
    console.log(`📢 Event: ${payload.event} for shipment ${payload.shipmentId}`);

    try {
      // Get shipment details
      const shipment = await prisma.shipment.findUnique({
        where: { id: payload.shipmentId },
        include: {
          order: {
            include: {
              client: true,
              items: true,
            },
          },
        },
      });

      if (!shipment) {
        throw new Error(`Shipment ${payload.shipmentId} not found`);
      }

      // Find matching notification rules
      const rules = await prisma.notificationRule.findMany({
        where: {
          isActive: true,
          triggerEvent: payload.event,
          OR: [
            { shipmentStatus: shipment.status },
            { shipmentStatus: null }, // null = matches any status
          ],
        },
        orderBy: { priority: 'desc' },
      });

      console.log(`✓ Found ${rules.length} matching rules`);

      // Execute each rule
      for (const rule of rules) {
        await this.executeRule(rule, shipment, payload.metadata);
      }
    } catch (error) {
      console.error('❌ Notification error:', error);
      // Log error but don't crash
      await prisma.notificationAuditLog.create({
        data: {
          notificationId: payload.shipmentId,
          action: 'FAILED',
          details: { error: String(error) },
        },
      });
    }
  }

  /**
   * Execute a single notification rule
   */
  private static async executeRule(
    rule: any,
    shipment: any,
    metadata?: Record<string, any>
  ): Promise<void> {
    console.log(`📋 Executing rule: ${rule.name}`);

    // Check conditions
    if (!this.checkConditions(rule.conditions, shipment, metadata)) {
      console.log(`  ⏭️  Conditions not met, skipping`);
      return;
    }

    // Execute actions
    for (const action of rule.actions) {
      if (action.type === 'SEND_NOTIFICATION') {
        await this.sendNotification(action.templateId, shipment, action.recipientOverride);
      } else if (action.type === 'CREATE_TASK') {
        await this.createTask(shipment, action);
      } else if (action.type === 'ESCALATE') {
        await this.escalate(shipment, action);
      }
    }
  }

  /**
   * Check if conditions are met
   */
  private static checkConditions(
    conditions: any,
    shipment: any,
    metadata?: Record<string, any>
  ): boolean {
    if (!conditions) return true;

    // Example: check if all documents are present
    if (conditions.hasAllDocuments) {
      const docs = shipment.order.items.length;
      if (docs === 0) return false;
    }

    // Example: check delay
    if (conditions.delayMinutes) {
      const delay = this.calculateDelay(shipment);
      if (delay < conditions.delayMinutes) return false;
    }

    return true;
  }

  /**
   * Send notification using template
   */
  static async sendNotification(
    templateId: string,
    shipment: any,
    recipientOverride?: string
  ): Promise<void> {
    // Get template
    const template = await prisma.notificationTemplate.findUnique({
      where: { id: templateId },
    });

    if (!template) {
      throw new Error(`Template ${templateId} not found`);
    }

    // Determine recipients
    let recipients: User[] = [];

    if (recipientOverride === 'CLIENT') {
      recipients = await prisma.user.findMany({
        where: { companyId: shipment.order.clientId },
      });
    } else if (recipientOverride === 'LSCM_TEAM') {
      recipients = await prisma.user.findMany({
        where: { companyId: process.env.LSCM_COMPANY_ID },
      });
    }

    // For each recipient
    for (const recipient of recipients) {
      await this.sendToRecipient(
        template,
        shipment,
        recipient,
        template.messageType
      );
    }
  }

  /**
   * Send to single recipient via channel
   */
  private static async sendToRecipient(
    template: any,
    shipment: any,
    recipient: User,
    channel: string
  ): Promise<void> {
    // Render template (replace placeholders)
    const rendered = this.renderTemplate(
      template.templateBody,
      shipment,
      template.placeholders
    );

    // Create notification record
    const notification = await prisma.notification.create({
      data: {
        shipmentId: shipment.id,
        templateId: template.id,
        recipientId: recipient.id,
        subject: template.subject,
        body: rendered,
        channel,
        status: 'PENDING',
      },
    });

    // Send via channel
    switch (channel) {
      case 'EMAIL':
        await this.sendEmail(notification, rendered, recipient, template.subject);
        break;
      case 'SMS':
        await this.sendSMS(notification, rendered, recipient);
        break;
      case 'WHATSAPP':
        await this.sendWhatsApp(notification, rendered, recipient);
        break;
      case 'INTERNAL':
        // Just mark as sent (in-app notification)
        await prisma.notification.update({
          where: { id: notification.id },
          data: { status: 'SENT', sentAt: new Date() },
        });
        break;
    }
  }

  /**
   * Send email via SendGrid
   */
  private static async sendEmail(
    notification: any,
    body: string,
    recipient: User,
    subject: string
  ): Promise<void> {
    try {
      const msg = {
        to: recipient.email,
        from: process.env.SENDGRID_FROM_EMAIL!,
        subject: subject || 'Shipment Update',
        html: body,
        replyTo: 'support@lscm.com',
      };

      const response = await sgMail.send(msg);

      // Update notification
      await prisma.notification.update({
        where: { id: notification.id },
        data: {
          status: 'SENT',
          sentAt: new Date(),
          externalId: response[0].headers['x-message-id'],
        },
      });

      console.log(`✓ Email sent to ${recipient.email}`);
    } catch (error) {
      console.error('❌ Email send failed:', error);
      await prisma.notification.update({
        where: { id: notification.id },
        data: {
          status: 'FAILED',
          failureReason: String(error),
        },
      });
    }
  }

  /**
   * Send SMS via Twilio
   */
  private static async sendSMS(
    notification: any,
    body: string,
    recipient: User
  ): Promise<void> {
    if (!recipient.phone) {
      console.warn(`No phone for ${recipient.email}`);
      return;
    }

    try {
      const message = await twilioClient.messages.create({
        body: body.substring(0, 160), // SMS limit
        from: process.env.TWILIO_PHONE_NUMBER,
        to: recipient.phone,
      });

      await prisma.notification.update({
        where: { id: notification.id },
        data: {
          status: 'SENT',
          sentAt: new Date(),
          externalId: message.sid,
        },
      });

      console.log(`✓ SMS sent to ${recipient.phone}`);
    } catch (error) {
      console.error('❌ SMS send failed:', error);
      await prisma.notification.update({
        where: { id: notification.id },
        data: {
          status: 'FAILED',
          failureReason: String(error),
        },
      });
    }
  }

  /**
   * Send WhatsApp via Twilio
   */
  private static async sendWhatsApp(
    notification: any,
    body: string,
    recipient: User
  ): Promise<void> {
    if (!recipient.phone) return;

    try {
      const message = await twilioClient.messages.create({
        body: body,
        from: `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER}`,
        to: `whatsapp:${recipient.phone}`,
      });

      await prisma.notification.update({
        where: { id: notification.id },
        data: {
          status: 'SENT',
          sentAt: new Date(),
          externalId: message.sid,
        },
      });

      console.log(`✓ WhatsApp sent to ${recipient.phone}`);
    } catch (error) {
      console.error('❌ WhatsApp send failed:', error);
    }
  }

  /**
   * Render template - replace placeholders
   */
  private static renderTemplate(
    template: string,
    shipment: any,
    placeholders: string[]
  ): string {
    let rendered = template;

    const data = {
      REFERENCE: shipment.reference,
      CLIENT_NAME: shipment.order.client.name,
      PICKUP_DATE: shipment.createdAt.toLocaleDateString(),
      PICKUP_LOCATION: shipment.order.originCountry,
      WEIGHT: shipment.order.totalWeight,
      DESTINATION: shipment.order.destinationCountry,
      CARRIER: shipment.logisticsPartner?.name || 'TBD',
      TRACKING_URL: `https://tracking.lscm.com/${shipment.reference}`,
      // Add more placeholders as needed
    };

    for (const placeholder of placeholders) {
      const value = data[placeholder as keyof typeof data];
      if (value) {
        rendered = rendered.replace(`[${placeholder}]`, String(value));
      }
    }

    return rendered;
  }

  /**
   * Create task from rule action
   */
  private static async createTask(shipment: any, action: any): Promise<void> {
    console.log(`📋 Creating task: ${action.taskType}`);

    const task = await prisma.task.create({
      data: {
        shipmentId: shipment.id,
        type: action.taskType,
        title: action.title || action.taskType,
        description: action.description,
        priority: action.priority || 'MEDIUM',
        deadline: new Date(Date.now() + (action.deadlineHours || 24) * 3600000),
        status: 'TODO',
        // assignedToId: determined later
      },
    });

    console.log(`✓ Task created: ${task.id}`);
  }

  /**
   * Escalate to management
   */
  private static async escalate(shipment: any, action: any): Promise<void> {
    console.log(`🚨 Escalating: ${action.level}`);

    // Create urgent notification for manager
    const managers = await prisma.user.findMany({
      where: {
        role: 'ADMIN', // or specific manager role
      },
    });

    for (const manager of managers) {
      await prisma.notification.create({
        data: {
          shipmentId: shipment.id,
          recipientId: manager.id,
          templateId: 'escalation_template',
          subject: `URGENT: Shipment ${shipment.reference} requires attention`,
          body: `${action.reason || 'Shipment requires immediate attention'}`,
          channel: 'EMAIL',
          status: 'PENDING',
        },
      });
    }
  }

  /**
   * Calculate delay in minutes
   */
  private static calculateDelay(shipment: any): number {
    if (!shipment.expectedDelivery) return 0;
    const delay = Date.now() - shipment.expectedDelivery.getTime();
    return Math.floor(delay / (1000 * 60));
  }
}

export default NotificationService;
```

---

## 3. WEBHOOK INTEGRATION FOR STATUS CHANGES

```typescript
// src/routes/webhooks.ts

import { Router, Request, Response } from 'express';
import NotificationService from '../services/NotificationService';
import { prisma } from '../index';

const router = Router();

/**
 * Webhook: Shipment status changed
 * Called internally whenever shipment.status changes
 */
router.post('/shipment-status-changed', async (req: Request, res: Response) => {
  try {
    const { shipmentId, oldStatus, newStatus, metadata } = req.body;

    console.log(`🔄 Status change: ${oldStatus} → ${newStatus}`);

    // Trigger notification engine
    await NotificationService.handleShipmentEvent({
      shipmentId,
      event: 'STATUS_CHANGED',
      metadata: {
        oldStatus,
        newStatus,
        ...metadata,
      },
    });

    res.json({ success: true, message: 'Notifications queued' });
  } catch (error) {
    console.error('Webhook error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

/**
 * Webhook: Document uploaded
 */
router.post('/document-uploaded', async (req: Request, res: Response) => {
  try {
    const { shipmentId, documentType } = req.body;

    await NotificationService.handleShipmentEvent({
      shipmentId,
      event: 'DOCUMENT_UPLOADED',
      metadata: { documentType },
    });

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed' });
  }
});

/**
 * Manual trigger: Send notification
 */
router.post('/send-notification', async (req: Request, res: Response) => {
  try {
    const { shipmentId, templateId } = req.body;

    await NotificationService.sendNotification(templateId, shipmentId);

    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to send' });
  }
});

export default router;
```

---

## 4. NOTIFICATION TEMPLATES (SQL SEED)

```typescript
// prisma/seed-notifications.ts

import { prisma } from '../src/index';

async function seedNotifications() {
  console.log('🌱 Seeding notification templates...');

  // Template 1: Pickup Scheduled (Client)
  await prisma.notificationTemplate.create({
    data: {
      id: 'notif_pickup_scheduled',
      shipmentPhase: 'PICKUP',
      shipmentStatus: 'PICKUP_SCHEDULED',
      triggerEvent: 'STATUS_CHANGED',
      recipientType: 'CLIENT',
      messageType: 'EMAIL',
      subject: 'Your Shipment Pickup Scheduled',
      templateBody: `
        <h2>Pickup Scheduled</h2>
        <p>Dear [CLIENT_NAME],</p>
        <p>Your shipment [REFERENCE] has been scheduled for pickup on [PICKUP_DATE].</p>
        <p><strong>Details:</strong></p>
        <ul>
          <li>Vendor: [VENDOR_NAME]</li>
          <li>Location: [PICKUP_LOCATION]</li>
          <li>Weight: [WEIGHT] kg</li>
          <li>Our driver will arrive at [PICKUP_TIME]</li>
        </ul>
        <p>Track your shipment: <a href="[TRACKING_URL]">Click here</a></p>
        <p>Best regards,<br>LSCM Team</p>
      `,
      placeholders: [
        'CLIENT_NAME',
        'REFERENCE',
        'PICKUP_DATE',
        'VENDOR_NAME',
        'PICKUP_LOCATION',
        'WEIGHT',
        'PICKUP_TIME',
        'TRACKING_URL',
      ],
      language: 'EN',
      priority: 'NORMAL',
      isActive: true,
      createdById: 'system',
    },
  });

  // Template 2: Pickup Scheduled (SMS)
  await prisma.notificationTemplate.create({
    data: {
      id: 'notif_pickup_scheduled_sms',
      shipmentPhase: 'PICKUP',
      shipmentStatus: 'PICKUP_SCHEDULED',
      triggerEvent: 'STATUS_CHANGED',
      recipientType: 'CLIENT',
      messageType: 'SMS',
      templateBody: `Pickup scheduled for [REFERENCE] on [PICKUP_DATE] at [PICKUP_TIME]. Track: [TRACKING_URL]`,
      placeholders: ['REFERENCE', 'PICKUP_DATE', 'PICKUP_TIME', 'TRACKING_URL'],
      language: 'EN',
      priority: 'NORMAL',
      isActive: true,
      createdById: 'system',
    },
  });

  // Template 3: Picked Up (Client)
  await prisma.notificationTemplate.create({
    data: {
      id: 'notif_picked_up',
      shipmentPhase: 'PICKUP',
      shipmentStatus: 'PICKED_UP',
      triggerEvent: 'STATUS_CHANGED',
      recipientType: 'CLIENT',
      messageType: 'EMAIL',
      subject: 'Shipment Picked Up Successfully',
      templateBody: `
        <h2>Shipment Picked Up!</h2>
        <p>Dear [CLIENT_NAME],</p>
        <p>Great news! Your shipment [REFERENCE] has been successfully picked up from [PICKUP_LOCATION].</p>
        <p>Next milestone: Reception at our warehouse hub on [EXPECTED_RECEPTION_DATE].</p>
        <p><a href="[TRACKING_URL]">Track your shipment</a></p>
      `,
      placeholders: [
        'CLIENT_NAME',
        'REFERENCE',
        'PICKUP_LOCATION',
        'EXPECTED_RECEPTION_DATE',
        'TRACKING_URL',
      ],
      language: 'EN',
      priority: 'NORMAL',
      isActive: true,
      createdById: 'system',
    },
  });

  // Template 4: Customs Hold (Client)
  await prisma.notificationTemplate.create({
    data: {
      id: 'notif_customs_hold',
      shipmentPhase: 'CUSTOMS',
      shipmentStatus: 'CUSTOMS_HOLD',
      triggerEvent: 'STATUS_CHANGED',
      recipientType: 'CLIENT',
      messageType: 'EMAIL',
      subject: 'URGENT: Customs Review Required',
      templateBody: `
        <h2>Customs Hold - Action Required</h2>
        <p>Dear [CLIENT_NAME],</p>
        <p>Your shipment [REFERENCE] is currently being reviewed by customs authorities.</p>
        <p>Our compliance team is working to resolve this immediately.</p>
        <p>We will provide an update within 24 hours.</p>
        <p>Contact: support@lscm.com | Phone: +221 77 123 4567</p>
      `,
      placeholders: ['CLIENT_NAME', 'REFERENCE'],
      language: 'EN',
      priority: 'HIGH',
      isActive: true,
      createdById: 'system',
    },
  });

  // Template 5: Delivered (Client)
  await prisma.notificationTemplate.create({
    data: {
      id: 'notif_delivered',
      shipmentPhase: 'DELIVERY',
      shipmentStatus: 'DELIVERED',
      triggerEvent: 'STATUS_CHANGED',
      recipientType: 'CLIENT',
      messageType: 'EMAIL',
      subject: 'Shipment Delivered!',
      templateBody: `
        <h2>Shipment Delivered Successfully!</h2>
        <p>Dear [CLIENT_NAME],</p>
        <p>Excellent news! Your shipment [REFERENCE] has been delivered to [DELIVERY_LOCATION].</p>
        <p>Delivery Date: [DELIVERY_DATE]</p>
        <p>Thank you for choosing LSCM for your logistics needs.</p>
        <p>Invoice: <a href="[INVOICE_URL]">Download here</a></p>
      `,
      placeholders: [
        'CLIENT_NAME',
        'REFERENCE',
        'DELIVERY_LOCATION',
        'DELIVERY_DATE',
        'INVOICE_URL',
      ],
      language: 'EN',
      priority: 'NORMAL',
      isActive: true,
      createdById: 'system',
    },
  });

  console.log('✅ Notification templates seeded');
}

seedNotifications();
```

---

## 5. NOTIFICATION RULES (Configuration Examples)

```typescript
// prisma/seed-rules.ts

async function seedNotificationRules() {
  console.log('🌱 Seeding notification rules...');

  // Rule 1: Pickup Scheduled → Send client email
  await prisma.notificationRule.create({
    data: {
      name: 'Notify client on pickup scheduled',
      description: 'When pickup is scheduled, email the client',
      shipmentPhase: 'PICKUP',
      shipmentStatus: 'PICKUP_SCHEDULED',
      triggerEvent: 'STATUS_CHANGED',
      conditions: {},
      actions: [
        {
          type: 'SEND_NOTIFICATION',
          templateId: 'notif_pickup_scheduled',
          recipientOverride: 'CLIENT',
        },
        {
          type: 'CREATE_TASK',
          taskType: 'CONFIRM_PICKUP_WITH_VENDOR',
          title: 'Confirm pickup with vendor',
          deadlineHours: 48,
        },
      ],
      isActive: true,
      priority: 100,
    },
  });

  // Rule 2: Documents missing → Alert coordinator
  await prisma.notificationRule.create({
    data: {
      name: 'Alert if critical documents missing',
      shipmentPhase: 'PICKUP',
      shipmentStatus: 'PICKUP_SCHEDULED',
      triggerEvent: 'STATUS_CHANGED',
      conditions: {
        requiresAllDocuments: true,
      },
      actions: [
        {
          type: 'ESCALATE',
          level: 'COORDINATOR',
          reason: 'Documents missing before pickup',
        },
      ],
      isActive: true,
      priority: 150, // Higher = execute first
    },
  });

  // Rule 3: Customs hold → Escalate
  await prisma.notificationRule.create({
    data: {
      name: 'Escalate customs hold immediately',
      shipmentPhase: 'CUSTOMS',
      shipmentStatus: 'CUSTOMS_HOLD',
      triggerEvent: 'STATUS_CHANGED',
      conditions: {},
      actions: [
        {
          type: 'SEND_NOTIFICATION',
          templateId: 'notif_customs_hold',
          recipientOverride: 'CLIENT',
        },
        {
          type: 'CREATE_TASK',
          taskType: 'RESOLVE_CUSTOMS_ISSUE',
          priority: 'HIGH',
          deadlineHours: 2,
        },
        {
          type: 'ESCALATE',
          level: 'MANAGER',
          reason: 'Customs hold - requires immediate attention',
        },
      ],
      isActive: true,
      priority: 200, // Execute first!
    },
  });

  // Rule 4: Delivered → Generate invoice notification
  await prisma.notificationRule.create({
    data: {
      name: 'Notify on delivery',
      shipmentPhase: 'DELIVERY',
      shipmentStatus: 'DELIVERED',
      triggerEvent: 'STATUS_CHANGED',
      conditions: {},
      actions: [
        {
          type: 'SEND_NOTIFICATION',
          templateId: 'notif_delivered',
          recipientOverride: 'CLIENT',
        },
        {
          type: 'CREATE_TASK',
          taskType: 'GENERATE_INVOICE',
          title: 'Generate final invoice',
        },
      ],
      isActive: true,
      priority: 90,
    },
  });

  console.log('✅ Notification rules seeded');
}
```

---

## 6. INTEGRATION POINTS

```typescript
// Update Shipment status change to trigger notifications

// In src/services/ShipmentService.ts
async updateShipmentStatus(shipmentId: string, newStatus: string) {
  const shipment = await prisma.shipment.findUnique({ where: { id: shipmentId } });
  
  if (!shipment) throw new Error('Shipment not found');
  
  const oldStatus = shipment.status;
  
  // Update in database
  const updated = await prisma.shipment.update({
    where: { id: shipmentId },
    data: { status: newStatus as any },
  });
  
  // Trigger notification engine
  try {
    await NotificationService.handleShipmentEvent({
      shipmentId,
      event: 'STATUS_CHANGED',
      metadata: {
        oldStatus,
        newStatus,
      },
    });
  } catch (error) {
    console.error('Notification trigger failed:', error);
    // Don't block status update
  }
  
  return updated;
}
```

---

## 7. ADMIN INTERFACE FOR TEMPLATES

The admin can manage templates via API:

```typescript
// GET /api/v1/admin/notification-templates
// List all templates

// POST /api/v1/admin/notification-templates
// Create new template

// PATCH /api/v1/admin/notification-templates/:id
// Edit template

// DELETE /api/v1/admin/notification-templates/:id
// Delete template

// POST /api/v1/admin/notification-templates/:id/test
// Send test notification

// GET /api/v1/admin/notification-rules
// List all rules

// POST /api/v1/admin/notification-rules
// Create new rule
```

---

## ✅ BENEFITS

```
Automatic system → Reduces manual effort by 80%
├─ No more "forgot to email customer"
├─ Consistent messaging (no typos)
├─ Real-time tracking & alerts
├─ Audit trail for compliance
└─ Scales to unlimited orders/clients
```

This notification engine turns your Excel communication matrix into a **fully automated system** that keeps everyone informed in real-time! 🚀
