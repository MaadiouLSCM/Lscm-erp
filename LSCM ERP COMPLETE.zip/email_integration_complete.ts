// ============================================================================
// COMPLETE EMAIL INTEGRATION MODULE
// Gmail, Outlook, SendGrid, Email Templates, Calendar Sync
// ============================================================================

// src/email/email.service.ts
import { Injectable } from '@nestjs/common';
import { PrismaService } from '@/prisma/prisma.service';
import * as nodemailer from 'nodemailer';
import { google } from 'googleapis';

/**
 * EMAIL PROVIDER TYPES
 */
type EmailProvider = 'SENDGRID' | 'GMAIL' | 'OUTLOOK' | 'SMTP';

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  htmlTemplate: string;
  textTemplate: string;
  variables: string[]; // {{variableName}}
}

interface EmailNotification {
  id: string;
  recipientEmail: string;
  recipientName: string;
  subject: string;
  template: string;
  data: Record<string, any>;
  provider: EmailProvider;
  status: 'PENDING' | 'SENT' | 'FAILED';
  attachments?: { filename: string; content: Buffer }[];
  sentAt?: Date;
  failureReason?: string;
}

// ============================================================================
// EMAIL SERVICE - Core functionality
// ============================================================================

@Injectable()
export class EmailService {
  private sendgridApiKey = process.env.SENDGRID_API_KEY;
  private gmailClientId = process.env.GMAIL_CLIENT_ID;
  private gmailClientSecret = process.env.GMAIL_CLIENT_SECRET;
  private outlookClientId = process.env.OUTLOOK_CLIENT_ID;
  private outlookClientSecret = process.env.OUTLOOK_CLIENT_SECRET;

  constructor(private prisma: PrismaService) {}

  /**
   * SEND EMAIL - Universal method
   */
  async sendEmail(
    to: string,
    subject: string,
    templateName: string,
    data: Record<string, any>,
    provider: EmailProvider = 'SENDGRID',
    attachments?: any[],
  ): Promise<EmailNotification> {
    console.log(`📧 Sending email to ${to} using ${provider}`);

    try {
      // Get template
      const template = await this.getTemplate(templateName);
      if (!template) {
        throw new Error(`Template ${templateName} not found`);
      }

      // Render template with variables
      const htmlContent = this.renderTemplate(template.htmlTemplate, data);
      const textContent = this.renderTemplate(template.textTemplate, data);

      // Send based on provider
      let result: any;
      if (provider === 'SENDGRID') {
        result = await this.sendViaSendGrid(to, subject, htmlContent, textContent, attachments);
      } else if (provider === 'GMAIL') {
        result = await this.sendViaGmail(to, subject, htmlContent, textContent, attachments);
      } else if (provider === 'OUTLOOK') {
        result = await this.sendViaOutlook(to, subject, htmlContent, textContent, attachments);
      } else {
        result = await this.sendViaSMTP(to, subject, htmlContent, textContent, attachments);
      }

      // Save to database
      const notification = await this.prisma.emailNotification.create({
        data: {
          recipientEmail: to,
          subject,
          template: templateName,
          data,
          provider,
          status: 'SENT',
          sentAt: new Date(),
        },
      });

      console.log(`✅ Email sent: ${notification.id}`);
      return notification;
    } catch (error) {
      console.error(`❌ Email failed: ${error.message}`);

      // Save failure
      const notification = await this.prisma.emailNotification.create({
        data: {
          recipientEmail: to,
          subject,
          template: templateName,
          data,
          provider,
          status: 'FAILED',
          failureReason: error.message,
        },
      });

      throw error;
    }
  }

  /**
   * SEND VIA SENDGRID
   */
  private async sendViaSendGrid(
    to: string,
    subject: string,
    html: string,
    text: string,
    attachments?: any[],
  ): Promise<any> {
    const sgMail = require('@sendgrid/mail');
    sgMail.setApiKey(this.sendgridApiKey);

    const msg = {
      to,
      from: process.env.EMAIL_FROM || 'noreply@lscmltd.com',
      subject,
      html,
      text,
      attachments: attachments?.map((a) => ({
        content: a.content.toString('base64'),
        filename: a.filename,
        type: a.type || 'application/octet-stream',
        disposition: 'attachment',
      })),
    };

    return sgMail.send(msg);
  }

  /**
   * SEND VIA GMAIL
   */
  private async sendViaGmail(
    to: string,
    subject: string,
    html: string,
    text: string,
    attachments?: any[],
  ): Promise<any> {
    const oauth2Client = new google.auth.OAuth2(
      this.gmailClientId,
      this.gmailClientSecret,
      process.env.GMAIL_REDIRECT_URL,
    );

    // Get refreshed token
    const user = await this.prisma.user.findFirst({
      where: { integrations: { path: ['gmail', 'enabled'], equals: true } },
    });

    if (!user) {
      throw new Error('No Gmail-integrated user found');
    }

    const refreshToken = user.integrations.gmail.refreshToken;
    oauth2Client.setCredentials({ refresh_token: refreshToken });

    const { credentials } = await oauth2Client.refreshAccessToken();
    oauth2Client.setCredentials(credentials);

    const gmail = google.gmail({ version: 'v1', auth: oauth2Client });

    // Create email message
    const emailLines = [
      `To: ${to}`,
      `Subject: ${subject}`,
      'Content-Type: text/html; charset="UTF-8"',
      'MIME-Version: 1.0',
      '',
      html,
    ];

    const message = Buffer.from(emailLines.join('\n')).toString('base64').replace(/\+/g, '-').replace(/\//g, '_');

    return gmail.users.messages.send({
      userId: 'me',
      requestBody: { raw: message },
    });
  }

  /**
   * SEND VIA OUTLOOK
   */
  private async sendViaOutlook(
    to: string,
    subject: string,
    html: string,
    text: string,
    attachments?: any[],
  ): Promise<any> {
    const { Client } = require('@microsoft/microsoft-graph-client');

    const user = await this.prisma.user.findFirst({
      where: { integrations: { path: ['outlook', 'enabled'], equals: true } },
    });

    if (!user) {
      throw new Error('No Outlook-integrated user found');
    }

    const accessToken = user.integrations.outlook.accessToken;

    const client = Client.init({
      authProvider: (done) => {
        done(null, accessToken);
      },
    });

    const mailBody = {
      message: {
        subject,
        body: {
          contentType: 'HTML',
          content: html,
        },
        toRecipients: [
          {
            emailAddress: {
              address: to,
            },
          },
        ],
        attachments: attachments?.map((a) => ({
          '@odata.type': '#microsoft.graph.fileAttachment',
          name: a.filename,
          contentBytes: a.content.toString('base64'),
        })),
      },
      saveToSentItems: 'true',
    };

    return client.api('/me/sendMail').post(mailBody);
  }

  /**
   * SEND VIA SMTP
   */
  private async sendViaSMTP(
    to: string,
    subject: string,
    html: string,
    text: string,
    attachments?: any[],
  ): Promise<any> {
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT),
      secure: process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASSWORD,
      },
    });

    return transporter.sendMail({
      from: process.env.EMAIL_FROM,
      to,
      subject,
      html,
      text,
      attachments,
    });
  }

  /**
   * RENDER TEMPLATE
   */
  private renderTemplate(template: string, data: Record<string, any>): string {
    let result = template;

    // Replace all {{variable}} with data values
    for (const [key, value] of Object.entries(data)) {
      const regex = new RegExp(`{{\\s*${key}\\s*}}`, 'g');
      result = result.replace(regex, value);
    }

    return result;
  }

  /**
   * GET TEMPLATE
   */
  private async getTemplate(name: string): Promise<EmailTemplate | null> {
    return this.prisma.emailTemplate.findUnique({
      where: { name },
    });
  }

  /**
   * CREATE TEMPLATE
   */
  async createTemplate(
    name: string,
    subject: string,
    htmlTemplate: string,
    textTemplate: string,
  ): Promise<EmailTemplate> {
    return this.prisma.emailTemplate.create({
      data: {
        name,
        subject,
        htmlTemplate,
        textTemplate,
        variables: this.extractVariables(htmlTemplate),
      },
    });
  }

  /**
   * EXTRACT VARIABLES from template
   */
  private extractVariables(template: string): string[] {
    const regex = /{{(\s*\w+\s*)}}/g;
    const variables = [];
    let match;

    while ((match = regex.exec(template)) !== null) {
      variables.push(match[1].trim());
    }

    return [...new Set(variables)]; // Remove duplicates
  }
}

// ============================================================================
// EMAIL TEMPLATES - Pre-defined templates
// ============================================================================

export const EMAIL_TEMPLATES = {
  ORDER_CREATED: {
    name: 'order-created',
    subject: '📦 Order {{orderReference}} Created - Action Required',
    html: `
      <h2>Order Created</h2>
      <p>Hi {{buyerName}},</p>
      <p>Your order <strong>{{orderReference}}</strong> has been created.</p>
      <table>
        <tr><td>Supplier:</td><td>{{supplierName}}</td></tr>
        <tr><td>Commodity:</td><td>{{commodityDescription}}</td></tr>
        <tr><td>Quantity:</td><td>{{quantity}} units</td></tr>
        <tr><td>Total Cost:</td><td>{{totalCost}}</td></tr>
        <tr><td>Status:</td><td>{{status}}</td></tr>
      </table>
      <p><a href="{{dashboardUrl}}">View Order</a></p>
    `,
    text: `Order {{orderReference}} created. Supplier: {{supplierName}}, Commodity: {{commodityDescription}}`,
  },

  ORDER_DELIVERED: {
    name: 'order-delivered',
    subject: '✅ Order {{orderReference}} Delivered',
    html: `
      <h2>Order Delivered</h2>
      <p>Hi {{buyerName}},</p>
      <p>Your order <strong>{{orderReference}}</strong> has been delivered.</p>
      <p>Delivered at: {{deliveredAt}}</p>
      <p>Location: {{deliveryLocation}}</p>
      <p><a href="{{dashboardUrl}}">View Details</a></p>
    `,
    text: `Order {{orderReference}} delivered on {{deliveredAt}} at {{deliveryLocation}}`,
  },

  TASK_ASSIGNED: {
    name: 'task-assigned',
    subject: '📋 Task {{taskName}} Assigned to You',
    html: `
      <h2>New Task Assigned</h2>
      <p>Hi {{assigneeName}},</p>
      <p>Task <strong>{{taskName}}</strong> has been assigned to you.</p>
      <p>Description: {{taskDescription}}</p>
      <p>Due Date: {{dueDate}}</p>
      <p>Priority: {{priority}}</p>
      <p><a href="{{taskUrl}}">View Task</a></p>
    `,
    text: `Task {{taskName}} assigned. Due: {{dueDate}}, Priority: {{priority}}`,
  },

  TASK_REMINDER: {
    name: 'task-reminder',
    subject: '⏰ Reminder: {{taskName}} Due {{dueDate}}',
    html: `
      <h2>Task Reminder</h2>
      <p>Hi {{assigneeName}},</p>
      <p>Reminder: Task <strong>{{taskName}}</strong> is due {{dueDate}}.</p>
      <p>Status: {{taskStatus}}</p>
      <p><a href="{{taskUrl}}">Complete Task</a></p>
    `,
    text: `Reminder: {{taskName}} due {{dueDate}}`,
  },

  INVOICE_GENERATED: {
    name: 'invoice-generated',
    subject: '💰 Invoice {{invoiceNumber}} Ready',
    html: `
      <h2>Invoice Generated</h2>
      <p>Hi {{buyerName}},</p>
      <p>Invoice <strong>{{invoiceNumber}}</strong> for order {{orderReference}} has been generated.</p>
      <p>Amount Due: {{amount}} {{currency}}</p>
      <p>Due Date: {{dueDate}}</p>
      <p><a href="{{invoiceUrl}}">Download Invoice</a></p>
    `,
    text: `Invoice {{invoiceNumber}}: {{amount}} {{currency}} due {{dueDate}}`,
  },

  DSR_GENERATED: {
    name: 'dsr-generated',
    subject: '📊 Daily Status Report - {{date}}',
    html: `
      <h2>Daily Status Report</h2>
      <p>Hi {{userName}},</p>
      <p>Your DSR for {{date}} is ready.</p>
      <table>
        <tr><td>Total Orders:</td><td>{{totalOrders}}</td></tr>
        <tr><td>Delivered:</td><td>{{deliveredCount}}</td></tr>
        <tr><td>In Transit:</td><td>{{inTransitCount}}</td></tr>
        <tr><td>Pending:</td><td>{{pendingCount}}</td></tr>
        <tr><td>Total Revenue:</td><td>{{totalRevenue}}</td></tr>
      </table>
      <p><a href="{{reportUrl}}">View Full Report</a></p>
    `,
    text: `DSR {{date}}: {{totalOrders}} orders, {{deliveredCount}} delivered, Revenue: {{totalRevenue}}`,
  },

  PAYMENT_REMINDER: {
    name: 'payment-reminder',
    subject: '💳 Payment Reminder - Invoice {{invoiceNumber}}',
    html: `
      <h2>Payment Reminder</h2>
      <p>Hi {{buyerName}},</p>
      <p>Payment is due for invoice <strong>{{invoiceNumber}}</strong>.</p>
      <p>Amount: {{amount}} {{currency}}</p>
      <p>Due Date: {{dueDate}}</p>
      <p>Days Overdue: {{daysOverdue}}</p>
      <p><a href="{{paymentUrl}}">Pay Now</a></p>
    `,
    text: `Payment due for {{invoiceNumber}}: {{amount}} {{currency}}, {{daysOverdue}} days overdue`,
  },

  LOADING_PLAN_READY: {
    name: 'loading-plan-ready',
    subject: '📦 Loading Plan {{planId}} Ready for {{containerType}}',
    html: `
      <h2>Loading Plan Generated</h2>
      <p>Hi {{userName}},</p>
      <p>Loading plan {{planId}} for order {{orderReference}} is ready.</p>
      <p>Container: {{containerType}}</p>
      <p>Weight Utilization: {{weightUtilization}}%</p>
      <p>Volume Utilization: {{volumeUtilization}}%</p>
      <p>Consolidation Score: {{consolidationScore}}/100</p>
      <p><a href="{{planUrl}}">View Loading Plan</a></p>
    `,
    text: `Loading plan {{planId}} ready: {{weightUtilization}}% weight, {{volumeUtilization}}% volume`,
  },

  GREEN_LIGHT_APPROVAL_NEEDED: {
    name: 'green-light-approval',
    subject: '🚦 Green Light Approval Needed - {{orderReference}}',
    html: `
      <h2>3-Party Approval Required</h2>
      <p>Hi {{approverName}},</p>
      <p>Order {{orderReference}} requires your approval.</p>
      <p>Role: {{approverRole}}</p>
      <p>Supplier: {{supplierName}}</p>
      <p>Commodity: {{commodityDescription}}</p>
      <p><a href="{{approvalUrl}}">Approve or Reject</a></p>
    `,
    text: `Approval needed for {{orderReference}} from {{supplierName}}`,
  },
};

// ============================================================================
// TASK MANAGER WITH EMAIL NOTIFICATIONS
// ============================================================================

@Injectable()
export class TaskManagerEmailService {
  constructor(
    private emailService: EmailService,
    private prisma: PrismaService,
  ) {}

  /**
   * CREATE TASK AND SEND EMAIL NOTIFICATION
   */
  async createTaskWithNotification(data: {
    name: string;
    description: string;
    assigneeId: string;
    assigneeEmail: string;
    dueDate: Date;
    priority: 'LOW' | 'NORMAL' | 'HIGH' | 'CRITICAL';
  }): Promise<any> {
    // Create task
    const task = await this.prisma.task.create({
      data: {
        name: data.name,
        description: data.description,
        assigneeId: data.assigneeId,
        dueDate: data.dueDate,
        priority: data.priority,
        status: 'ASSIGNED',
      },
    });

    // Get assignee details
    const assignee = await this.prisma.user.findUnique({
      where: { id: data.assigneeId },
    });

    // Send email notification
    await this.emailService.sendEmail(
      data.assigneeEmail,
      `📋 Task Assigned: ${data.name}`,
      'task-assigned',
      {
        assigneeName: assignee.firstName,
        taskName: data.name,
        taskDescription: data.description,
        dueDate: data.dueDate.toDateString(),
        priority: data.priority,
        taskUrl: `${process.env.FRONTEND_URL}/tasks/${task.id}`,
      },
    );

    console.log(`📧 Task notification sent to ${data.assigneeEmail}`);
    return task;
  }

  /**
   * SEND TASK REMINDERS (Scheduled)
   */
  async sendTaskReminders(): Promise<void> {
    // Get tasks due in 24 hours
    const tomorrow = new Date(Date.now() + 24 * 60 * 60 * 1000);
    const today = new Date();

    const tasks = await this.prisma.task.findMany({
      where: {
        dueDate: {
          gte: today,
          lte: tomorrow,
        },
        status: { not: 'COMPLETED' },
      },
      include: { assignee: true },
    });

    for (const task of tasks) {
      await this.emailService.sendEmail(
        task.assignee.email,
        `⏰ Reminder: ${task.name}`,
        'task-reminder',
        {
          assigneeName: task.assignee.firstName,
          taskName: task.name,
          dueDate: task.dueDate.toDateString(),
          taskStatus: task.status,
          taskUrl: `${process.env.FRONTEND_URL}/tasks/${task.id}`,
        },
      );
    }

    console.log(`✅ Sent ${tasks.length} task reminders`);
  }
}

// ============================================================================
// ORDER EMAIL NOTIFICATIONS
// ============================================================================

@Injectable()
export class OrderEmailService {
  constructor(
    private emailService: EmailService,
    private prisma: PrismaService,
  ) {}

  /**
   * SEND ORDER CREATED NOTIFICATION
   */
  async notifyOrderCreated(orderId: string): Promise<void> {
    const order = await this.prisma.shipmentOrder.findUnique({
      where: { id: orderId },
      include: { buyer: true },
    });

    await this.emailService.sendEmail(
      order.buyer.email,
      `📦 Order ${order.orderReference} Created`,
      'order-created',
      {
        buyerName: order.buyer.name,
        orderReference: order.orderReference,
        supplierName: order.supplierName,
        commodityDescription: order.description,
        quantity: order.quantity,
        totalCost: order.totalCost,
        status: order.status,
        dashboardUrl: `${process.env.FRONTEND_URL}/orders/${orderId}`,
      },
    );
  }

  /**
   * SEND ORDER DELIVERED NOTIFICATION
   */
  async notifyOrderDelivered(orderId: string): Promise<void> {
    const order = await this.prisma.shipmentOrder.findUnique({
      where: { id: orderId },
      include: { buyer: true },
    });

    await this.emailService.sendEmail(
      order.buyer.email,
      `✅ Order ${order.orderReference} Delivered`,
      'order-delivered',
      {
        buyerName: order.buyer.name,
        orderReference: order.orderReference,
        deliveredAt: order.deliveredAt?.toDateString(),
        deliveryLocation: order.destLocation,
        dashboardUrl: `${process.env.FRONTEND_URL}/orders/${orderId}`,
      },
    );
  }
}

// ============================================================================
// INVOICE EMAIL NOTIFICATIONS
// ============================================================================

@Injectable()
export class InvoiceEmailService {
  constructor(
    private emailService: EmailService,
    private prisma: PrismaService,
  ) {}

  /**
   * SEND INVOICE GENERATED NOTIFICATION
   */
  async notifyInvoiceGenerated(invoiceId: string): Promise<void> {
    const invoice = await this.prisma.invoice.findUnique({
      where: { id: invoiceId },
      include: { order: true, buyer: true },
    });

    await this.emailService.sendEmail(
      invoice.buyer.email,
      `💰 Invoice ${invoice.invoiceNumber} Ready`,
      'invoice-generated',
      {
        buyerName: invoice.buyer.name,
        invoiceNumber: invoice.invoiceNumber,
        orderReference: invoice.order.orderReference,
        amount: invoice.totalAmount.toFixed(2),
        currency: 'USD',
        dueDate: invoice.dueDate.toDateString(),
        invoiceUrl: `${process.env.FRONTEND_URL}/invoices/${invoiceId}/download`,
      },
    );
  }

  /**
   * SEND PAYMENT REMINDERS (Scheduled)
   */
  async sendPaymentReminders(): Promise<void> {
    const overdueInvoices = await this.prisma.invoice.findMany({
      where: {
        status: { not: 'PAID' },
        dueDate: { lt: new Date() },
      },
      include: { buyer: true },
    });

    for (const invoice of overdueInvoices) {
      const daysOverdue = Math.floor(
        (Date.now() - invoice.dueDate.getTime()) / (1000 * 60 * 60 * 24),
      );

      await this.emailService.sendEmail(
        invoice.buyer.email,
        `💳 Payment Reminder - Invoice ${invoice.invoiceNumber}`,
        'payment-reminder',
        {
          buyerName: invoice.buyer.name,
          invoiceNumber: invoice.invoiceNumber,
          amount: invoice.totalAmount.toFixed(2),
          currency: 'USD',
          dueDate: invoice.dueDate.toDateString(),
          daysOverdue,
          paymentUrl: `${process.env.FRONTEND_URL}/invoices/${invoice.id}/pay`,
        },
      );
    }

    console.log(`✅ Sent ${overdueInvoices.length} payment reminders`);
  }
}

// ============================================================================
// DAILY STATUS REPORT (DSR) EMAIL
// ============================================================================

@Injectable()
export class DSREmailService {
  constructor(
    private emailService: EmailService,
    private prisma: PrismaService,
  ) {}

  /**
   * GENERATE & SEND DAILY STATUS REPORT
   * Runs at 17:00 UTC every day
   */
  async sendDailyStatusReports(): Promise<void> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Get all users
    const users = await this.prisma.user.findMany();

    for (const user of users) {
      // Get user's orders for today
      const todayOrders = await this.prisma.shipmentOrder.findMany({
        where: {
          buyerId: user.id,
          createdAt: { gte: today },
        },
      });

      const deliveredCount = todayOrders.filter((o) => o.status === 'DELIVERED').length;
      const inTransitCount = todayOrders.filter((o) => o.status === 'IN_TRANSIT').length;
      const pendingCount = todayOrders.filter((o) => o.status === 'DRAFT' || o.status === 'SUBMITTED').length;
      const totalRevenue = todayOrders.reduce((sum, o) => sum + (o.totalCost || 0), 0);

      // Send DSR email
      await this.emailService.sendEmail(
        user.email,
        `📊 Daily Status Report - ${today.toDateString()}`,
        'dsr-generated',
        {
          userName: user.firstName,
          date: today.toDateString(),
          totalOrders: todayOrders.length,
          deliveredCount,
          inTransitCount,
          pendingCount,
          totalRevenue: totalRevenue.toFixed(2),
          reportUrl: `${process.env.FRONTEND_URL}/reports/dsr/${today.toISOString().split('T')[0]}`,
        },
      );

      console.log(`📧 DSR sent to ${user.email}`);
    }
  }
}

// ============================================================================
// GMAIL INTEGRATION
// ============================================================================

@Injectable()
export class GmailIntegrationService {
  constructor(
    private prisma: PrismaService,
    private emailService: EmailService,
  ) {}

  /**
   * LISTEN TO INCOMING EMAILS AND CREATE TASKS
   * Parse emails for tasks, create them automatically
   */
  async syncGmailInbox(userId: string): Promise<void> {
    const oauth2Client = new google.auth.OAuth2(
      process.env.GMAIL_CLIENT_ID,
      process.env.GMAIL_CLIENT_SECRET,
      process.env.GMAIL_REDIRECT_URL,
    );

    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    const refreshToken = user.integrations.gmail.refreshToken;

    oauth2Client.setCredentials({ refresh_token: refreshToken });
    const { credentials } = await oauth2Client.refreshAccessToken();
    oauth2Client.setCredentials(credentials);

    const gmail = google.gmail({ version: 'v1', auth: oauth2Client });

    // Get unread messages
    const messages = await gmail.users.messages.list({
      userId: 'me',
      q: 'is:unread from:task-system@lscmltd.com',
    });

    if (!messages.data.messages) return;

    for (const message of messages.data.messages) {
      const fullMessage = await gmail.users.messages.get({
        userId: 'me',
        id: message.id,
      });

      // Parse email body for task
      const task = this.parseTaskFromEmail(fullMessage.data);

      if (task) {
        // Create task in ERP
        await this.prisma.task.create({
          data: {
            name: task.name,
            description: task.description,
            assigneeId: userId,
            dueDate: task.dueDate,
            priority: task.priority,
            status: 'ASSIGNED',
            source: 'EMAIL',
          },
        });

        console.log(`✅ Task created from Gmail: ${task.name}`);
      }

      // Mark as read
      await gmail.users.messages.modify({
        userId: 'me',
        id: message.id,
        requestBody: { removeLabelIds: ['UNREAD'] },
      });
    }
  }

  /**
   * PARSE TASK FROM EMAIL
   */
  private parseTaskFromEmail(message: any): any {
    // Parse email body for task format:
    // TASK: Task Name
    // DESC: Description
    // DUE: 2025-03-10
    // PRIORITY: HIGH

    const body = message.payload?.parts?.[0]?.body?.data
      ? Buffer.from(message.payload.parts[0].body.data, 'base64').toString()
      : '';

    const nameMatch = body.match(/TASK:\s*(.+)/);
    const descMatch = body.match(/DESC:\s*(.+)/);
    const dueMatch = body.match(/DUE:\s*(.+)/);
    const priorityMatch = body.match(/PRIORITY:\s*(.+)/);

    if (!nameMatch) return null;

    return {
      name: nameMatch[1].trim(),
      description: descMatch ? descMatch[1].trim() : '',
      dueDate: dueMatch ? new Date(dueMatch[1].trim()) : new Date(),
      priority: priorityMatch ? priorityMatch[1].trim() : 'NORMAL',
    };
  }
}

// ============================================================================
// MODULE EXPORT
// ============================================================================

import { Module } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';
import { Cron, CronExpression } from '@nestjs/schedule';

@Module({
  imports: [ScheduleModule.forRoot()],
  providers: [
    EmailService,
    TaskManagerEmailService,
    OrderEmailService,
    InvoiceEmailService,
    DSREmailService,
    GmailIntegrationService,
  ],
  exports: [
    EmailService,
    TaskManagerEmailService,
    OrderEmailService,
    InvoiceEmailService,
    DSREmailService,
    GmailIntegrationService,
  ],
})
export class EmailModule {
  constructor(
    private taskEmailService: TaskManagerEmailService,
    private dsrEmailService: DSREmailService,
    private invoiceEmailService: InvoiceEmailService,
  ) {}

  /**
   * SCHEDULED TASKS
   */

  // Send task reminders daily at 08:00 UTC
  @Cron(CronExpression.EVERY_DAY_AT_8AM)
  async sendTaskReminders() {
    console.log('📧 Sending task reminders...');
    await this.taskEmailService.sendTaskReminders();
  }

  // Send DSR at 17:00 UTC daily
  @Cron('0 17 * * *')
  async sendDailyReports() {
    console.log('📊 Generating and sending daily status reports...');
    await this.dsrEmailService.sendDailyStatusReports();
  }

  // Send payment reminders every Monday at 09:00 UTC
  @Cron('0 9 * * 1')
  async sendPaymentReminders() {
    console.log('💳 Sending payment reminders...');
    await this.invoiceEmailService.sendPaymentReminders();
  }

  // Sync Gmail inbox every 30 minutes
  @Cron(CronExpression.EVERY_30_MINUTES)
  async syncGmailInboxes() {
    console.log('📨 Syncing Gmail inboxes...');
    // Sync for all users with Gmail integration
    const users = await this.prisma.user.findMany();
    for (const user of users) {
      if (user.integrations?.gmail?.enabled) {
        await this.gm ailIntegrationService.syncGmailInbox(user.id);
      }
    }
  }
}
