// test/integration/task-manager.integration.spec.ts
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, BadRequestException } from '@nestjs/common';
import * as request from 'supertest';
import { TaskService } from '@/tasks/task.service';
import { PrismaService } from '@/prisma/prisma.service';
import { TaskStatus, TaskPriority, TaskType } from '@/tasks/task.types';

describe('Task Manager Integration Tests (e2e)', () => {
  let app: INestApplication;
  let taskService: TaskService;
  let prisma: PrismaService;
  let authToken: string;

  beforeAll(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [/* your app module */],
    }).compile();

    app = moduleFixture.createNestApplication();
    taskService = moduleFixture.get<TaskService>(TaskService);
    prisma = moduleFixture.get<PrismaService>(PrismaService);

    await app.init();

    // Get auth token
    const loginRes = await request(app.getHttpServer())
      .post('/api/v1/auth/login')
      .send({
        email: 'test@lscm.com',
        password: 'password123',
      });

    authToken = loginRes.body.accessToken;
  });

  afterAll(async () => {
    await app.close();
  });

  describe('Task Creation & Assignment', () => {
    it('should create a task', async () => {
      const res = await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'Generate DSR for order SNIM-001',
          type: TaskType.GENERATE_DSR,
          orderId: 'order-123',
          priority: TaskPriority.HIGH,
          dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000),
        });

      expect(res.status).toBe(201);
      expect(res.body.status).toBe(TaskStatus.ASSIGNED);
      expect(res.body.title).toBe('Generate DSR for order SNIM-001');
    });

    it('should create task with dependencies', async () => {
      // Create first task
      const task1Res = await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'Task 1',
          type: TaskType.GENERATE_DOCUMENTS,
          orderId: 'order-456',
          priority: TaskPriority.NORMAL,
        });

      const task1Id = task1Res.body.id;

      // Create dependent task
      const task2Res = await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'Task 2 (depends on Task 1)',
          type: TaskType.SCHEDULE_PICKUP,
          orderId: 'order-456',
          dependsOn: [task1Id],
          priority: TaskPriority.NORMAL,
        });

      expect(task2Res.status).toBe(201);
      expect(task2Res.body.status).toBe(TaskStatus.PENDING); // Not assigned until deps complete
      expect(task2Res.body.dependsOn).toContain(task1Id);
    });

    it('should auto-assign dependent tasks when dependency completes', async () => {
      // Create dependency chain
      const task1Res = await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'Task 1',
          type: TaskType.GENERATE_DOCUMENTS,
          orderId: 'order-789',
        });

      const task1Id = task1Res.body.id;

      const task2Res = await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'Task 2',
          type: TaskType.SCHEDULE_PICKUP,
          orderId: 'order-789',
          dependsOn: [task1Id],
        });

      const task2Id = task2Res.body.id;

      // Complete task 1
      await request(app.getHttpServer())
        .put(`/api/v1/tasks/${task1Id}/complete`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({ result: {} });

      // Task 2 should now be ASSIGNED
      const task2Updated = await request(app.getHttpServer())
        .get(`/api/v1/tasks/${task2Id}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(task2Updated.body.status).toBe(TaskStatus.ASSIGNED);
    });
  });

  describe('Task Execution & Completion', () => {
    it('should start and complete a task', async () => {
      const createRes = await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'Test Task',
          type: TaskType.VERIFY_PAYMENT,
          priority: TaskPriority.NORMAL,
        });

      const taskId = createRes.body.id;

      // Start task
      const startRes = await request(app.getHttpServer())
        .put(`/api/v1/tasks/${taskId}/start`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(startRes.body.status).toBe(TaskStatus.IN_PROGRESS);

      // Complete task
      const completeRes = await request(app.getHttpServer())
        .put(`/api/v1/tasks/${taskId}/complete`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          result: {
            verified: true,
            reference: 'TXN-123',
          },
        });

      expect(completeRes.body.status).toBe(TaskStatus.COMPLETED);
      expect(completeRes.body.completedAt).toBeDefined();
    });

    it('should block task with reason', async () => {
      const createRes = await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'Blocked Task',
          type: TaskType.REQUEST_GREEN_LIGHT,
          orderId: 'order-blocked',
        });

      const taskId = createRes.body.id;

      const blockRes = await request(app.getHttpServer())
        .put(`/api/v1/tasks/${taskId}/block`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          reason: 'Waiting for customs broker approval',
        });

      expect(blockRes.body.status).toBe(TaskStatus.BLOCKED);
      expect(blockRes.body.blockReason).toBe('Waiting for customs broker approval');

      // Unblock
      const unblockRes = await request(app.getHttpServer())
        .put(`/api/v1/tasks/${taskId}/unblock`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(unblockRes.body.status).toBe(TaskStatus.ASSIGNED);
    });
  });

  describe('Task Retry Logic & Dead Letter Queue', () => {
    it('should retry failed task with exponential backoff', async () => {
      const createRes = await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'Flaky Task',
          type: TaskType.SEND_PAYMENT_REMINDER,
          priority: TaskPriority.HIGH,
        });

      const taskId = createRes.body.id;

      // Fail task (first time)
      const fail1Res = await request(app.getHttpServer())
        .put(`/api/v1/tasks/${taskId}/fail`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          error: 'Network timeout',
        });

      expect(fail1Res.body.status).toBe(TaskStatus.PENDING);
      expect(fail1Res.body.retryCount).toBe(1);
      expect(fail1Res.body.nextRetryTime).toBeDefined();

      // Fail again (second time)
      const fail2Res = await request(app.getHttpServer())
        .put(`/api/v1/tasks/${taskId}/fail`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          error: 'Network timeout again',
        });

      expect(fail2Res.body.retryCount).toBe(2);

      // Fail third time (should go to DLQ)
      const fail3Res = await request(app.getHttpServer())
        .put(`/api/v1/tasks/${taskId}/fail`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          error: 'Network timeout (retry 3)',
        });

      // After 3 retries, should fail
      expect(fail3Res.body.status).toBe(TaskStatus.FAILED);
      expect(fail3Res.body.deadLetterAt).toBeDefined();
    });
  });

  describe('Task Filtering & Metrics', () => {
    beforeEach(async () => {
      // Create various tasks for filtering
      await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'High Priority Task',
          type: TaskType.GENERATE_DSR,
          priority: TaskPriority.HIGH,
          orderId: 'order-filter-1',
        });

      await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'Low Priority Task',
          type: TaskType.HEALTH_CHECK,
          priority: TaskPriority.LOW,
          orderId: 'order-filter-2',
        });

      await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'Critical Task',
          type: TaskType.DATABASE_BACKUP,
          priority: TaskPriority.CRITICAL,
          assignedTo: 'admin@lscm.com',
        });
    });

    it('should filter tasks by priority', async () => {
      const res = await request(app.getHttpServer())
        .get('/api/v1/tasks?priority=3') // HIGH
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.body.data.length).toBeGreaterThan(0);
      expect(res.body.data[0].priority).toBe(TaskPriority.HIGH);
    });

    it('should filter tasks by status', async () => {
      const res = await request(app.getHttpServer())
        .get(`/api/v1/tasks?status=${TaskStatus.ASSIGNED}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.body.data.length).toBeGreaterThan(0);
      expect(res.body.data.every((t: any) => t.status === TaskStatus.ASSIGNED)).toBe(true);
    });

    it('should filter overdue tasks', async () => {
      const res = await request(app.getHttpServer())
        .get('/api/v1/tasks?overdue=true')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.status).toBe(200);
      expect(res.body.pagination.total).toBeGreaterThanOrEqual(0);
    });

    it('should get task metrics', async () => {
      const res = await request(app.getHttpServer())
        .get('/api/v1/tasks/metrics')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('total');
      expect(res.body).toHaveProperty('pending');
      expect(res.body).toHaveProperty('inProgress');
      expect(res.body).toHaveProperty('completed');
      expect(res.body).toHaveProperty('failed');
      expect(res.body).toHaveProperty('overdue');
      expect(res.body).toHaveProperty('slaBreached');
      expect(res.body).toHaveProperty('averageCompletionTimeMinutes');
    });
  });

  describe('Scheduled Tasks (DSR, WSR, Backups)', () => {
    it('should have DSR task scheduled daily at 17:00', async () => {
      // Wait for scheduled task execution (in test, this is simulated)
      const tasks = await request(app.getHttpServer())
        .get(`/api/v1/tasks?type=${TaskType.GENERATE_DSR}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(tasks.body.data.length).toBeGreaterThanOrEqual(0);
    });

    it('should have WSR task scheduled weekly', async () => {
      const tasks = await request(app.getHttpServer())
        .get(`/api/v1/tasks?type=${TaskType.GENERATE_WSR}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(tasks.status).toBe(200);
    });

    it('should have backup task scheduled daily', async () => {
      const tasks = await request(app.getHttpServer())
        .get(`/api/v1/tasks?type=${TaskType.DATABASE_BACKUP}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(tasks.status).toBe(200);
    });
  });

  describe('Complete Order Workflow with Task Management', () => {
    it('should execute complete order-to-closure workflow with tasks', async () => {
      // 1. Create order
      const orderRes = await request(app.getHttpServer())
        .post('/api/v1/orders')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          supplierId: 'SNIM',
          supplierName: 'SNIM',
          supplierCountry: 'Mauritania',
          buyerId: 'BUYER-001',
          buyerName: 'Test Buyer',
          buyerCountry: 'South Africa',
          commodityCode: '2601',
          description: 'Iron Ore',
          quantity: 25,
          grossWeight: 8500,
          originLocation: 'NKC',
          destLocation: 'JNB',
          incoterm: 'FOB',
          transportMode: 'AIR',
          createdBy: 'test@lscm.com',
        });

      const orderId = orderRes.body.id;

      // 2. Auto-create task: Generate documents
      const docTaskRes = await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: `Generate documents for ${orderRes.body.orderReference}`,
          type: TaskType.GENERATE_DOCUMENTS,
          orderId,
          priority: TaskPriority.HIGH,
        });

      // 3. Complete document task
      await request(app.getHttpServer())
        .put(`/api/v1/tasks/${docTaskRes.body.id}/start`)
        .set('Authorization', `Bearer ${authToken}`);

      const docCompleteRes = await request(app.getHttpServer())
        .put(`/api/v1/tasks/${docTaskRes.body.id}/complete`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({ result: { docCount: 3 } });

      expect(docCompleteRes.body.status).toBe(TaskStatus.COMPLETED);

      // 4. Create dependent tasks (Green Light approval)
      const glTaskRes = await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: `Request Green Light for ${orderRes.body.orderReference}`,
          type: TaskType.REQUEST_GREEN_LIGHT,
          orderId,
          dependsOn: [docTaskRes.body.id],
          priority: TaskPriority.CRITICAL,
        });

      // Should now be assigned since dependency is complete
      const glTaskUpdated = await request(app.getHttpServer())
        .get(`/api/v1/tasks/${glTaskRes.body.id}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(glTaskUpdated.body.status).toBe(TaskStatus.ASSIGNED);

      // 5. Complete Green Light
      await request(app.getHttpServer())
        .put(`/api/v1/tasks/${glTaskRes.body.id}/complete`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({ result: { approved: true } });

      // 6. Create booking task
      const bookingTaskRes = await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: `Book carrier for ${orderRes.body.orderReference}`,
          type: TaskType.BOOK_CARRIER,
          orderId,
          dependsOn: [glTaskRes.body.id],
          priority: TaskPriority.HIGH,
        });

      const bookingTaskUpdated = await request(app.getHttpServer())
        .get(`/api/v1/tasks/${bookingTaskRes.body.id}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(bookingTaskUpdated.body.status).toBe(TaskStatus.ASSIGNED);

      // 7. Complete booking
      await request(app.getHttpServer())
        .put(`/api/v1/tasks/${bookingTaskRes.body.id}/complete`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({ result: { carrierName: 'Turkish Airlines' } });

      // 8. Get all tasks for order
      const orderTasksRes = await request(app.getHttpServer())
        .get(`/api/v1/tasks?orderId=${orderId}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(orderTasksRes.body.data.length).toBe(3);

      // All should be completed
      const allCompleted = orderTasksRes.body.data.every(
        (t: any) => t.status === TaskStatus.COMPLETED
      );
      expect(allCompleted).toBe(true);
    });
  });

  describe('SLA Tracking & Escalation', () => {
    it('should track SLA and breach notifications', async () => {
      const pastTime = new Date(Date.now() - 2 * 60 * 60 * 1000); // 2 hours ago

      const createRes = await request(app.getHttpServer())
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'SLA Test Task',
          type: TaskType.SEND_PAYMENT_REMINDER,
          slaDays: -1, // Already past SLA
          priority: TaskPriority.CRITICAL,
        });

      const task = await prisma.task.update({
        where: { id: createRes.body.id },
        data: { slaDueDate: pastTime },
      });

      expect(task.slaDueDate.getTime()).toBeLessThan(Date.now());
    });
  });
});
