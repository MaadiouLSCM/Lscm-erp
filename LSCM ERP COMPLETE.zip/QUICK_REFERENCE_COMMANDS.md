# ⚡ DEPLOYMENT QUICK REFERENCE
## Copy-Paste Commands for DigitalOcean + Kubernetes

═══════════════════════════════════════════════════════════════════════════════
## SETUP VARIABLES (RUN THESE FIRST!)
═══════════════════════════════════════════════════════════════════════════════

```bash
# Save these to use in commands below
export PROJECT_DIR=~/projects/lscm-erp
export DIGITALOCEAN_TOKEN="dop_v1_your_token_here"
export POSTGRES_PASSWORD="your-secure-password-123"
export DO_REGISTRY="registry.digitalocean.com/lscm-erp"
export CLUSTER_NAME="lscm-prod"
export NAMESPACE="lscm-prod"
export REGION="nyc3"  # Change to your region (nyc3, sfo3, ams3, lon1, etc.)
```

═══════════════════════════════════════════════════════════════════════════════
## PHASE 1: LOCAL (QUICK COMMANDS)
═══════════════════════════════════════════════════════════════════════════════

### Step 1: Start local services
```bash
cd $PROJECT_DIR
docker-compose up -d
sleep 30
docker-compose exec backend npx prisma migrate deploy
docker-compose exec backend npx prisma db seed
```

### Step 2: Verify
```bash
docker-compose ps
curl http://localhost:3000/health
# Open browser: http://localhost:3001
```

### Step 3: Run tests
```bash
npm run test-all
```

### Step 4: Stop everything
```bash
docker-compose down
```

═══════════════════════════════════════════════════════════════════════════════
## PHASE 2: DIGITALOCEAN ACCOUNT
═══════════════════════════════════════════════════════════════════════════════

### Step 1: Install doctl
```bash
# macOS
brew install doctl

# Linux
cd ~
wget https://github.com/digitalocean/doctl/releases/download/v1.94.0/doctl-1.94.0-linux-amd64.tar.gz
tar xf doctl-1.94.0-linux-amd64.tar.gz
sudo mv doctl /usr/local/bin
rm doctl-1.94.0-linux-amd64.tar.gz

# Windows
# Download from: https://github.com/digitalocean/doctl/releases
```

### Step 2: Authenticate doctl
```bash
doctl auth init
# Paste your DIGITALOCEAN_TOKEN when prompted
doctl auth list
```

### Step 3: Create Container Registry
```bash
doctl registry create lscm-erp --region $REGION
# Verify:
doctl registry list
```

### Step 4: Configure Docker
```bash
doctl registry login
```

═══════════════════════════════════════════════════════════════════════════════
## PHASE 3: BUILD & PUSH IMAGE
═══════════════════════════════════════════════════════════════════════════════

```bash
cd $PROJECT_DIR

# Build
docker build -t lscm-erp:latest .

# Tag
docker tag lscm-erp:latest $DO_REGISTRY/backend:latest

# Push
docker push $DO_REGISTRY/backend:latest

# Verify
doctl registry list-repositories lscm-erp
```

═══════════════════════════════════════════════════════════════════════════════
## PHASE 4: KUBERNETES CLUSTER
═══════════════════════════════════════════════════════════════════════════════

### Create cluster
```bash
doctl kubernetes cluster create $CLUSTER_NAME \
  --region $REGION \
  --version latest \
  --node-pool "name=worker-pool;size=s-2vcpu-2gb;count=3"

# Wait 5-10 minutes, then verify:
doctl kubernetes cluster list
doctl kubernetes cluster get $CLUSTER_NAME
```

### Connect kubectl
```bash
doctl kubernetes cluster kubeconfig save $CLUSTER_NAME
kubectl cluster-info
kubectl get nodes
```

### Create namespace
```bash
kubectl create namespace $NAMESPACE
kubectl config set-context --current --namespace=$NAMESPACE
```

═══════════════════════════════════════════════════════════════════════════════
## PHASE 5: CREATE SECRETS
═══════════════════════════════════════════════════════════════════════════════

```bash
# Database secret
kubectl create secret generic postgres-secret \
  --from-literal=password=$POSTGRES_PASSWORD \
  -n $NAMESPACE

# JWT secret (generate random)
JWT_SECRET=$(openssl rand -base64 32)
kubectl create secret generic jwt-secret \
  --from-literal=secret=$JWT_SECRET \
  -n $NAMESPACE

# Registry credentials
kubectl create secret docker-registry regcred \
  --docker-server=registry.digitalocean.com \
  --docker-username=YOUR_EMAIL@gmail.com \
  --docker-password=$DIGITALOCEAN_TOKEN \
  -n $NAMESPACE

# Verify
kubectl get secrets -n $NAMESPACE
```

═══════════════════════════════════════════════════════════════════════════════
## PHASE 6: DEPLOY DATABASES
═══════════════════════════════════════════════════════════════════════════════

### Deploy PostgreSQL
```bash
kubectl apply -f - <<EOF
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: postgres-pvc
  namespace: $NAMESPACE
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 20Gi
---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: postgres
  namespace: $NAMESPACE
spec:
  serviceName: postgres
  replicas: 1
  selector:
    matchLabels:
      app: postgres
  template:
    metadata:
      labels:
        app: postgres
    spec:
      containers:
      - name: postgres
        image: postgres:15-alpine
        ports:
        - containerPort: 5432
        env:
        - name: POSTGRES_DB
          value: lscm_erp
        - name: POSTGRES_USER
          value: lscm_user
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: postgres-secret
              key: password
        volumeMounts:
        - name: postgres-storage
          mountPath: /var/lib/postgresql/data
  volumeClaimTemplates:
  - metadata:
      name: postgres-storage
    spec:
      accessModes:
      - ReadWriteOnce
      resources:
        requests:
          storage: 20Gi
---
apiVersion: v1
kind: Service
metadata:
  name: postgres
  namespace: $NAMESPACE
spec:
  ports:
  - port: 5432
    targetPort: 5432
  selector:
    app: postgres
  clusterIP: None
EOF

# Wait for postgres-0 to be ready
kubectl get pods -n $NAMESPACE -w
# Press Ctrl+C when postgres-0 shows 1/1 Running
```

### Deploy Redis
```bash
kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
  namespace: $NAMESPACE
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:7-alpine
        ports:
        - containerPort: 6379
        resources:
          requests:
            memory: "128Mi"
            cpu: "100m"
          limits:
            memory: "256Mi"
            cpu: "500m"
---
apiVersion: v1
kind: Service
metadata:
  name: redis
  namespace: $NAMESPACE
spec:
  ports:
  - port: 6379
    targetPort: 6379
  selector:
    app: redis
  type: ClusterIP
EOF

# Verify
kubectl get pods -n $NAMESPACE
```

═══════════════════════════════════════════════════════════════════════════════
## PHASE 7: DEPLOY APPLICATION
═══════════════════════════════════════════════════════════════════════════════

### Deploy Backend
```bash
# First get your backend IP that will be assigned
# (This is created by the LoadBalancer service)

kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: lscm-backend
  namespace: $NAMESPACE
spec:
  replicas: 2
  selector:
    matchLabels:
      app: lscm-backend
  template:
    metadata:
      labels:
        app: lscm-backend
    spec:
      imagePullSecrets:
      - name: regcred
      containers:
      - name: backend
        image: $DO_REGISTRY/backend:latest
        ports:
        - containerPort: 3000
        env:
        - name: DATABASE_URL
          value: postgresql://lscm_user:$POSTGRES_PASSWORD@postgres:5432/lscm_erp
        - name: REDIS_URL
          value: redis://redis:6379
        - name: NODE_ENV
          value: production
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: jwt-secret
              key: secret
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 10
          periodSeconds: 5
        resources:
          requests:
            memory: "256Mi"
            cpu: "200m"
          limits:
            memory: "512Mi"
            cpu: "500m"
---
apiVersion: v1
kind: Service
metadata:
  name: lscm-backend
  namespace: $NAMESPACE
spec:
  type: LoadBalancer
  ports:
  - port: 80
    targetPort: 3000
    protocol: TCP
  selector:
    app: lscm-backend
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: backend-hpa
  namespace: $NAMESPACE
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: lscm-backend
  minReplicas: 2
  maxReplicas: 5
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
EOF

# Wait for pods and get IP
kubectl get pods -n $NAMESPACE -w
# Once 2 backend pods are "Running", get IP:
kubectl get service lscm-backend -n $NAMESPACE
# Save EXTERNAL-IP as BACKEND_IP
export BACKEND_IP=$(kubectl get service lscm-backend -n $NAMESPACE -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
echo "Backend IP: $BACKEND_IP"
```

### Deploy Frontend
```bash
kubectl apply -f - <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: lscm-frontend
  namespace: $NAMESPACE
spec:
  replicas: 2
  selector:
    matchLabels:
      app: lscm-frontend
  template:
    metadata:
      labels:
        app: lscm-frontend
    spec:
      containers:
      - name: frontend
        image: node:18-alpine
        workingDir: /app
        command: ["npm", "run", "start:prod"]
        ports:
        - containerPort: 3001
        env:
        - name: NEXT_PUBLIC_API_URL
          value: "http://$BACKEND_IP"
        - name: NODE_ENV
          value: production
        resources:
          requests:
            memory: "256Mi"
            cpu: "100m"
          limits:
            memory: "512Mi"
            cpu: "500m"
---
apiVersion: v1
kind: Service
metadata:
  name: lscm-frontend
  namespace: $NAMESPACE
spec:
  type: LoadBalancer
  ports:
  - port: 80
    targetPort: 3001
    protocol: TCP
  selector:
    app: lscm-frontend
EOF

# Get frontend IP
kubectl get service lscm-frontend -n $NAMESPACE
export FRONTEND_IP=$(kubectl get service lscm-frontend -n $NAMESPACE -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
echo "Frontend IP: $FRONTEND_IP"
```

═══════════════════════════════════════════════════════════════════════════════
## PHASE 8: INITIALIZE DATABASE
═══════════════════════════════════════════════════════════════════════════════

```bash
# Run migrations
kubectl exec -it -n $NAMESPACE postgres-0 -- \
  psql -U lscm_user -d lscm_erp \
  -c "CREATE TABLE IF NOT EXISTS shipment_orders (id SERIAL PRIMARY KEY);"

# Or use Prisma if available in your deployment
```

═══════════════════════════════════════════════════════════════════════════════
## USEFUL COMMANDS (ONGOING)
═══════════════════════════════════════════════════════════════════════════════

### Check status
```bash
kubectl get all -n $NAMESPACE
kubectl get pods -n $NAMESPACE
kubectl get services -n $NAMESPACE
kubectl get pvc -n $NAMESPACE
```

### View logs
```bash
# Backend logs
kubectl logs -n $NAMESPACE -f deployment/lscm-backend

# Frontend logs
kubectl logs -n $NAMESPACE -f deployment/lscm-frontend

# Postgres logs
kubectl logs -n $NAMESPACE -f statefulset/postgres

# Specific pod
kubectl logs -n $NAMESPACE <pod-name>
```

### Describe resources
```bash
kubectl describe pod -n $NAMESPACE <pod-name>
kubectl describe service -n $NAMESPACE <service-name>
kubectl describe deployment -n $NAMESPACE <deployment-name>
```

### Scale deployments
```bash
# Scale backend to 3 replicas
kubectl scale deployment lscm-backend -n $NAMESPACE --replicas=3

# Scale frontend to 3 replicas
kubectl scale deployment lscm-frontend -n $NAMESPACE --replicas=3
```

### Port forwarding
```bash
# Forward postgres locally
kubectl port-forward -n $NAMESPACE svc/postgres 5432:5432 &

# Forward redis locally
kubectl port-forward -n $NAMESPACE svc/redis 6379:6379 &

# Kill port forwards
kill %1 %2
```

### Get into a pod
```bash
kubectl exec -it -n $NAMESPACE <pod-name> -- sh
```

### Delete resources
```bash
# Delete a pod (it will restart)
kubectl delete pod -n $NAMESPACE <pod-name>

# Delete entire deployment
kubectl delete deployment -n $NAMESPACE lscm-backend

# Delete entire namespace (CAREFUL!)
kubectl delete namespace $NAMESPACE
```

### Watch events
```bash
# Watch cluster events
kubectl get events -n $NAMESPACE -w

# Watch specific resource
kubectl get pods -n $NAMESPACE -w
```

═══════════════════════════════════════════════════════════════════════════════
## MONITORING & MAINTENANCE
═══════════════════════════════════════════════════════════════════════════════

### Check resources
```bash
# CPU and memory usage
kubectl top pods -n $NAMESPACE
kubectl top nodes

# Disk usage
kubectl get pvc -n $NAMESPACE
```

### Backup database
```bash
# Create backup
kubectl exec -n $NAMESPACE postgres-0 -- \
  pg_dump -U lscm_user lscm_erp > backup.sql

# Restore backup
kubectl exec -i -n $NAMESPACE postgres-0 -- \
  psql -U lscm_user lscm_erp < backup.sql
```

### Health check
```bash
# Check backend health
curl http://$BACKEND_IP/health

# Check all pods running
kubectl get pods -n $NAMESPACE
# All should show "Running" and "1/1" ready

# Check services have IPs
kubectl get services -n $NAMESPACE
# Backend and Frontend should have EXTERNAL-IP
```

═══════════════════════════════════════════════════════════════════════════════
## CLEANUP (WHEN DONE)
═══════════════════════════════════════════════════════════════════════════════

### Delete everything (careful!)
```bash
# Delete namespace (everything in it)
kubectl delete namespace $NAMESPACE

# Delete cluster
doctl kubernetes cluster delete $CLUSTER_NAME

# Delete registry
doctl registry delete lscm-erp

# Verify cleanup
doctl kubernetes cluster list
doctl registry list-repositories
```

### Cost savings
```bash
# Check current resources
doctl kubernetes cluster list
doctl kubernetes cluster get-size lscm-prod
doctl registry list-repositories

# Stop cluster (saves money):
# Don't delete, just stop if you'll resume later
# DigitalOcean Dashboard → Kubernetes → More → Power Off
```

═══════════════════════════════════════════════════════════════════════════════
## QUICK ACCESS
═══════════════════════════════════════════════════════════════════════════════

Once everything is running:

```
Frontend:      http://$FRONTEND_IP
API Docs:      http://$BACKEND_IP/api/docs
API Health:    http://$BACKEND_IP/health

Login:
  Email: coordinator@lscm.com
  Password: password123

Database:
  Host: postgres (internal)
  Port: 5432
  User: lscm_user
  Password: $POSTGRES_PASSWORD

Redis:
  Host: redis
  Port: 6379
```

═══════════════════════════════════════════════════════════════════════════════
## TROUBLESHOOTING
═══════════════════════════════════════════════════════════════════════════════

### Pod won't start
```bash
kubectl describe pod -n $NAMESPACE <pod-name>
kubectl logs -n $NAMESPACE <pod-name>
```

### LoadBalancer IP not assigned
```bash
# Wait 5+ minutes
kubectl get service -n $NAMESPACE
# If still pending, check firewall rules in DigitalOcean
```

### Connection refused
```bash
# Check if service is running
kubectl get service lscm-backend -n $NAMESPACE

# Check if pod is running
kubectl get pods -n $NAMESPACE -o wide

# Test connection
kubectl run -it --rm debug --image=alpine --restart=Never \
  -n $NAMESPACE -- wget -O - http://lscm-backend
```

### Database connection failed
```bash
# Check postgres is running
kubectl get pods -n $NAMESPACE | grep postgres

# Check connection
kubectl exec -it -n $NAMESPACE postgres-0 -- \
  psql -U lscm_user -d lscm_erp -c "SELECT 1"
```

═══════════════════════════════════════════════════════════════════════════════

**Ready to deploy? Follow the DEPLOYMENT_GUIDE_LOCAL_DO.md for detailed steps!**
