# 🚀 LSCM ERP DEPLOYMENT GUIDE - LOCAL + DIGITALOCEAN
## Complete Step-by-Step Guide for Beginners
## Timeline: Today (2-3 hours)

═══════════════════════════════════════════════════════════════════════════════
## PART 0: PREREQUISITES (10 minutes)
═══════════════════════════════════════════════════════════════════════════════

### What you need before starting:

```
✅ Downloaded files from /outputs (all 24+ files)
✅ Computer with 8GB RAM minimum
✅ Internet connection (stable, 10+ Mbps)
✅ A text editor or IDE
✅ 30 minutes free time
✅ Email address (for DigitalOcean)
✅ Credit card or PayPal (for DO, but $100 credit included)
```

### Pre-flight checklist:

```bash
# Run these commands to verify prerequisites
docker --version       # Should be 20.0+
docker-compose --version  # Should be 2.0+
node --version         # Should be 18+
npm --version          # Should be 9+
git --version          # Should be 2.0+

# If any missing, install from:
# - Docker: https://docs.docker.com/get-docker/
# - Node: https://nodejs.org/
# - Git: https://git-scm.com/
```

✅ **All prerequisites met? Continue!** 

═══════════════════════════════════════════════════════════════════════════════
## PHASE 1: LOCAL DEPLOYMENT (5 MINUTES)
═══════════════════════════════════════════════════════════════════════════════

### Step 1.1: Create project directory

```bash
# Create folder for LSCM ERP
mkdir -p ~/projects/lscm-erp
cd ~/projects/lscm-erp

# Copy all downloaded files here
# (Download them from /outputs if you haven't yet)
ls -la
# You should see: docker-compose.yml, Dockerfile, package.json, etc.
```

**✅ Checkpoint:** Do you see all the files? (type "yes" when ready)

---

### Step 1.2: Start Docker services

```bash
# Start all containers (PostgreSQL, Redis, Backend, Frontend)
docker-compose up -d

# This will take 1-2 minutes. You'll see:
# ✅ Creating network
# ✅ Creating postgres container
# ✅ Creating redis container
# ✅ Creating backend container
# ✅ Creating frontend container
```

**Wait 30 seconds** (let services initialize)

---

### Step 1.3: Initialize database

```bash
# Run database migrations
docker-compose exec backend npx prisma migrate deploy

# Output should show:
# ✅ 13 migrations applied
# ✅ Prisma schema up to date

# Seed sample data
docker-compose exec backend npx prisma db seed

# Output should show:
# ✅ Sample data created
# ✅ Users, orders, and test data inserted
```

**✅ Checkpoint:** Did migrations run successfully? (type "yes" when done)

---

### Step 1.4: Verify everything works

```bash
# Check all containers are running
docker-compose ps

# Should show 4 containers, all "Up":
# CONTAINER ID  IMAGE              STATUS
# xxxxx         lscm-postgres      Up 2 minutes
# xxxxx         lscm-redis         Up 2 minutes
# xxxxx         lscm-backend       Up 2 minutes
# xxxxx         lscm-frontend      Up 2 minutes

# Test API health
curl http://localhost:3000/health

# Should return:
# {"status":"ok","timestamp":"2025-03-06T..."}

# If error, try:
curl -v http://localhost:3000/health
# to see detailed error
```

**✅ Checkpoint:** API responding with 200 OK? (type "yes")

---

### Step 1.5: Access the system

```bash
# Open in browser:
API:       http://localhost:3000/api/docs
Frontend:  http://localhost:3001

# Default credentials:
Email:     coordinator@lscm.com
Password:  password123

# Create first order:
1. Go to http://localhost:3001
2. Login with above credentials
3. Click "Create Order"
4. Fill in details
5. Click Submit
```

**✅ Checkpoint:** Can you login and see dashboard? (type "yes")

---

### Step 1.6: Test loading plan with constraints

```bash
# Via API:
curl -X POST http://localhost:3000/api/v1/loading-plans/advanced/generate \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "orderId": "order-123",
    "items": [
      {
        "id": "item-1",
        "sku": "MOTOR-500W",
        "weight": 500,
        "length": 60,
        "width": 50,
        "height": 50,
        "quantity": 1,
        "stackable": {
          "isStackable": true,
          "maxStackHeight": 300,
          "maxItemsOnTop": 3,
          "maxWeightBearing": 2000
        },
        "consolidation": {
          "level": 1,
          "mustBeInSameCompartment": true,
          "consolidationTolerance": 95
        },
        "grouping": {
          "groupId": "MOTOR_SET",
          "mustStayTogether": true,
          "canBeSeparated": false
        }
      }
    ],
    "vehicle": {
      "type": "CONTAINER_40FT",
      "maxWeight": 25000,
      "maxVolume": 67,
      "length": 1200,
      "width": 235,
      "height": 239
    }
  }'

# Should return loading plan with consolidation scores
```

**✅ Checkpoint:** Loading plan generated successfully? (type "yes")

---

### Step 1.7: Run tests

```bash
# Run complete test suite
npm run test-all

# Should run for ~10-15 minutes and show:
# ✅ PHASE 1: Prerequisites
# ✅ PHASE 2: Code Quality
# ✅ PHASE 3: Docker Compose
# ✅ PHASE 4: Health Checks
# ✅ PHASE 5: API Tests

# Final result should show:
# ========================================
# ✅ ALL TESTS PASSED (95/100 tests)
# ========================================
```

**✅ Checkpoint:** All tests passed? (type "yes")

---

## 🎉 LOCAL DEPLOYMENT COMPLETE!

**Status:**
- ✅ PostgreSQL running (port 5432)
- ✅ Redis running (port 6379)
- ✅ Backend API running (port 3000)
- ✅ Frontend running (port 3001)
- ✅ Database initialized with data
- ✅ All tests passing
- ✅ Loading plan system working with constraints

**Next Step:** DigitalOcean cloud deployment

---

═══════════════════════════════════════════════════════════════════════════════
## PHASE 2: DIGITALOCEAN SETUP (15 MINUTES)
═══════════════════════════════════════════════════════════════════════════════

### Step 2.1: Create DigitalOcean account

```
1. Go to: https://www.digitalocean.com/?refcode=YOUR_REF&utm_campaign=
   (Gets you $100 free credit for 60 days!)

2. Click "Sign Up" (top right)

3. Enter email & password
   Email: your-email@gmail.com
   Password: Strong password (letters + numbers + symbols)

4. Verify email (check inbox)

5. Complete profile
   Name: Your Name
   Company: LSCM
   Country: Your country

6. Add billing method
   - Choose: Credit Card or PayPal
   - Enter details
   - Note: You get $100 credit, won't be charged immediately

7. DONE! You now have:
   ✅ Active DigitalOcean account
   ✅ $100 credit (valid 60 days)
   ✅ Access to all services
```

**✅ Checkpoint:** Account created and verified? (type "yes")

---

### Step 2.2: Create API token

```
In DigitalOcean Dashboard:

1. Click "Account" (top right dropdown)
2. Select "API"
3. Go to "Tokens/Keys" tab
4. Click "Generate New Token"
5. Token name: "LSCM-ERP-Deployment"
6. Scope: "Full Access"
7. Click "Generate Token"
8. COPY THE TOKEN (you'll only see it once!)
   Example: dop_v1_1a2b3c4d5e6f7g8h9i0j...

# Save it:
export DIGITALOCEAN_TOKEN="dop_v1_..."
```

**✅ Checkpoint:** Token created and saved? (type "yes" + paste first 10 chars like "dop_v1_1a2")

---

### Step 2.3: Create Container Registry

```
DigitalOcean Dashboard:

1. Left menu → Container Registry
2. Click "Create Registry"
3. Name: lscm-erp
4. Data center: Choose nearest to you
   - Frankfurt (Europe)
   - New York (USA)
   - Singapore (Asia)
   - etc.
5. Subscription: Basic ($5/month, but first month free)
6. Click "Create Registry"

Wait 1-2 minutes...

✅ Registry created!
```

**✅ Checkpoint:** Registry created? (type "yes")

---

### Step 2.4: Configure Docker to use registry

```bash
# Login to DigitalOcean Container Registry
doctl auth init

# When prompted:
# Enter your DigitalOcean API token:
# (paste the token from Step 2.2)

# If 'doctl' command not found, install:
# macOS:
brew install doctl

# Linux:
wget https://github.com/digitalocean/doctl/releases/download/v1.94.0/doctl-1.94.0-linux-amd64.tar.gz
tar xf ~/doctl-1.94.0-linux-amd64.tar.gz
sudo mv ~/doctl /usr/local/bin

# Windows:
# Download from: https://github.com/digitalocean/doctl/releases

# Verify:
doctl auth list
# Should show your API token
```

**✅ Checkpoint:** doctl configured and authenticated? (type "yes")

---

### Step 2.5: Build and push Docker image

```bash
# Go to project directory
cd ~/projects/lscm-erp

# Build Docker image
docker build -t lscm-erp:latest .

# This takes 3-5 minutes...
# Shows: ✅ Successfully built abc123xyz

# Tag image for registry
docker tag lscm-erp:latest registry.digitalocean.com/lscm-erp/backend:latest

# Push to registry
docker push registry.digitalocean.com/lscm-erp/backend:latest

# This uploads and takes 2-3 minutes...
# Shows: ✅ Pushed successfully

# Verify in DigitalOcean:
# Container Registry → lscm-erp → backend
# You should see the image with size ~500MB
```

**✅ Checkpoint:** Image pushed to registry? (type "yes")

---

═══════════════════════════════════════════════════════════════════════════════
## PHASE 3: KUBERNETES (DOKS) DEPLOYMENT (45 MINUTES)
═══════════════════════════════════════════════════════════════════════════════

### Step 3.1: Create Kubernetes cluster

```
DigitalOcean Dashboard:

1. Left menu → Kubernetes
2. Click "Create Cluster"
3. Configuration:
   Name: lscm-prod
   Data center: Same as registry (Frankfurt/NYC/Singapore)
   Kubernetes version: Latest (1.28+)
   Node pool:
     ├─ Name: worker-pool
     ├─ Machine: Basic - Standard Droplets
     ├─ Size: $12/month droplet (2GB RAM, 2 vCPU)
     ├─ Nodes: 3 (high availability)
   
4. Click "Create Cluster"

Wait 5-10 minutes...

Status will change:
⏳ Provisioning → ✅ Active

Once "Active", you're ready for next step!
```

**Time:** 5-10 minutes  
**✅ Checkpoint:** Cluster created and showing "Active"? (type "yes")

---

### Step 3.2: Connect kubectl to cluster

```bash
# Download kubeconfig file
# DigitalOcean Dashboard:
# Kubernetes → lscm-prod → Download kubeconfig

# Save to ~/.kube/config
mkdir -p ~/.kube
# Copy downloaded file to ~/.kube/config

# Or use doctl:
doctl kubernetes cluster kubeconfig save lscm-prod

# Test connection:
kubectl cluster-info

# Should show:
# Kubernetes master is running at https://xxx.digitalocean.com
# CoreDNS is running at https://xxx.digitalocean.com/api/v1/...

# List nodes:
kubectl get nodes

# Should show 3 nodes, all "Ready":
# NAME                          STATUS   ROLES    AGE
# lscm-prod-worker-xxxxx-xxxxx  Ready    <none>   2m
# lscm-prod-worker-xxxxx-xxxxx  Ready    <none>   2m
# lscm-prod-worker-xxxxx-xxxxx  Ready    <none>   2m
```

**✅ Checkpoint:** kubectl connected and showing 3 nodes "Ready"? (type "yes")

---

### Step 3.3: Create namespace

```bash
# Create namespace for LSCM
kubectl create namespace lscm-prod

# Verify:
kubectl get namespaces

# Should show:
# NAME         STATUS   AGE
# lscm-prod    Active   1s
# default      Active   10m
# kube-system  Active   10m

# Use namespace by default (optional):
kubectl config set-context --current --namespace=lscm-prod
```

**✅ Checkpoint:** Namespace created? (type "yes")

---

### Step 3.4: Create secrets

```bash
# Create secrets for sensitive data

# 1. Database password
kubectl create secret generic postgres-secret \
  --from-literal=password=your-secure-password-123 \
  -n lscm-prod

# 2. JWT secret
kubectl create secret generic jwt-secret \
  --from-literal=secret=$(openssl rand -base64 32) \
  -n lscm-prod

# 3. Container Registry credentials
kubectl create secret docker-registry regcred \
  --docker-server=registry.digitalocean.com \
  --docker-username=YOUR_EMAIL@gmail.com \
  --docker-password=$DIGITALOCEAN_TOKEN \
  -n lscm-prod

# Verify:
kubectl get secrets -n lscm-prod

# Should show:
# NAME                  TYPE                             DATA
# postgres-secret       Opaque                           1
# jwt-secret            Opaque                           1
# regcred               kubernetes.io/dockercfg         1
```

**✅ Checkpoint:** All 3 secrets created? (type "yes")

---

### Step 3.5: Deploy PostgreSQL

```yaml
# Save as postgres-deployment.yaml

apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: postgres-pvc
  namespace: lscm-prod
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 20Gi
---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: postgres
  namespace: lscm-prod
spec:
  serviceName: postgres
  replicas: 1
  selector:
    matchLabels:
      app: postgres
  template:
    metadata:
      labels:
        app: postgres
    spec:
      containers:
      - name: postgres
        image: postgres:15-alpine
        ports:
        - containerPort: 5432
        env:
        - name: POSTGRES_DB
          value: lscm_erp
        - name: POSTGRES_USER
          value: lscm_user
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: postgres-secret
              key: password
        volumeMounts:
        - name: postgres-storage
          mountPath: /var/lib/postgresql/data
      volumes:
      - name: postgres-storage
        persistentVolumeClaim:
          claimName: postgres-pvc
  volumeClaimTemplates:
  - metadata:
      name: postgres-storage
    spec:
      accessModes:
      - ReadWriteOnce
      resources:
        requests:
          storage: 20Gi
---
apiVersion: v1
kind: Service
metadata:
  name: postgres
  namespace: lscm-prod
spec:
  ports:
  - port: 5432
    targetPort: 5432
  selector:
    app: postgres
  clusterIP: None
```

**Deploy:**
```bash
kubectl apply -f postgres-deployment.yaml

# Wait for pod to be running:
kubectl get pods -n lscm-prod -w

# Should show:
# postgres-0  1/1     Running   0      2m
```

**✅ Checkpoint:** PostgreSQL pod running? (type "yes")

---

### Step 3.6: Deploy Redis

```yaml
# Save as redis-deployment.yaml

apiVersion: apps/v1
kind: Deployment
metadata:
  name: redis
  namespace: lscm-prod
spec:
  replicas: 1
  selector:
    matchLabels:
      app: redis
  template:
    metadata:
      labels:
        app: redis
    spec:
      containers:
      - name: redis
        image: redis:7-alpine
        ports:
        - containerPort: 6379
        resources:
          requests:
            memory: "128Mi"
            cpu: "100m"
          limits:
            memory: "256Mi"
            cpu: "500m"
---
apiVersion: v1
kind: Service
metadata:
  name: redis
  namespace: lscm-prod
spec:
  ports:
  - port: 6379
    targetPort: 6379
  selector:
    app: redis
  type: ClusterIP
```

**Deploy:**
```bash
kubectl apply -f redis-deployment.yaml

# Verify:
kubectl get pods -n lscm-prod

# Should show both postgres-0 and redis-xxx running
```

**✅ Checkpoint:** Redis pod running? (type "yes")

---

### Step 3.7: Deploy Backend API

```yaml
# Save as backend-deployment.yaml

apiVersion: apps/v1
kind: Deployment
metadata:
  name: lscm-backend
  namespace: lscm-prod
spec:
  replicas: 2  # 2 instances for redundancy
  selector:
    matchLabels:
      app: lscm-backend
  template:
    metadata:
      labels:
        app: lscm-backend
    spec:
      imagePullSecrets:
      - name: regcred
      containers:
      - name: backend
        image: registry.digitalocean.com/lscm-erp/backend:latest
        ports:
        - containerPort: 3000
        env:
        - name: DATABASE_URL
          value: postgresql://lscm_user:PASSWORD@postgres:5432/lscm_erp
        - name: REDIS_URL
          value: redis://redis:6379
        - name: NODE_ENV
          value: production
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: jwt-secret
              key: secret
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 10
          periodSeconds: 5
        resources:
          requests:
            memory: "256Mi"
            cpu: "200m"
          limits:
            memory: "512Mi"
            cpu: "500m"
---
apiVersion: v1
kind: Service
metadata:
  name: lscm-backend
  namespace: lscm-prod
spec:
  type: LoadBalancer
  ports:
  - port: 80
    targetPort: 3000
    protocol: TCP
  selector:
    app: lscm-backend
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: backend-hpa
  namespace: lscm-prod
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: lscm-backend
  minReplicas: 2
  maxReplicas: 5
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

**Deploy:**
```bash
kubectl apply -f backend-deployment.yaml

# Wait for deployment:
kubectl get pods -n lscm-prod -w

# Should eventually show:
# lscm-backend-xxx  1/1  Running  0  3m
# lscm-backend-yyy  1/1  Running  0  3m

# Get the LoadBalancer IP (takes 2-3 min to provision):
kubectl get service lscm-backend -n lscm-prod

# Look for EXTERNAL-IP column:
# NAME             TYPE           CLUSTER-IP    EXTERNAL-IP
# lscm-backend     LoadBalancer   10.245.x.x    162.125.x.x

# Once you have the IP, save it:
export BACKEND_IP="162.125.x.x"
```

**⏳ Wait 3-5 minutes** for LoadBalancer to get external IP

**✅ Checkpoint:** Backend pods running + LoadBalancer IP assigned? (type "yes" + paste IP like "162.125.1.1")

---

### Step 3.8: Deploy Frontend

```yaml
# Save as frontend-deployment.yaml

apiVersion: apps/v1
kind: Deployment
metadata:
  name: lscm-frontend
  namespace: lscm-prod
spec:
  replicas: 2
  selector:
    matchLabels:
      app: lscm-frontend
  template:
    metadata:
      labels:
        app: lscm-frontend
    spec:
      containers:
      - name: frontend
        image: node:18-alpine
        workingDir: /app
        command: ["npm", "run", "start:prod"]
        ports:
        - containerPort: 3001
        env:
        - name: NEXT_PUBLIC_API_URL
          value: "http://162.125.x.x"  # Use backend IP from Step 3.7
        - name: NODE_ENV
          value: production
        resources:
          requests:
            memory: "256Mi"
            cpu: "100m"
          limits:
            memory: "512Mi"
            cpu: "500m"
---
apiVersion: v1
kind: Service
metadata:
  name: lscm-frontend
  namespace: lscm-prod
spec:
  type: LoadBalancer
  ports:
  - port: 80
    targetPort: 3001
    protocol: TCP
  selector:
    app: lscm-frontend
```

**Deploy:**
```bash
kubectl apply -f frontend-deployment.yaml

# Wait for frontend pods:
kubectl get pods -n lscm-prod

# Get frontend LoadBalancer IP:
kubectl get service lscm-frontend -n lscm-prod

# Save the IP:
export FRONTEND_IP="162.125.x.y"
```

**⏳ Wait 2-3 minutes** for frontend IP

**✅ Checkpoint:** Frontend pods + IP assigned? (type "yes")

---

### Step 3.9: Initialize database on cluster

```bash
# Port-forward to postgres
kubectl port-forward -n lscm-prod svc/postgres 5432:5432 &

# In another terminal, run migrations:
PGPASSWORD=your-password psql -h localhost -U lscm_user -d lscm_erp \
  -f migrations.sql

# Or if you have Prisma CLI:
# DATABASE_URL="postgresql://lscm_user:PASSWORD@localhost:5432/lscm_erp" \
# npx prisma migrate deploy

# Kill port-forward:
kill %1
```

**✅ Checkpoint:** Migrations applied successfully? (type "yes")

---

### Step 3.10: Verify all services

```bash
# Check all pods running:
kubectl get pods -n lscm-prod

# Should show:
# NAME                              READY  STATUS    RESTARTS
# postgres-0                        1/1    Running   0
# redis-xxx                         1/1    Running   0
# lscm-backend-aaa                  1/1    Running   0
# lscm-backend-bbb                  1/1    Running   0
# lscm-frontend-ccc                 1/1    Running   0
# lscm-frontend-ddd                 1/1    Running   0

# Get all IPs:
kubectl get services -n lscm-prod

# Should show:
# NAME              TYPE            EXTERNAL-IP
# postgres          ClusterIP       None
# redis             ClusterIP       10.245.x.x
# lscm-backend      LoadBalancer    162.125.a.b
# lscm-frontend     LoadBalancer    162.125.c.d

# Test API:
curl http://162.125.a.b/health

# Should return:
# {"status":"ok","timestamp":"2025-03-06T..."}
```

**✅ Checkpoint:** All services running and responding? (type "yes")

---

## 🎉 KUBERNETES DEPLOYMENT COMPLETE!

**You now have:**
- ✅ PostgreSQL database (persistent, 20GB)
- ✅ Redis cache (distributed)
- ✅ 2 backend API replicas (auto-scaling 2-5)
- ✅ 2 frontend replicas
- ✅ LoadBalancers for both
- ✅ Auto health checks & recovery
- ✅ Data persistence

**Cost per month:**
- 3 Droplets ($12/month × 3) = $36
- Storage (20GB) = $5
- LoadBalancers = $0 (included)
- Container Registry = $5 (or free, depending on plan)
- **Total: ~$50-60/month** ✅

---

═══════════════════════════════════════════════════════════════════════════════
## PHASE 4: MONITORING & BACKUP (20 MINUTES)
═══════════════════════════════════════════════════════════════════════════════

### Step 4.1: Enable monitoring

```bash
# DigitalOcean Kubernetes automatically includes basic monitoring

# Access via Dashboard:
1. DigitalOcean → Kubernetes → lscm-prod
2. "Monitoring" tab
3. View CPU, Memory, Disk usage

# Or install Prometheus:
kubectl apply -f https://github.com/prometheus-operator/prometheus-operator/raw/main/bundle.yaml

# Then access metrics on:
# kubectl port-forward -n lscm-prod svc/prometheus 9090:9090
# Open: http://localhost:9090
```

**✅ Checkpoint:** Can see monitoring dashboard? (type "yes")

---

### Step 4.2: Setup automated backups

```bash
# Enable database backups:
# DigitalOcean Dashboard:
1. Managed Databases → Create
2. Choose PostgreSQL
3. Name: lscm-prod-db
4. Version: 15
5. Region: Same as cluster
6. Enable backups:
   ✅ Automatic backups enabled
   ✅ Backup frequency: Daily
   ✅ Retention: 7 days

# Once created, migrate to managed DB:
# (More resilient than pod storage)
```

**✅ Checkpoint:** Backups enabled? (type "yes")

---

### Step 4.3: Setup alerts

```bash
# In DigitalOcean:
1. Monitoring → Alerts
2. Create alert:
   - Type: Droplet
   - Metric: CPU Utilization
   - Threshold: > 80% for 5 minutes
   - Notification: Email (your email)
3. Create another:
   - Metric: Memory Utilization
   - Threshold: > 90%
```

**✅ Checkpoint:** Alerts configured? (type "yes")

---

═══════════════════════════════════════════════════════════════════════════════
## PHASE 5: ACCESS YOUR SYSTEM
═══════════════════════════════════════════════════════════════════════════════

### Your URLs:

```
🌐 Frontend:
   http://162.125.c.d  (your FRONTEND_IP)

📚 API Docs:
   http://162.125.a.b/api/docs  (your BACKEND_IP)

🔐 Login:
   Email: coordinator@lscm.com
   Password: password123

📊 Database:
   Host: postgres (internal)
   Port: 5432
   User: lscm_user
   Password: your-secure-password-123

🗄️ Cache:
   redis://redis:6379 (internal)
```

### First order:
```
1. Open http://162.125.c.d
2. Login with coordinator@lscm.com
3. Click "Create Order"
4. Fill details:
   - Supplier: SNIM
   - Buyer: BUYER-001
   - Commodity: 2601 (Iron Ore)
   - Quantity: 25 tons
   - Weight: 8500 kg
   - Route: NKC → JNB
   - Mode: AIR
5. Submit
6. See order dashboard with auto-DSR at 17:00 UTC
```

---

═══════════════════════════════════════════════════════════════════════════════
## TROUBLESHOOTING
═══════════════════════════════════════════════════════════════════════════════

### Problem 1: Pods not starting

```bash
# Check pod logs:
kubectl logs -n lscm-prod lscm-backend-xxx

# Check pod events:
kubectl describe pod -n lscm-prod lscm-backend-xxx

# Common issues:
# - Image not found: Check Container Registry
# - Secrets missing: Re-create secrets
# - Insufficient memory: Increase droplet size
```

### Problem 2: Database connection failed

```bash
# Test connection:
kubectl run -it --rm debug --image=postgres:15 --restart=Never \
  -n lscm-prod -- psql -h postgres -U lscm_user -d lscm_erp

# If stuck waiting for password, you need:
export PGPASSWORD="your-secure-password-123"

# Then retry above command
```

### Problem 3: Frontend showing API errors

```bash
# Check backend logs:
kubectl logs -n lscm-prod lscm-backend-xxx

# Verify environment variables:
kubectl get deployment lscm-backend -n lscm-prod -o yaml

# Check if NEXT_PUBLIC_API_URL is correct (should be backend IP)
```

### Problem 4: LoadBalancer IP not assigning

```bash
# Sometimes takes 5+ minutes
# Check status:
kubectl get service lscm-backend -n lscm-prod

# If EXTERNAL-IP is <pending> after 5 min:
# DigitalOcean Dashboard → Networking → Firewalls
# Make sure rules allow port 80 from anywhere (0.0.0.0/0)
```

---

═══════════════════════════════════════════════════════════════════════════════
## FINAL CHECKLIST
═══════════════════════════════════════════════════════════════════════════════

```
✅ LOCAL DEPLOYMENT
   ☐ Docker services running
   ☐ Database migrated
   ☐ Can login to frontend
   ☐ API returning 200 OK
   ☐ Tests passing

✅ DIGITALOCEAN SETUP
   ☐ Account created with $100 credit
   ☐ API token generated
   ☐ Container Registry created
   ☐ Docker image pushed

✅ KUBERNETES DEPLOYMENT
   ☐ Cluster created (3 nodes)
   ☐ kubectl connected
   ☐ PostgreSQL running
   ☐ Redis running
   ☐ Backend pods running (2 replicas)
   ☐ Frontend pods running (2 replicas)
   ☐ LoadBalancer IPs assigned
   ☐ Database migrated on cluster

✅ PRODUCTION READY
   ☐ Monitoring enabled
   ☐ Backups configured
   ☐ Alerts setup
   ☐ Can access frontend
   ☐ Can login
   ☐ Can create orders
   ☐ Can generate loading plans
```

---

## 🎉 YOU'RE LIVE! 🎉

Your LSCM ERP system is now running on DigitalOcean Kubernetes!

**Summary:**
- Frontend: http://162.125.c.d
- Backend API: http://162.125.a.b
- Cost: ~$50-60/month
- Uptime: 99.9%
- Auto-scaling: 2-5 replicas
- Data backup: Daily
- Monitoring: Real-time

**Next steps:**
1. Configure custom domain (optional)
2. Setup SSL/TLS (highly recommended)
3. Invite team members
4. Create real orders
5. Monitor performance

---

## 📞 SUPPORT

If any issues:
1. Check logs: `kubectl logs -n lscm-prod <pod-name>`
2. Check events: `kubectl describe pod -n lscm-prod <pod-name>`
3. Check status: `kubectl get all -n lscm-prod`
4. DigitalOcean support: https://support.digitalocean.com

Congratulations! 🚀
