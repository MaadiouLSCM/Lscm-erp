#!/bin/bash
# azure/deploy-to-azure.sh - Complete Azure Deployment Script

set -e

# ============================================================================
# AZURE DEPLOYMENT SCRIPT - LSCM ERP SYSTEM
# ============================================================================
# Components: AKS (Kubernetes), Azure Database for PostgreSQL, Azure Cache for Redis

AZURE_SUBSCRIPTION=${AZURE_SUBSCRIPTION:-"your-subscription-id"}
AZURE_RESOURCE_GROUP="lscm-erp-prod"
AZURE_REGION="eastus"
CLUSTER_NAME="lscm-erp-cluster"
REGISTRY_NAME="lscmerpacr"
APP_NAME="lscm-erp"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_section() {
    echo ""
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}║ $1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
}

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_azure_cli() {
    if ! command -v az &> /dev/null; then
        log_error "Azure CLI not installed"
        exit 1
    fi
    
    if ! az account show > /dev/null 2>&1; then
        log_error "Azure CLI not authenticated. Run: az login"
        exit 1
    fi
    
    log_info "Azure CLI authenticated"
}

create_resource_group() {
    log_section "Creating Resource Group"
    
    if az group exists --name "$AZURE_RESOURCE_GROUP" --subscription "$AZURE_SUBSCRIPTION" | grep -q true; then
        log_info "Resource group already exists"
    else
        log_info "Creating resource group..."
        
        az group create \
            --name "$AZURE_RESOURCE_GROUP" \
            --location "$AZURE_REGION" \
            --subscription "$AZURE_SUBSCRIPTION"
        
        log_info "Resource group created"
    fi
}

create_container_registry() {
    log_section "Creating Container Registry"
    
    if az acr show \
        --name "$REGISTRY_NAME" \
        --resource-group "$AZURE_RESOURCE_GROUP" \
        --subscription "$AZURE_SUBSCRIPTION" > /dev/null 2>&1; then
        log_info "Container registry already exists"
    else
        log_info "Creating container registry..."
        
        az acr create \
            --resource-group "$AZURE_RESOURCE_GROUP" \
            --name "$REGISTRY_NAME" \
            --sku Basic \
            --admin-enabled true \
            --subscription "$AZURE_SUBSCRIPTION"
        
        log_info "Container registry created"
    fi
}

build_and_push_image_acr() {
    log_section "Building and Pushing Docker Image to ACR"
    
    REGISTRY_URL="${REGISTRY_NAME}.azurecr.io"
    IMAGE_NAME="${REGISTRY_URL}/${APP_NAME}:latest"
    
    log_info "Logging into ACR..."
    
    az acr login --name "$REGISTRY_NAME" \
        --resource-group "$AZURE_RESOURCE_GROUP" \
        --subscription "$AZURE_SUBSCRIPTION"
    
    log_info "Building Docker image..."
    
    az acr build \
        --registry "$REGISTRY_NAME" \
        --image "${APP_NAME}:latest" \
        --file Dockerfile .
    
    log_info "Image pushed: $IMAGE_NAME"
    echo "$IMAGE_NAME"
}

create_azure_database() {
    log_section "Creating Azure Database for PostgreSQL"
    
    DB_SERVER_NAME="$APP_NAME-postgres"
    DB_NAME="lscm_erp"
    
    if az postgres server show \
        --name "$DB_SERVER_NAME" \
        --resource-group "$AZURE_RESOURCE_GROUP" \
        --subscription "$AZURE_SUBSCRIPTION" > /dev/null 2>&1; then
        log_info "PostgreSQL server already exists"
    else
        log_info "Creating PostgreSQL server..."
        
        az postgres server create \
            --name "$DB_SERVER_NAME" \
            --resource-group "$AZURE_RESOURCE_GROUP" \
            --location "$AZURE_REGION" \
            --admin-user lscm_admin \
            --admin-password "$(openssl rand -base64 32)" \
            --sku-name B_Gen5_1 \
            --storage-size 102400 \
            --version 15 \
            --backup-retention 30 \
            --geo-redundant-backup Enabled \
            --enable-log-analytics true \
            --subscription "$AZURE_SUBSCRIPTION"
        
        log_info "PostgreSQL server created"
    fi
    
    # Create database
    log_info "Creating database..."
    az postgres db create \
        --name "$DB_NAME" \
        --server-name "$DB_SERVER_NAME" \
        --resource-group "$AZURE_RESOURCE_GROUP" \
        --subscription "$AZURE_SUBSCRIPTION" 2>/dev/null || true
    
    # Get connection string
    FQDN=$(az postgres server show \
        --name "$DB_SERVER_NAME" \
        --resource-group "$AZURE_RESOURCE_GROUP" \
        --subscription "$AZURE_SUBSCRIPTION" \
        --query "fullyQualifiedDomainName" -o tsv)
    
    echo "$FQDN"
}

create_azure_cache() {
    log_section "Creating Azure Cache for Redis"
    
    CACHE_NAME="$APP_NAME-redis"
    
    if az redis show \
        --name "$CACHE_NAME" \
        --resource-group "$AZURE_RESOURCE_GROUP" \
        --subscription "$AZURE_SUBSCRIPTION" > /dev/null 2>&1; then
        log_info "Redis cache already exists"
    else
        log_info "Creating Redis cache..."
        
        az redis create \
            --resource-group "$AZURE_RESOURCE_GROUP" \
            --name "$CACHE_NAME" \
            --location "$AZURE_REGION" \
            --sku Basic \
            --vm-size c0 \
            --enable-non-ssl-port false \
            --subscription "$AZURE_SUBSCRIPTION"
        
        log_info "Redis cache created"
    fi
    
    # Get connection string
    REDIS_HOST=$(az redis show \
        --name "$CACHE_NAME" \
        --resource-group "$AZURE_RESOURCE_GROUP" \
        --subscription "$AZURE_SUBSCRIPTION" \
        --query "hostName" -o tsv)
    
    echo "$REDIS_HOST"
}

create_aks_cluster() {
    log_section "Creating AKS Cluster"
    
    if az aks show \
        --name "$CLUSTER_NAME" \
        --resource-group "$AZURE_RESOURCE_GROUP" \
        --subscription "$AZURE_SUBSCRIPTION" > /dev/null 2>&1; then
        log_info "AKS cluster already exists"
    else
        log_info "Creating AKS cluster..."
        
        az aks create \
            --resource-group "$AZURE_RESOURCE_GROUP" \
            --name "$CLUSTER_NAME" \
            --node-count 3 \
            --vm-set-type VirtualMachineScaleSets \
            --load-balancer-sku standard \
            --enable-managed-identity \
            --enable-addons monitoring \
            --monitoring-log-analytics-workspace-resource-id "/subscriptions/$AZURE_SUBSCRIPTION/resourceGroups/$AZURE_RESOURCE_GROUP/providers/Microsoft.OperationalInsights/workspaces/${CLUSTER_NAME}-workspace" \
            --attach-acr "$REGISTRY_NAME" \
            --network-policy azure \
            --enable-aad \
            --aad-server-app-id "your-server-app-id" \
            --aad-server-app-secret "your-server-app-secret" \
            --aad-tenant-id "your-tenant-id" \
            --subscription "$AZURE_SUBSCRIPTION"
        
        log_info "AKS cluster created"
    fi
    
    # Get cluster credentials
    az aks get-credentials \
        --resource-group "$AZURE_RESOURCE_GROUP" \
        --name "$CLUSTER_NAME" \
        --subscription "$AZURE_SUBSCRIPTION"
    
    log_info "Cluster credentials configured"
}

deploy_to_aks() {
    log_section "Deploying Application to AKS"
    
    IMAGE_NAME=$1
    DB_FQDN=$2
    REDIS_HOST=$3
    
    log_info "Creating namespace..."
    kubectl create namespace "$APP_NAME" 2>/dev/null || true
    
    log_info "Creating secrets..."
    kubectl create secret generic lscm-db-creds \
        --from-literal=username=lscm_user \
        --from-literal=password="$(openssl rand -base64 32)" \
        -n "$APP_NAME" \
        --dry-run=client -o yaml | kubectl apply -f -
    
    log_info "Creating deployment..."
    
    cat > /tmp/aks-deployment.yaml << EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: $APP_NAME-backend
  namespace: $APP_NAME
spec:
  replicas: 3
  selector:
    matchLabels:
      app: $APP_NAME-backend
  template:
    metadata:
      labels:
        app: $APP_NAME-backend
    spec:
      containers:
      - name: $APP_NAME-backend
        image: $IMAGE_NAME
        ports:
        - containerPort: 3000
        env:
        - name: NODE_ENV
          value: "production"
        - name: DATABASE_HOST
          value: "$DB_FQDN"
        - name: REDIS_HOST
          value: "$REDIS_HOST"
        envFrom:
        - secretRef:
            name: lscm-db-creds
        resources:
          requests:
            cpu: 500m
            memory: 512Mi
          limits:
            cpu: 1000m
            memory: 1024Mi
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 10
          periodSeconds: 5

---
apiVersion: v1
kind: Service
metadata:
  name: $APP_NAME-service
  namespace: $APP_NAME
spec:
  type: LoadBalancer
  selector:
    app: $APP_NAME-backend
  ports:
  - port: 80
    targetPort: 3000

---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: $APP_NAME-hpa
  namespace: $APP_NAME
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: $APP_NAME-backend
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
EOF
    
    kubectl apply -f /tmp/aks-deployment.yaml
    
    log_info "Waiting for deployment..."
    kubectl rollout status deployment/$APP_NAME-backend -n "$APP_NAME" --timeout=300s
    
    log_info "Deployment successful"
}

# ============================================================================
# MAIN
# ============================================================================

main() {
    clear
    
    echo -e "${GREEN}"
    cat << "EOF"
╔═══════════════════════════════════════════════════════════╗
║         LSCM ERP - AZURE DEPLOYMENT SCRIPT               ║
║    Complete deployment to Azure (AKS, DB, Redis)         ║
╚═══════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    
    echo ""
    echo "Azure Subscription: $AZURE_SUBSCRIPTION"
    echo "Region: $AZURE_REGION"
    echo ""
    
    log_section "Pre-Flight Checks"
    check_azure_cli
    
    create_resource_group
    create_container_registry
    IMAGE_NAME=$(build_and_push_image_acr)
    DB_FQDN=$(create_azure_database)
    REDIS_HOST=$(create_azure_cache)
    create_aks_cluster
    deploy_to_aks "$IMAGE_NAME" "$DB_FQDN" "$REDIS_HOST"
    
    log_section "Deployment Complete!"
    
    echo -e "${GREEN}✅ Azure deployment successful!${NC}"
    echo ""
    echo "Next steps:"
    echo "  1. Get service IP: kubectl get service -n $APP_NAME"
    echo "  2. Configure DNS"
    echo "  3. Monitor: https://portal.azure.com"
    echo ""
}

trap 'log_error "Deployment failed at line $LINENO"' ERR

main "$@"
