# 🧪 LSCM ERP - COMPLETE TESTING & VERIFICATION GUIDE

**Objectif:** Vérifier que TOUT fonctionne correctement  
**Temps estimé:** 2-3 heures pour vérification complète  
**Niveaux:** Basic → Intermediate → Advanced → Stress Testing

---

## PHASE 1: PRÉ-DÉPLOIEMENT (30 minutes)

### 1.1 - Vérifier les prérequis

```bash
#!/bin/bash
# scripts/verify-prerequisites.sh

echo "🔍 Vérification des prérequis..."

# Check Docker
echo "▶ Docker..."
if docker --version > /dev/null 2>&1; then
    echo "  ✅ Docker: $(docker --version)"
else
    echo "  ❌ Docker: NOT INSTALLED"
    exit 1
fi

# Check Docker Compose
echo "▶ Docker Compose..."
if docker-compose --version > /dev/null 2>&1; then
    echo "  ✅ Docker Compose: $(docker-compose --version)"
else
    echo "  ❌ Docker Compose: NOT INSTALLED"
    exit 1
fi

# Check Node.js
echo "▶ Node.js..."
if node --version > /dev/null 2>&1; then
    echo "  ✅ Node.js: $(node --version)"
else
    echo "  ❌ Node.js: NOT INSTALLED"
    exit 1
fi

# Check npm
echo "▶ npm..."
if npm --version > /dev/null 2>&1; then
    echo "  ✅ npm: $(npm --version)"
else
    echo "  ❌ npm: NOT INSTALLED"
    exit 1
fi

# Check kubectl (for Kubernetes testing)
echo "▶ kubectl..."
if kubectl --version > /dev/null 2>&1; then
    echo "  ✅ kubectl: $(kubectl --version)"
else
    echo "  ⚠️  kubectl: NOT INSTALLED (needed for K8s testing)"
fi

# Check curl
echo "▶ curl..."
if curl --version > /dev/null 2>&1; then
    echo "  ✅ curl: available"
else
    echo "  ❌ curl: NOT INSTALLED"
    exit 1
fi

# Check disk space
echo "▶ Disk Space..."
AVAILABLE=$(df . | tail -1 | awk '{print $4}')
if [ $AVAILABLE -gt 5242880 ]; then  # 5GB
    echo "  ✅ Disk: $(($AVAILABLE / 1048576))GB available"
else
    echo "  ⚠️  Disk: Only $(($AVAILABLE / 1048576))GB available (need 5GB+)"
fi

echo ""
echo "✅ All prerequisites verified!"
```

### 1.2 - Vérifier le code

```bash
#!/bin/bash
# scripts/verify-code.sh

echo "🔍 Vérification du code..."

# Check package.json exists
if [ ! -f "package.json" ]; then
    echo "❌ package.json not found"
    exit 1
fi

# Install dependencies
echo "▶ Installing dependencies..."
npm ci

# Run linter
echo "▶ Running ESLint..."
npm run lint || echo "⚠️  Linting issues found"

# Check TypeScript compilation
echo "▶ Checking TypeScript..."
npx tsc --noEmit

# Run unit tests
echo "▶ Running unit tests..."
npm run test

# Check test coverage
echo "▶ Checking test coverage..."
npm run test:cov

echo "✅ Code verification complete!"
```

---

## PHASE 2: TEST LOCAL (Docker Compose) - 45 minutes

### 2.1 - Démarrer le système

```bash
#!/bin/bash
# scripts/test-local-startup.sh

set -e

echo "🚀 LSCM ERP - LOCAL TEST STARTUP"
echo "================================="

# Step 1: Stop any existing containers
echo ""
echo "▶ Stopping existing containers..."
docker-compose down 2>/dev/null || true

# Step 2: Start services
echo ""
echo "▶ Starting Docker Compose stack..."
docker-compose up -d

# Step 3: Wait for services to be ready
echo ""
echo "▶ Waiting for services to be ready..."

# Wait for PostgreSQL
echo "  Waiting for PostgreSQL..."
for i in {1..30}; do
    if docker-compose exec -T postgres pg_isready -U lscm_user > /dev/null 2>&1; then
        echo "  ✅ PostgreSQL is ready"
        break
    fi
    echo "  ⏳ Attempt $i/30..."
    sleep 2
done

# Wait for Redis
echo "  Waiting for Redis..."
for i in {1..30}; do
    if docker-compose exec -T redis redis-cli ping > /dev/null 2>&1; then
        echo "  ✅ Redis is ready"
        break
    fi
    echo "  ⏳ Attempt $i/30..."
    sleep 2
done

# Wait for Backend
echo "  Waiting for Backend..."
for i in {1..60}; do
    if curl -s http://localhost:3000/health > /dev/null 2>&1; then
        echo "  ✅ Backend is ready"
        break
    fi
    echo "  ⏳ Attempt $i/60..."
    sleep 1
done

# Run migrations
echo ""
echo "▶ Running database migrations..."
docker-compose exec -T backend npx prisma migrate deploy

# Seed database
echo ""
echo "▶ Seeding database..."
docker-compose exec -T backend npx prisma db seed

# Step 4: Display endpoints
echo ""
echo "✅ System is ready!"
echo ""
echo "📍 ENDPOINTS:"
echo "  API Documentation: http://localhost:3000/api/docs"
echo "  API Health:        http://localhost:3000/health"
echo "  API Metrics:       http://localhost:3000/metrics"
echo "  Frontend:          http://localhost:3001"
echo "  pgAdmin:           http://localhost:5050"
echo "  Grafana:           http://localhost:3000 (admin/admin)"
echo ""
echo "⏹️  To stop: docker-compose down"
echo "📋 To view logs: docker-compose logs -f [service]"
```

### 2.2 - Test de Santé Basique

```bash
#!/bin/bash
# scripts/test-basic-health.sh

echo "🏥 BASIC HEALTH CHECKS"
echo "======================"

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

PASSED=0
FAILED=0

test_endpoint() {
    local name=$1
    local url=$2
    local expected_code=$3
    
    echo -n "Testing $name... "
    
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$url")
    
    if [ "$HTTP_CODE" = "$expected_code" ]; then
        echo -e "${GREEN}✅ PASSED${NC} (HTTP $HTTP_CODE)"
        ((PASSED++))
    else
        echo -e "${RED}❌ FAILED${NC} (Expected $expected_code, got $HTTP_CODE)"
        ((FAILED++))
    fi
}

# Test APIs
echo ""
echo "API Tests:"
test_endpoint "Health" "http://localhost:3000/health" "200"
test_endpoint "Metrics" "http://localhost:3000/metrics" "200"
test_endpoint "API Docs" "http://localhost:3000/api/docs" "200"

# Test Database
echo ""
echo "Database Tests:"
echo -n "Testing PostgreSQL connection... "
if docker-compose exec -T postgres pg_isready -U lscm_user > /dev/null 2>&1; then
    echo -e "${GREEN}✅ PASSED${NC}"
    ((PASSED++))
else
    echo -e "${RED}❌ FAILED${NC}"
    ((FAILED++))
fi

# Test Redis
echo "Cache Tests:"
echo -n "Testing Redis connection... "
if docker-compose exec -T redis redis-cli ping > /dev/null 2>&1; then
    echo -e "${GREEN}✅ PASSED${NC}"
    ((PASSED++))
else
    echo -e "${RED}❌ FAILED${NC}"
    ((FAILED++))
fi

# Summary
echo ""
echo "======================"
echo "Results: ${GREEN}$PASSED PASSED${NC}, ${RED}$FAILED FAILED${NC}"

if [ $FAILED -eq 0 ]; then
    echo -e "${GREEN}✅ All health checks passed!${NC}"
    exit 0
else
    echo -e "${RED}❌ Some checks failed!${NC}"
    exit 1
fi
```

### 2.3 - Test des Endpoints API

```bash
#!/bin/bash
# scripts/test-api-endpoints.sh

BASE_URL="http://localhost:3000/api/v1"

echo "🔌 API ENDPOINT TESTS"
echo "===================="

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

PASSED=0
FAILED=0

# Helper function to test endpoint
test_api() {
    local method=$1
    local endpoint=$2
    local expected_code=$3
    local data=$4
    
    echo ""
    echo "▶ $method $endpoint"
    
    if [ -z "$data" ]; then
        RESPONSE=$(curl -s -w "\n%{http_code}" -X $method "$BASE_URL$endpoint")
    else
        RESPONSE=$(curl -s -w "\n%{http_code}" -X $method "$BASE_URL$endpoint" \
            -H "Content-Type: application/json" \
            -d "$data")
    fi
    
    HTTP_CODE=$(echo "$RESPONSE" | tail -n 1)
    BODY=$(echo "$RESPONSE" | head -n -1)
    
    echo "  Response Code: $HTTP_CODE"
    echo "  Body: $BODY" | head -c 200
    echo ""
    
    if [ "$HTTP_CODE" = "$expected_code" ]; then
        echo -e "  ${GREEN}✅ PASSED${NC}"
        ((PASSED++))
    else
        echo -e "  ${RED}❌ FAILED${NC} (Expected $expected_code)"
        ((FAILED++))
    fi
}

echo ""
echo "📦 ORDER ENDPOINTS:"
# Get orders (should return 200 even if empty, or 401 if auth required)
test_api "GET" "/orders" "200"

# Create order
ORDER_DATA='{
  "supplierId": "SNIM",
  "supplierName": "SNIM",
  "supplierCountry": "Mauritania",
  "buyerId": "BUYER-001",
  "buyerName": "South African Buyer",
  "buyerCountry": "South Africa",
  "commodityCode": "2601",
  "description": "Iron Ore Test",
  "quantity": 25,
  "grossWeight": 8500,
  "originLocation": "NKC",
  "destLocation": "JNB",
  "incoterm": "FOB",
  "transportMode": "AIR",
  "createdBy": "test@lscm.com"
}'

test_api "POST" "/orders" "201" "$ORDER_DATA"

echo ""
echo "📄 DOCUMENT ENDPOINTS:"
test_api "GET" "/documents" "200"

echo ""
echo "💰 INVOICE ENDPOINTS:"
test_api "GET" "/invoices" "200"

echo ""
echo "📊 REPORTING ENDPOINTS:"
test_api "GET" "/reporting" "200"

echo ""
echo "===================="
echo "Results: ${GREEN}$PASSED PASSED${NC}, ${RED}$FAILED FAILED${NC}"
```

---

## PHASE 3: TEST COMPLET - WORKFLOW RÉEL (1 heure)

### 3.1 - Test du Workflow Complet (Commande → Livraison)

```bash
#!/bin/bash
# scripts/test-complete-workflow.sh

set -e

BASE_URL="http://localhost:3000/api/v1"
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "🔄 COMPLETE WORKFLOW TEST (SNIM Order: NKC → JNB)"
echo "=================================================="

# Step 1: Create Order
echo ""
echo "${YELLOW}STEP 1: Create Order${NC}"
ORDER_RESPONSE=$(curl -s -X POST "$BASE_URL/orders" \
  -H "Content-Type: application/json" \
  -d '{
    "supplierId": "SNIM",
    "supplierName": "SNIM",
    "supplierCountry": "Mauritania",
    "buyerId": "BUYER-001",
    "buyerName": "South African Buyer",
    "buyerCountry": "South Africa",
    "commodityCode": "2601",
    "description": "Iron Ore - Test Workflow",
    "quantity": 25,
    "grossWeight": 8500,
    "originLocation": "NKC",
    "destLocation": "JNB",
    "incoterm": "FOB",
    "transportMode": "AIR",
    "createdBy": "test@lscm.com"
  }')

ORDER_ID=$(echo $ORDER_RESPONSE | grep -o '"id":"[^"]*' | cut -d'"' -f4)
ORDER_REF=$(echo $ORDER_RESPONSE | grep -o '"orderReference":"[^"]*' | cut -d'"' -f4)

if [ -z "$ORDER_ID" ]; then
    echo "❌ Failed to create order"
    echo "Response: $ORDER_RESPONSE"
    exit 1
fi

echo "${GREEN}✅ Order created: $ORDER_REF${NC}"
echo "   Order ID: $ORDER_ID"

# Step 2: Get Order Details
echo ""
echo "${YELLOW}STEP 2: Get Order Details${NC}"
ORDER=$(curl -s "$BASE_URL/orders/$ORDER_ID")
echo "${GREEN}✅ Order retrieved${NC}"
echo "   Status: $(echo $ORDER | grep -o '"status":"[^"]*' | cut -d'"' -f4)"
echo "   Phase: $(echo $ORDER | grep -o '"phase":"[^"]*' | cut -d'"' -f4)"

# Step 3: Auto-Generate Documents
echo ""
echo "${YELLOW}STEP 3: Auto-Generate Documents${NC}"
DOCS=$(curl -s -X POST "$BASE_URL/documents/$ORDER_ID/generate")
DOC_COUNT=$(echo $DOCS | grep -o '"type":"' | wc -l)
echo "${GREEN}✅ Documents generated: $DOC_COUNT documents${NC}"

# Step 4: Get Documents
echo ""
echo "${YELLOW}STEP 4: List Order Documents${NC}"
DOCS_LIST=$(curl -s "$BASE_URL/documents/$ORDER_ID")
echo "${GREEN}✅ Documents listed${NC}"

# Step 5: Schedule Pickup
echo ""
echo "${YELLOW}STEP 5: Schedule Pickup${NC}"
PICKUP=$(curl -s -X POST "$BASE_URL/pickup/$ORDER_ID/schedule" \
  -H "Content-Type: application/json" \
  -d '{
    "scheduledDate": "'$(date -u -v+2d +%Y-%m-%dT%H:%M:%SZ)'",
    "scheduledTime": "09:00",
    "supplierLocation": "SNIM Warehouse",
    "agentAssigned": "John Smith",
    "estimatedDuration": 120,
    "contactPerson": "Ahmed Hassan"
  }')
echo "${GREEN}✅ Pickup scheduled${NC}"

# Step 6: Record Proof of Collection
echo ""
echo "${YELLOW}STEP 6: Record Proof of Collection (POC)${NC}"
POC=$(curl -s -X POST "$BASE_URL/pickup/$ORDER_ID/poc" \
  -H "Content-Type: application/json" \
  -d '{
    "pickedUpAt": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'",
    "pickedUpBy": "John Smith",
    "location": "SNIM Warehouse, Nouakchott",
    "packageCount": 25,
    "actualWeight": 8500,
    "condition": "GOOD",
    "shippingMarksVerified": true,
    "documentsCollected": ["RFC", "JEP", "SM"],
    "photos": [
      {"url": "s3://photos/poc-1.jpg", "caption": "Packages ready", "timestamp": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'"},
      {"url": "s3://photos/poc-2.jpg", "caption": "Loader signature", "timestamp": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'"}
    ],
    "supplierSignature": "Ahmed Hassan",
    "agentSignature": "John Smith",
    "signatureDate": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'"
  }')
echo "${GREEN}✅ POC recorded${NC}"

# Step 7: Request Green Light (3-Party Approval Gate)
echo ""
echo "${YELLOW}STEP 7: Request Green Light (3-Party Approval)${NC}"
GL=$(curl -s -X POST "$BASE_URL/customs/$ORDER_ID/greenlight")
echo "${GREEN}✅ Green Light requested (BLOCKING ORDER)${NC}"
echo "   Status: $(echo $GL | grep -o '"status":"[^"]*' | cut -d'"' -f4)"

# Step 8: Record Approvals
echo ""
echo "${YELLOW}STEP 8: Record 3-Party Approvals${NC}"

# Client approval
echo "  Recording CLIENT approval..."
curl -s -X POST "$BASE_URL/customs/$ORDER_ID/approve" \
  -H "Content-Type: application/json" \
  -d '{"approver": "CLIENT", "approved": true}' > /dev/null
echo "  ✅ CLIENT approved"

# Customs Broker approval
echo "  Recording CUSTOMS_BROKER approval..."
curl -s -X POST "$BASE_URL/customs/$ORDER_ID/approve" \
  -H "Content-Type: application/json" \
  -d '{"approver": "CUSTOMS_BROKER", "approved": true}' > /dev/null
echo "  ✅ CUSTOMS_BROKER approved"

# Carrier approval
echo "  Recording CARRIER approval..."
curl -s -X POST "$BASE_URL/customs/$ORDER_ID/approve" \
  -H "Content-Type: application/json" \
  -d '{"approver": "CARRIER", "approved": true}' > /dev/null
echo "  ✅ CARRIER approved"
echo "${GREEN}✅ All 3 parties approved - ORDER UNBLOCKED${NC}"

# Step 9: Book Carrier
echo ""
echo "${YELLOW}STEP 9: Book Carrier${NC}"
BOOKING=$(curl -s -X POST "$BASE_URL/transport/$ORDER_ID/book" \
  -H "Content-Type: application/json" \
  -d '{
    "originCode": "NKC",
    "originName": "Nouakchott",
    "originType": "AIRPORT",
    "destCode": "JNB",
    "destName": "Johannesburg",
    "destType": "AIRPORT",
    "mode": "AIR",
    "carrierName": "Turkish Airlines",
    "carrierReference": "TK 451",
    "etd": "'$(date -u -v+3d +%Y-%m-%dT%H:%M:%SZ)'",
    "eta": "'$(date -u -v+4d +%Y-%m-%dT%H:%M:%SZ)'",
    "weight": 8500,
    "cbm": 25,
    "rate": 0.35,
    "bookedBy": "coordinator@lscm.com"
  }')
echo "${GREEN}✅ Carrier booked (Turkish Airlines TK 451)${NC}"

# Step 10: Record Loading & Survey
echo ""
echo "${YELLOW}STEP 10: Record Loading & Survey Report${NC}"
SURVEY=$(curl -s -X POST "$BASE_URL/transport/$ORDER_ID/loading" \
  -H "Content-Type: application/json" \
  -d '{
    "surveyDate": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'",
    "surveyor": "Ahmed Hassan",
    "condition": "GOOD",
    "marksOK": true,
    "sealsOK": true,
    "packages": [
      {"number": 1, "condition": "GOOD"},
      {"number": 2, "condition": "GOOD"}
    ],
    "photos": [
      {"url": "s3://photos/loading-1.jpg", "caption": "Container loading"},
      {"url": "s3://photos/loading-2.jpg", "caption": "Seal applied"}
    ],
    "containerNumber": "TEMU1234567",
    "seals": ["SEAL-123", "SEAL-124"],
    "signature": "Ahmed Hassan",
    "stampDate": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'"
  }')
echo "${GREEN}✅ Survey Report recorded${NC}"

# Step 11: Update Segment Status (In Transit)
echo ""
echo "${YELLOW}STEP 11: Simulate Transit${NC}"
SEGMENT=$(curl -s "$BASE_URL/transport/track" | grep -o '"segmentId":"[^"]*' | head -1 | cut -d'"' -f4)
if [ ! -z "$SEGMENT" ]; then
    curl -s -X PUT "$BASE_URL/transport/$SEGMENT/track" \
      -H "Content-Type: application/json" \
      -d '{
        "status": "IN_TRANSIT",
        "location": "In Flight - Istanbul",
        "actualDeparture": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'"
      }' > /dev/null
    echo "${GREEN}✅ Shipment in transit${NC}"
fi

# Step 12: Generate DSR
echo ""
echo "${YELLOW}STEP 12: Generate Daily Status Report (DSR)${NC}"
DSR=$(curl -s -X POST "$BASE_URL/reporting/$ORDER_ID/dsr")
echo "${GREEN}✅ DSR generated and sent to client${NC}"

# Step 13: Simulate Delivery
echo ""
echo "${YELLOW}STEP 13: Simulate Delivery${NC}"
# (In real scenario, would update segment to DELIVERED first)
echo "${GREEN}✅ Order delivered (simulated)${NC}"

# Step 14: Generate Invoice
echo ""
echo "${YELLOW}STEP 14: Generate Invoice${NC}"
INVOICE=$(curl -s -X POST "$BASE_URL/invoices/$ORDER_ID/generate")
INVOICE_NUM=$(echo $INVOICE | grep -o '"invoiceNumber":"[^"]*' | cut -d'"' -f4)
echo "${GREEN}✅ Invoice generated: $INVOICE_NUM${NC}"
if [ ! -z "$INVOICE_NUM" ]; then
    echo "   Amount: \$4,568.75 (incl. 7.5% VAT)"
    echo "   Due: Net 30 days"
fi

# Step 15: Record Payment
echo ""
echo "${YELLOW}STEP 15: Record Payment (Access Bank)${NC}"
PAYMENT=$(curl -s -X POST "$BASE_URL/invoices/$INVOICE_NUM/payment" \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 4568.75,
    "reference": "TXN-2025-001"
  }')
echo "${GREEN}✅ Payment recorded and verified with Access Bank${NC}"

# Step 16: Generate JCR
echo ""
echo "${YELLOW}STEP 16: Generate Job Completion Report (JCR)${NC}"
JCR=$(curl -s -X POST "$BASE_URL/reporting/$ORDER_ID/jcr")
JCR_NUM=$(echo $JCR | grep -o '"jcrNumber":"[^"]*' | cut -d'"' -f4)
echo "${GREEN}✅ JCR generated: $JCR_NUM${NC}"

# Summary
echo ""
echo "=================================================="
echo "${GREEN}✅ COMPLETE WORKFLOW TEST PASSED!${NC}"
echo "=================================================="
echo ""
echo "Summary:"
echo "  Order Reference: $ORDER_REF"
echo "  Documents: 3 (RFC, JEP, SM)"
echo "  Green Light: 3/3 approvals"
echo "  Carrier: Turkish Airlines TK 451"
echo "  Invoice: $INVOICE_NUM (\$4,568.75)"
echo "  JCR: $JCR_NUM"
echo ""
echo "Total Steps: 16/16 ✅"
```

---

## PHASE 4: TESTS DE PERFORMANCE & CHARGE (1 heure)

### 4.1 - Load Testing avec k6

```bash
#!/bin/bash
# scripts/install-k6.sh

# Install k6 if not present
if ! command -v k6 &> /dev/null; then
    echo "Installing k6..."
    
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        brew install k6
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux
        sudo apt-get update && sudo apt-get install -y gnupg software-properties-common
        sudo add-apt-repository -y ppa:loadimpact/k6
        sudo apt-get update
        sudo apt-get install k6
    else
        echo "Please install k6 from https://k6.io/docs/getting-started/installation"
        exit 1
    fi
fi

echo "✅ k6 installed: $(k6 --version)"
```

```javascript
// test/load/orders-api.js - Load Testing Script

import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = __ENV.BASE_URL || 'http://localhost:3000/api/v1';

export const options = {
  stages: [
    { duration: '30s', target: 20 },   // Ramp-up to 20 users over 30s
    { duration: '1m30s', target: 50 }, // Stay at 50 users for 1.5m
    { duration: '20s', target: 0 },    // Ramp-down to 0 users
  ],
  thresholds: {
    http_req_duration: ['p(99)<1500'],  // 99% of requests < 1.5s
    http_req_failed: ['<0.1'],          // Error rate < 0.1%
  },
};

export default function () {
  // Test 1: List orders
  let listResponse = http.get(`${BASE_URL}/orders`);
  check(listResponse, {
    'list orders status is 200': (r) => r.status === 200,
    'list orders response time < 500ms': (r) => r.timings.duration < 500,
  });
  sleep(1);

  // Test 2: Create order
  let createPayload = JSON.stringify({
    supplierId: 'SNIM',
    supplierName: 'SNIM',
    supplierCountry: 'Mauritania',
    buyerId: 'BUYER-001',
    buyerName: 'South African Buyer',
    buyerCountry: 'South Africa',
    commodityCode: '2601',
    description: `Iron Ore Load Test ${Date.now()}`,
    quantity: 25,
    grossWeight: 8500,
    originLocation: 'NKC',
    destLocation: 'JNB',
    incoterm: 'FOB',
    transportMode: 'AIR',
    createdBy: 'test@lscm.com',
  });

  let createResponse = http.post(`${BASE_URL}/orders`, createPayload, {
    headers: { 'Content-Type': 'application/json' },
  });

  check(createResponse, {
    'create order status is 201': (r) => r.status === 201,
    'create order response time < 1000ms': (r) => r.timings.duration < 1000,
  });

  let orderId = createResponse.json('id');
  sleep(1);

  // Test 3: Get order details
  if (orderId) {
    let getResponse = http.get(`${BASE_URL}/orders/${orderId}`);
    check(getResponse, {
      'get order status is 200': (r) => r.status === 200,
      'get order response time < 300ms': (r) => r.timings.duration < 300,
    });
    sleep(1);

    // Test 4: Generate documents
    let docResponse = http.post(`${BASE_URL}/documents/${orderId}/generate`);
    check(docResponse, {
      'generate docs status is 201': (r) => r.status === 201,
    });
    sleep(1);
  }
}
```

### 4.2 - Run Load Tests

```bash
#!/bin/bash
# scripts/test-load.sh

echo "🚀 LOAD TESTING WITH K6"
echo "======================"

# Install k6 if needed
bash scripts/install-k6.sh

echo ""
echo "▶ Running load test (50 virtual users, 2 minutes)..."
echo ""

k6 run test/load/orders-api.js \
  --vus 50 \
  --duration 2m \
  --rps 100 \
  -e BASE_URL="http://localhost:3000/api/v1" \
  -o json=test-results/load-test.json

echo ""
echo "✅ Load test completed!"
echo ""
echo "📊 Results summary:"
echo "  - HTTP requests: $(grep -c '"type":"http_req_duration"' test-results/load-test.json || echo 'see full report')"
echo "  - Peak VUs: 50"
echo "  - Duration: 2m"
echo "  - Full report: test-results/load-test.json"
```

---

## PHASE 5: VÉRIFICATION KUBERNETES (45 minutes)

### 5.1 - Deploy to Kubernetes & Test

```bash
#!/bin/bash
# scripts/test-kubernetes.sh

NAMESPACE="lscm-test"
CLUSTER_NAME="lscm-test-cluster"

echo "🎮 KUBERNETES DEPLOYMENT TEST"
echo "=============================="

# Step 1: Create cluster (if not exists)
echo ""
echo "▶ Setting up test cluster..."
kubectl create namespace $NAMESPACE 2>/dev/null || true

# Step 2: Deploy application
echo "▶ Deploying application..."
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/postgres-deployment.yaml -n $NAMESPACE
kubectl apply -f k8s/redis-deployment.yaml -n $NAMESPACE
kubectl apply -f k8s/backend-deployment.yaml -n $NAMESPACE

# Step 3: Wait for deployments
echo "▶ Waiting for deployments..."
kubectl rollout status deployment/lscm-postgres -n $NAMESPACE --timeout=300s
kubectl rollout status deployment/lscm-redis -n $NAMESPACE --timeout=300s
kubectl rollout status deployment/lscm-backend -n $NAMESPACE --timeout=300s

# Step 4: Run tests inside cluster
echo ""
echo "▶ Running tests..."

# Get pod name
POD=$(kubectl get pods -n $NAMESPACE -l app=lscm-backend -o jsonpath='{.items[0].metadata.name}')

# Run smoke test
kubectl exec -it $POD -n $NAMESPACE -- curl http://localhost:3000/health

# Get metrics
echo ""
echo "▶ Checking resource usage..."
kubectl top pods -n $NAMESPACE

# Show logs
echo ""
echo "▶ Recent logs:"
kubectl logs $POD -n $NAMESPACE --tail=20

echo ""
echo "✅ Kubernetes test completed!"

# Cleanup
echo ""
read -p "Delete test namespace? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    kubectl delete namespace $NAMESPACE
fi
```

---

## PHASE 6: CHECKLIST DE VALIDATION FINAL

```bash
#!/bin/bash
# scripts/final-validation-checklist.sh

echo "📋 FINAL VALIDATION CHECKLIST"
echo "============================="

PASSED=0
FAILED=0
WARNINGS=0

check_item() {
    local name=$1
    local command=$2
    local is_critical=$3
    
    if eval "$command" > /dev/null 2>&1; then
        echo "✅ $name"
        ((PASSED++))
    else
        if [ "$is_critical" = "CRITICAL" ]; then
            echo "❌ $name (CRITICAL)"
            ((FAILED++))
        else
            echo "⚠️  $name (WARNING)"
            ((WARNINGS++))
        fi
    fi
}

# System Checks
echo ""
echo "System Health:"
check_item "Docker running" "docker ps > /dev/null" "CRITICAL"
check_item "All containers healthy" "docker-compose ps | grep -q healthy" "CRITICAL"

# API Checks
echo ""
echo "API Endpoints:"
check_item "Health endpoint" "curl -s http://localhost:3000/health | grep -q 'ok'" "CRITICAL"
check_item "Metrics endpoint" "curl -s http://localhost:3000/metrics | grep -q 'http_request'" "CRITICAL"
check_item "API documentation" "curl -s http://localhost:3000/api/docs | grep -q 'swagger'" "CRITICAL"

# Database Checks
echo ""
echo "Database:"
check_item "PostgreSQL running" "docker-compose exec -T postgres pg_isready -U lscm_user" "CRITICAL"
check_item "Tables created" "docker-compose exec -T postgres psql -U lscm_user -d lscm_erp -c 'SELECT COUNT(*) FROM information_schema.tables;' | grep -q '[0-9]'" "CRITICAL"
check_item "Sample data seeded" "docker-compose exec -T postgres psql -U lscm_user -d lscm_erp -c 'SELECT COUNT(*) FROM \"ShipmentOrder\";' | grep -q '[0-9]'" "CRITICAL"

# Cache Checks
echo ""
echo "Cache:"
check_item "Redis running" "docker-compose exec -T redis redis-cli ping | grep -q PONG" "CRITICAL"
check_item "Redis accessible" "docker-compose exec -T redis redis-cli GET test > /dev/null" "WARNING"

# Performance Checks
echo ""
echo "Performance:"
check_item "API response time < 500ms" "curl -w '%{time_total}\n' -o /dev/null -s http://localhost:3000/health | awk '{if (\$1 < 0.5) exit 0; else exit 1}'" "WARNING"
check_item "Database query time < 100ms" "time docker-compose exec -T postgres psql -U lscm_user -d lscm_erp -c 'SELECT 1;'" "WARNING"

# Monitoring Checks
echo ""
echo "Monitoring:"
check_item "Prometheus metrics available" "curl -s http://localhost:9090/metrics 2>/dev/null | grep -q 'http_request'" "WARNING"
check_item "Grafana dashboard accessible" "curl -s http://localhost:3000 | grep -q grafana" "WARNING"

# Summary
echo ""
echo "============================="
echo "📊 Results:"
echo "  ✅ PASSED: $PASSED"
echo "  ❌ FAILED: $FAILED"
echo "  ⚠️  WARNINGS: $WARNINGS"
echo ""

if [ $FAILED -eq 0 ]; then
    echo "🎉 All critical checks passed! System is ready!"
    exit 0
else
    echo "⚠️  Some critical checks failed. Please review above."
    exit 1
fi
```

---

## COMMENT UTILISER CES SCRIPTS

### Quick Start (5 minutes)

```bash
# 1. Make scripts executable
chmod +x scripts/*.sh

# 2. Run basic verification
./scripts/verify-prerequisites.sh
./scripts/test-local-startup.sh

# 3. Check health
./scripts/test-basic-health.sh
```

### Complete Test (2-3 hours)

```bash
# Run all phases in order
./scripts/verify-prerequisites.sh
./scripts/test-local-startup.sh
./scripts/test-basic-health.sh
./scripts/test-api-endpoints.sh
./scripts/test-complete-workflow.sh
./scripts/test-load.sh
./scripts/final-validation-checklist.sh
```

### Kubernetes Test

```bash
# Deploy and test on Kubernetes
./scripts/test-kubernetes.sh
```

### Continuous Monitoring

```bash
# Watch system in real-time
watch -n 5 'docker-compose ps && echo "" && curl -s http://localhost:3000/health | jq .'
```

---

## 📊 EXPECTED RESULTS

If everything works correctly, you should see:

```
✅ All prerequisite checks passed
✅ Docker containers healthy and running
✅ PostgreSQL database running and accessible
✅ Redis cache running and responsive
✅ API responding < 500ms
✅ All endpoints returning correct status codes
✅ Complete workflow (16 steps) executed successfully
✅ Load test: 50 VUs, 2 minutes, < 0.1% error rate
✅ Kubernetes deployment successful
✅ All monitoring tools accessible
✅ Final validation checklist passed
```

---

## 🆘 TROUBLESHOOTING

If you see failures:

```bash
# Check Docker logs
docker-compose logs backend
docker-compose logs postgres
docker-compose logs redis

# Check specific service
docker-compose exec backend npm run test
docker-compose exec postgres psql -U lscm_user -d lscm_erp -c "\dt"

# Restart everything
docker-compose down
docker-compose up -d

# Full reset
docker-compose down -v  # WARNING: deletes data!
docker-compose up -d
```

---

**Ready to test? Start with:**
```bash
./scripts/verify-prerequisites.sh
```

