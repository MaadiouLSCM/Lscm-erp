#!/bin/bash
# digitalocean/deploy-to-digitalocean.sh - Complete DigitalOcean Deployment

set -e

DIGITALOCEAN_TOKEN=${DIGITALOCEAN_TOKEN:-"your-do-token"}
CLUSTER_NAME="lscm-erp-cluster"
REGION="nyc3"
NODE_COUNT=3
NODE_SIZE="s-2vcpu-4gb"
APP_NAME="lscm-erp"
DOMAIN="lscm-erp.com"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_section() {
    echo ""
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}║ $1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
}

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_doctl() {
    if ! command -v doctl &> /dev/null; then
        log_error "doctl not installed. Install from: https://github.com/digitalocean/doctl"
        exit 1
    fi
    
    if [ -z "$DIGITALOCEAN_TOKEN" ]; then
        log_error "DIGITALOCEAN_TOKEN not set"
        exit 1
    fi
    
    log_info "DigitalOcean CLI authenticated"
}

create_doks_cluster() {
    log_section "Creating DigitalOcean Kubernetes Cluster"
    
    if doctl kubernetes cluster get "$CLUSTER_NAME" > /dev/null 2>&1; then
        log_info "DOKS cluster already exists"
    else
        log_info "Creating DOKS cluster (takes ~10 minutes)..."
        
        doctl kubernetes cluster create "$CLUSTER_NAME" \
            --region "$REGION" \
            --version latest \
            --node-pool "name=default;size=$NODE_SIZE;count=$NODE_COUNT;auto-scale=true;min-nodes=1;max-nodes=10" \
            --enable-surge-upgrade=true \
            --enable-monitoring=true \
            --maintenance-window "day=monday;start_hour=01" \
            --wait
        
        log_info "DOKS cluster created"
    fi
    
    # Get kubeconfig
    log_info "Downloading kubeconfig..."
    doctl kubernetes cluster kubeconfig save "$CLUSTER_NAME"
    
    log_info "Cluster credentials configured"
}

create_database() {
    log_section "Creating Managed Database (PostgreSQL)"
    
    DB_NAME="$APP_NAME-postgres"
    
    if doctl databases list | grep -q "$DB_NAME"; then
        log_info "Managed database already exists"
    else
        log_info "Creating managed PostgreSQL database..."
        
        doctl databases create "$DB_NAME" \
            --engine pg \
            --version 15 \
            --region "$REGION" \
            --num-nodes 1 \
            --size db-s-1vcpu-1gb \
            --wait
        
        log_info "Managed database created"
    fi
    
    # Get connection details
    DB_ID=$(doctl databases list --format ID,Name --no-header | grep "$DB_NAME" | awk '{print $1}')
    
    doctl databases get "$DB_ID" --format Host,Port,Username --no-header
}

create_redis_cluster() {
    log_section "Creating Managed Redis Cluster"
    
    REDIS_NAME="$APP_NAME-redis"
    
    if doctl databases list | grep -q "$REDIS_NAME"; then
        log_info "Managed Redis cluster already exists"
    else
        log_info "Creating managed Redis cluster..."
        
        doctl databases create "$REDIS_NAME" \
            --engine redis \
            --region "$REGION" \
            --num-nodes 1 \
            --size db-s-1vcpu-1gb \
            --wait
        
        log_info "Managed Redis cluster created"
    fi
}

push_to_registry() {
    log_section "Pushing Docker Image to DigitalOcean Container Registry"
    
    REGISTRY_NAME="lscm"
    REGISTRY_DOMAIN="${REGISTRY_NAME}.ondigitalocean.com"
    
    # Create registry if not exists
    if ! doctl registry get "$REGISTRY_NAME" > /dev/null 2>&1; then
        log_info "Creating container registry..."
        doctl registry create "$REGISTRY_NAME"
    fi
    
    # Login to registry
    log_info "Logging into DigitalOcean registry..."
    doctl registry login
    
    # Push image
    IMAGE="${REGISTRY_DOMAIN}/${APP_NAME}:latest"
    docker tag "$APP_NAME:latest" "$IMAGE"
    docker push "$IMAGE"
    
    echo "$IMAGE"
}

deploy_to_doks() {
    log_section "Deploying to DOKS Cluster"
    
    IMAGE=$1
    
    # Create namespace
    kubectl create namespace "$APP_NAME" 2>/dev/null || true
    
    # Create secrets
    kubectl create secret generic lscm-secrets \
        --from-literal=db-password="$(openssl rand -base64 32)" \
        --from-literal=jwt-secret="$(openssl rand -base64 32)" \
        -n "$APP_NAME" \
        --dry-run=client -o yaml | kubectl apply -f -
    
    # Create deployment
    cat > /tmp/doks-deployment.yaml << EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: $APP_NAME-backend
  namespace: $APP_NAME
spec:
  replicas: 3
  selector:
    matchLabels:
      app: $APP_NAME-backend
  template:
    metadata:
      labels:
        app: $APP_NAME-backend
    spec:
      containers:
      - name: $APP_NAME-backend
        image: $IMAGE
        ports:
        - containerPort: 3000
        env:
        - name: NODE_ENV
          value: "production"
        envFrom:
        - secretRef:
            name: lscm-secrets
        resources:
          requests:
            cpu: 250m
            memory: 256Mi
          limits:
            cpu: 500m
            memory: 512Mi
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 10
          periodSeconds: 5

---
apiVersion: v1
kind: Service
metadata:
  name: $APP_NAME-service
  namespace: $APP_NAME
  annotations:
    service.beta.kubernetes.io/do-loadbalancer-enable-proxy-protocol: "false"
    service.beta.kubernetes.io/do-loadbalancer-disable-lets-encrypt-dns-checks: "false"
spec:
  type: LoadBalancer
  selector:
    app: $APP_NAME-backend
  ports:
  - port: 80
    targetPort: 3000
    protocol: TCP

---
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: admin@$DOMAIN
    privateKeySecretRef:
      name: letsencrypt-prod
    solvers:
    - http01:
        ingress:
          class: nginx

---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: $APP_NAME-ingress
  namespace: $APP_NAME
  annotations:
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
    kubernetes.io/ingress.class: "nginx"
spec:
  tls:
  - hosts:
    - api.$DOMAIN
    secretName: $APP_NAME-tls
  rules:
  - host: api.$DOMAIN
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: $APP_NAME-service
            port:
              number: 80

---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: $APP_NAME-hpa
  namespace: $APP_NAME
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: $APP_NAME-backend
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
EOF
    
    kubectl apply -f /tmp/doks-deployment.yaml
    
    log_info "Waiting for deployment..."
    kubectl rollout status deployment/$APP_NAME-backend -n "$APP_NAME" --timeout=300s
    
    log_info "Deployment successful"
}

setup_spaces_storage() {
    log_section "Setting up DigitalOcean Spaces for Document Storage"
    
    SPACE_NAME="lscm-erp-docs"
    
    log_info "Creating Spaces bucket..."
    
    doctl compute cdn create \
        --origin "$SPACE_NAME.nyc3.digitaloceanspaces.com" \
        --certificate-id "" 2>/dev/null || true
    
    log_info "Spaces bucket configured"
}

# Main
main() {
    clear
    
    echo -e "${GREEN}"
    cat << "EOF"
╔═══════════════════════════════════════════════════════════╗
║      LSCM ERP - DIGITALOCEAN DEPLOYMENT SCRIPT           ║
║     Complete deployment to DigitalOcean (DOKS)           ║
╚═══════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}"
    
    echo ""
    echo "Cluster: $CLUSTER_NAME"
    echo "Region: $REGION"
    echo "Domain: $DOMAIN"
    echo ""
    
    log_section "Pre-Flight Checks"
    check_doctl
    
    create_doks_cluster
    create_database
    create_redis_cluster
    IMAGE=$(push_to_registry)
    deploy_to_doks "$IMAGE"
    setup_spaces_storage
    
    log_section "Deployment Complete!"
    
    echo -e "${GREEN}✅ DigitalOcean deployment successful!${NC}"
    echo ""
    echo "Next steps:"
    echo "  1. Get service IP: kubectl get service -n $APP_NAME"
    echo "  2. Point DNS api.$DOMAIN to LoadBalancer IP"
    echo "  3. Monitor: doctl kubernetes cluster get $CLUSTER_NAME"
    echo "  4. Logs: kubectl logs -n $APP_NAME -f deployment/$APP_NAME-backend"
    echo ""
}

trap 'log_error "Deployment failed"' ERR

main "$@"
